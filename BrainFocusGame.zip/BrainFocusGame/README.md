# Brain Focus Game

A focus-training grid game built in **Kotlin + Jetpack Compose**.

## Gameplay (matches your spec)
1. A **5 × 6 grid (30 boxes)** is generated, each box showing a number and a distinct, randomly-generated color.
2. Numbers **1–30 are shuffled** into random positions (never sorted in order).
3. Tap a box only when it's the **next number in sequence** (start with 1). Tapping the wrong number gives a brief red flash and is ignored — no penalty, just try again.
4. Hit the **refresh icon** (top-right) any time to reshuffle both the **number positions and every box's color**, and reset the timer.
5. A **timer** starts the instant you tap "1" and stops the instant you tap "30". Your best time is saved locally on the device and shown alongside the current run.

Color theme: **"Vibrant Focus"** — a dark navy/indigo background (`#121218`) with each grid box colored from an evenly-spaced, randomized point on the full color wheel every time the board refreshes, so all 30 boxes look visually distinct. Text color (black/white) auto-adjusts per box for readability.

## Project structure
```
BrainFocusGame/
├── app/
│   ├── build.gradle.kts          # App module config (Compose, min/target SDK)
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/brainfocus/game/
│       │   ├── MainActivity.kt           # Entry point, applies theme
│       │   └── ui/
│       │       ├── GridGameScreen.kt     # All game logic + UI (the core feature)
│       │       └── theme/                # Color.kt, Theme.kt, Type.kt
│       └── res/
│           ├── drawable/                 # Adaptive icon layers
│           ├── mipmap-anydpi-v26/        # Adaptive launcher icon
│           └── values/                   # strings.xml, colors.xml, themes.xml
├── build.gradle.kts               # Root Gradle config
├── settings.gradle.kts
└── gradle.properties
```

## How to build the APK
This zip contains the **source project only** (no compiled Gradle wrapper jar, since it's a binary file). To build:

### Option A — Android Studio (recommended, easiest)
1. Extract the zip.
2. Open Android Studio → **Open** → select the extracted `BrainFocusGame` folder.
3. Let Gradle sync (Android Studio will auto-generate the wrapper and download dependencies — needs internet).
4. Build → **Build APK(s)**, or Run ▶ on a device/emulator.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

### Option B — Command line (if you have Gradle installed)
```bash
cd BrainFocusGame
gradle wrapper          # generates gradlew/gradlew.bat + wrapper jar
./gradlew assembleDebug # builds app/build/outputs/apk/debug/app-debug.apk
```

## Requirements
- Android Studio Hedgehog+ (or Gradle 8.6 / AGP 8.4 / Kotlin 1.9.24 if building manually)
- minSdk 24 (Android 7.0+), targetSdk 34
