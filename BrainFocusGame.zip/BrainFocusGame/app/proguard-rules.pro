# Add project specific ProGuard rules here.
-keep class com.brainfocus.game.data.** { *; }
