package com.brainfocus.game.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.brainfocus.game.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val COLUMNS = 5
private const val ROWS = 6
private const val TOTAL_BOXES = COLUMNS * ROWS // 30

private data class GridBox(val number: Int, val color: Color)

private fun shuffledNumbers(): List<Int> = (1..TOTAL_BOXES).shuffled()

private fun freshColors(): List<Color> {
    val hueStep = 360f / TOTAL_BOXES
    return (0 until TOTAL_BOXES).map { i ->
        val hue = (i * hueStep + (0..359).random()) % 360f
        Color.hsv(hue = hue, saturation = 0.65f, value = 0.85f)
    }.shuffled()
}

private fun buildGrid(): List<GridBox> {
    val numbers = shuffledNumbers()
    val colors = freshColors()
    return numbers.indices.map { i -> GridBox(number = numbers[i], color = colors[i]) }
}

private fun bestTimeKey() = "best_time_ms"

private fun getBestTime(context: Context): Long? {
    val prefs = context.getSharedPreferences("brain_focus_grid", Context.MODE_PRIVATE)
    return if (prefs.contains(bestTimeKey())) prefs.getLong(bestTimeKey(), 0L) else null
}

private fun saveBestTime(context: Context, timeMs: Long) {
    context.getSharedPreferences("brain_focus_grid", Context.MODE_PRIVATE)
        .edit().putLong(bestTimeKey(), timeMs).apply()
}

private fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000.0
    val minutes = (totalSeconds / 60).toInt()
    val seconds = totalSeconds % 60
    return if (minutes > 0) String.format("%d:%05.2f", minutes, seconds)
    else String.format("%.2fs", seconds)
}

/** Plays a short high-pitched beep using SoundPool tone generation. */
private fun playBeep(context: Context) {
    try {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioManager.playSoundEffect(AudioManager.FX_KEY_CLICK, 1.0f)
        } else {
            audioManager.playSoundEffect(AudioManager.FX_KEY_CLICK)
        }
    } catch (_: Exception) {}
}

/** Vibrates the device for a short error buzz. */
private fun vibrateError(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            val vibrator = vm.defaultVibrator
            vibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 80, 60, 80), -1)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 80, 60, 80), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 80, 60, 80), -1)
            }
        }
    } catch (_: Exception) {}
}

// ── Celebration particle data ──────────────────────────────────────────────
private data class Particle(
    val x: Float,          // 0..1 relative horizontal start position
    val color: Color,
    val size: Float,       // dp
    val durationMs: Int,
    val horizontalDrift: Float  // how far it drifts sideways (dp)
)

private val celebrationColors = listOf(
    Color(0xFFFFD700), Color(0xFFFF6B6B), Color(0xFF6C63FF),
    Color(0xFF00E5C7), Color(0xFFFF9F43), Color(0xFF4CD97B),
    Color(0xFFFF78C4), Color(0xFFFFFFFF)
)

private fun makeParticles(count: Int = 40): List<Particle> =
    (0 until count).map {
        Particle(
            x = (0..100).random() / 100f,
            color = celebrationColors.random(),
            size = (6..14).random().toFloat(),
            durationMs = (900..1600).random(),
            horizontalDrift = ((-60)..(60)).random().toFloat()
        )
    }

@Composable
private fun CelebrationOverlay(visible: Boolean) {
    if (!visible) return
    val particles = remember { makeParticles(50) }

    Box(modifier = Modifier.fillMaxSize()) {
        particles.forEach { p ->
            val infiniteTransition = rememberInfiniteTransition(label = "particle")
            val progress by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(p.durationMs, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "progress"
            )
            val alpha = (1f - progress).coerceIn(0f, 1f)
            val yOffset = progress * 800f   // falls 800dp
            val xOffset = p.x * 400f + p.horizontalDrift * progress

            Box(
                modifier = Modifier
                    .offset(x = xOffset.dp, y = yOffset.dp)
                    .size(p.size.dp)
                    .graphicsLayer { this.alpha = alpha }
                    .background(p.color, CircleShape)
            )
        }

        // Big centre "NEW BEST!" text
        val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
            initialValue = 0.85f, targetValue = 1.15f,
            animationSpec = infiniteRepeatable(
                tween(500), RepeatMode.Reverse
            ), label = "scale"
        )
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "🏆 NEW BEST! 🏆",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = WarningAmber,
                textAlign = TextAlign.Center,
                modifier = Modifier.scale(pulse)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "Amazing! You beat your record!",
                fontSize = 15.sp,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun GridGameScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var grid by remember { mutableStateOf(buildGrid()) }
    var nextExpected by remember { mutableIntStateOf(1) }
    var isRunning by remember { mutableStateOf(false) }
    var isComplete by remember { mutableStateOf(false) }
    var startTimeMs by remember { mutableLongStateOf(0L) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var wrongTapNumber by remember { mutableStateOf<Int?>(null) }
    var newBest by remember { mutableStateOf(false) }
    var showCelebration by remember { mutableStateOf(false) }
    var bestTime by remember { mutableStateOf(getBestTime(context)) }

    fun resetGame() {
        grid = buildGrid()
        nextExpected = 1
        isRunning = false
        isComplete = false
        elapsedMs = 0L
        wrongTapNumber = null
        newBest = false
        showCelebration = false
    }

    // Timer tick
    LaunchedEffect(isRunning) {
        while (isRunning) {
            elapsedMs = System.currentTimeMillis() - startTimeMs
            delay(31)
        }
    }

    // Brief red flash on wrong tap
    LaunchedEffect(wrongTapNumber) {
        if (wrongTapNumber != null) {
            delay(280)
            wrongTapNumber = null
        }
    }

    // Auto-dismiss celebration after 3.5s
    LaunchedEffect(showCelebration) {
        if (showCelebration) {
            delay(3500)
            showCelebration = false
        }
    }

    fun onBoxTap(number: Int) {
        if (isComplete) return
        if (number == nextExpected) {
            // ── correct tap: beep ──
            playBeep(context)

            if (!isRunning && nextExpected == 1) {
                isRunning = true
                startTimeMs = System.currentTimeMillis()
            }
            if (nextExpected == TOTAL_BOXES) {
                elapsedMs = System.currentTimeMillis() - startTimeMs
                isRunning = false
                isComplete = true
                val prevBest = bestTime
                if (prevBest == null || elapsedMs < prevBest) {
                    newBest = true
                    showCelebration = true
                    bestTime = elapsedMs
                    saveBestTime(context, elapsedMs)
                }
            }
            nextExpected++
        } else {
            // ── wrong tap: beep + vibrate ──
            playBeep(context)
            vibrateError(context)
            wrongTapNumber = number
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ── Main content pushed down slightly (Change 1: top padding 48dp instead of 20dp) ──
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .padding(top = 48.dp, bottom = 20.dp)   // ← moved down here
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Brain Focus Game",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (isComplete) "Find them all again — refresh for a new board"
                        else "Tap 1 → $TOTAL_BOXES in order, as fast as you can",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                IconButton(onClick = { resetGame() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh grid", tint = TealAccent)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TimerChip(label = "Time", value = formatTime(elapsedMs))
                // Change 2: "Best" label → "Best Time"
                TimerChip(label = "Best Time", value = bestTime?.let { formatTime(it) } ?: "—")
                TimerChip(
                    label = "Next",
                    value = if (isComplete) "Done!" else "$nextExpected"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isComplete) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SuccessGreen.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (newBest) "New best! ${formatTime(elapsedMs)} 🎉"
                            else "Finished in ${formatTime(elapsedMs)}",
                            color = SuccessGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = { resetGame() }) {
                            Text("Play Again", color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(COLUMNS),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(grid.size) { index ->
                    val box = grid[index]
                    val isFlashingWrong = wrongTapNumber == box.number
                    val isFound = box.number < nextExpected

                    val boxColor = when {
                        isFlashingWrong -> ErrorRed
                        isFound -> box.color.copy(alpha = 0.25f)
                        else -> box.color
                    }
                    val textColor = if (isFound) TextSecondary else bestTextColorFor(boxColor)

                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .graphicsLayer { alpha = if (isFound) 0.85f else 1f }
                            .clickable(enabled = !isFound) { onBoxTap(box.number) }
                            .background(color = boxColor, shape = RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${box.number}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }
                }
            }
        }

        // Change 5: Celebration overlay on top of everything when new best is set
        CelebrationOverlay(visible = showCelebration)
    }
}

private fun bestTextColorFor(background: Color): Color =
    if (background.luminance() > 0.5f) Color.Black else Color.White

@Composable
private fun TimerChip(label: String, value: String) {
    Surface(shape = RoundedCornerShape(12.dp), color = SurfaceDark) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.titleMedium, color = TealAccent, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
    }
}
