package com.brainfocus.game.ui.theme

import androidx.compose.ui.graphics.Color

// "Deep Focus" theme
val DeepNavy = Color(0xFF121218)
val SurfaceDark = Color(0xFF1E1E2A)
val SurfaceVariantDark = Color(0xFF2A2A3A)
val IndigoPrimary = Color(0xFF6C63FF)
val IndigoLight = Color(0xFF9A93FF)
val TealAccent = Color(0xFF00E5C7)
val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFFA0A0B2)
val ErrorRed = Color(0xFFFF6B6B)
val SuccessGreen = Color(0xFF4CD97B)
val WarningAmber = Color(0xFFFFC857)
