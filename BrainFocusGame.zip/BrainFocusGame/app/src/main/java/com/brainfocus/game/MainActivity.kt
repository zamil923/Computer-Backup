package com.brainfocus.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.brainfocus.game.ui.GridGameScreen
import com.brainfocus.game.ui.theme.BrainFocusGameTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BrainFocusApp()
        }
    }
}

@Composable
fun BrainFocusApp() {
    BrainFocusGameTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            GridGameScreen()
        }
    }
}
