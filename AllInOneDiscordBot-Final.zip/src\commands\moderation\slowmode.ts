import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';
import { Formatters } from '../../utils/formatters.js';

export const slowmodeCommand: Command = {
  name: 'slowmode',
  description: 'Set channel slowmode rate limit per user',
  category: 'Moderation',
  usage: 'slowmode <seconds|duration: 5s, 1m, 0 to disable> [reason]',
  examples: ['/slowmode seconds:10', '/slowmode seconds:0', '^slowmode 30s', '^slowmode 0'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.ManageChannels],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set channel slowmode rate limit per user')
    .addStringOption(opt =>
      opt.setName('duration').setDescription('Seconds or duration like 10s, 1m, or 0 to turn off').setRequired(true)
    )
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for slowmode change').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member || !ctx.channel || !ctx.channel.isTextBased()) return;

    const durationStr = ctx.getString('duration', true) || '0';
    const reason = ctx.getString('reason') || 'No reason provided';

    let seconds = 0;
    if (durationStr === '0' || durationStr.toLowerCase() === 'off') {
      seconds = 0;
    } else {
      const parsed = Formatters.parseDuration(durationStr);
      seconds = parsed !== null ? parsed : parseInt(durationStr, 10) || 0;
    }

    await ctx.defer();
    const result = await ModerationService.slowmode(ctx.channel as TextChannel, seconds, ctx.member, reason);
    await ctx.editReply(result.message);
  },
};
