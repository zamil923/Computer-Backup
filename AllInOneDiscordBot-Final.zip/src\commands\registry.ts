import { Collection, RESTPostAPIChatInputApplicationCommandsJSONBody } from 'discord.js';
import { Command, CommandCategory } from '../types/command.js';
import { logger } from '../utils/logger.js';

export class CommandRegistry {
  private static commands = new Collection<string, Command>();
  private static categories = new Map<CommandCategory, Command[]>();

  /**
   * Register a new command into the system
   */
  public static register(command: Command): void {
    if (this.commands.has(command.name)) {
      logger.warn('CommandRegistry', `Overwriting already registered command: ${command.name}`);
    }

    this.commands.set(command.name, command);

    const categoryList = this.categories.get(command.category) ?? [];
    categoryList.push(command);
    this.categories.set(command.category, categoryList);

    logger.debug('CommandRegistry', `Registered command: ${command.name} [${command.category}]`);
  }

  /**
   * Get command by name
   */
  public static get(name: string): Command | undefined {
    return this.commands.get(name.toLowerCase());
  }

  /**
   * Get all registered commands
   */
  public static getAll(): Collection<string, Command> {
    return this.commands;
  }

  /**
   * Get all commands in a category
   */
  public static getByCategory(category: CommandCategory): Command[] {
    return this.categories.get(category) ?? [];
  }

  /**
   * Get all active categories with commands
   */
  public static getCategories(): CommandCategory[] {
    return Array.from(this.categories.keys());
  }

  /**
   * Export all slash commands as JSON for Discord REST registration
   */
  public static getSlashCommandsData(): RESTPostAPIChatInputApplicationCommandsJSONBody[] {
    return this.commands.map(cmd => cmd.slashBuilder.toJSON());
  }
}
