export interface EmbedFieldData {
  name: string;
  value: string;
  inline?: boolean;
}

export interface EmbedAuthorData {
  name: string;
  iconURL?: string;
  url?: string;
}

export interface EmbedFooterData {
  text: string;
  iconURL?: string;
}

export interface UniversalEmbedData {
  title?: string;
  description?: string;
  url?: string;
  color?: number | string;
  author?: EmbedAuthorData;
  footer?: EmbedFooterData;
  thumbnail?: string;
  image?: string;
  timestamp?: boolean | string;
  fields?: EmbedFieldData[];
}

export type ButtonStyleType = 'PRIMARY' | 'SECONDARY' | 'SUCCESS' | 'DANGER' | 'LINK';

export interface UniversalButtonData {
  type: 'BUTTON';
  customId?: string;
  url?: string;
  label: string;
  emoji?: string;
  style: ButtonStyleType;
  disabled?: boolean;
}

export interface SelectMenuOptionData {
  label: string;
  value: string;
  description?: string;
  emoji?: string;
  default?: boolean;
}

export interface UniversalSelectMenuData {
  type: 'SELECT_MENU';
  customId: string;
  placeholder?: string;
  minValues?: number;
  maxValues?: number;
  options: SelectMenuOptionData[];
  disabled?: boolean;
}

export type UniversalComponentData = UniversalButtonData | UniversalSelectMenuData;

export interface UniversalMessagePayload {
  content?: string;
  embeds?: UniversalEmbedData[];
  components?: UniversalComponentData[][]; // array of action rows
}
