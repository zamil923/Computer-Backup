import { GuildMember, TextChannel, PermissionFlagsBits } from 'discord.js';
import { prisma } from '../database/prisma.js';
import { MessageBuilder } from '../utils/embedBuilder.js';
import { TemplateRepository } from '../repositories/templateRepository.js';
import { UniversalEmbedData, UniversalComponentData } from '../types/templates.js';
import { logger } from '../utils/logger.js';
import { RolePanelRepository } from '../repositories/rolePanelRepository.js';

export class WelcomeService {
  /**
   * Handle GuildMemberAdd: AutoRoles and Welcome message
   */
  public static async handleMemberAdd(member: GuildMember): Promise<void> {
    const guild = member.guild;

    // 1. Assign Auto Roles
    try {
      const autoRoles = await RolePanelRepository.listAutoRoles(guild.id);
      const botMember = guild.members.me;

      for (const autoRole of autoRoles) {
        if (autoRole.targetType === 'BOT' && !member.user.bot) continue;
        if (autoRole.targetType === 'HUMAN' && member.user.bot) continue;

        const role = guild.roles.cache.get(autoRole.roleId);
        if (!role) continue;

        // Check bot permissions and hierarchy
        if (
          botMember?.permissions.has(PermissionFlagsBits.ManageRoles) &&
          botMember.roles.highest.position > role.position &&
          !role.managed
        ) {
          if (autoRole.delaySeconds > 0) {
            setTimeout(async () => {
              await member.roles.add(role).catch(err => {
                logger.warn('WelcomeService', `Failed to apply delayed auto-role: ${role.name}`, err);
              });
            }, autoRole.delaySeconds * 1000);
          } else {
            await member.roles.add(role).catch(err => {
              logger.warn('WelcomeService', `Failed to apply auto-role: ${role.name}`, err);
            });
          }
        }
      }
    } catch (err) {
      logger.error('WelcomeService', `Error applying auto roles in ${guild.id}`, err);
    }

    // 2. Dispatch Welcome Message
    try {
      const config = await prisma.welcomeConfig.findUnique({
        where: { guildId: guild.id },
      });

      if (!config || !config.enabled || !config.channelId) return;

      const channel = guild.channels.cache.get(config.channelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      const context = { member, user: member.user, guild };

      if (config.templateId) {
        const template = await TemplateRepository.getById(config.templateId);
        if (template) {
          const payload = MessageBuilder.buildPayload(
            {
              content: template.content || undefined,
              embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
              components: template.componentsData
                ? (template.componentsData as unknown as UniversalComponentData[][])
                : undefined,
            },
            context
          );
          await channel.send(payload);
          return;
        }
      }

      if (config.plainText) {
        const payload = MessageBuilder.buildPayload({ content: config.plainText }, context);
        await channel.send(payload);
      }
    } catch (err) {
      logger.error('WelcomeService', `Error dispatching welcome message in ${guild.id}`, err);
    }
  }

  /**
   * Handle GuildMemberRemove: Leave message
   */
  public static async handleMemberRemove(member: GuildMember): Promise<void> {
    const guild = member.guild;

    try {
      const config = await prisma.leaveConfig.findUnique({
        where: { guildId: guild.id },
      });

      if (!config || !config.enabled || !config.channelId) return;

      const channel = guild.channels.cache.get(config.channelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      const context = { member, user: member.user, guild };

      if (config.templateId) {
        const template = await TemplateRepository.getById(config.templateId);
        if (template) {
          const payload = MessageBuilder.buildPayload(
            {
              content: template.content || undefined,
              embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
              components: template.componentsData
                ? (template.componentsData as unknown as UniversalComponentData[][])
                : undefined,
            },
            context
          );
          await channel.send(payload);
          return;
        }
      }

      if (config.plainText) {
        const payload = MessageBuilder.buildPayload({ content: config.plainText }, context);
        await channel.send(payload);
      }
    } catch (err) {
      logger.error('WelcomeService', `Error dispatching leave message in ${guild.id}`, err);
    }
  }

  /**
   * Handle Guild Boost announcements
   */
  public static async handleMemberBoost(member: GuildMember): Promise<void> {
    const guild = member.guild;

    try {
      const config = await prisma.boostConfig.findUnique({
        where: { guildId: guild.id },
      });

      if (!config || !config.enabled || !config.channelId) return;

      const channel = guild.channels.cache.get(config.channelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      const context = {
        member,
        user: member.user,
        guild,
        extra: {
          boostCount: guild.premiumSubscriptionCount ?? 0,
          tier: guild.premiumTier,
        },
      };

      if (config.templateId) {
        const template = await TemplateRepository.getById(config.templateId);
        if (template) {
          const payload = MessageBuilder.buildPayload(
            {
              content: template.content || undefined,
              embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
              components: template.componentsData
                ? (template.componentsData as unknown as UniversalComponentData[][])
                : undefined,
            },
            context
          );
          await channel.send(payload);
          return;
        }
      }

      const defaultText =
        config.plainText || `🚀 **{username}** just boosted the server! We are now at **{boostCount}** boosts!`;
      const payload = MessageBuilder.buildPayload({ content: defaultText }, context);
      await channel.send(payload);
    } catch (err) {
      logger.error('WelcomeService', `Error dispatching boost announcement in ${guild.id}`, err);
    }
  }
}
