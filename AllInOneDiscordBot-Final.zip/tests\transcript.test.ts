import { describe, it, expect } from 'vitest';
import { TranscriptGenerator } from '../src/utils/transcript.js';

describe('TranscriptGenerator', () => {
  it('should safely escape HTML entities to prevent XSS', () => {
    const raw = '<script>alert("hack")</script> & "quotes"';
    const escaped = TranscriptGenerator.escapeHtml(raw);
    expect(escaped).toBe('&lt;script&gt;alert(&quot;hack&quot;)&lt;/script&gt; &amp; &quot;quotes&quot;');
  });

  it('should generate valid standalone HTML transcript document', () => {
    const mockMessages = [
      {
        content: 'Hello, I need help with my account!',
        author: { tag: 'User#1234', bot: false, displayAvatarURL: () => 'https://example.com/avatar.png' },
        createdAt: new Date('2026-01-01T12:00:00Z'),
        createdTimestamp: 1000,
        attachments: new Map(),
        embeds: [],
      } as any,
    ];

    const mockMeta = {
      ticketId: 't-12345',
      guild: { name: 'Support Guild', id: '111' } as any,
      channel: { name: 'ticket-user' } as any,
      openerTag: 'User#1234',
      openerId: 'u123',
      createdAt: new Date(),
      closedAt: new Date(),
    };

    const html = TranscriptGenerator.generateHtml(mockMessages, mockMeta);
    expect(html).toContain('<!DOCTYPE html>');
    expect(html).toContain('Ticket Transcript: t-12345');
    expect(html).toContain('Hello, I need help with my account!');
  });
});
