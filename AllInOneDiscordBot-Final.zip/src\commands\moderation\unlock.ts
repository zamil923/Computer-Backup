import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const unlockCommand: Command = {
  name: 'unlock',
  description: 'Unlock the current channel and restore default permissions',
  category: 'Moderation',
  usage: 'unlock [reason]',
  examples: ['/unlock', '^unlock', '^unlock Incident resolved'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.ManageChannels],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock the current channel')
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for unlocking').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member || !ctx.channel || !ctx.channel.isTextBased()) return;

    const reason = ctx.getString('reason') || 'Channel unlocked';
    await ctx.defer();

    const result = await ModerationService.unlock(ctx.channel as TextChannel, ctx.member, reason);
    await ctx.editReply(result.message);
  },
};
