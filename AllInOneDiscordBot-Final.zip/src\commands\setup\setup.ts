import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { GuildRepository } from '../../repositories/guildRepository.js';

export const setupCommand: Command = {
  name: 'setup',
  description: 'Interactive server onboarding and configuration wizard',
  category: 'Setup',
  usage: 'setup [quick]',
  examples: ['/setup', '^setup', '^setup quick'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Guided server setup wizard')
    .addBooleanOption(opt =>
      opt
        .setName('auto_create_channels')
        .setDescription('Automatically create default log, ticket, and announcement channels')
        .setRequired(false)
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    await ctx.defer();
    const autoCreate = ctx.getBoolean('auto_create_channels') ?? false;

    if (autoCreate) {
      // Create default channels and configure
      const botMember = ctx.guild.members.me;
      if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
        await ctx.editReply('❌ I do not have `Manage Channels` permission to auto-create channels.');
        return;
      }

      const modLog = await ctx.guild.channels.create({
        name: 'mod-logs',
        topic: 'Automated moderation and security audit log',
      });

      const welcome = await ctx.guild.channels.create({
        name: 'welcome',
        topic: 'Server member arrivals and departures',
      });

      await GuildRepository.updateLoggingConfig(ctx.guild.id, {
        modLogsChannelId: modLog.id,
        automodLogsChannelId: modLog.id,
        serverLogsChannelId: modLog.id,
      });

      await ctx.editReply(
        `✅ **Quick Setup Completed!**\n` +
          `• Created <#${modLog.id}> for moderation and security logs.\n` +
          `• Created <#${welcome.id}> for arrivals.\n` +
          `• Configured bot database records.\n\n` +
          `Run \`${ctx.prefix}welcome channel #${welcome.name}\` to link welcome messages!`
      );
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🚀 Server Setup Wizard — ${ctx.guild.name}`)
      .setColor(Colors.Blurple)
      .setDescription(
        `This wizard will guide you through setting up essential server features:\n\n` +
          `**Step 1:** Configure Administrator & Moderator roles (\`${ctx.prefix}permissions addadmin @Role\`)\n` +
          `**Step 2:** Setup Mod Logs & Audit Channels (\`${ctx.prefix}config\`)\n` +
          `**Step 3:** Enable Welcome & Leave Messages (\`${ctx.prefix}welcome channel #channel\`)\n` +
          `**Step 4:** Setup Automatic Member Roles (\`${ctx.prefix}autorole add @Role\`)\n` +
          `**Step 5:** Deploy Support Tickets (\`${ctx.prefix}ticket panel\`)\n` +
          `**Step 6:** Enable AutoMod Protections (\`${ctx.prefix}automod enable spam\`)\n\n` +
          `Would you like to auto-create standard moderation log channels now?`
      )
      .setFooter({ text: 'This wizard is safe to rerun at any time.' });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId('setup_quick_channels')
        .setLabel('Auto-Create Channels')
        .setEmoji('⚡')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('setup_open_config')
        .setLabel('Open Control Center')
        .setEmoji('⚙️')
        .setStyle(ButtonStyle.Primary)
    );

    await ctx.editReply({
      embeds: [embed],
      components: [row],
    });
  },
};
