import { prisma } from '../database/prisma.js';
import { MessageTemplate, Prisma } from '@prisma/client';
import { UniversalEmbedData, UniversalComponentData } from '../types/templates.js';

export interface CreateTemplateInput {
  guildId: string;
  name: string;
  description?: string;
  content?: string;
  embedData?: UniversalEmbedData;
  componentsData?: UniversalComponentData[][];
  createdBy: string;
}

export class TemplateRepository {
  public static async create(input: CreateTemplateInput): Promise<MessageTemplate> {
    return prisma.messageTemplate.create({
      data: {
        guildId: input.guildId,
        name: input.name,
        description: input.description,
        content: input.content,
        embedData: input.embedData ? (input.embedData as unknown as Prisma.InputJsonValue) : Prisma.JsonNull,
        componentsData: input.componentsData ? (input.componentsData as unknown as Prisma.InputJsonValue) : Prisma.JsonNull,
        createdBy: input.createdBy,
      },
    });
  }

  public static async getByName(guildId: string, name: string): Promise<MessageTemplate | null> {
    return prisma.messageTemplate.findUnique({
      where: { guildId_name: { guildId, name } },
    });
  }

  public static async getById(id: string): Promise<MessageTemplate | null> {
    return prisma.messageTemplate.findUnique({
      where: { id },
    });
  }

  public static async list(guildId: string): Promise<MessageTemplate[]> {
    return prisma.messageTemplate.findMany({
      where: { guildId },
      orderBy: { updatedAt: 'desc' },
    });
  }

  public static async update(
    id: string,
    data: {
      name?: string;
      description?: string;
      content?: string;
      embedData?: UniversalEmbedData;
      componentsData?: UniversalComponentData[][];
    }
  ): Promise<MessageTemplate> {
    return prisma.messageTemplate.update({
      where: { id },
      data: {
        ...(data.name && { name: data.name }),
        ...(data.description !== undefined && { description: data.description }),
        ...(data.content !== undefined && { content: data.content }),
        ...(data.embedData !== undefined && {
          embedData: data.embedData ? (data.embedData as unknown as Prisma.InputJsonValue) : Prisma.JsonNull,
        }),
        ...(data.componentsData !== undefined && {
          componentsData: data.componentsData ? (data.componentsData as unknown as Prisma.InputJsonValue) : Prisma.JsonNull,
        }),
      },
    });
  }

  public static async duplicate(guildId: string, sourceName: string, newName: string, creatorId: string): Promise<MessageTemplate> {
    const source = await this.getByName(guildId, sourceName);
    if (!source) {
      throw new Error(`Template "${sourceName}" not found.`);
    }

    return prisma.messageTemplate.create({
      data: {
        guildId,
        name: newName,
        description: source.description,
        content: source.content,
        embedData: source.embedData ?? Prisma.JsonNull,
        componentsData: source.componentsData ?? Prisma.JsonNull,
        createdBy: creatorId,
      },
    });
  }

  public static async delete(guildId: string, name: string): Promise<MessageTemplate> {
    return prisma.messageTemplate.delete({
      where: { guildId_name: { guildId, name } },
    });
  }
}
