import {
  Interaction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  ModalSubmitInteraction,
  EmbedBuilder,
  Colors,
  TextChannel,
  PermissionFlagsBits,
} from 'discord.js';
import { RolePanelService } from '../services/rolePanelService.js';
import { TicketService } from '../services/ticketService.js';
import { TicketRepository } from '../repositories/ticketRepository.js';
import { CommandRegistry } from '../commands/registry.js';
import { GuildRepository } from '../repositories/guildRepository.js';
import { FormService } from '../services/formService.js';

export class ComponentRouter {
  public static async handle(interaction: Interaction): Promise<void> {
    if (interaction.isButton()) {
      await this.handleButton(interaction);
    } else if (interaction.isStringSelectMenu()) {
      await this.handleSelectMenu(interaction);
    } else if (interaction.isModalSubmit()) {
      await this.handleModal(interaction);
    }
  }

  private static async handleButton(interaction: ButtonInteraction): Promise<void> {
    const customId = interaction.customId;

    // 1. Role Toggle Button: `role_toggle:panelId:roleId`
    if (customId.startsWith('role_toggle:')) {
      const parts = customId.split(':');
      const panelId = parts[1] ?? '';
      const roleId = parts[2] ?? '';

      if (!interaction.member || !panelId || !roleId) return;

      await interaction.deferReply({ ephemeral: true });
      const member = await interaction.guild?.members.fetch(interaction.user.id);
      if (!member) return;

      const result = await RolePanelService.handleRoleToggle(member, panelId, roleId);
      await interaction.editReply(result.message);
      return;
    }

    // 2. Ticket Create Button: `ticket_create_default`
    if (customId === 'ticket_create_default' || customId.startsWith('ticket_create:')) {
      if (!interaction.guild || !interaction.member) return;

      await interaction.deferReply({ ephemeral: true });
      const member = await interaction.guild.members.fetch(interaction.user.id);
      const categoryId = customId.includes(':') ? customId.split(':')[1] : undefined;

      const result = await TicketService.createTicket(interaction.guild, member, categoryId);
      await interaction.editReply(result.message);
      return;
    }

    // 3. Ticket Close Button: `ticket_close:ticketId`
    if (customId.startsWith('ticket_close:')) {
      if (!interaction.channel || !interaction.member) return;

      await interaction.deferReply();
      const member = await interaction.guild?.members.fetch(interaction.user.id);
      if (!member) return;

      const result = await TicketService.closeTicket(
        interaction.channel as TextChannel,
        member,
        'Closed via ticket button'
      );
      if (!result.success) {
        await interaction.editReply(result.message);
      }
      return;
    }

    // 4. Ticket Claim Button: `ticket_claim:ticketId`
    if (customId.startsWith('ticket_claim:')) {
      if (!interaction.channel || !interaction.member) return;

      await interaction.deferReply();
      const member = await interaction.guild?.members.fetch(interaction.user.id);
      if (!member) return;

      const result = await TicketService.claimTicket(interaction.channel as TextChannel, member);
      await interaction.editReply(result.message);
      return;
    }

    // 5. Ticket Transcript Button: `ticket_transcript:ticketId`
    if (customId.startsWith('ticket_transcript:')) {
      await interaction.reply({
        content: '📜 Transcripts are generated and saved automatically upon closing the ticket.',
        ephemeral: true,
      });
      return;
    }

    // 6. Ticket Rating: `ticket_rate:ticketId:stars`
    if (customId.startsWith('ticket_rate:')) {
      const parts = customId.split(':');
      const ticketId = parts[1] ?? '';
      const stars = parseInt(parts[2] ?? '5', 10);

      if (ticketId) {
        await TicketRepository.saveRating(ticketId, stars);
        await interaction.reply({
          content: `⭐ Thank you for your feedback! You rated this support session **${stars}/5 stars**.`,
          ephemeral: true,
        });
      }
      return;
    }

    if (customId.startsWith('form_open_')) {
      const formId = customId.replace('form_open_', '');
      await FormService.handleFormOpen(interaction, formId);
      return;
    }

    // 7. Setup Quick Channels Button: `setup_quick_channels`
    if (customId === 'setup_quick_channels') {
      if (!interaction.guild || !interaction.member) return;

      await interaction.deferReply({ ephemeral: true });
      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
        await interaction.editReply('❌ I do not have `Manage Channels` permission.');
        return;
      }

      const modLog = await interaction.guild.channels.create({
        name: 'mod-logs',
        topic: 'Automated moderation and security audit log',
      });

      const welcome = await interaction.guild.channels.create({
        name: 'welcome',
        topic: 'Server member arrivals and departures',
      });

      await GuildRepository.updateLoggingConfig(interaction.guild.id, {
        modLogsChannelId: modLog.id,
        automodLogsChannelId: modLog.id,
        serverLogsChannelId: modLog.id,
      });

      await interaction.editReply(
        `✅ Created <#${modLog.id}> for logs and <#${welcome.id}> for member greetings!`
      );
      return;
    }

    // 8. Setup Open Config: `setup_open_config`
    if (customId === 'setup_open_config') {
      await interaction.reply({
        content: `Run \`/config\` or \`^config\` to access the interactive server control center.`,
        ephemeral: true,
      });
      return;
    }
  }

  private static async handleSelectMenu(interaction: StringSelectMenuInteraction): Promise<void> {
    const customId = interaction.customId;

    // 1. Role Select Menu: `role_select:panelId`
    if (customId.startsWith('role_select:')) {
      const panelId = customId.split(':')[1] ?? '';
      if (!interaction.guild || !interaction.member || !panelId) return;

      await interaction.deferReply({ ephemeral: true });
      const member = await interaction.guild.members.fetch(interaction.user.id);
      const selectedRoleIds = interaction.values;

      const result = await RolePanelService.handleRoleSelect(member, panelId, selectedRoleIds);
      await interaction.editReply(result.message);
      return;
    }

    // 2. Help Category Select Menu: `help_category_select`
    if (customId === 'help_category_select') {
      const selectedCategory = interaction.values[0];
      if (!selectedCategory) return;

      const commands = CommandRegistry.getByCategory(selectedCategory as any);
      const guildConfig = interaction.guild ? await GuildRepository.get(interaction.guild.id) : null;
      const prefix = guildConfig?.prefix || '^';

      const embed = new EmbedBuilder()
        .setTitle(`📚 Category: ${selectedCategory}`)
        .setColor(Colors.Blue)
        .setDescription(
          commands.length > 0
            ? commands
                .map(
                  cmd =>
                    `• **\`/${cmd.name}\`** / **\`${prefix}${cmd.usage}\`**\n  ${cmd.description}`
                )
                .join('\n\n')
            : 'No commands in this category.'
        )
        .setFooter({ text: `Type ${prefix}help <command> for detailed usage and examples.` });

      await interaction.update({ embeds: [embed] });
      return;
    }

    // 3. Config Module Select Menu: `config_module_select`
    if (customId === 'config_module_select') {
      const selected = interaction.values[0];
      const guildConfig = interaction.guild ? await GuildRepository.get(interaction.guild.id) : null;
      const prefix = guildConfig?.prefix || '^';

      let title = 'Module Information';
      let desc = '';

      switch (selected) {
        case 'welcome':
          title = '👋 Welcome System';
          desc = `Configure with: \`${prefix}welcome channel #channel\`, \`${prefix}welcome template <name>\`, or \`${prefix}welcome status\``;
          break;
        case 'leave':
          title = '🚪 Leave System';
          desc = `Configure with: \`${prefix}leave channel #channel\`, \`${prefix}leave text <message>\`, or \`${prefix}leave status\``;
          break;
        case 'boost':
          title = '🚀 Boost System';
          desc = `Configure with: \`${prefix}boost channel #channel\`, or \`${prefix}boost status\``;
          break;
        case 'automod':
          title = '🛡️ AutoMod Settings';
          desc = `Enable modules with: \`${prefix}automod enable <module>\` (spam, repeats, mentions, invites, links, caps, words)`;
          break;
        case 'permissions':
          title = '🔑 Permissions & Staff Roles';
          desc = `Add staff roles with: \`${prefix}permissions addadmin @Role\` or \`${prefix}permissions addmod @Role\``;
          break;
        case 'tickets':
          title = '🎫 Support Tickets';
          desc = `Deploy a ticket panel with: \`${prefix}ticket panel title:"Support" description:"Click to open ticket"\``;
          break;
        default:
          desc = 'Module overview.';
          break;
      }

      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(desc)
        .setColor(Colors.Blurple);

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }
  }
  private static async handleModal(interaction: ModalSubmitInteraction): Promise<void> {
    const customId = interaction.customId;
    if (customId.startsWith('form_submit_')) {
      const formId = customId.replace('form_submit_', '');
      await FormService.handleFormSubmit(interaction, formId);
    }
  }
}
