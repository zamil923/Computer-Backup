import { Message, GuildMember } from 'discord.js';
import { CommandRegistry } from '../commands/registry.js';
import { ArgParser } from '../commands/argParser.js';
import { PrefixCommandContext } from '../commands/context.js';
import { PermissionManager } from '../permissions/permissionManager.js';
import { GuildRepository } from '../repositories/guildRepository.js';
import { AutoModService } from '../services/autoModService.js';
import { AutoResponderService } from '../services/autoResponderService.js';
import { LevelingService } from '../services/levelingService.js';
import { prisma } from '../database/prisma.js';
import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';

async function checkHoneypot(message: Message): Promise<void> {
  if (!message.guild || !message.member) return;
  const guildId = message.guild.id;

  const config = await prisma.honeypotConfig.findUnique({ where: { guildId } });
  if (!config || !config.enabled || !config.channelId) return;
  if (message.channelId !== config.channelId) return;

  // Check exempt roles
  const member = message.member as GuildMember;
  for (const roleId of config.exemptRoleIds) {
    if (member.roles.cache.has(roleId)) return;
  }

  // Delete the message
  await message.delete().catch(() => null);

  const action = config.action;
  const reason = '[Honeypot] Sent a message in the honeypot channel';
  logger.warn('Honeypot', `${message.author.tag} triggered honeypot in ${message.guild.name}. Action: ${action}`);

  if (action === 'WARN') {
    // Just log — actual warn requires ModerationService; keep this lightweight
    if ('send' in message.channel) {
      const channelWithSend = message.channel as any;
      const m = await channelWithSend.send(`⚠️ <@${message.author.id}>, accessing this channel is not permitted.`);
      setTimeout(() => m.delete().catch(() => null), 5000);
    }
  } else if (action === 'TIMEOUT') {
    await member.timeout(3600 * 1000, reason).catch(() => null);
  } else if (action === 'KICK') {
    await member.kick(reason).catch(() => null);
  } else if (action === 'BAN') {
    await message.guild.members.ban(message.author.id, { reason }).catch(() => null);
  }
  // LOG — just the logger.warn above is sufficient
}


export async function handleMessageCreate(message: Message): Promise<void> {
  // Ignore bots to prevent loops
  if (message.author.bot) return;

  // 1. AutoMod Evaluation (for guild messages)
  if (message.guild) {
    const intercepted = await AutoModService.processMessage(message);
    if (intercepted) return;
  }

  // 1b. Honeypot check (fire and forget – non-blocking to avoid slowing regular messages)
  if (message.guild && !message.author.bot) {
    checkHoneypot(message).catch(() => null);
  }

  // 2. XP/Leveling (fire-and-forget, non-blocking)
  if (message.guild) {
    LevelingService.processMessage(message).catch(() => null);
  }

  // 3. Fetch Guild Custom Prefix or Fallback
  let prefix = env.DEFAULT_PREFIX;
  if (message.guild) {
    const guildConfig = await GuildRepository.get(message.guild.id);
    if (guildConfig?.prefix) {
      prefix = guildConfig.prefix;
    }
  }

  // 3. Prefix Command Parsing
  if (message.content.startsWith(prefix)) {
    const parsed = ArgParser.parse(message.content, prefix);
    if (parsed) {
      const command = CommandRegistry.get(parsed.commandName);
      if (command) {
        const ctx = new PrefixCommandContext(message, prefix, parsed);
        const permCheck = await PermissionManager.checkCommandAccess(command, ctx);

        if (!permCheck.allowed) {
          await ctx.reply(`⛔ **Access Denied:** ${permCheck.reason ?? 'You do not have permission to execute this command.'}`);
          return;
        }

        try {
          await command.execute(ctx);
        } catch (err) {
          logger.error('CommandHandler', `Error executing prefix command ${prefix}${command.name}`, err);
          await ctx.reply('⚠️ An internal error occurred while executing this command.').catch(() => null);
        }
        return;
      }
    }
  }

  // 4. Auto Responder Evaluation
  if (message.guild) {
    await AutoResponderService.processMessage(message);
  }
}
