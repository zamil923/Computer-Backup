import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const lockCommand: Command = {
  name: 'lock',
  description: 'Lock the current channel to prevent members from sending messages',
  category: 'Moderation',
  usage: 'lock [reason]',
  examples: ['/lock reason:Server raid ongoing', '^lock', '^lock Under maintenance'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.ManageChannels],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock the current channel')
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for locking').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member || !ctx.channel || !ctx.channel.isTextBased()) return;

    const reason = ctx.getString('reason') || 'Emergency channel lock';
    await ctx.defer();

    const result = await ModerationService.lock(ctx.channel as TextChannel, ctx.member, reason);
    await ctx.editReply(result.message);
  },
};
