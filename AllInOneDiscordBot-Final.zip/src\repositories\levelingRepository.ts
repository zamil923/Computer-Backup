import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export class LevelingRepository {
  // ── XP CONFIG ──────────────────────────────────────────────

  public static async getConfig(guildId: string) {
    return prisma.levelConfig.findUnique({ where: { guildId } });
  }

  public static async upsertConfig(guildId: string, data: {
    enabled?: boolean;
    xpMin?: number;
    xpMax?: number;
    cooldownSeconds?: number;
    ignoredChannelIds?: string[];
    ignoredRoleIds?: string[];
    levelUpChannelId?: string | null;
    levelUpMessage?: string | null;
    stackRoles?: boolean;
  }) {
    return prisma.levelConfig.upsert({
      where: { guildId },
      update: data,
      create: { guildId, ...data },
    });
  }

  // ── LEVEL ROLES ────────────────────────────────────────────

  public static async getLevelRoles(guildId: string) {
    return prisma.levelRole.findMany({
      where: { guildId },
      orderBy: { level: 'asc' },
    });
  }

  public static async setLevelRole(guildId: string, level: number, roleId: string) {
    return prisma.levelRole.upsert({
      where: { guildId_level: { guildId, level } },
      update: { roleId },
      create: { guildId, level, roleId },
    });
  }

  public static async removeLevelRole(guildId: string, level: number) {
    return prisma.levelRole.deleteMany({ where: { guildId, level } });
  }

  // ── MEMBER XP ──────────────────────────────────────────────

  public static async getMemberXp(guildId: string, userId: string) {
    return prisma.memberXp.findUnique({
      where: { guildId_userId: { guildId, userId } },
    });
  }

  public static async upsertMemberXp(guildId: string, userId: string, xpToAdd: number) {
    const record = await this.getMemberXp(guildId, userId);
    const currentXp = record?.xp ?? 0;
    const newXp = currentXp + xpToAdd;
    const newLevel = this.calculateLevel(newXp);

    const updated = await prisma.memberXp.upsert({
      where: { guildId_userId: { guildId, userId } },
      update: { xp: newXp, level: newLevel, lastMessageAt: new Date() },
      create: { guildId, userId, xp: newXp, level: newLevel },
    });

    return { ...updated, prevLevel: record?.level ?? 0 };
  }

  public static async setMemberXp(guildId: string, userId: string, xp: number) {
    const newLevel = this.calculateLevel(xp);
    return prisma.memberXp.upsert({
      where: { guildId_userId: { guildId, userId } },
      update: { xp, level: newLevel },
      create: { guildId, userId, xp, level: newLevel },
    });
  }

  public static async resetMember(guildId: string, userId: string) {
    return prisma.memberXp.deleteMany({ where: { guildId, userId } });
  }

  public static async resetLeaderboard(guildId: string) {
    return prisma.memberXp.deleteMany({ where: { guildId } });
  }

  public static async getLeaderboard(guildId: string, limit = 10, offset = 0) {
    return prisma.memberXp.findMany({
      where: { guildId },
      orderBy: { xp: 'desc' },
      take: limit,
      skip: offset,
    });
  }

  public static async getMemberRank(guildId: string, userId: string) {
    const member = await this.getMemberXp(guildId, userId);
    if (!member) return null;

    const rank = await prisma.memberXp.count({
      where: { guildId, xp: { gt: member.xp } },
    });

    return { ...member, rank: rank + 1 };
  }

  // ── HELPERS ────────────────────────────────────────────────

  public static calculateLevel(xp: number): number {
    // Level = floor(sqrt(xp / 100))
    return Math.floor(Math.sqrt(xp / 100));
  }

  public static xpRequiredForLevel(level: number): number {
    return level * level * 100;
  }

  public static xpRequiredForNextLevel(currentLevel: number): number {
    return this.xpRequiredForLevel(currentLevel + 1);
  }
}
