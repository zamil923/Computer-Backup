import { prisma } from '../database/prisma.js';
import { StatsConfig, VoiceStatChannel } from '@prisma/client';
import { GuildRepository } from './guildRepository.js';

export class StatsRepository {
  public static async getConfig(guildId: string): Promise<StatsConfig> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.statsConfig.upsert({
      where: { guildId },
      update: {},
      create: { guildId },
    });
  }

  public static async updateConfig(
    guildId: string,
    data: Partial<Omit<StatsConfig, 'id' | 'guildId'>>
  ): Promise<StatsConfig> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.statsConfig.upsert({
      where: { guildId },
      update: data,
      create: { guildId, ...data },
    });
  }

  public static async listVoiceStatChannels(guildId: string): Promise<VoiceStatChannel[]> {
    return prisma.voiceStatChannel.findMany({
      where: { guildId },
    });
  }

  public static async setVoiceStatChannel(
    guildId: string,
    channelId: string,
    statType: string,
    formatString: string
  ): Promise<VoiceStatChannel> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.voiceStatChannel.upsert({
      where: { guildId_channelId: { guildId, channelId } },
      update: { statType, formatString },
      create: { guildId, channelId, statType, formatString },
    });
  }

  public static async removeVoiceStatChannel(guildId: string, channelId: string): Promise<VoiceStatChannel | null> {
    const existing = await prisma.voiceStatChannel.findUnique({
      where: { guildId_channelId: { guildId, channelId } },
    });
    if (!existing) return null;
    return prisma.voiceStatChannel.delete({
      where: { id: existing.id },
    });
  }

  public static async updateVoiceStatChannelValue(id: string, value: number): Promise<VoiceStatChannel> {
    return prisma.voiceStatChannel.update({
      where: { id },
      data: {
        lastValue: value,
        lastUpdated: new Date(),
      },
    });
  }
}
