import { describe, it, expect } from 'vitest';
import { ArgParser } from '../src/commands/argParser.js';

describe('ArgParser', () => {
  it('should ignore messages without prefix', () => {
    const result = ArgParser.parse('hello world', '^');
    expect(result).toBeNull();
  });

  it('should correctly parse command name and positional arguments', () => {
    const result = ArgParser.parse('^ban 123456789 Rule violation', '^');
    expect(result).not.toBeNull();
    expect(result?.commandName).toBe('ban');
    expect(result?.positional).toEqual(['123456789', 'Rule', 'violation']);
  });

  it('should preserve quoted multi-word strings', () => {
    const result = ArgParser.parse('^embed create "Server Rules" "1. Be respectful" #5865f2', '^');
    expect(result).not.toBeNull();
    expect(result?.commandName).toBe('embed');
    expect(result?.positional).toEqual(['create', 'Server Rules', '1. Be respectful', '#5865f2']);
    expect(result?.subcommand).toBe('create');
  });

  it('should parse named flags correctly', () => {
    const result = ArgParser.parse('^timeout @user 10m --reason "Excessive spamming" --silent', '^');
    expect(result).not.toBeNull();
    expect(result?.commandName).toBe('timeout');
    expect(result?.positional).toEqual(['@user', '10m']);
    expect(result?.flags['reason']).toBe('Excessive spamming');
    expect(result?.flags['silent']).toBe(true);
  });
});
