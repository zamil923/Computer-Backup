import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  ActivityType,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { CommandRegistry } from '../registry.js';
import { env } from '../../config/env.js';

export const ownerCommand: Command = {
  name: 'owner',
  description: 'Global Bot Owner administrative commands and diagnostics',
  category: 'Owner',
  usage: 'owner <diagnostics|sync|presence|status|info> [options]',
  examples: [
    '/owner diagnostics',
    '/owner sync',
    '/owner presence status:online type:Watching text:"over servers"',
    '^owner diagnostics',
    '^owner sync',
  ],
  requiredPermission: PermissionLevel.GLOBAL_BOT_OWNER,
  ownerOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('owner')
    .setDescription('Global Bot Owner tools')
    .addSubcommand(sub => sub.setName('diagnostics').setDescription('Inspect server host and bot runtime diagnostics'))
    .addSubcommand(sub => sub.setName('sync').setDescription('Synchronize application slash commands with Discord API'))
    .addSubcommand(sub =>
      sub
        .setName('presence')
        .setDescription('Update bot presence and activity')
        .addStringOption(opt =>
          opt
            .setName('status')
            .setDescription('Online status')
            .setRequired(true)
            .addChoices(
              { name: 'Online', value: 'online' },
              { name: 'Idle', value: 'idle' },
              { name: 'Do Not Disturb', value: 'dnd' },
              { name: 'Invisible', value: 'invisible' }
            )
        )
        .addStringOption(opt =>
          opt
            .setName('type')
            .setDescription('Activity type')
            .setRequired(true)
            .addChoices(
              { name: 'Playing', value: 'Playing' },
              { name: 'Watching', value: 'Watching' },
              { name: 'Listening to', value: 'Listening' },
              { name: 'Competing in', value: 'Competing' }
            )
        )
        .addStringOption(opt => opt.setName('text').setDescription('Activity description text').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('info').setDescription('Bot instance information and owner roster')),

  async execute(ctx) {
    const subcommand = ctx.getSubcommand() || 'info';
    await ctx.defer(true);

    // 1. DIAGNOSTICS
    if (subcommand === 'diagnostics') {
      const memoryUsage = process.memoryUsage();
      const uptimeSec = Math.floor(process.uptime());
      const days = Math.floor(uptimeSec / 86400);
      const hours = Math.floor((uptimeSec % 86400) / 3600);
      const minutes = Math.floor((uptimeSec % 3600) / 60);
      const seconds = uptimeSec % 60;

      const embed = new EmbedBuilder()
        .setTitle('⚙️ System & Runtime Diagnostics')
        .setColor(Colors.DarkPurple)
        .addFields(
          {
            name: 'Process Uptime',
            value: `${days}d ${hours}h ${minutes}m ${seconds}s`,
            inline: true,
          },
          {
            name: 'Memory (Heap Used)',
            value: `${Math.round(memoryUsage.heapUsed / 1024 / 1024)} MB / ${Math.round(memoryUsage.heapTotal / 1024 / 1024)} MB`,
            inline: true,
          },
          {
            name: 'RSS Memory',
            value: `${Math.round(memoryUsage.rss / 1024 / 1024)} MB`,
            inline: true,
          },
          {
            name: 'Node.js Version',
            value: `\`${process.version}\``,
            inline: true,
          },
          {
            name: 'Cached Guilds',
            value: `${ctx.client.guilds.cache.size}`,
            inline: true,
          },
          {
            name: 'WebSocket Ping',
            value: `\`${ctx.client.ws.ping}ms\``,
            inline: true,
          }
        )
        .setTimestamp();

      await ctx.editReply({ embeds: [embed] });
      return;
    }

    // 2. SYNC SLASH COMMANDS
    if (subcommand === 'sync') {
      try {
        const slashData = CommandRegistry.getSlashCommandsData();
        if (env.DEV_GUILD_ID) {
          const guild = ctx.client.guilds.cache.get(env.DEV_GUILD_ID);
          if (guild) {
            await guild.commands.set(slashData);
            await ctx.editReply(`✅ Synchronized ${slashData.length} slash commands to DEV guild: \`${guild.name}\`.`);
            return;
          }
        }

        await ctx.client.application?.commands.set(slashData);
        await ctx.editReply(`✅ Globally synchronized ${slashData.length} application slash commands.`);
      } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        await ctx.editReply(`❌ Error synchronizing slash commands: ${errorMsg}`);
      }
      return;
    }

    // 3. PRESENCE
    if (subcommand === 'presence') {
      const status = ctx.getString('status', true)?.toLowerCase();
      const typeStr = ctx.getString('type', true);
      const text = ctx.getString('text', true) || '';

      let actType = ActivityType.Playing;
      if (typeStr === 'Watching') actType = ActivityType.Watching;
      if (typeStr === 'Listening') actType = ActivityType.Listening;
      if (typeStr === 'Competing') actType = ActivityType.Competing;

      ctx.client.user?.setPresence({
        status: (status || 'online') as any,
        activities: [
          {
            name: text,
            type: actType,
          },
        ],
      });

      await ctx.editReply(`✅ Bot presence updated to **${status}**, ${typeStr} **"${text}"**.`);
      return;
    }

    // 4. INFO
    const embed = new EmbedBuilder()
      .setTitle('👑 Global Bot Authority Information')
      .setColor(Colors.Gold)
      .addFields(
        {
          name: 'Authorized Bot Owners',
          value: env.BOT_OWNER_IDS.map(id => `<@${id}> (\`${id}\`)`).join('\n') || 'None configured in .env',
          inline: false,
        },
        {
          name: 'Registered Commands',
          value: `${CommandRegistry.getAll().size} commands across ${CommandRegistry.getCategories().length} categories`,
          inline: true,
        },
        {
          name: 'Environment',
          value: `\`${env.NODE_ENV}\``,
          inline: true,
        }
      )
      .setFooter({ text: 'All operations strictly verified server-side.' });

    await ctx.editReply({ embeds: [embed] });
  },
};
