import { Client, GatewayIntentBits, Partials, Events } from 'discord.js';
import { env } from './config/env.js';
import { logger } from './utils/logger.js';
import { disconnectPrisma } from './database/prisma.js';
import { registerAllCommands } from './commands/index.js';
import { handleReady } from './events/ready.js';
import { handleInteractionCreate } from './events/interactionCreate.js';
import { handleMessageCreate } from './events/messageCreate.js';
import { handleGuildMemberAdd } from './events/guildMemberAdd.js';
import { handleGuildMemberRemove } from './events/guildMemberRemove.js';
import { handleGuildMemberUpdate } from './events/guildMemberUpdate.js';

// Global Process Exception Handlers
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Process', 'Unhandled Promise Rejection at:', { promise, reason });
});

process.on('uncaughtException', (error) => {
  logger.error('Process', 'Uncaught Exception thrown:', error);
});

export function createBotClient(): Client {
  return new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers, // Privileged intent for welcome/autorole
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent, // Privileged intent for prefix commands
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.GuildModeration,
    ],
    partials: [
      Partials.Message,
      Partials.Channel,
      Partials.Reaction,
      Partials.GuildMember,
      Partials.User,
    ],
  });
}

export async function bootstrap(): Promise<Client> {
  logger.info('Bootstrap', 'Initializing All-in-One Discord Bot...');

  // 1. Register all core commands
  registerAllCommands();

  // 2. Initialize Discord Client
  const client = createBotClient();

  // 3. Register Event Handlers
  client.once(Events.ClientReady, () => handleReady(client));
  client.on(Events.InteractionCreate, handleInteractionCreate);
  client.on(Events.MessageCreate, handleMessageCreate);
  client.on(Events.GuildMemberAdd, handleGuildMemberAdd);
  client.on(Events.GuildMemberRemove, handleGuildMemberRemove);
  client.on(Events.GuildMemberUpdate, handleGuildMemberUpdate);

  // 4. Graceful Shutdown Handlers
  const shutdown = async (signal: string) => {
    logger.info('Shutdown', `Received ${signal}. Shutting down gracefully...`);
    try {
      client.destroy();
      await disconnectPrisma();
      logger.info('Shutdown', 'Closed Discord connection and Prisma database pool.');
      process.exit(0);
    } catch (err) {
      logger.error('Shutdown', 'Error during shutdown', err);
      process.exit(1);
    }
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  // 5. Connect to Discord Gateway
  if (env.DISCORD_TOKEN && env.DISCORD_TOKEN !== 'YOUR_DISCORD_BOT_TOKEN_HERE') {
    await client.login(env.DISCORD_TOKEN);
  } else {
    logger.warn(
      'Bootstrap',
      'No valid DISCORD_TOKEN provided in environment. Running in offline/testing mode.'
    );
  }

  return client;
}

// Only launch automatically if executed directly
if (process.env['NODE_ENV'] !== 'test') {
  bootstrap().catch(err => {
    logger.error('Main', 'Failed to bootstrap bot application', err);
  });
}
