import { describe, it, expect } from 'vitest';
import { SlidingWindowRateLimiter } from '../src/utils/rateLimiter.js';

describe('SlidingWindowRateLimiter', () => {
  it('should allow events within the limit', () => {
    const limiter = new SlidingWindowRateLimiter(3, 10);
    expect(limiter.check('user1').isLimited).toBe(false);
    expect(limiter.check('user1').isLimited).toBe(false);
    expect(limiter.check('user1').isLimited).toBe(false);
  });

  it('should block events that exceed the limit', () => {
    const limiter = new SlidingWindowRateLimiter(2, 10);
    expect(limiter.check('user2').isLimited).toBe(false);
    expect(limiter.check('user2').isLimited).toBe(false);
    expect(limiter.check('user2').isLimited).toBe(true);
  });

  it('should allow resetting rate limits', () => {
    const limiter = new SlidingWindowRateLimiter(1, 10);
    expect(limiter.check('user3').isLimited).toBe(false);
    expect(limiter.check('user3').isLimited).toBe(true);
    limiter.reset('user3');
    expect(limiter.check('user3').isLimited).toBe(false);
  });
});
