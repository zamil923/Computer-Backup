import { describe, it, expect } from 'vitest';
import { MessageBuilder } from '../src/utils/embedBuilder.js';
import { UniversalEmbedData, UniversalComponentData } from '../src/types/templates.js';

describe('MessageBuilder', () => {
  it('should parse hex colors correctly', () => {
    expect(MessageBuilder.parseColor('#ff0000')).toBe(16711680);
    expect(MessageBuilder.parseColor('00ff00')).toBe(65280);
    expect(MessageBuilder.parseColor('invalid')).toBeNull();
  });

  it('should build discord embed and enforce text limits', () => {
    const longDesc = 'a'.repeat(5000);
    const embedData: UniversalEmbedData = {
      title: 'Valid Title',
      description: longDesc,
      color: '#5865F2',
    };

    const embed = MessageBuilder.buildEmbed(embedData);
    expect(embed.data.title).toBe('Valid Title');
    expect(embed.data.description?.length).toBe(MessageBuilder.LIMITS.DESCRIPTION);
  });

  it('should build button components properly', () => {
    const components: UniversalComponentData[][] = [
      [
        {
          type: 'BUTTON',
          label: 'Click Me',
          style: 'PRIMARY',
          customId: 'btn_test',
        },
      ],
    ];

    const rows = MessageBuilder.buildComponents(components);
    expect(rows.length).toBe(1);
    expect(rows[0]?.components.length).toBe(1);
  });
});
