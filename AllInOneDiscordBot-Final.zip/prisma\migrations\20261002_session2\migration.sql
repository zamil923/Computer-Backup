-- CreateTable
CREATE TABLE "Form" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Form_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FormQuestion" (
    "id" TEXT NOT NULL,
    "formId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "description" TEXT,
    "type" TEXT NOT NULL DEFAULT 'SHORT_TEXT',
    "required" BOOLEAN NOT NULL DEFAULT true,
    "order" INTEGER NOT NULL DEFAULT 0,
    "choices" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "FormQuestion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FormSubmission" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "formId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "userTag" TEXT NOT NULL,
    "answers" JSONB NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "reviewerId" TEXT,
    "reviewerTag" TEXT,
    "reviewNotes" TEXT,
    "decisionReason" TEXT,
    "submittedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewedAt" TIMESTAMP(3),

    CONSTRAINT "FormSubmission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ApplicationConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "formId" TEXT NOT NULL,
    "reviewChannelId" TEXT,
    "reviewerRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "approveRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "approveMessage" TEXT,
    "approveTemplateId" TEXT,
    "rejectMessage" TEXT,
    "rejectTemplateId" TEXT,
    "sendDmOnDecision" BOOLEAN NOT NULL DEFAULT true,
    "cooldownDays" INTEGER NOT NULL DEFAULT 0,
    "maxActive" INTEGER NOT NULL DEFAULT 1,
    "eligibilityRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "blockedRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "isOpen" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "ApplicationConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LevelConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "xpMin" INTEGER NOT NULL DEFAULT 15,
    "xpMax" INTEGER NOT NULL DEFAULT 25,
    "cooldownSeconds" INTEGER NOT NULL DEFAULT 60,
    "ignoredChannelIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "ignoredRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "levelUpChannelId" TEXT,
    "levelUpMessage" TEXT,
    "levelUpTemplateId" TEXT,
    "stackRoles" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "LevelConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LevelRole" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "level" INTEGER NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "LevelRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MemberXp" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "xp" INTEGER NOT NULL DEFAULT 0,
    "level" INTEGER NOT NULL DEFAULT 0,
    "lastMessageAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "MemberXp_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HoneypotConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "channelId" TEXT,
    "action" TEXT NOT NULL DEFAULT 'LOG',
    "exemptRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "HoneypotConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoModEscalation" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "violationCount" INTEGER NOT NULL,
    "action" TEXT NOT NULL,
    "durationSeconds" INTEGER,

    CONSTRAINT "AutoModEscalation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ServerTemplate" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "version" TEXT NOT NULL DEFAULT '1.0',
    "data" JSONB NOT NULL,
    "isBackup" BOOLEAN NOT NULL DEFAULT false,
    "creatorId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ServerTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TemplateLog" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "templateId" TEXT,
    "executorId" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "details" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TemplateLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Form_guildId_idx" ON "Form"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "Form_guildId_name_key" ON "Form"("guildId", "name");

-- CreateIndex
CREATE INDEX "FormQuestion_formId_idx" ON "FormQuestion"("formId");

-- CreateIndex
CREATE INDEX "FormSubmission_guildId_idx" ON "FormSubmission"("guildId");

-- CreateIndex
CREATE INDEX "FormSubmission_formId_idx" ON "FormSubmission"("formId");

-- CreateIndex
CREATE INDEX "FormSubmission_userId_idx" ON "FormSubmission"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "ApplicationConfig_guildId_key" ON "ApplicationConfig"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "ApplicationConfig_formId_key" ON "ApplicationConfig"("formId");

-- CreateIndex
CREATE UNIQUE INDEX "LevelConfig_guildId_key" ON "LevelConfig"("guildId");

-- CreateIndex
CREATE INDEX "LevelRole_guildId_idx" ON "LevelRole"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "LevelRole_guildId_level_key" ON "LevelRole"("guildId", "level");

-- CreateIndex
CREATE INDEX "MemberXp_guildId_idx" ON "MemberXp"("guildId");

-- CreateIndex
CREATE INDEX "MemberXp_xp_idx" ON "MemberXp"("xp" DESC);

-- CreateIndex
CREATE UNIQUE INDEX "MemberXp_guildId_userId_key" ON "MemberXp"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "HoneypotConfig_guildId_key" ON "HoneypotConfig"("guildId");

-- CreateIndex
CREATE INDEX "AutoModEscalation_guildId_idx" ON "AutoModEscalation"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "AutoModEscalation_guildId_violationCount_key" ON "AutoModEscalation"("guildId", "violationCount");

-- CreateIndex
CREATE INDEX "ServerTemplate_guildId_idx" ON "ServerTemplate"("guildId");

-- CreateIndex
CREATE INDEX "TemplateLog_guildId_idx" ON "TemplateLog"("guildId");

-- AddForeignKey
ALTER TABLE "Form" ADD CONSTRAINT "Form_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FormQuestion" ADD CONSTRAINT "FormQuestion_formId_fkey" FOREIGN KEY ("formId") REFERENCES "Form"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FormSubmission" ADD CONSTRAINT "FormSubmission_formId_fkey" FOREIGN KEY ("formId") REFERENCES "Form"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FormSubmission" ADD CONSTRAINT "FormSubmission_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApplicationConfig" ADD CONSTRAINT "ApplicationConfig_formId_fkey" FOREIGN KEY ("formId") REFERENCES "Form"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApplicationConfig" ADD CONSTRAINT "ApplicationConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LevelConfig" ADD CONSTRAINT "LevelConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LevelRole" ADD CONSTRAINT "LevelRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MemberXp" ADD CONSTRAINT "MemberXp_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HoneypotConfig" ADD CONSTRAINT "HoneypotConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoModEscalation" ADD CONSTRAINT "AutoModEscalation_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ServerTemplate" ADD CONSTRAINT "ServerTemplate_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TemplateLog" ADD CONSTRAINT "TemplateLog_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

