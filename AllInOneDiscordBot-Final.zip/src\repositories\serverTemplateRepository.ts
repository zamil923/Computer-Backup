import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export class ServerTemplateRepository {
  public static async createTemplate(
    guildId: string,
    name: string,
    creatorId: string,
    data: any,
    isBackup = false,
    description?: string,
  ) {
    return prisma.serverTemplate.create({
      data: {
        guildId,
        name,
        description,
        data,
        isBackup,
        creatorId,
      },
    });
  }

  public static async getTemplate(id: string) {
    return prisma.serverTemplate.findUnique({
      where: { id },
    });
  }

  public static async listTemplates(guildId: string, isBackup?: boolean) {
    const where: any = { guildId };
    if (isBackup !== undefined) {
      where.isBackup = isBackup;
    }
    return prisma.serverTemplate.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
  }

  public static async deleteTemplate(id: string) {
    return prisma.serverTemplate.delete({
      where: { id },
    });
  }

  public static async logOperation(
    guildId: string,
    action: string,
    executorId: string,
    status: string,
    templateId?: string,
    details?: string
  ) {
    return prisma.templateLog.create({
      data: {
        guildId,
        action,
        executorId,
        status,
        templateId,
        details,
      },
    });
  }
}
