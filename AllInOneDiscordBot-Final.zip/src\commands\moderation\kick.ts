import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const kickCommand: Command = {
  name: 'kick',
  description: 'Kick a member from the server',
  category: 'Moderation',
  usage: 'kick <@user|id> [reason]',
  examples: ['/kick user:@troublemaker reason:Rule violations', '^kick @troublemaker Rule violations'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.KickMembers],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption(opt => opt.setName('user').setDescription('Member to kick').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for kicking').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member) return;

    const member = await ctx.getMember('user', true);
    if (!member) {
      await ctx.reply('❌ Please specify a member currently in the server to kick.');
      return;
    }

    const reason = ctx.getString('reason') || 'No reason provided';
    await ctx.defer();

    const result = await ModerationService.kick(ctx.guild, ctx.member, member, reason);
    await ctx.editReply(result.message);
  },
};
