import { SlashCommandBuilder, EmbedBuilder, Colors, TextChannel } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { prisma } from '../../database/prisma.js';
import { TemplateRepository } from '../../repositories/templateRepository.js';
import { MessageBuilder } from '../../utils/embedBuilder.js';
import { UniversalEmbedData, UniversalComponentData } from '../../types/templates.js';

export const boostCommand: Command = {
  name: 'boost',
  description: 'Configure and test the server boost announcement system',
  category: 'Welcome / Leave / Boost',
  usage: 'boost <status|enable|disable|channel|text|template|test> [options]',
  examples: [
    '/boost status',
    '/boost enable',
    '/boost channel channel:#boosts',
    '/boost text content:"🚀 {user} just boosted {server}! We have {boostCount} boosts!"',
    '/boost template name:boost_card',
    '/boost test',
    '^boost status',
    '^boost enable',
    '^boost channel #boosts',
    '^boost test',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('boost')
    .setDescription('Configure boost announcements')
    .addSubcommand(sub => sub.setName('status').setDescription('View current boost configuration'))
    .addSubcommand(sub => sub.setName('enable').setDescription('Enable boost announcements'))
    .addSubcommand(sub => sub.setName('disable').setDescription('Disable boost announcements'))
    .addSubcommand(sub =>
      sub
        .setName('channel')
        .setDescription('Set the announcement channel')
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send boost announcements').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('text')
        .setDescription('Set plain text boost message')
        .addStringOption(opt => opt.setName('content').setDescription('Message text').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('template')
        .setDescription('Link a saved embed template to the boost system')
        .addStringOption(opt => opt.setName('name').setDescription('Template name').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('test').setDescription('Send a test boost message')),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'status';
    await ctx.defer();

    // 1. ENABLE / DISABLE
    if (subcommand === 'enable' || subcommand === 'disable') {
      const enabled = subcommand === 'enable';
      await prisma.boostConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { enabled },
        create: { guildId: ctx.guild.id, enabled },
      });
      await ctx.editReply(`✅ Boost announcements have been **${enabled ? 'enabled' : 'disabled'}**.`);
      return;
    }

    // 2. CHANNEL
    if (subcommand === 'channel') {
      const channel = ctx.getChannel('channel', true);
      if (!channel || !channel.isTextBased()) {
        await ctx.editReply('❌ Please select a valid text channel.');
        return;
      }

      await prisma.boostConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { channelId: channel.id, enabled: true },
        create: { guildId: ctx.guild.id, channelId: channel.id, enabled: true },
      });

      await ctx.editReply(`✅ Boost channel set to <#${channel.id}> (and system enabled).`);
      return;
    }

    // 3. TEXT
    if (subcommand === 'text') {
      const content = ctx.getString('content', true);
      if (!content) {
        await ctx.editReply('❌ Please provide the boost message text.');
        return;
      }

      await prisma.boostConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { plainText: content, templateId: null },
        create: { guildId: ctx.guild.id, plainText: content },
      });

      await ctx.editReply(`✅ Boost message text updated!`);
      return;
    }

    // 4. TEMPLATE
    if (subcommand === 'template') {
      const templateName = ctx.getString('name', true);
      if (!templateName) {
        await ctx.editReply('❌ Please provide a template name.');
        return;
      }

      const template = await TemplateRepository.getByName(ctx.guild.id, templateName);
      if (!template) {
        await ctx.editReply(`❌ Template **"${templateName}"** not found. Create one with \`${ctx.prefix}embed create\`.`);
        return;
      }

      await prisma.boostConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { templateId: template.id },
        create: { guildId: ctx.guild.id, templateId: template.id },
      });

      await ctx.editReply(`✅ Linked template **"${templateName}"** to the boost system!`);
      return;
    }

    // 5. TEST
    if (subcommand === 'test') {
      const config = await prisma.boostConfig.findUnique({
        where: { guildId: ctx.guild.id },
      });

      if (!config || !config.channelId) {
        await ctx.editReply(`❌ No boost channel configured. Set one with \`${ctx.prefix}boost channel #channel\`.`);
        return;
      }

      const targetChannel = ctx.guild.channels.cache.get(config.channelId) as TextChannel | undefined;
      if (!targetChannel || !targetChannel.isTextBased()) {
        await ctx.editReply('❌ Configured boost channel no longer exists.');
        return;
      }

      const context = {
        user: ctx.user,
        member: ctx.member ?? undefined,
        guild: ctx.guild,
        extra: {
          boostCount: ctx.guild.premiumSubscriptionCount ?? 1,
        },
      };

      if (config.templateId) {
        const template = await TemplateRepository.getById(config.templateId);
        if (template) {
          const payload = MessageBuilder.buildPayload(
            {
              content: template.content || undefined,
              embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
              components: template.componentsData
                ? (template.componentsData as unknown as UniversalComponentData[][])
                : undefined,
            },
            context
          );
          await targetChannel.send(payload);
          await ctx.editReply(`✅ Test boost template sent to <#${targetChannel.id}>!`);
          return;
        }
      }

      const msg =
        config.plainText ||
        '🚀 **{user}** just boosted the server! Thank you for supporting **{server}**! We are now at **{boostCount}** boosts!';
      const payload = MessageBuilder.buildPayload({ content: msg }, context);
      await targetChannel.send(payload);
      await ctx.editReply(`✅ Test boost message sent to <#${targetChannel.id}>!`);
      return;
    }

    // 6. STATUS
    const config = await prisma.boostConfig.findUnique({
      where: { guildId: ctx.guild.id },
    });

    let templateName = 'None';
    if (config?.templateId) {
      const tmpl = await TemplateRepository.getById(config.templateId);
      if (tmpl) templateName = tmpl.name;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🚀 Boost Configuration — ${ctx.guild.name}`)
      .setColor(Colors.LuminousVividPink)
      .addFields(
        { name: 'Status', value: config?.enabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
        { name: 'Channel', value: config?.channelId ? `<#${config.channelId}>` : 'Not set', inline: true },
        { name: 'Linked Template', value: templateName, inline: true },
        {
          name: 'Plain Text',
          value: config?.plainText ? `\`${config.plainText.slice(0, 200)}\`` : 'Default boost text',
          inline: false,
        }
      )
      .setFooter({ text: `Test boost message: ${ctx.prefix}boost test` });

    await ctx.editReply({ embeds: [embed] });
  },
};
