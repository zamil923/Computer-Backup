interface RateLimitEntry {
  timestamps: number[];
}

export class SlidingWindowRateLimiter {
  private entries = new Map<string, RateLimitEntry>();
  private readonly windowMs: number;
  private readonly maxLimit: number;

  constructor(maxLimit: number, windowSeconds: number) {
    this.maxLimit = maxLimit;
    this.windowMs = windowSeconds * 1000;
  }

  /**
   * Check if action is rate limited and record current timestamp
   * Returns { isLimited: boolean, remaining: number, resetMs: number }
   */
  public check(key: string): { isLimited: boolean; count: number; resetMs: number } {
    const now = Date.now();
    let entry = this.entries.get(key);

    if (!entry) {
      entry = { timestamps: [] };
      this.entries.set(key, entry);
    }

    // Filter out timestamps outside current window
    const threshold = now - this.windowMs;
    entry.timestamps = entry.timestamps.filter(ts => ts > threshold);

    if (entry.timestamps.length >= this.maxLimit) {
      const oldest = entry.timestamps[0] ?? now;
      const resetMs = Math.max(0, oldest + this.windowMs - now);
      return { isLimited: true, count: entry.timestamps.length, resetMs };
    }

    entry.timestamps.push(now);
    return { isLimited: false, count: entry.timestamps.length, resetMs: this.windowMs };
  }

  /**
   * Reset rate limit for a specific key
   */
  public reset(key: string): void {
    this.entries.delete(key);
  }

  /**
   * Clean expired entries to prevent memory leaks
   */
  public cleanup(): void {
    const now = Date.now();
    const threshold = now - this.windowMs;
    for (const [key, entry] of this.entries.entries()) {
      entry.timestamps = entry.timestamps.filter(ts => ts > threshold);
      if (entry.timestamps.length === 0) {
        this.entries.delete(key);
      }
    }
  }
}
