import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';

describe('Project Scope Enforcement', () => {
  function scanDir(dir: string, fileList: string[] = []): string[] {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      if (file === 'node_modules' || file === 'dist' || file === '.git') continue;
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        scanDir(fullPath, fileList);
      } else {
        fileList.push(fullPath);
      }
    }
    return fileList;
  }

  it('must not contain Minecraft, RCON, or Pterodactyl files or modules', () => {
    const root = path.resolve(__dirname, '..');
    const allFiles = scanDir(root);

    const forbiddenTerms = [
      'minecraft',
      'pterodactyl',
      'rcon',
      'mcserver',
      'mc-server',
      'web-dashboard',
      'express',
      'fastify',
    ];

    for (const filePath of allFiles) {
      const lowerPath = filePath.toLowerCase();
      for (const term of forbiddenTerms) {
        expect(lowerPath.includes(term), `File path contains forbidden scope term: ${filePath}`).toBe(false);
      }

      // Check file content for imports of express/pterodactyl/rcon
      if (filePath.endsWith('.ts') && !filePath.includes('scopeEnforcement.test.ts')) {
        const content = fs.readFileSync(filePath, 'utf-8');
        expect(content.includes('rcon-client')).toBe(false);
        expect(content.includes('minecraft-server-util')).toBe(false);
        expect(content.includes('@pterodactyl')).toBe(false);
      }
    }
  });
});
