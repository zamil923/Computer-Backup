import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationRepository } from '../../repositories/moderationRepository.js';

export const warningsCommand: Command = {
  name: 'warnings',
  description: 'View or remove warnings for a member',
  category: 'Moderation',
  usage: 'warnings <@user|id> [remove <warningId>]',
  examples: [
    '/warnings user:@member',
    '/warnings remove warning_id:cm2xxxxxx',
    '^warnings @member',
    '^warnings remove cm2xxxxxx',
  ],
  requiredPermission: PermissionLevel.MODERATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View or manage user warnings')
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List warnings for a member')
        .addUserOption(opt => opt.setName('user').setDescription('Target member').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a warning by ID')
        .addStringOption(opt => opt.setName('warning_id').setDescription('Warning ID to remove').setRequired(true))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'list';

    if (subcommand === 'remove') {
      const warningId = ctx.getString('warning_id') || ctx.getString('id');
      if (!warningId) {
        await ctx.reply('❌ Please provide the warning ID to delete.');
        return;
      }

      await ctx.defer();
      const deleted = await ModerationRepository.deleteWarning(warningId).catch(() => null);
      if (!deleted) {
        await ctx.editReply('❌ Warning ID not found or already removed.');
        return;
      }

      await ctx.editReply(`✅ Warning \`${warningId}\` has been removed.`);
      return;
    }

    // Default: list warnings
    const user = await ctx.getUser('user', true);
    if (!user) {
      await ctx.reply('❌ Please specify a user to check warnings for.');
      return;
    }

    await ctx.defer();
    const warnings = await ModerationRepository.getWarnings(ctx.guild.id, user.id);

    if (warnings.length === 0) {
      await ctx.editReply(`ℹ️ **${user.tag}** has no active warnings on this server.`);
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`⚠️ Warnings for ${user.tag} (${warnings.length} total)`)
      .setColor(Colors.Yellow)
      .setThumbnail(user.displayAvatarURL())
      .setDescription(
        warnings
          .map(
            (w, i) =>
              `**${i + 1}. ID:** \`${w.id}\`\n• **Reason:** ${w.reason}\n• **Moderator:** <@${w.moderatorId}>\n• **Date:** <t:${Math.floor(w.createdAt.getTime() / 1000)}:R>`
          )
          .join('\n\n')
      )
      .setFooter({ text: `To remove a warning: ${ctx.prefix}warnings remove <warningId>` });

    await ctx.editReply({ embeds: [embed] });
  },
};
