import { describe, it, expect } from 'vitest';
import { VariableEngine } from '../src/utils/variables.js';

describe('VariableEngine', () => {
  it('should substitute user and server variables safely', () => {
    const text = 'Welcome {user} ({userId}) to {server}! Member count: {memberCount}.';
    const mockContext = {
      user: { username: 'DiscordMaster', id: '9876543210' } as any,
      guild: { name: 'Epic Community', memberCount: 1500 } as any,
    };

    const replaced = VariableEngine.replace(text, mockContext);
    expect(replaced).toBe('Welcome DiscordMaster (9876543210) to Epic Community! Member count: 1500.');
  });

  it('should not evaluate arbitrary code or expressions', () => {
    const malicious = 'Hello {process.exit(1)} and {__proto__}';
    const replaced = VariableEngine.replace(malicious, {});
    expect(replaced).toBe('Hello {process.exit(1)} and {__proto__}');
  });

  it('should recursively replace variables in deep object structures', () => {
    const data = {
      title: 'Greetings from {server}',
      description: 'Hello {username}!',
      fields: [{ name: 'ID', value: '{userId}' }],
    };

    const mockContext = {
      user: { username: 'Alex', id: '111' } as any,
      guild: { name: 'MainServer' } as any,
    };

    const result = VariableEngine.replaceDeep(data, mockContext);
    expect(result.title).toBe('Greetings from MainServer');
    expect(result.description).toBe('Hello Alex!');
    expect(result.fields[0]?.value).toBe('111');
  });
});
