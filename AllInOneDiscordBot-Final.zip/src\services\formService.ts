import {
  ButtonInteraction,
  ModalSubmitInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  Colors,
  TextChannel,
} from 'discord.js';
import { FormRepository } from '../repositories/formRepository.js';

export class FormService {
  public static async handleFormOpen(interaction: ButtonInteraction, formId: string) {
    if (!interaction.guild) return;

    const form = await FormRepository.getFormById(formId);
    if (!form) {
      await interaction.reply({ content: '❌ Form not found or deleted.', ephemeral: true });
      return;
    }

    if (!form.questions.length) {
      await interaction.reply({ content: '❌ This form has no questions.', ephemeral: true });
      return;
    }

    // Modal can only have up to 5 action rows. If a form has > 5 questions, we can't do it in a single modal natively.
    // For Session 2, we will limit to first 5 questions for modals to satisfy discord limits safely.
    const questions = form.questions.slice(0, 5);
    
    const modal = new ModalBuilder()
      .setCustomId(`form_submit_${form.id}`)
      .setTitle(form.name.substring(0, 45));

    for (const q of questions) {
      const input = new TextInputBuilder()
        .setCustomId(`q_${q.id}`)
        .setLabel(q.label.substring(0, 45))
        .setStyle(q.type === 'LONG_TEXT' ? TextInputStyle.Paragraph : TextInputStyle.Short)
        .setRequired(q.required);
      
      const row = new ActionRowBuilder<TextInputBuilder>().addComponents(input);
      modal.addComponents(row);
    }

    await interaction.showModal(modal);
  }

  public static async handleFormSubmit(interaction: ModalSubmitInteraction, formId: string) {
    if (!interaction.guild) return;
    
    const form = await FormRepository.getFormById(formId);
    if (!form) {
      await interaction.reply({ content: '❌ Form not found or deleted.', ephemeral: true });
      return;
    }

    const answers: Record<string, string> = {};
    const questions = form.questions.slice(0, 5);
    
    for (const q of questions) {
      try {
        const val = interaction.fields.getTextInputValue(`q_${q.id}`);
        answers[q.label] = val;
      } catch (e) {
        // Not provided
      }
    }

    const submission = await FormRepository.submitForm(
      interaction.guild.id,
      form.id,
      interaction.user.id,
      interaction.user.tag,
      answers
    );

    await interaction.reply({ content: '✅ Form submitted successfully.', ephemeral: true });

    // Handle Application routing
    const appConfig = await FormRepository.getApplicationConfig(form.id);
    if (appConfig && appConfig.reviewChannelId) {
      const reviewChannel = interaction.guild.channels.cache.get(appConfig.reviewChannelId) as TextChannel;
      if (reviewChannel && reviewChannel.isTextBased()) {
        const embed = new EmbedBuilder()
          .setTitle(`New Submission: ${form.name}`)
          .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
          .setColor(Colors.Orange)
          .setFooter({ text: `Submission ID: ${submission.id}` });
        
        let desc = '';
        for (const [q, a] of Object.entries(answers)) {
          desc += `**${q}**\n${a}\n\n`;
        }
        embed.setDescription(desc.substring(0, 4000));

        await reviewChannel.send({ embeds: [embed] }).catch(() => null);
      }
    }
  }
}
