import { prisma } from '../database/prisma.js';
import { AutoRole, RolePanel, RolePanelOption } from '@prisma/client';
import { GuildRepository } from './guildRepository.js';

export class RolePanelRepository {
  // --- Auto Roles ---

  public static async listAutoRoles(guildId: string): Promise<AutoRole[]> {
    return prisma.autoRole.findMany({
      where: { guildId },
    });
  }

  public static async addAutoRole(
    guildId: string,
    roleId: string,
    targetType = 'ALL',
    delaySeconds = 0
  ): Promise<AutoRole> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.autoRole.upsert({
      where: { guildId_roleId_targetType: { guildId, roleId, targetType } },
      update: { delaySeconds },
      create: { guildId, roleId, targetType, delaySeconds },
    });
  }

  public static async removeAutoRole(guildId: string, roleId: string, targetType = 'ALL'): Promise<AutoRole | null> {
    const existing = await prisma.autoRole.findUnique({
      where: { guildId_roleId_targetType: { guildId, roleId, targetType } },
    });
    if (!existing) return null;
    return prisma.autoRole.delete({
      where: { id: existing.id },
    });
  }

  // --- Role Panels ---

  public static async createPanel(
    guildId: string,
    data: {
      channelId: string;
      messageId?: string;
      title: string;
      description?: string;
      panelType?: 'BUTTON' | 'SELECT_MENU';
      minSelect?: number;
      maxSelect?: number;
      templateId?: string;
    }
  ): Promise<RolePanel> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.rolePanel.create({
      data: {
        guildId,
        channelId: data.channelId,
        messageId: data.messageId,
        title: data.title,
        description: data.description,
        panelType: data.panelType ?? 'BUTTON',
        minSelect: data.minSelect ?? 0,
        maxSelect: data.maxSelect ?? 1,
        templateId: data.templateId,
      },
    });
  }

  public static async getPanel(id: string) {
    return prisma.rolePanel.findUnique({
      where: { id },
      include: {
        options: {
          orderBy: { order: 'asc' },
        },
      },
    });
  }

  public static async listPanels(guildId: string) {
    return prisma.rolePanel.findMany({
      where: { guildId },
      include: {
        options: {
          orderBy: { order: 'asc' },
        },
      },
    });
  }

  public static async updatePanelMessageId(id: string, messageId: string): Promise<RolePanel> {
    return prisma.rolePanel.update({
      where: { id },
      data: { messageId },
    });
  }

  public static async addOptionToPanel(
    panelId: string,
    data: {
      roleId: string;
      label: string;
      emoji?: string;
      description?: string;
      buttonStyle?: string;
      requiredRoleIds?: string[];
      forbiddenRoleIds?: string[];
      order?: number;
    }
  ): Promise<RolePanelOption> {
    return prisma.rolePanelOption.create({
      data: {
        panelId,
        roleId: data.roleId,
        label: data.label,
        emoji: data.emoji,
        description: data.description,
        buttonStyle: data.buttonStyle ?? 'PRIMARY',
        requiredRoleIds: data.requiredRoleIds ?? [],
        forbiddenRoleIds: data.forbiddenRoleIds ?? [],
        order: data.order ?? 0,
      },
    });
  }

  public static async removeOption(optionId: string): Promise<RolePanelOption> {
    return prisma.rolePanelOption.delete({
      where: { id: optionId },
    });
  }

  public static async deletePanel(id: string): Promise<RolePanel> {
    return prisma.rolePanel.delete({
      where: { id },
    });
  }
}
