import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { FormRepository } from '../../repositories/formRepository.js';

export const applicationCommand: Command = {
  name: 'application',
  description: 'Manage applications (built on Forms)',
  category: 'Configuration',
  usage: 'application <subcommand>',
  examples: ['/application setup', '/application submissions'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('application')
    .setDescription('Manage applications')
    .addSubcommand(sub =>
      sub
        .setName('setup')
        .setDescription('Convert a form into an application')
        .addStringOption(opt => opt.setName('form').setDescription('Form name').setRequired(true))
        .addChannelOption(opt => opt.setName('review_channel').setDescription('Channel for reviews').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('submissions')
        .setDescription('View submissions for an application')
        .addStringOption(opt => opt.setName('form').setDescription('Form name').setRequired(true))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand();

    if (subcommand === 'setup') {
      const formName = ctx.getString('form', true) ?? '';
      const channel = ctx.getChannel('review_channel');

      const form = await FormRepository.getFormByName(ctx.guild.id, formName);
      if (!form) {
        await ctx.reply(`❌ Form **${formName}** not found.`);
        return;
      }

      await FormRepository.createApplicationConfig(ctx.guild.id, form.id, channel?.id);
      await ctx.reply(`✅ Application setup for **${formName}** updated.`);
    }

    if (subcommand === 'submissions') {
      const formName = ctx.getString('form', true) ?? '';
      const form = await FormRepository.getFormByName(ctx.guild.id, formName);
      if (!form) {
        await ctx.reply(`❌ Form **${formName}** not found.`);
        return;
      }

      const submissions = await FormRepository.getSubmissions(ctx.guild.id, form.id);
      if (!submissions.length) {
        await ctx.reply('No submissions found.');
        return;
      }

      const pending = submissions.filter(s => s.status === 'PENDING').length;
      
      const embed = new EmbedBuilder()
        .setTitle(`Submissions for ${form.name}`)
        .setColor(Colors.Blue)
        .setDescription(`Total: **${submissions.length}**\nPending: **${pending}**`);
      
      await ctx.reply({ embeds: [embed] });
    }
  }
};
