import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  ActionRowBuilder,
  StringSelectMenuBuilder,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { GuildRepository } from '../../repositories/guildRepository.js';

export const configCommand: Command = {
  name: 'config',
  description: 'Interactive server management control center and overview',
  category: 'Configuration',
  usage: 'config [prefix <newPrefix>]',
  examples: ['/config', '/config prefix:!', '^config', '^config prefix !'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Server control center and configuration overview')
    .addStringOption(opt =>
      opt.setName('prefix').setDescription('Change the command prefix for this server').setRequired(false)
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    await ctx.defer();
    const newPrefix = ctx.getString('prefix');

    if (newPrefix) {
      const cleanPrefix = newPrefix.trim();
      if (cleanPrefix.length > 5) {
        await ctx.editReply('❌ Prefix cannot exceed 5 characters.');
        return;
      }

      await GuildRepository.updatePrefix(ctx.guild.id, cleanPrefix);
      await ctx.editReply(`✅ Server command prefix has been updated to: \`${cleanPrefix}\``);
      return;
    }

    const guildConfig = await GuildRepository.get(ctx.guild.id);
    const prefix = guildConfig?.prefix || '^';

    const embed = new EmbedBuilder()
      .setTitle(`⚙️ Server Control Center — ${ctx.guild.name}`)
      .setColor(Colors.Blurple)
      .setDescription(
        `Manage bot settings directly from Discord without editing databases.\n` +
          `• **Current Prefix:** \`${prefix}\`\n` +
          `• **Setup Wizard:** Run \`${prefix}setup\` for automated onboarding.\n\n` +
          `Choose a module below to inspect or configure:`
      )
      .addFields(
        {
          name: '👋 Welcome / Leave / Boost',
          value: `• Welcome: ${guildConfig?.welcomeConfig?.enabled ? '🟢 Enabled' : '🔴 Disabled'}\n• Leave: ${guildConfig?.leaveConfig?.enabled ? '🟢 Enabled' : '🔴 Disabled'}\n• Boosts: ${guildConfig?.boostConfig?.enabled ? '🟢 Enabled' : '🔴 Disabled'}`,
          inline: true,
        },
        {
          name: '🛡️ Moderation & AutoMod',
          value: `• Mod Log: ${guildConfig?.loggingConfig?.modLogsChannelId ? `<#${guildConfig.loggingConfig.modLogsChannelId}>` : 'Not set'}\n• AutoMod: ${guildConfig?.autoModConfig ? 'Configured' : 'Defaults'}\n• Mod Cases: Recorded in DB`,
          inline: true,
        },
        {
          name: '🎫 Support Tickets',
          value: `• Tickets: Active\n• Transcripts: Enabled\n• Ratings: Enabled`,
          inline: true,
        },
        {
          name: '🔑 Authority & Roles',
          value: `• Admin Roles: ${guildConfig?.adminRoles.length ?? 0}\n• Mod Roles: ${guildConfig?.modRoles.length ?? 0}`,
          inline: true,
        }
      )
      .setFooter({ text: 'Select an option from the menu to jump directly to that module.' });

    const menu = new StringSelectMenuBuilder()
      .setCustomId('config_module_select')
      .setPlaceholder('Select a system to manage...')
      .addOptions([
        { label: 'Welcome System', value: 'welcome', emoji: '👋', description: 'Configure welcome channel and message' },
        { label: 'Leave System', value: 'leave', emoji: '🚪', description: 'Configure goodbye announcements' },
        { label: 'Boost Announcements', value: 'boost', emoji: '🚀', description: 'Configure server boost alerts' },
        { label: 'AutoMod Settings', value: 'automod', emoji: '🛡️', description: 'Anti-spam, filters, and word blacklist' },
        { label: 'Permissions & Staff', value: 'permissions', emoji: '🔑', description: 'Manage admin and mod roles' },
        { label: 'Support Tickets', value: 'tickets', emoji: '🎫', description: 'Ticket categories and panels' },
      ]);

    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);

    await ctx.editReply({
      embeds: [embed],
      components: [row],
    });
  },
};
