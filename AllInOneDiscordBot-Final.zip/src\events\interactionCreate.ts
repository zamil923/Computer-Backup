import { Interaction } from 'discord.js';
import { CommandRegistry } from '../commands/registry.js';
import { SlashCommandContext } from '../commands/context.js';
import { PermissionManager } from '../permissions/permissionManager.js';
import { ComponentRouter } from '../components/router.js';
import { logger } from '../utils/logger.js';

export async function handleInteractionCreate(interaction: Interaction): Promise<void> {
  try {
    // 1. Slash Commands
    if (interaction.isChatInputCommand()) {
      const command = CommandRegistry.get(interaction.commandName);
      if (!command) {
        await interaction.reply({ content: '❌ Unknown command.', ephemeral: true });
        return;
      }

      const ctx = new SlashCommandContext(interaction);
      const permCheck = await PermissionManager.checkCommandAccess(command, ctx);

      if (!permCheck.allowed) {
        await ctx.reply({
          content: `⛔ **Access Denied:** ${permCheck.reason ?? 'You do not have permission to execute this command.'}`,
          ephemeral: true,
        });
        return;
      }

      try {
        await command.execute(ctx);
      } catch (err) {
        logger.error('CommandHandler', `Error executing slash command /${command.name}`, err);
        const errorMsg = '⚠️ An internal error occurred while executing this command.';
        if (interaction.deferred || interaction.replied) {
          await interaction.editReply(errorMsg).catch(() => null);
        } else {
          await interaction.reply({ content: errorMsg, ephemeral: true }).catch(() => null);
        }
      }
      return;
    }

    // 2. Buttons, Select Menus, Modals
    await ComponentRouter.handle(interaction);
  } catch (err) {
    logger.error('InteractionHandler', 'Unhandled interaction error', err);
  }
}
