import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  AttachmentBuilder,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ServerTemplateService } from '../../services/serverTemplateService.js';
import { ServerTemplateRepository } from '../../repositories/serverTemplateRepository.js';

// Active confirmation tokens: token -> { guildId, executorId, expiry, mode, templateId }
const confirmTokens = new Map<string, {
  guildId: string;
  executorId: string;
  expiry: number;
  mode: 'safe' | 'full';
  templateId: string;
}>();

export const serverTemplateCommand: Command = {
  name: 'template',
  description: 'Manage server structure templates and backups',
  category: 'Server Templates',
  usage: 'template <subcommand>',
  examples: ['/template export', '/template backup', '/template list', '^template list'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('template')
    .setDescription('Server structure templates and backups')
    .addSubcommand(sub =>
      sub
        .setName('export')
        .setDescription('Export the current server structure as a template')
        .addStringOption(opt => opt.setName('name').setDescription('Template name').setRequired(true))
        .addStringOption(opt => opt.setName('description').setDescription('Template description').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('backup')
        .setDescription('Create a structural backup of the server')
        .addStringOption(opt => opt.setName('name').setDescription('Backup name').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List saved templates and backups')
    )
    .addSubcommand(sub =>
      sub
        .setName('preview')
        .setDescription('Preview what a template contains')
        .addStringOption(opt => opt.setName('id').setDescription('Template ID').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('delete')
        .setDescription('Delete a saved template')
        .addStringOption(opt => opt.setName('id').setDescription('Template ID').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('apply')
        .setDescription('Apply a template in Safe Build mode (non-destructive)')
        .addStringOption(opt => opt.setName('id').setDescription('Template ID').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('rebuild')
        .setDescription('[SERVER OWNER ONLY] Full destructive rebuild from a template')
        .addStringOption(opt => opt.setName('id').setDescription('Template ID').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('confirm')
        .setDescription('[SERVER OWNER ONLY] Confirm a pending destructive rebuild')
        .addStringOption(opt => opt.setName('token').setDescription('Confirmation token').setRequired(true))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;
    await ctx.defer();

    const sub = ctx.getSubcommand();

    // ── EXPORT ──────────────────────────────────────────────

    if (sub === 'export' || sub === 'backup') {
      const isBackup = sub === 'backup';
      const name = ctx.getString('name') ?? `Backup-${new Date().toISOString().split('T')[0]}`;
      const description = ctx.getString('description') ?? undefined;

      const data = await ServerTemplateService.exportGuild(ctx.guild);

      const saved = await ServerTemplateRepository.createTemplate(
        ctx.guild.id, name, ctx.user.id, data, isBackup, description
      );
      await ServerTemplateRepository.logOperation(
        ctx.guild.id, sub.toUpperCase(), ctx.user.id, 'SUCCESS', saved.id,
        `${isBackup ? 'Backup' : 'Template'} "${name}" created: ${data.roles.length} roles, ${data.channels.length} channels`
      );

      // Send as file attachment
      const json = JSON.stringify(data, null, 2);
      const attachment = new AttachmentBuilder(Buffer.from(json), { name: `${name.replace(/\s+/g, '_')}.json` });

      await ctx.editReply({
        content: `✅ ${isBackup ? 'Backup' : 'Template'} **${name}** saved (ID: \`${saved.id}\`). Attach this file somewhere safe.`,
        files: [attachment],
      });
    }

    // ── LIST ────────────────────────────────────────────────

    if (sub === 'list') {
      const all = await ServerTemplateRepository.listTemplates(ctx.guild.id);
      if (!all.length) {
        await ctx.editReply('No templates or backups saved.');
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle('Saved Server Templates & Backups')
        .setColor(Colors.Blue)
        .setDescription(
          all.map(t =>
            `**${t.isBackup ? '📦' : '📄'} ${t.name}** (ID: \`${t.id.slice(0, 8)}\`)\n` +
            `Created: <t:${Math.floor(t.createdAt.getTime() / 1000)}:R> by <@${t.creatorId}>`
          ).join('\n\n')
        );

      await ctx.editReply({ embeds: [embed] });
    }

    // ── PREVIEW ─────────────────────────────────────────────

    if (sub === 'preview') {
      const id = ctx.getString('id', true) ?? '';
      const template = await ServerTemplateRepository.getTemplate(id);
      if (!template || template.guildId !== ctx.guild.id) {
        await ctx.editReply('❌ Template not found.');
        return;
      }

      const data = template.data as any;
      const roles = Array.isArray(data.roles) ? data.roles.length : 0;
      const channels = Array.isArray(data.channels) ? data.channels.length : 0;
      const categories = Array.isArray(data.channels) ? data.channels.filter((c: any) => c.type === 4).length : 0;

      const embed = new EmbedBuilder()
        .setTitle(`Preview: ${template.name}`)
        .setColor(Colors.Blue)
        .addFields(
          { name: 'Roles', value: `${roles}`, inline: true },
          { name: 'Channels', value: `${channels}`, inline: true },
          { name: 'Categories', value: `${categories}`, inline: true },
          { name: 'Version', value: data.version ?? '?', inline: true },
          { name: 'Created', value: `<t:${Math.floor(template.createdAt.getTime() / 1000)}:f>`, inline: true },
        )
        .setDescription('Use `/template apply id:<id>` for safe build or `/template rebuild` for full rebuild (server owner only).');

      await ctx.editReply({ embeds: [embed] });
    }

    // ── DELETE ──────────────────────────────────────────────

    if (sub === 'delete') {
      const id = ctx.getString('id', true) ?? '';
      const template = await ServerTemplateRepository.getTemplate(id);
      if (!template || template.guildId !== ctx.guild.id) {
        await ctx.editReply('❌ Template not found.');
        return;
      }

      await ServerTemplateRepository.deleteTemplate(id);
      await ctx.editReply(`✅ Template **${template.name}** deleted.`);
    }

    // ── SAFE BUILD (APPLY) ───────────────────────────────────

    if (sub === 'apply') {
      const id = ctx.getString('id', true) ?? '';
      const template = await ServerTemplateRepository.getTemplate(id);
      if (!template || template.guildId !== ctx.guild.id) {
        await ctx.editReply('❌ Template not found.');
        return;
      }

      await ctx.editReply(`🔄 Applying template **${template.name}** in **Safe Build** mode…\nThis will create missing channels and roles without deleting existing ones.`);

      try {
        await ServerTemplateService.safeBuild(ctx.guild, template.data as any);
        await ServerTemplateRepository.logOperation(ctx.guild.id, 'SAFE_BUILD', ctx.user.id, 'SUCCESS', id, `Safe build completed`);
        await ctx.followUp('✅ Safe Build complete. Missing resources have been created.');
      } catch (err) {
        await ServerTemplateRepository.logOperation(ctx.guild.id, 'SAFE_BUILD', ctx.user.id, 'FAILED', id, String(err));
        await ctx.followUp('❌ Safe Build encountered errors. Check the bot console log for details.');
      }
    }

    // ── CONFIRM REBUILD ──────────────────────────────────────

    if (sub === 'rebuild') {
      // Must be server owner
      if (ctx.user.id !== ctx.guild.ownerId) {
        await ctx.editReply('❌ **Full Rebuild** is restricted to the **server owner** only. Discord Administrator permission is not sufficient.');
        return;
      }

      const id = ctx.getString('id', true) ?? '';
      const template = await ServerTemplateRepository.getTemplate(id);
      if (!template || template.guildId !== ctx.guild.id) {
        await ctx.editReply('❌ Template not found.');
        return;
      }

      // Create backup before destructive op
      const backupData = await ServerTemplateService.exportGuild(ctx.guild);
      const backup = await ServerTemplateRepository.createTemplate(
        ctx.guild.id, `Pre-Rebuild-Backup-${Date.now()}`, ctx.user.id, backupData, true
      );

      // Generate a time-limited confirmation token (5 minutes)
      const token = Math.random().toString(36).substring(2, 10).toUpperCase();
      confirmTokens.set(token, {
        guildId: ctx.guild.id,
        executorId: ctx.user.id,
        expiry: Date.now() + 5 * 60 * 1000,
        mode: 'full',
        templateId: id,
      });

      const embed = new EmbedBuilder()
        .setTitle('⚠️ FULL REBUILD CONFIRMATION REQUIRED')
        .setColor(Colors.Red)
        .setDescription(
          `You are about to perform a **FULL REBUILD** of **${ctx.guild.name}** using template **${template.name}**.\n\n` +
          `**This is a destructive operation that will:**\n` +
          `• Create roles, channels, and categories from the template\n` +
          `• **Delete** channels and roles that do not exist in the template\n\n` +
          `**Backup saved:** ID \`${backup.id}\`\n\n` +
          `To confirm, run:\n\`/template confirm token:${token}\`\n\n` +
          `⏰ This token expires in **5 minutes**. It can only be used once.`
        );

      await ctx.editReply({ embeds: [embed] });
    }

    // ── FULL REBUILD (subcommand 'rebuild') ──────────────────

    if (sub === 'confirm') {
      if (ctx.user.id !== ctx.guild.ownerId) {
        await ctx.editReply('❌ Only the **server owner** can confirm a rebuild.');
        return;
      }

      const token = (ctx.getString('token', true) ?? '').toUpperCase();
      const pending = confirmTokens.get(token);

      if (!pending) {
        await ctx.editReply('❌ Invalid or expired confirmation token.');
        return;
      }

      if (pending.guildId !== ctx.guild.id) {
        await ctx.editReply('❌ This token is not valid for this server.');
        return;
      }

      if (pending.executorId !== ctx.user.id) {
        await ctx.editReply('❌ Only the user who initiated the rebuild can confirm it.');
        return;
      }

      if (Date.now() > pending.expiry) {
        confirmTokens.delete(token);
        await ctx.editReply('❌ Confirmation token has expired. Run `/template rebuild` again.');
        return;
      }

      // Consume the token immediately to prevent double-execution
      confirmTokens.delete(token);

      const template = await ServerTemplateRepository.getTemplate(pending.templateId);
      if (!template) {
        await ctx.editReply('❌ The template no longer exists.');
        return;
      }

      await ctx.editReply('🔄 **Full Rebuild initiated.** Creating roles → categories → channels → applying permissions → removing obsolete resources…');

      try {
        await ServerTemplateService.fullRebuild(ctx.guild, template.data as any);
        await ServerTemplateRepository.logOperation(ctx.guild.id, 'FULL_REBUILD', ctx.user.id, 'SUCCESS', pending.templateId, 'Full rebuild completed');
        await ctx.followUp('✅ **Full Rebuild complete.**');
      } catch (err) {
        await ServerTemplateRepository.logOperation(ctx.guild.id, 'FULL_REBUILD', ctx.user.id, 'FAILED', pending.templateId, String(err));
        await ctx.followUp('❌ Full Rebuild encountered errors. Check bot console for details. A pre-rebuild backup was saved.');
      }
    }
  },
};
