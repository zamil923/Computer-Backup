import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const unbanCommand: Command = {
  name: 'unban',
  description: 'Unban a user from the server by user ID',
  category: 'Moderation',
  usage: 'unban <userId> [reason]',
  examples: ['/unban user_id:1234567890 reason:Appeal accepted', '^unban 1234567890 Appeal accepted'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.BanMembers],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user from the server')
    .addStringOption(opt => opt.setName('user_id').setDescription('Discord User ID to unban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the unban').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member) return;

    const userId = ctx.getString('user_id') || ctx.getString('user');
    if (!userId) {
      await ctx.reply('❌ Please provide the user ID to unban.');
      return;
    }

    const cleanId = userId.replace(/[<@!>]/g, '');
    const reason = ctx.getString('reason') || 'No reason provided';
    await ctx.defer();

    const result = await ModerationService.unban(ctx.guild, ctx.member, cleanId, reason);
    await ctx.editReply(result.message);
  },
};
