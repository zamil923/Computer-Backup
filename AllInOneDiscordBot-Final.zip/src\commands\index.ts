import { CommandRegistry } from './registry.js';
import { pingCommand } from './general/ping.js';
import { helpCommand } from './general/help.js';
import { statsCommand } from './general/stats.js';
import { banCommand } from './moderation/ban.js';
import { unbanCommand } from './moderation/unban.js';
import { kickCommand } from './moderation/kick.js';
import { timeoutCommand } from './moderation/timeout.js';
import { warnCommand } from './moderation/warn.js';
import { warningsCommand } from './moderation/warnings.js';
import { purgeCommand } from './moderation/purge.js';
import { slowmodeCommand } from './moderation/slowmode.js';
import { lockCommand } from './moderation/lock.js';
import { unlockCommand } from './moderation/unlock.js';
import { casesCommand } from './moderation/cases.js';
import { automodCommand } from './automod/automod.js';
import { blacklistCommand } from './automod/blacklist.js';
import { embedCommand } from './embeds/embed.js';
import { ticketCommand } from './tickets/ticket.js';
import { welcomeCommand } from './welcome/welcome.js';
import { leaveCommand } from './welcome/leave.js';
import { boostCommand } from './welcome/boost.js';
import { autoroleCommand } from './roles/autorole.js';
import { rolepanelCommand } from './roles/rolepanel.js';
import { autoresponderCommand } from './autoresponder/autoresponder.js';
import { permissionsCommand } from './configuration/permissions.js';
import { configCommand } from './configuration/config.js';
import { setupCommand } from './setup/setup.js';
import { formCommand } from './configuration/form.js';
import { applicationCommand } from './configuration/application.js';
import { serverTemplateCommand } from './configuration/template.js';
import { rankCommand } from './leveling/rank.js';
import { leaderboardCommand } from './leveling/leaderboard.js';
import { levelCommand } from './leveling/level.js';
import { honeypotCommand } from './automod/honeypot.js';
import { ownerCommand } from './owner/owner.js';
import { logger } from '../utils/logger.js';

export function registerAllCommands(): void {
  const commands = [
    // General
    pingCommand,
    helpCommand,
    statsCommand,

    // Moderation
    banCommand,
    unbanCommand,
    kickCommand,
    timeoutCommand,
    warnCommand,
    warningsCommand,
    purgeCommand,
    slowmodeCommand,
    lockCommand,
    unlockCommand,
    casesCommand,

    // AutoMod / Security
    automodCommand,
    blacklistCommand,

    // Embeds
    embedCommand,

    // Tickets
    ticketCommand,

    // Welcome / Leave / Boost
    welcomeCommand,
    leaveCommand,
    boostCommand,

    // Roles
    autoroleCommand,
    rolepanelCommand,

    // Auto Responder
    autoresponderCommand,

    // Configuration & Setup
    permissionsCommand,
    configCommand,
    setupCommand,
    formCommand,
    applicationCommand,
    serverTemplateCommand,

    // Leveling
    rankCommand,
    leaderboardCommand,
    levelCommand,

    // Security
    honeypotCommand,

    // Owner
    ownerCommand,
  ];

  for (const cmd of commands) {
    CommandRegistry.register(cmd);
  }

  logger.info('CommandLoader', `Registered all ${commands.length} core commands into CommandRegistry.`);
}
