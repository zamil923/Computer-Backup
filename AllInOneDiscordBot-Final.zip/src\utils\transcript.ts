import { Message, Guild, Channel } from 'discord.js';

export interface TranscriptMetadata {
  ticketId: string;
  guild: Guild;
  channel: Channel;
  openerTag: string;
  openerId: string;
  closedByTag?: string;
  createdAt: Date;
  closedAt: Date;
  rating?: number | null;
  ratingFeedback?: string | null;
}

export class TranscriptGenerator {
  /**
   * Escape HTML entities to prevent XSS in transcripts
   */
  public static escapeHtml(text: string): string {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /**
   * Generate an offline standalone HTML transcript document
   */
  public static generateHtml(messages: Message[], meta: TranscriptMetadata): string {
    const formattedMessages = messages
      .slice()
      .sort((a, b) => a.createdTimestamp - b.createdTimestamp)
      .map(msg => {
        const time = msg.createdAt.toISOString().replace('T', ' ').slice(0, 19);
        const authorTag = TranscriptGenerator.escapeHtml(msg.author.tag);
        const authorAvatar = msg.author.displayAvatarURL({ size: 64 });
        const content = TranscriptGenerator.escapeHtml(msg.content);
        const isBot = msg.author.bot ? `<span class="badge">BOT</span>` : '';

        let attachmentsHtml = '';
        if (msg.attachments.size > 0) {
          attachmentsHtml = '<div class="attachments">' +
            msg.attachments
              .map(att => {
                const name = TranscriptGenerator.escapeHtml(att.name);
                const url = att.url;
                if (att.contentType?.startsWith('image/')) {
                  return `<a href="${url}" target="_blank"><img class="att-img" src="${url}" alt="${name}" /></a>`;
                }
                return `<div class="att-file"><a href="${url}" target="_blank">📎 ${name}</a></div>`;
              })
              .join('') +
            '</div>';
        }

        let embedsHtml = '';
        if (msg.embeds.length > 0) {
          embedsHtml = '<div class="embeds">' +
            msg.embeds
              .map(e => {
                const title = e.title ? `<div class="embed-title">${TranscriptGenerator.escapeHtml(e.title)}</div>` : '';
                const desc = e.description ? `<div class="embed-desc">${TranscriptGenerator.escapeHtml(e.description)}</div>` : '';
                return `<div class="embed-box">${title}${desc}</div>`;
              })
              .join('') +
            '</div>';
        }

        return `
        <div class="message">
          <img class="avatar" src="${authorAvatar}" alt="${authorTag}" />
          <div class="msg-body">
            <div class="msg-header">
              <span class="author">${authorTag}</span>
              ${isBot}
              <span class="timestamp">${time}</span>
            </div>
            ${content ? `<div class="content">${content}</div>` : ''}
            ${attachmentsHtml}
            ${embedsHtml}
          </div>
        </div>`;
      })
      .join('\n');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ticket Transcript - ${TranscriptGenerator.escapeHtml(meta.ticketId)}</title>
  <style>
    body { background-color: #313338; color: #dbdee1; font-family: 'gg sans', 'Helvetica Neue', Arial, sans-serif; margin: 0; padding: 20px; }
    .header { background: #2b2d31; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #5865f2; }
    .header h1 { margin: 0 0 10px 0; font-size: 20px; color: #f2f3f5; }
    .meta-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; font-size: 13px; color: #949ba4; }
    .meta-item strong { color: #f2f3f5; }
    .message { display: flex; gap: 16px; padding: 8px 12px; margin-bottom: 4px; border-radius: 4px; }
    .message:hover { background-color: #2e3035; }
    .avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
    .msg-body { flex: 1; }
    .msg-header { margin-bottom: 4px; }
    .author { font-weight: 600; color: #f2f3f5; font-size: 15px; margin-right: 6px; }
    .badge { background: #5865f2; color: #fff; font-size: 10px; padding: 2px 4px; border-radius: 3px; font-weight: 700; margin-right: 6px; }
    .timestamp { font-size: 11px; color: #949ba4; }
    .content { font-size: 14px; line-height: 1.4; color: #dbdee1; white-space: pre-wrap; word-break: break-word; }
    .attachments { margin-top: 8px; }
    .att-img { max-width: 400px; max-height: 300px; border-radius: 6px; margin-top: 4px; display: block; }
    .att-file a { color: #00a8fc; text-decoration: none; font-size: 13px; }
    .embed-box { border-left: 4px solid #5865f2; background: #2b2d31; padding: 12px; border-radius: 4px; margin-top: 8px; max-width: 520px; }
    .embed-title { font-weight: 600; color: #f2f3f5; margin-bottom: 4px; }
    .embed-desc { font-size: 13px; color: #dbdee1; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Ticket Transcript: ${TranscriptGenerator.escapeHtml(meta.ticketId)}</h1>
    <div class="meta-grid">
      <div class="meta-item"><strong>Server:</strong> ${TranscriptGenerator.escapeHtml(meta.guild.name)}</div>
      <div class="meta-item"><strong>Opened By:</strong> ${TranscriptGenerator.escapeHtml(meta.openerTag)} (${meta.openerId})</div>
      <div class="meta-item"><strong>Closed By:</strong> ${TranscriptGenerator.escapeHtml(meta.closedByTag || 'System')}</div>
      <div class="meta-item"><strong>Opened At:</strong> ${meta.createdAt.toISOString()}</div>
      <div class="meta-item"><strong>Closed At:</strong> ${meta.closedAt.toISOString()}</div>
      <div class="meta-item"><strong>Total Messages:</strong> ${messages.length}</div>
      ${meta.rating ? `<div class="meta-item"><strong>Rating:</strong> ${'⭐'.repeat(meta.rating)} (${meta.rating}/5)</div>` : ''}
      ${meta.ratingFeedback ? `<div class="meta-item"><strong>Feedback:</strong> ${TranscriptGenerator.escapeHtml(meta.ratingFeedback)}</div>` : ''}
    </div>
  </div>
  <div class="chat-log">
    ${formattedMessages}
  </div>
</body>
</html>`;
  }

  /**
   * Generate plain text transcript
   */
  public static generateText(messages: Message[], meta: TranscriptMetadata): string {
    const lines = [
      `=== TICKET TRANSCRIPT ===`,
      `Ticket ID: ${meta.ticketId}`,
      `Guild: ${meta.guild.name} (${meta.guild.id})`,
      `Opener: ${meta.openerTag} (${meta.openerId})`,
      `Closed By: ${meta.closedByTag || 'System'}`,
      `Opened At: ${meta.createdAt.toISOString()}`,
      `Closed At: ${meta.closedAt.toISOString()}`,
      `Messages: ${messages.length}`,
      meta.rating ? `Rating: ${meta.rating}/5` : '',
      meta.ratingFeedback ? `Feedback: ${meta.ratingFeedback}` : '',
      `=========================\n`,
    ].filter(l => l !== '');

    const sorted = messages.slice().sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    for (const msg of sorted) {
      const time = msg.createdAt.toISOString().replace('T', ' ').slice(0, 19);
      lines.push(`[${time}] ${msg.author.tag}: ${msg.content}`);
      for (const att of msg.attachments.values()) {
        lines.push(`  [Attachment: ${att.name} -> ${att.url}]`);
      }
    }

    return lines.join('\n');
  }
}
