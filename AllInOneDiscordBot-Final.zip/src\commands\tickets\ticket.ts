import {
  SlashCommandBuilder,
  TextChannel,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { TicketService } from '../../services/ticketService.js';
import { TicketRepository } from '../../repositories/ticketRepository.js';

export const ticketCommand: Command = {
  name: 'ticket',
  description: 'Manage support tickets, panels, and active ticket channels',
  category: 'Tickets',
  usage: 'ticket <create|close|claim|unclaim|add|remove|panel|category> [options]',
  examples: [
    '/ticket create category:Billing',
    '/ticket close reason:Issue resolved',
    '/ticket claim',
    '/ticket add user:@collaborator',
    '/ticket panel create title:"Support" description:"Click to open ticket"',
    '^ticket close',
    '^ticket claim',
    '^ticket add @collaborator',
  ],
  requiredPermission: PermissionLevel.EVERYONE,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Manage support tickets and channels')
    .addSubcommand(sub => sub.setName('create').setDescription('Open a new support ticket'))
    .addSubcommand(sub =>
      sub
        .setName('close')
        .setDescription('Close the current ticket channel')
        .addStringOption(opt => opt.setName('reason').setDescription('Reason for closing').setRequired(false))
    )
    .addSubcommand(sub => sub.setName('claim').setDescription('Claim the current ticket as staff'))
    .addSubcommand(sub => sub.setName('unclaim').setDescription('Unclaim the current ticket'))
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add a user to the current ticket')
        .addUserOption(opt => opt.setName('user').setDescription('User to add').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a user from the current ticket')
        .addUserOption(opt => opt.setName('user').setDescription('User to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('panel')
        .setDescription('Post an interactive ticket creation panel')
        .addStringOption(opt => opt.setName('title').setDescription('Panel title').setRequired(true))
        .addStringOption(opt => opt.setName('description').setDescription('Panel description').setRequired(true))
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to post in').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('category')
        .setDescription('Create a ticket category')
        .addStringOption(opt => opt.setName('name').setDescription('Category name').setRequired(true))
        .addStringOption(opt => opt.setName('emoji').setDescription('Emoji for category button').setRequired(false))
    ),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member || !ctx.channel) return;

    const subcommand = ctx.getSubcommand() || 'create';
    await ctx.defer();

    // 1. CREATE TICKET
    if (subcommand === 'create') {
      const res = await TicketService.createTicket(ctx.guild, ctx.member);
      await ctx.editReply(res.message);
      return;
    }

    // 2. CLOSE TICKET
    if (subcommand === 'close') {
      const reason = ctx.getString('reason') || 'Resolved by user/staff';
      const res = await TicketService.closeTicket(ctx.channel as TextChannel, ctx.member, reason);
      await ctx.editReply(res.message);
      return;
    }

    // 3. CLAIM
    if (subcommand === 'claim') {
      const res = await TicketService.claimTicket(ctx.channel as TextChannel, ctx.member);
      await ctx.editReply(res.message);
      return;
    }

    // 4. UNCLAIM
    if (subcommand === 'unclaim') {
      const res = await TicketService.unclaimTicket(ctx.channel as TextChannel, ctx.member);
      await ctx.editReply(res.message);
      return;
    }

    // 5. ADD MEMBER
    if (subcommand === 'add') {
      const user = await ctx.getUser('user', true);
      if (!user) {
        await ctx.editReply('❌ Please specify a user to add.');
        return;
      }
      const res = await TicketService.addMember(ctx.channel as TextChannel, user);
      await ctx.editReply(res.message);
      return;
    }

    // 6. REMOVE MEMBER
    if (subcommand === 'remove') {
      const user = await ctx.getUser('user', true);
      if (!user) {
        await ctx.editReply('❌ Please specify a user to remove.');
        return;
      }
      const res = await TicketService.removeMember(ctx.channel as TextChannel, user);
      await ctx.editReply(res.message);
      return;
    }

    // 7. POST PANEL (Admin only)
    if (subcommand === 'panel') {
      const title = ctx.getString('title', true) || 'Support Tickets';
      const description = ctx.getString('description', true) || 'Click the button below to create a support ticket.';
      const channel = (ctx.getChannel('channel') ?? ctx.channel) as TextChannel;

      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(Colors.Blue)
        .setFooter({ text: 'Customer Support' });

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_create_default')
          .setLabel('Open Ticket')
          .setEmoji('🎫')
          .setStyle(ButtonStyle.Primary)
      );

      const sent = await channel.send({ embeds: [embed], components: [row] });
      await TicketRepository.createPanel(ctx.guild.id, {
        channelId: channel.id,
        messageId: sent.id,
        title,
        description,
        categoryIds: [],
      });

      await ctx.editReply(`✅ Ticket panel created and posted in <#${channel.id}>!`);
      return;
    }

    // 8. CREATE CATEGORY
    if (subcommand === 'category') {
      const catName = ctx.getString('name', true);
      const emoji = ctx.getString('emoji') || '🎫';

      if (!catName) {
        await ctx.editReply('❌ Please specify a category name.');
        return;
      }

      await TicketRepository.createCategory(ctx.guild.id, {
        name: catName,
        emoji,
      });

      await ctx.editReply(`✅ Created ticket category **${catName}** with icon ${emoji}.`);
      return;
    }

    await ctx.editReply('❌ Unknown subcommand.');
  },
};
