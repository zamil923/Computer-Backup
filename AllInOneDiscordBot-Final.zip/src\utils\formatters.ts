export class Formatters {
  /**
   * Parse duration string like "10s", "5m", "2h", "7d", "1w" into seconds
   */
  public static parseDuration(str: string): number | null {
    if (!str) return null;
    const match = str.trim().match(/^(\d+)\s*(s|m|h|d|w)?$/i);
    if (!match) return null;

    const val = parseInt(match[1] ?? '0', 10);
    const unit = (match[2] ?? 's').toLowerCase();

    switch (unit) {
      case 's':
        return val;
      case 'm':
        return val * 60;
      case 'h':
        return val * 3600;
      case 'd':
        return val * 86400;
      case 'w':
        return val * 604800;
      default:
        return null;
    }
  }

  /**
   * Format seconds into human readable duration (e.g. "2h 30m")
   */
  public static formatDuration(seconds: number): string {
    if (seconds <= 0) return '0s';
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts: string[] = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (secs > 0 || parts.length === 0) parts.push(`${secs}s`);

    return parts.join(' ');
  }

  /**
   * Truncate text with ellipsis
   */
  public static truncate(text: string, maxLength: number): string {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength - 3) + '...';
  }
}
