import { GuildMember } from 'discord.js';
import { WelcomeService } from '../services/welcomeService.js';
import { logger } from '../utils/logger.js';

export async function handleGuildMemberAdd(member: GuildMember): Promise<void> {
  try {
    await WelcomeService.handleMemberAdd(member);
  } catch (err) {
    logger.error('EventHandler', `Error handling guildMemberAdd in ${member.guild.id}`, err);
  }
}
