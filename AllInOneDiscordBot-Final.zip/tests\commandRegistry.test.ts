import { describe, it, expect, beforeAll } from 'vitest';
import { CommandRegistry } from '../src/commands/registry.js';
import { registerAllCommands } from '../src/commands/index.js';

describe('CommandRegistry', () => {
  beforeAll(() => {
    registerAllCommands();
  });

  it('should register all expected Session 1 core commands', () => {
    const commands = CommandRegistry.getAll();
    expect(commands.size).toBeGreaterThanOrEqual(18);

    // Verify key commands exist
    expect(CommandRegistry.get('help')).toBeDefined();
    expect(CommandRegistry.get('ban')).toBeDefined();
    expect(CommandRegistry.get('unban')).toBeDefined();
    expect(CommandRegistry.get('kick')).toBeDefined();
    expect(CommandRegistry.get('timeout')).toBeDefined();
    expect(CommandRegistry.get('warn')).toBeDefined();
    expect(CommandRegistry.get('warnings')).toBeDefined();
    expect(CommandRegistry.get('purge')).toBeDefined();
    expect(CommandRegistry.get('slowmode')).toBeDefined();
    expect(CommandRegistry.get('lock')).toBeDefined();
    expect(CommandRegistry.get('unlock')).toBeDefined();
    expect(CommandRegistry.get('cases')).toBeDefined();
    expect(CommandRegistry.get('ticket')).toBeDefined();
    expect(CommandRegistry.get('embed')).toBeDefined();
    expect(CommandRegistry.get('welcome')).toBeDefined();
    expect(CommandRegistry.get('leave')).toBeDefined();
    expect(CommandRegistry.get('boost')).toBeDefined();
    expect(CommandRegistry.get('autorole')).toBeDefined();
    expect(CommandRegistry.get('rolepanel')).toBeDefined();
    expect(CommandRegistry.get('automod')).toBeDefined();
    expect(CommandRegistry.get('blacklist')).toBeDefined();
    expect(CommandRegistry.get('autoresponder')).toBeDefined();
    expect(CommandRegistry.get('config')).toBeDefined();
    expect(CommandRegistry.get('setup')).toBeDefined();
    expect(CommandRegistry.get('permissions')).toBeDefined();
    expect(CommandRegistry.get('owner')).toBeDefined();
  });

  it('should generate valid Slash Command JSON definitions without throwing', () => {
    const slashData = CommandRegistry.getSlashCommandsData();
    expect(slashData.length).toBe(CommandRegistry.getAll().size);

    for (const item of slashData) {
      expect(item.name).toBeTruthy();
      expect(item.description).toBeTruthy();
    }
  });

  it('should categorize commands properly', () => {
    const categories = CommandRegistry.getCategories();
    expect(categories).toContain('Moderation');
    expect(categories).toContain('General');
    expect(categories).toContain('Tickets');
    expect(categories).toContain('AutoMod / Security');
    expect(categories).toContain('Welcome / Leave / Boost');
    expect(categories).toContain('Roles');
    expect(categories).toContain('Embeds & Messages');
    expect(categories).toContain('Configuration');
    expect(categories).toContain('Owner');
  });
});
