import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { AutoModRepository } from '../../repositories/autoModRepository.js';

export const automodCommand: Command = {
  name: 'automod',
  description: 'Configure automated server moderation filters and protections',
  category: 'AutoMod / Security',
  usage: 'automod <status|enable|disable> <module: spam|repeats|mentions|invites|links|caps|words>',
  examples: [
    '/automod status',
    '/automod enable module:invites',
    '/automod disable module:links',
    '^automod status',
    '^automod enable spam',
    '^automod disable caps',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure automated moderation')
    .addSubcommand(sub => sub.setName('status').setDescription('View current AutoMod configuration status'))
    .addSubcommand(sub =>
      sub
        .setName('enable')
        .setDescription('Enable an AutoMod module')
        .addStringOption(opt =>
          opt
            .setName('module')
            .setDescription('Module to enable')
            .setRequired(true)
            .addChoices(
              { name: 'Anti-Spam', value: 'spam' },
              { name: 'Anti-Repeated Messages', value: 'repeats' },
              { name: 'Anti-Mention Spam', value: 'mentions' },
              { name: 'Invite Link Filter', value: 'invites' },
              { name: 'External Link Filter', value: 'links' },
              { name: 'Excessive Caps Filter', value: 'caps' },
              { name: 'Blacklisted Words', value: 'words' }
            )
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('disable')
        .setDescription('Disable an AutoMod module')
        .addStringOption(opt =>
          opt
            .setName('module')
            .setDescription('Module to disable')
            .setRequired(true)
            .addChoices(
              { name: 'Anti-Spam', value: 'spam' },
              { name: 'Anti-Repeated Messages', value: 'repeats' },
              { name: 'Anti-Mention Spam', value: 'mentions' },
              { name: 'Invite Link Filter', value: 'invites' },
              { name: 'External Link Filter', value: 'links' },
              { name: 'Excessive Caps Filter', value: 'caps' },
              { name: 'Blacklisted Words', value: 'words' }
            )
        )
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'status';
    await ctx.defer();

    if (subcommand === 'enable' || subcommand === 'disable') {
      const moduleName = ctx.getString('module', true)?.toLowerCase();
      const enable = subcommand === 'enable';

      const updateData: Record<string, boolean> = {};
      let friendlyName = '';

      switch (moduleName) {
        case 'spam':
          updateData['spamEnabled'] = enable;
          friendlyName = 'Anti-Spam';
          break;
        case 'repeats':
          updateData['repeatedEnabled'] = enable;
          friendlyName = 'Anti-Repeated Messages';
          break;
        case 'mentions':
          updateData['mentionSpamEnabled'] = enable;
          friendlyName = 'Anti-Mention Spam';
          break;
        case 'invites':
          updateData['inviteFilterEnabled'] = enable;
          friendlyName = 'Invite Link Filter';
          break;
        case 'links':
          updateData['linkFilterEnabled'] = enable;
          friendlyName = 'External Link Filter';
          break;
        case 'caps':
          updateData['capsFilterEnabled'] = enable;
          friendlyName = 'Excessive Caps Filter';
          break;
        case 'words':
          updateData['blacklistedWordsEnabled'] = enable;
          friendlyName = 'Blacklisted Words';
          break;
        default:
          await ctx.editReply('❌ Invalid module specified. Options: `spam`, `repeats`, `mentions`, `invites`, `links`, `caps`, `words`.');
          return;
      }

      await AutoModRepository.updateConfig(ctx.guild.id, updateData);
      await ctx.editReply(`✅ **${friendlyName}** has been **${enable ? 'enabled' : 'disabled'}**.`);
      return;
    }

    // Status display
    const config = await AutoModRepository.getConfig(ctx.guild.id);
    const words = await AutoModRepository.listBlacklistedWords(ctx.guild.id);

    const embed = new EmbedBuilder()
      .setTitle(`🛡️ AutoMod Configuration — ${ctx.guild.name}`)
      .setColor(Colors.DarkNavy)
      .setDescription('Automated moderation status for this server:')
      .addFields(
        {
          name: 'Modules',
          value:
            `• **Anti-Spam:** ${config.spamEnabled ? '🟢 Enabled' : '🔴 Disabled'} (${config.spamThreshold} msgs / ${config.spamIntervalSeconds}s)\n` +
            `• **Anti-Repeats:** ${config.repeatedEnabled ? '🟢 Enabled' : '🔴 Disabled'} (${config.repeatedThreshold} consecutive)\n` +
            `• **Mention Spam:** ${config.mentionSpamEnabled ? '🟢 Enabled' : '🔴 Disabled'} (max ${config.mentionThreshold} mentions)\n` +
            `• **Invite Links:** ${config.inviteFilterEnabled ? '🟢 Enabled' : '🔴 Disabled'}\n` +
            `• **External Links:** ${config.linkFilterEnabled ? '🟢 Enabled' : '🔴 Disabled'}\n` +
            `• **Excessive Caps:** ${config.capsFilterEnabled ? '🟢 Enabled' : '🔴 Disabled'} (${config.capsPercentageThreshold}% uppercase)\n` +
            `• **Blacklisted Words:** ${config.blacklistedWordsEnabled ? '🟢 Enabled' : '🔴 Disabled'} (${words.length} active words)`,
          inline: false,
        },
        {
          name: 'Default Penalty Action',
          value: `\`${config.defaultAction}\` (Timeout duration: ${config.defaultTimeoutSeconds}s)`,
          inline: true,
        },
        {
          name: 'Exemptions',
          value: `• **Exempt Roles:** ${config.exemptRoleIds.length}\n• **Exempt Channels:** ${config.exemptChannelIds.length}`,
          inline: true,
        }
      )
      .setFooter({ text: `Toggle modules: ${ctx.prefix}automod enable|disable <module>` });

    await ctx.editReply({ embeds: [embed] });
  },
};
