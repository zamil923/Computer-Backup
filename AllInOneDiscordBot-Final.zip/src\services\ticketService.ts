import {
  Guild,
  GuildMember,
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  Colors,
  TextChannel,
  User,
  AttachmentBuilder,
} from 'discord.js';
import { TicketRepository } from '../repositories/ticketRepository.js';
import { LoggingService } from './loggingService.js';
import { TranscriptGenerator } from '../utils/transcript.js';
import { MessageBuilder } from '../utils/embedBuilder.js';
import { TemplateRepository } from '../repositories/templateRepository.js';
import { UniversalEmbedData } from '../types/templates.js';
import { logger } from '../utils/logger.js';

export class TicketService {
  /**
   * Create a new ticket channel and database entry
   */
  public static async createTicket(
    guild: Guild,
    opener: GuildMember,
    categoryId?: string
  ): Promise<{ success: boolean; channelId?: string; message: string }> {
    const config = await TicketRepository.getConfig(guild.id);
    if (!config.enabled) {
      return { success: false, message: 'The ticket system is currently disabled on this server.' };
    }

    // Check maximum open tickets per user
    const openCount = await TicketRepository.countOpenTicketsForUser(guild.id, opener.id);
    if (openCount >= config.maxOpenTicketsPerUser) {
      return {
        success: false,
        message: `You already have ${openCount} open tickets. The maximum allowed is ${config.maxOpenTicketsPerUser}.`,
      };
    }

    let category = null;
    if (categoryId) {
      category = await TicketRepository.getCategory(categoryId);
    }

    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return { success: false, message: 'I do not have Discord permission to create channels.' };
    }

    // Generate channel name
    const namingFormat = category?.namingFormat || 'ticket-{username}';
    const channelName = namingFormat
      .replace('{username}', opener.user.username.toLowerCase().replace(/[^a-z0-9]/g, ''))
      .replace('{userId}', opener.id)
      .slice(0, 32);

    // Permission overwrites: @everyone deny, opener allow, bot allow, support roles allow
    const permissionOverwrites = [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: opener.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.AttachFiles,
          PermissionFlagsBits.EmbedLinks,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
      {
        id: botMember.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ManageChannels,
          PermissionFlagsBits.ManageMessages,
          PermissionFlagsBits.AttachFiles,
          PermissionFlagsBits.EmbedLinks,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
    ];

    if (category?.supportRoleIds) {
      for (const roleId of category.supportRoleIds) {
        if (guild.roles.cache.has(roleId)) {
          permissionOverwrites.push({
            id: roleId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.EmbedLinks,
              PermissionFlagsBits.ReadMessageHistory,
            ],
          });
        }
      }
    }

    const parentId = category?.discordCategoryId || config.categoryChannelId || undefined;

    const channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: parentId,
      permissionOverwrites,
    });

    const ticket = await TicketRepository.createTicket({
      guildId: guild.id,
      channelId: channel.id,
      categoryId: category?.id,
      openerId: opener.id,
      openerTag: opener.user.tag,
    });

    // Send initial control message in ticket channel
    const controlRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`ticket_close:${ticket.id}`)
        .setLabel('Close Ticket')
        .setEmoji('🔒')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`ticket_claim:${ticket.id}`)
        .setLabel('Claim Ticket')
        .setEmoji('🙋‍♂️')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`ticket_transcript:${ticket.id}`)
        .setLabel('Transcript')
        .setEmoji('📜')
        .setStyle(ButtonStyle.Secondary)
    );

    let welcomeEmbed: EmbedBuilder;
    if (category?.welcomeTemplateId) {
      const template = await TemplateRepository.getById(category.welcomeTemplateId);
      if (template && template.embedData) {
        const payload = MessageBuilder.buildPayload(
          { embeds: [template.embedData as unknown as UniversalEmbedData] },
          { user: opener.user, member: opener, guild }
        );
        welcomeEmbed = (payload.embeds?.[0] as EmbedBuilder) ?? new EmbedBuilder();
      } else {
        welcomeEmbed = new EmbedBuilder()
          .setTitle(`Ticket Opened - ${category.name}`)
          .setDescription(category.welcomeMessage || 'Support will be with you shortly.')
          .setColor(Colors.Blue);
      }
    } else {
      welcomeEmbed = new EmbedBuilder()
        .setTitle(`Support Ticket - ${category ? category.name : 'General'}`)
        .setDescription(
          `Welcome <@${opener.id}>!\nPlease describe your inquiry in detail. A staff member will assist you shortly.`
        )
        .setColor(Colors.Blue)
        .addFields(
          { name: 'Opened By', value: `<@${opener.id}> (${opener.user.tag})`, inline: true },
          { name: 'Category', value: category ? category.name : 'General', inline: true }
        )
        .setTimestamp();
    }

    const pingText = category?.pingRoleIds && category.pingRoleIds.length > 0
      ? category.pingRoleIds.map(r => `<@&${r}>`).join(' ')
      : `<@${opener.id}>`;

    await channel.send({
      content: pingText,
      embeds: [welcomeEmbed],
      components: [controlRow],
    });

    await LoggingService.logTicketEvent(
      guild,
      'Ticket Created',
      `Ticket <#${channel.id}> created by <@${opener.id}> (${opener.user.tag}). Category: **${category ? category.name : 'General'}**`,
      Colors.Green
    );

    return {
      success: true,
      channelId: channel.id,
      message: `Your ticket has been created: <#${channel.id}>`,
    };
  }

  /**
   * Close a ticket, generate transcript, dispatch ratings
   */
  public static async closeTicket(
    channel: TextChannel,
    closer: GuildMember,
    reason?: string
  ): Promise<{ success: boolean; message: string }> {
    const ticket = await TicketRepository.getTicketByChannel(channel.id);
    if (!ticket) {
      return { success: false, message: 'This channel is not an active ticket.' };
    }

    if (ticket.status === 'CLOSED') {
      return { success: false, message: 'This ticket is already closed.' };
    }

    // Fetch messages for transcript
    const messages = await channel.messages.fetch({ limit: 100 });
    const messageList = Array.from(messages.values());

    const meta = {
      ticketId: ticket.id,
      guild: channel.guild,
      channel,
      openerTag: ticket.openerTag,
      openerId: ticket.openerId,
      closedByTag: closer.user.tag,
      createdAt: ticket.createdAt,
      closedAt: new Date(),
    };

    const config = await TicketRepository.getConfig(channel.guild.id);
    const isHtml = config.transcriptFormat === 'HTML';
    const transcriptContent = isHtml
      ? TranscriptGenerator.generateHtml(messageList, meta)
      : TranscriptGenerator.generateText(messageList, meta);

    // Save transcript to database
    await TicketRepository.saveTranscript({
      ticketId: ticket.id,
      guildId: channel.guild.id,
      content: transcriptContent,
      format: config.transcriptFormat,
      messageCount: messageList.length,
      generatedBy: closer.user.tag,
    });

    // Close in database
    await TicketRepository.closeTicket(channel.id, closer.user.tag, reason);

    const transcriptBuffer = Buffer.from(transcriptContent, 'utf-8');
    const attachment = new AttachmentBuilder(transcriptBuffer, {
      name: `transcript-${ticket.id}.${isHtml ? 'html' : 'txt'}`,
    });

    // Send transcript to ticket log channel if configured
    if (config.logChannelId) {
      const logChannel = channel.guild.channels.cache.get(config.logChannelId) as TextChannel | undefined;
      if (logChannel?.isTextBased()) {
        const logEmbed = new EmbedBuilder()
          .setTitle(`🔒 Ticket Closed: #${channel.name}`)
          .setColor(Colors.DarkRed)
          .addFields(
            { name: 'Opened By', value: `<@${ticket.openerId}> (${ticket.openerTag})`, inline: true },
            { name: 'Closed By', value: `<@${closer.id}> (${closer.user.tag})`, inline: true },
            { name: 'Reason', value: reason || 'No reason specified', inline: false }
          )
          .setTimestamp();

        await logChannel.send({ embeds: [logEmbed], files: [attachment] }).catch(() => null);
      }
    }

    // Send rating request & transcript to ticket creator DM
    if (config.enableRatings) {
      try {
        const openerUser = await channel.client.users.fetch(ticket.openerId).catch(() => null);
        if (openerUser) {
          const ratingRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`ticket_rate:${ticket.id}:1`).setEmoji('⭐').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`ticket_rate:${ticket.id}:2`).setEmoji('⭐').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`ticket_rate:${ticket.id}:3`).setEmoji('⭐').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`ticket_rate:${ticket.id}:4`).setEmoji('⭐').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`ticket_rate:${ticket.id}:5`).setEmoji('⭐').setStyle(ButtonStyle.Primary)
          );

          const dmEmbed = new EmbedBuilder()
            .setTitle(`Ticket Closed - ${channel.guild.name}`)
            .setDescription(
              `Your ticket **#${channel.name}** has been closed.\nA copy of your transcript is attached.\n\nPlease rate your support experience below:`
            )
            .setColor(Colors.Blue)
            .setTimestamp();

          await openerUser.send({ embeds: [dmEmbed], components: [ratingRow], files: [attachment] }).catch(() => null);
        }
      } catch (err) {
        logger.warn('TicketService', 'Could not send DM transcript/rating to user', err);
      }
    }

    // Announce closing and schedule channel deletion in 5 seconds
    await channel.send('🔒 This ticket has been closed. This channel will be deleted in 5 seconds...');
    setTimeout(() => {
      channel.delete('Ticket closed').catch(() => null);
    }, 5000);

    return {
      success: true,
      message: 'Ticket closed successfully.',
    };
  }

  /**
   * Claim ticket
   */
  public static async claimTicket(channel: TextChannel, staff: GuildMember): Promise<{ success: boolean; message: string }> {
    const ticket = await TicketRepository.getTicketByChannel(channel.id);
    if (!ticket) {
      return { success: false, message: 'This channel is not an active ticket.' };
    }

    if (ticket.claimerId) {
      return { success: false, message: `This ticket is already claimed by <@${ticket.claimerId}>.` };
    }

    await TicketRepository.claimTicket(channel.id, staff.id);
    await channel.send(`🙋‍♂️ **${staff.user.tag}** has claimed this ticket!`);

    return { success: true, message: 'Ticket claimed successfully.' };
  }

  /**
   * Unclaim ticket
   */
  public static async unclaimTicket(channel: TextChannel, staff: GuildMember): Promise<{ success: boolean; message: string }> {
    const ticket = await TicketRepository.getTicketByChannel(channel.id);
    if (!ticket) {
      return { success: false, message: 'This channel is not an active ticket.' };
    }

    if (!ticket.claimerId) {
      return { success: false, message: 'This ticket is not currently claimed.' };
    }

    await TicketRepository.unclaimTicket(channel.id);
    await channel.send(`🔓 **${staff.user.tag}** has unclaimed this ticket. It is now open for any staff member.`);

    return { success: true, message: 'Ticket unclaimed.' };
  }

  /**
   * Add member to ticket channel
   */
  public static async addMember(channel: TextChannel, targetUser: User): Promise<{ success: boolean; message: string }> {
    await channel.permissionOverwrites.edit(targetUser.id, {
      ViewChannel: true,
      SendMessages: true,
      AttachFiles: true,
      EmbedLinks: true,
      ReadMessageHistory: true,
    });

    await channel.send(`👋 Added <@${targetUser.id}> to the ticket.`);
    return { success: true, message: `Added <@${targetUser.id}> to this ticket.` };
  }

  /**
   * Remove member from ticket channel
   */
  public static async removeMember(channel: TextChannel, targetUser: User): Promise<{ success: boolean; message: string }> {
    await channel.permissionOverwrites.delete(targetUser.id);
    await channel.send(`👋 Removed <@${targetUser.id}> from the ticket.`);
    return { success: true, message: `Removed <@${targetUser.id}> from this ticket.` };
  }
}
