import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { LevelingRepository } from '../../repositories/levelingRepository.js';

export const rankCommand: Command = {
  name: 'rank',
  description: 'View your XP rank or another member\'s rank',
  category: 'Leveling',
  usage: 'rank [user]',
  examples: ['/rank', '/rank @User', '^rank', '^rank @User'],
  requiredPermission: PermissionLevel.EVERYONE,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('View XP rank')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to check (defaults to yourself)').setRequired(false)
    ),

  async execute(ctx) {
    if (!ctx.guild) return;
    await ctx.defer();

    const target = (await ctx.getUser('user')) ?? ctx.user;
    const rankData = await LevelingRepository.getMemberRank(ctx.guild.id, target.id);

    if (!rankData) {
      await ctx.editReply(`**${target.username}** has no XP yet. Start chatting to earn some!`);
      return;
    }

    const config = await LevelingRepository.getConfig(ctx.guild.id);
    if (!config?.enabled) {
      await ctx.editReply('❌ Leveling is not enabled on this server.');
      return;
    }

    const nextLevelXp = LevelingRepository.xpRequiredForNextLevel(rankData.level);
    const currentLevelXp = LevelingRepository.xpRequiredForLevel(rankData.level);
    const progress = rankData.xp - currentLevelXp;
    const needed = nextLevelXp - currentLevelXp;
    const barLength = 20;
    const filled = Math.round((progress / needed) * barLength);
    const bar = '█'.repeat(filled) + '░'.repeat(barLength - filled);

    const embed = new EmbedBuilder()
      .setTitle(`Rank: ${target.username}`)
      .setThumbnail(target.displayAvatarURL())
      .setColor(Colors.Gold)
      .addFields(
        { name: '🏆 Rank', value: `#${rankData.rank}`, inline: true },
        { name: '⭐ Level', value: `${rankData.level}`, inline: true },
        { name: '✨ Total XP', value: `${rankData.xp.toLocaleString()}`, inline: true },
        { name: 'Progress to Next Level', value: `\`${bar}\`\n${progress}/${needed} XP` }
      );

    await ctx.editReply({ embeds: [embed] });
  },
};
