import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const banCommand: Command = {
  name: 'ban',
  description: 'Ban a member from the server',
  category: 'Moderation',
  usage: 'ban <@user|id> [reason]',
  examples: ['/ban user:@baduser reason:Spamming', '^ban @baduser Spamming', '^ban 123456789 Raiding'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.BanMembers],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption(opt => opt.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the ban').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member) return;

    const user = await ctx.getUser('user', true);
    if (!user) {
      await ctx.reply('❌ Please specify a valid user to ban.');
      return;
    }

    const reason = ctx.getString('reason') || 'No reason provided';
    await ctx.defer();

    const result = await ModerationService.ban(ctx.guild, ctx.member, user, reason);
    await ctx.editReply(result.message);
  },
};
