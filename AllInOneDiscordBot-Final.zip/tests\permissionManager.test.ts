import { describe, it, expect } from 'vitest';
import { PermissionManager } from '../src/permissions/permissionManager.js';

describe('PermissionManager', () => {
  it('should identify global bot owners from env correctly', () => {
    // env.BOT_OWNER_IDS is array from environment
    expect(typeof PermissionManager.isGlobalBotOwner('non_existent')).toBe('boolean');
  });

  it('should identify server owner correctly', () => {
    const mockGuild = { ownerId: '12345' } as any;
    expect(PermissionManager.isServerOwner(mockGuild, '12345')).toBe(true);
    expect(PermissionManager.isServerOwner(mockGuild, '99999')).toBe(false);
  });

  it('should enforce hierarchy: prevent moderating server owner', () => {
    const mockGuild = { ownerId: 'owner_1' };
    const mockExecutor = { id: 'admin_1', guild: mockGuild, roles: { highest: { position: 10 } } } as any;
    const mockTarget = { id: 'owner_1', guild: mockGuild, roles: { highest: { position: 1 } } } as any;

    const check = PermissionManager.checkRoleHierarchy(mockExecutor, mockTarget);
    expect(check.allowed).toBe(false);
    expect(check.reason).toContain('Server Owner');
  });

  it('should enforce hierarchy: prevent moderating self', () => {
    const mockGuild = { ownerId: 'owner_1' };
    const mockMember = { id: 'user_1', guild: mockGuild, roles: { highest: { position: 5 } } } as any;

    const check = PermissionManager.checkRoleHierarchy(mockMember, mockMember);
    expect(check.allowed).toBe(false);
    expect(check.reason).toContain('yourself');
  });

  it('should enforce hierarchy: prevent moderating higher or equal role', () => {
    const mockGuild = { ownerId: 'owner_1' };
    const mockExecutor = { id: 'mod_1', guild: mockGuild, roles: { highest: { position: 5 } } } as any;
    const mockTarget = { id: 'user_2', guild: mockGuild, roles: { highest: { position: 8 } } } as any;

    const check = PermissionManager.checkRoleHierarchy(mockExecutor, mockTarget);
    expect(check.allowed).toBe(false);
  });
});
