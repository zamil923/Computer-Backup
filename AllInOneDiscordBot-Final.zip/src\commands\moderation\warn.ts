import { SlashCommandBuilder } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const warnCommand: Command = {
  name: 'warn',
  description: 'Issue an official persistent warning to a member',
  category: 'Moderation',
  usage: 'warn <@user|id> <reason>',
  examples: ['/warn user:@member reason:Rule 1 violation', '^warn @member Rule 1 violation'],
  requiredPermission: PermissionLevel.MODERATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Issue a persistent warning to a member')
    .addUserOption(opt => opt.setName('user').setDescription('Member to warn').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the warning').setRequired(true)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member) return;

    const member = await ctx.getMember('user', true);
    if (!member) {
      await ctx.reply('❌ Please specify a member currently in the server.');
      return;
    }

    const reason = ctx.getString('reason', true) || 'No reason provided';
    await ctx.defer();

    const result = await ModerationService.warn(ctx.guild, ctx.member, member, reason);
    await ctx.editReply(result.message);
  },
};
