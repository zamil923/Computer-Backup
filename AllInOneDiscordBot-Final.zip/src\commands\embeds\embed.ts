import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  TextChannel,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { TemplateRepository } from '../../repositories/templateRepository.js';
import { MessageBuilder } from '../../utils/embedBuilder.js';
import { UniversalEmbedData } from '../../types/templates.js';

export const embedCommand: Command = {
  name: 'embed',
  description: 'Universal message & embed template builder, manager, and sender',
  category: 'Embeds & Messages',
  usage: 'embed <create|edit|preview|send|list|duplicate|delete> <name> [options]',
  examples: [
    '/embed create name:rules title:"Server Rules" description:"1. Be respectful" color:#5865f2',
    '/embed preview name:rules',
    '/embed send name:rules channel:#announcements',
    '/embed list',
    '/embed duplicate name:rules new_name:rules_copy',
    '/embed delete name:rules_copy',
    '^embed create rules "Server Rules" "1. Be respectful"',
    '^embed preview rules',
    '^embed send rules #announcements',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Universal embed and message builder')
    .addSubcommand(sub =>
      sub
        .setName('create')
        .setDescription('Create a saved embed template')
        .addStringOption(opt => opt.setName('name').setDescription('Template unique identifier name').setRequired(true))
        .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(false))
        .addStringOption(opt => opt.setName('description').setDescription('Embed description text').setRequired(false))
        .addStringOption(opt => opt.setName('color').setDescription('Hex color code (e.g. #5865f2)').setRequired(false))
        .addStringOption(opt => opt.setName('footer').setDescription('Footer text').setRequired(false))
        .addStringOption(opt => opt.setName('image').setDescription('Image URL').setRequired(false))
        .addStringOption(opt => opt.setName('thumbnail').setDescription('Thumbnail URL').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('preview')
        .setDescription('Preview how a saved template looks')
        .addStringOption(opt => opt.setName('name').setDescription('Template name').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('send')
        .setDescription('Send a saved template into a channel')
        .addStringOption(opt => opt.setName('name').setDescription('Template name to send').setRequired(true))
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send into').setRequired(false))
    )
    .addSubcommand(sub => sub.setName('list').setDescription('List all saved embed templates for this server'))
    .addSubcommand(sub =>
      sub
        .setName('duplicate')
        .setDescription('Duplicate an existing template')
        .addStringOption(opt => opt.setName('name').setDescription('Source template name').setRequired(true))
        .addStringOption(opt => opt.setName('new_name').setDescription('New template name').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('delete')
        .setDescription('Delete a saved template')
        .addStringOption(opt => opt.setName('name').setDescription('Template name to delete').setRequired(true))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'list';
    await ctx.defer();

    // 1. CREATE
    if (subcommand === 'create') {
      const name = ctx.getString('name', true)?.toLowerCase().trim();
      if (!name) {
        await ctx.editReply('❌ Please specify a unique name for the template.');
        return;
      }

      const existing = await TemplateRepository.getByName(ctx.guild.id, name);
      if (existing) {
        await ctx.editReply(`❌ A template named **"${name}"** already exists.`);
        return;
      }

      const title = ctx.getString('title') || undefined;
      const description = ctx.getString('description') || undefined;
      const color = ctx.getString('color') || '#5865F2';
      const footer = ctx.getString('footer');
      const image = ctx.getString('image') || undefined;
      const thumbnail = ctx.getString('thumbnail') || undefined;

      const embedData: UniversalEmbedData = {
        title,
        description,
        color,
        footer: footer ? { text: footer } : undefined,
        image,
        thumbnail,
        timestamp: true,
      };

      await TemplateRepository.create({
        guildId: ctx.guild.id,
        name,
        createdBy: ctx.user.tag,
        embedData,
      });

      await ctx.editReply(`✅ Template **"${name}"** created successfully! Type \`${ctx.prefix}embed preview ${name}\` to inspect it.`);
      return;
    }

    // 2. PREVIEW
    if (subcommand === 'preview') {
      const name = ctx.getString('name', true)?.toLowerCase().trim();
      if (!name) {
        await ctx.editReply('❌ Please specify a template name.');
        return;
      }

      const template = await TemplateRepository.getByName(ctx.guild.id, name);
      if (!template) {
        await ctx.editReply(`❌ Template **"${name}"** not found.`);
        return;
      }

      const context = {
        user: ctx.user,
        member: ctx.member ?? undefined,
        guild: ctx.guild,
      };

      const payload = MessageBuilder.buildPayload(
        {
          content: template.content || undefined,
          embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
        },
        context
      );

      await ctx.editReply({
        content: `👁️ **Preview of template "${template.name}":**`,
        embeds: payload.embeds,
      });
      return;
    }

    // 3. SEND
    if (subcommand === 'send') {
      const name = ctx.getString('name', true)?.toLowerCase().trim();
      if (!name) {
        await ctx.editReply('❌ Please specify a template name.');
        return;
      }

      const template = await TemplateRepository.getByName(ctx.guild.id, name);
      if (!template) {
        await ctx.editReply(`❌ Template **"${name}"** not found.`);
        return;
      }

      const channel = (ctx.getChannel('channel') ?? ctx.channel) as TextChannel | null;
      if (!channel || !channel.isTextBased()) {
        await ctx.editReply('❌ Invalid channel destination.');
        return;
      }

      const context = {
        user: ctx.user,
        member: ctx.member ?? undefined,
        guild: ctx.guild,
      };

      const payload = MessageBuilder.buildPayload(
        {
          content: template.content || undefined,
          embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
        },
        context
      );

      await channel.send(payload);
      await ctx.editReply(`✅ Template **"${name}"** sent to <#${channel.id}>!`);
      return;
    }

    // 4. DUPLICATE
    if (subcommand === 'duplicate') {
      const sourceName = ctx.getString('name', true)?.toLowerCase().trim();
      const newName = ctx.getString('new_name', true)?.toLowerCase().trim();

      if (!sourceName || !newName) {
        await ctx.editReply('❌ Please specify both the source name and new name.');
        return;
      }

      try {
        await TemplateRepository.duplicate(ctx.guild.id, sourceName, newName, ctx.user.tag);
        await ctx.editReply(`✅ Template **"${sourceName}"** duplicated as **"${newName}"**.`);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Failed to duplicate template.';
        await ctx.editReply(`❌ ${msg}`);
      }
      return;
    }

    // 5. DELETE
    if (subcommand === 'delete') {
      const name = ctx.getString('name', true)?.toLowerCase().trim();
      if (!name) {
        await ctx.editReply('❌ Please specify a template name to delete.');
        return;
      }

      try {
        await TemplateRepository.delete(ctx.guild.id, name);
        await ctx.editReply(`✅ Template **"${name}"** deleted.`);
      } catch {
        await ctx.editReply(`❌ Template **"${name}"** not found.`);
      }
      return;
    }

    // 6. LIST
    const templates = await TemplateRepository.list(ctx.guild.id);
    if (templates.length === 0) {
      await ctx.editReply('ℹ️ There are no saved message templates on this server.');
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`📋 Message Templates — ${ctx.guild.name} (${templates.length})`)
      .setColor(Colors.Purple)
      .setDescription(
        templates
          .map(t => `• **${t.name}** — Created by \`${t.createdBy}\` (<t:${Math.floor(t.createdAt.getTime() / 1000)}:R>)`)
          .join('\n')
      )
      .setFooter({ text: `Preview: ${ctx.prefix}embed preview <name> | Send: ${ctx.prefix}embed send <name>` });

    await ctx.editReply({ embeds: [embed] });
  },
};
