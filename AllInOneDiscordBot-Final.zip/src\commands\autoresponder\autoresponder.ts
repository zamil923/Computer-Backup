import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { AutoResponderRepository } from '../../repositories/autoResponderRepository.js';
import { TemplateRepository } from '../../repositories/templateRepository.js';

export const autoresponderCommand: Command = {
  name: 'autoresponder',
  description: 'Manage automated trigger-and-response messages',
  category: 'Auto Responder',
  usage: 'autoresponder <add|remove|list|toggle> [trigger] [response] [match: exact|contains]',
  examples: [
    '/autoresponder add trigger:"!ip" response:"play.example.com" match:exact',
    '/autoresponder add trigger:"rules" template:rules_card',
    '/autoresponder remove trigger:"!ip"',
    '/autoresponder list',
    '^autoresponder add "!website" "https://example.com"',
    '^autoresponder list',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('autoresponder')
    .setDescription('Manage automated trigger responses')
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Create an auto-response trigger')
        .addStringOption(opt => opt.setName('trigger').setDescription('Text trigger word or phrase').setRequired(true))
        .addStringOption(opt => opt.setName('response').setDescription('Text reply').setRequired(false))
        .addStringOption(opt => opt.setName('template').setDescription('Linked template name').setRequired(false))
        .addStringOption(opt =>
          opt
            .setName('match')
            .setDescription('Matching style')
            .setRequired(false)
            .addChoices({ name: 'Exact Match', value: 'EXACT' }, { name: 'Contains Match', value: 'CONTAINS' })
        )
        .addIntegerOption(opt => opt.setName('cooldown').setDescription('Cooldown in seconds (default 5s)').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Delete an auto-response trigger')
        .addStringOption(opt => opt.setName('trigger').setDescription('Trigger to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('toggle')
        .setDescription('Enable or disable a trigger')
        .addStringOption(opt => opt.setName('trigger').setDescription('Trigger to toggle').setRequired(true))
        .addBooleanOption(opt => opt.setName('enabled').setDescription('Enable (true) or Disable (false)').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('list').setDescription('List all auto responders')),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'list';
    await ctx.defer();

    // 1. ADD
    if (subcommand === 'add') {
      const trigger = ctx.getString('trigger', true)?.trim();
      const responseText = ctx.getString('response');
      const templateName = ctx.getString('template');
      const matchType = (ctx.getString('match') || 'EXACT').toUpperCase() as 'EXACT' | 'CONTAINS';
      const cooldownSeconds = ctx.getInteger('cooldown') || 5;

      if (!trigger) {
        await ctx.editReply('❌ Trigger is required.');
        return;
      }

      if (!responseText && !templateName) {
        await ctx.editReply('❌ You must specify either a response text or a template name.');
        return;
      }

      let templateId: string | undefined;
      if (templateName) {
        const template = await TemplateRepository.getByName(ctx.guild.id, templateName);
        if (!template) {
          await ctx.editReply(`❌ Template **"${templateName}"** not found.`);
          return;
        }
        templateId = template.id;
      }

      await AutoResponderRepository.create(ctx.guild.id, {
        trigger,
        matchType,
        responseText: responseText || undefined,
        templateId,
        cooldownSeconds,
      });

      await ctx.editReply(`✅ Auto responder for trigger **"${trigger}"** created (Match: \`${matchType}\`, Cooldown: \`${cooldownSeconds}s\`).`);
      return;
    }

    // 2. REMOVE
    if (subcommand === 'remove') {
      const trigger = ctx.getString('trigger', true)?.trim();
      if (!trigger) {
        await ctx.editReply('❌ Trigger is required.');
        return;
      }

      try {
        await AutoResponderRepository.delete(ctx.guild.id, trigger);
        await ctx.editReply(`✅ Auto responder trigger **"${trigger}"** deleted.`);
      } catch {
        await ctx.editReply(`❌ Trigger **"${trigger}"** not found.`);
      }
      return;
    }

    // 3. TOGGLE
    if (subcommand === 'toggle') {
      const trigger = ctx.getString('trigger', true)?.trim();
      const enabled = ctx.getBoolean('enabled', true) ?? true;

      if (!trigger) {
        await ctx.editReply('❌ Trigger is required.');
        return;
      }

      try {
        await AutoResponderRepository.toggle(ctx.guild.id, trigger, enabled);
        await ctx.editReply(`✅ Auto responder **"${trigger}"** has been **${enabled ? 'enabled' : 'disabled'}**.`);
      } catch {
        await ctx.editReply(`❌ Trigger **"${trigger}"** not found.`);
      }
      return;
    }

    // 4. LIST
    const list = await AutoResponderRepository.list(ctx.guild.id);
    if (list.length === 0) {
      await ctx.editReply('ℹ️ No auto responders are configured on this server.');
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🤖 Auto Responders — ${ctx.guild.name} (${list.length})`)
      .setColor(Colors.Green)
      .setDescription(
        list
          .map(
            (ar, i) =>
              `**${i + 1}. "${ar.trigger}"** (${ar.enabled ? '🟢' : '🔴'})\n• Match: \`${ar.matchType}\` | Cooldown: \`${ar.cooldownSeconds}s\`\n• Reply: ${ar.templateId ? 'Linked Template' : `\`${ar.responseText}\``}`
          )
          .join('\n\n')
      )
      .setFooter({ text: `Add new: ${ctx.prefix}autoresponder add trigger:"hello" response:"world"` });

    await ctx.editReply({ embeds: [embed] });
  },
};
