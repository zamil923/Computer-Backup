import { SlashCommandBuilder, TextChannel, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { RolePanelRepository } from '../../repositories/rolePanelRepository.js';
import { RolePanelService } from '../../services/rolePanelService.js';

export const rolepanelCommand: Command = {
  name: 'rolepanel',
  description: 'Create and deploy interactive button and dropdown role assignment panels',
  category: 'Roles',
  usage: 'rolepanel <create|addrole|post|list|delete> [options]',
  examples: [
    '/rolepanel create title:"Color Roles" type:button',
    '/rolepanel addrole panel_id:cm2xxxxxx role:@Red label:Red emoji:🔴 style:DANGER',
    '/rolepanel post panel_id:cm2xxxxxx channel:#roles',
    '/rolepanel list',
    '^rolepanel list',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('rolepanel')
    .setDescription('Manage interactive role panels')
    .addSubcommand(sub =>
      sub
        .setName('create')
        .setDescription('Create a new role panel container')
        .addStringOption(opt => opt.setName('title').setDescription('Panel title').setRequired(true))
        .addStringOption(opt =>
          opt
            .setName('type')
            .setDescription('Panel display type')
            .setRequired(false)
            .addChoices({ name: 'Buttons', value: 'BUTTON' }, { name: 'Select Menu Dropdown', value: 'SELECT_MENU' })
        )
        .addStringOption(opt => opt.setName('description').setDescription('Panel instructions').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('addrole')
        .setDescription('Add a selectable role option to a panel')
        .addStringOption(opt => opt.setName('panel_id').setDescription('Panel ID').setRequired(true))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to grant').setRequired(true))
        .addStringOption(opt => opt.setName('label').setDescription('Button/Option label').setRequired(true))
        .addStringOption(opt => opt.setName('emoji').setDescription('Emoji for option').setRequired(false))
        .addStringOption(opt =>
          opt
            .setName('style')
            .setDescription('Button style (for button panels)')
            .setRequired(false)
            .addChoices(
              { name: 'Primary (Blue)', value: 'PRIMARY' },
              { name: 'Secondary (Grey)', value: 'SECONDARY' },
              { name: 'Success (Green)', value: 'SUCCESS' },
              { name: 'Danger (Red)', value: 'DANGER' }
            )
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('post')
        .setDescription('Post the interactive role panel to a channel')
        .addStringOption(opt => opt.setName('panel_id').setDescription('Panel ID to post').setRequired(true))
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to post in').setRequired(false))
    )
    .addSubcommand(sub => sub.setName('list').setDescription('List all role panels in this server'))
    .addSubcommand(sub =>
      sub
        .setName('delete')
        .setDescription('Delete a role panel')
        .addStringOption(opt => opt.setName('panel_id').setDescription('Panel ID to delete').setRequired(true))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'list';
    await ctx.defer();

    // 1. CREATE PANEL
    if (subcommand === 'create') {
      const title = ctx.getString('title', true) || 'Roles';
      const description = ctx.getString('description') || 'Select your roles below:';
      const panelType = (ctx.getString('type') || 'BUTTON').toUpperCase() as 'BUTTON' | 'SELECT_MENU';

      const panel = await RolePanelRepository.createPanel(ctx.guild.id, {
        channelId: ctx.channel?.id || '',
        title,
        description,
        panelType,
      });

      await ctx.editReply(
        `✅ Role panel **"${panel.title}"** created (ID: \`${panel.id}\`).\nNow add roles using \`${ctx.prefix}rolepanel addrole panel_id:${panel.id} role:@Role label:"Role Name"\`.`
      );
      return;
    }

    // 2. ADD ROLE TO PANEL
    if (subcommand === 'addrole') {
      const panelId = ctx.getString('panel_id', true);
      const role = ctx.getRole('role', true);
      const label = ctx.getString('label', true);
      const emoji = ctx.getString('emoji') || undefined;
      const buttonStyle = (ctx.getString('style') || 'PRIMARY').toUpperCase();

      if (!panelId || !role || !label) {
        await ctx.editReply('❌ Missing required parameters: panel_id, role, or label.');
        return;
      }

      const panel = await RolePanelRepository.getPanel(panelId);
      if (!panel) {
        await ctx.editReply('❌ Role panel not found.');
        return;
      }

      await RolePanelRepository.addOptionToPanel(panelId, {
        roleId: role.id,
        label,
        emoji,
        buttonStyle,
      });

      await ctx.editReply(`✅ Added <@&${role.id}> (${label}) to role panel \`${panelId}\`.`);
      return;
    }

    // 3. POST PANEL
    if (subcommand === 'post') {
      const panelId = ctx.getString('panel_id', true);
      if (!panelId) {
        await ctx.editReply('❌ Please specify the panel_id to post.');
        return;
      }

      const channel = (ctx.getChannel('channel') ?? ctx.channel) as TextChannel | null;
      if (!channel || !channel.isTextBased()) {
        await ctx.editReply('❌ Invalid channel destination.');
        return;
      }

      const result = await RolePanelService.postPanel(panelId, channel);
      await ctx.editReply(result.message);
      return;
    }

    // 4. DELETE PANEL
    if (subcommand === 'delete') {
      const panelId = ctx.getString('panel_id', true);
      if (!panelId) {
        await ctx.editReply('❌ Please specify the panel_id to delete.');
        return;
      }

      try {
        await RolePanelRepository.deletePanel(panelId);
        await ctx.editReply(`✅ Role panel \`${panelId}\` deleted.`);
      } catch {
        await ctx.editReply('❌ Panel not found or already deleted.');
      }
      return;
    }

    // 5. LIST PANELS
    const panels = await RolePanelRepository.listPanels(ctx.guild.id);
    if (panels.length === 0) {
      await ctx.editReply('ℹ️ No role panels configured on this server yet.');
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🏷️ Role Panels — ${ctx.guild.name} (${panels.length})`)
      .setColor(Colors.Blue)
      .setDescription(
        panels
          .map(
            p =>
              `• **${p.title}** (ID: \`${p.id}\`)\n  Type: \`${p.panelType}\` | Options: ${p.options.length} roles`
          )
          .join('\n\n')
      )
      .setFooter({ text: `Post panel: ${ctx.prefix}rolepanel post <panelId> [channel]` });

    await ctx.editReply({ embeds: [embed] });
  },
};
