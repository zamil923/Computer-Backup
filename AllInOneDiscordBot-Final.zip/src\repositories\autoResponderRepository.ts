import { prisma } from '../database/prisma.js';
import { AutoResponder } from '@prisma/client';
import { GuildRepository } from './guildRepository.js';

export class AutoResponderRepository {
  public static async create(
    guildId: string,
    data: {
      trigger: string;
      matchType?: 'EXACT' | 'CONTAINS';
      caseSensitive?: boolean;
      responseText?: string;
      templateId?: string;
      cooldownSeconds?: number;
      exemptRoleIds?: string[];
      allowedChannelIds?: string[];
    }
  ): Promise<AutoResponder> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.autoResponder.upsert({
      where: { guildId_trigger: { guildId, trigger: data.trigger } },
      update: {
        matchType: data.matchType ?? 'EXACT',
        caseSensitive: data.caseSensitive ?? false,
        responseText: data.responseText,
        templateId: data.templateId,
        cooldownSeconds: data.cooldownSeconds ?? 5,
        exemptRoleIds: data.exemptRoleIds ?? [],
        allowedChannelIds: data.allowedChannelIds ?? [],
      },
      create: {
        guildId,
        trigger: data.trigger,
        matchType: data.matchType ?? 'EXACT',
        caseSensitive: data.caseSensitive ?? false,
        responseText: data.responseText,
        templateId: data.templateId,
        cooldownSeconds: data.cooldownSeconds ?? 5,
        exemptRoleIds: data.exemptRoleIds ?? [],
        allowedChannelIds: data.allowedChannelIds ?? [],
      },
    });
  }

  public static async getByTrigger(guildId: string, trigger: string): Promise<AutoResponder | null> {
    return prisma.autoResponder.findUnique({
      where: { guildId_trigger: { guildId, trigger } },
    });
  }

  public static async list(guildId: string): Promise<AutoResponder[]> {
    return prisma.autoResponder.findMany({
      where: { guildId },
      orderBy: { createdAt: 'desc' },
    });
  }

  public static async listEnabled(guildId: string): Promise<AutoResponder[]> {
    return prisma.autoResponder.findMany({
      where: { guildId, enabled: true },
    });
  }

  public static async toggle(guildId: string, trigger: string, enabled: boolean): Promise<AutoResponder> {
    return prisma.autoResponder.update({
      where: { guildId_trigger: { guildId, trigger } },
      data: { enabled },
    });
  }

  public static async delete(guildId: string, trigger: string): Promise<AutoResponder> {
    return prisma.autoResponder.delete({
      where: { guildId_trigger: { guildId, trigger } },
    });
  }
}
