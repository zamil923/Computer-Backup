import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { LevelingRepository } from '../../repositories/levelingRepository.js';

export const levelCommand: Command = {
  name: 'level',
  description: 'Configure the leveling/XP system',
  category: 'Configuration',
  usage: 'level <subcommand>',
  examples: ['/level config enable:true', '/level role add level:5 role:@Member', '^level config'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('level')
    .setDescription('Configure the XP and leveling system')
    .addSubcommand(sub =>
      sub
        .setName('config')
        .setDescription('View or toggle leveling settings')
        .addBooleanOption(opt => opt.setName('enable').setDescription('Enable or disable leveling').setRequired(false))
        .addIntegerOption(opt => opt.setName('xp_min').setDescription('Minimum XP per message').setMinValue(1).setRequired(false))
        .addIntegerOption(opt => opt.setName('xp_max').setDescription('Maximum XP per message').setMinValue(1).setRequired(false))
        .addIntegerOption(opt => opt.setName('cooldown').setDescription('Cooldown seconds between XP gains').setMinValue(5).setRequired(false))
        .addChannelOption(opt => opt.setName('levelup_channel').setDescription('Channel for level-up messages (empty = current)').setRequired(false))
        .addStringOption(opt => opt.setName('levelup_message').setDescription('Custom level-up message (supports variables)').setRequired(false))
        .addBooleanOption(opt => opt.setName('stack_roles').setDescription('Stack all earned level roles (true) or only give the highest (false)').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('role')
        .setDescription('Manage level-role rewards')
        .addStringOption(opt =>
          opt.setName('action').setDescription('Action').setRequired(true)
            .addChoices({ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' }, { name: 'list', value: 'list' })
        )
        .addIntegerOption(opt => opt.setName('level').setDescription('Level threshold').setMinValue(1).setRequired(false))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to assign').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('xp')
        .setDescription('Manually adjust a member\'s XP')
        .addStringOption(opt =>
          opt.setName('action').setDescription('Action').setRequired(true)
            .addChoices({ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' }, { name: 'set', value: 'set' }, { name: 'reset', value: 'reset' })
        )
        .addUserOption(opt => opt.setName('user').setDescription('Target user').setRequired(true))
        .addIntegerOption(opt => opt.setName('amount').setDescription('Amount of XP').setMinValue(0).setRequired(false))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;
    await ctx.defer();

    const sub = ctx.getSubcommand();

    // ── CONFIG ──────────────────────────────────────────────

    if (sub === 'config') {
      const currentConfig = await LevelingRepository.getConfig(ctx.guild.id);

      const enable = ctx.getBoolean('enable');
      const xpMin = ctx.getInteger('xp_min');
      const xpMax = ctx.getInteger('xp_max');
      const cooldown = ctx.getInteger('cooldown');
      const levelupChannel = ctx.getChannel('levelup_channel');
      const levelupMessage = ctx.getString('levelup_message');
      const stackRoles = ctx.getBoolean('stack_roles');

      // If no args, just show current config
      const hasArgs = [enable, xpMin, xpMax, cooldown, levelupChannel, levelupMessage, stackRoles].some(v => v !== null && v !== undefined);

      if (!hasArgs) {
        if (!currentConfig) {
          await ctx.editReply('Leveling is not configured. Use `/level config enable:true` to enable it.');
          return;
        }
        const embed = new EmbedBuilder()
          .setTitle('Leveling Configuration')
          .setColor(Colors.Gold)
          .addFields(
            { name: 'Enabled', value: currentConfig.enabled ? '✅ Yes' : '❌ No', inline: true },
            { name: 'XP Range', value: `${currentConfig.xpMin}–${currentConfig.xpMax}`, inline: true },
            { name: 'Cooldown', value: `${currentConfig.cooldownSeconds}s`, inline: true },
            { name: 'Level-Up Channel', value: currentConfig.levelUpChannelId ? `<#${currentConfig.levelUpChannelId}>` : 'Current channel', inline: true },
            { name: 'Stack Roles', value: currentConfig.stackRoles ? '✅ Yes' : '❌ No (highest only)', inline: true }
          );
        await ctx.editReply({ embeds: [embed] });
        return;
      }

      const updateData: any = {};
      if (enable !== null && enable !== undefined) updateData.enabled = enable;
      if (xpMin !== null) updateData.xpMin = xpMin;
      if (xpMax !== null) updateData.xpMax = xpMax;
      if (cooldown !== null) updateData.cooldownSeconds = cooldown;
      if (levelupChannel !== null) updateData.levelUpChannelId = levelupChannel.id;
      if (levelupMessage !== null) updateData.levelUpMessage = levelupMessage;
      if (stackRoles !== null && stackRoles !== undefined) updateData.stackRoles = stackRoles;

      await LevelingRepository.upsertConfig(ctx.guild.id, updateData);
      await ctx.editReply('✅ Leveling configuration updated.');
    }

    // ── LEVEL ROLES ─────────────────────────────────────────

    if (sub === 'role') {
      const action = ctx.getString('action', true) ?? '';

      if (action === 'list') {
        const roles = await LevelingRepository.getLevelRoles(ctx.guild.id);
        if (!roles.length) {
          await ctx.editReply('No level roles configured.');
          return;
        }
        const lines = roles.map(r => `Level **${r.level}** → <@&${r.roleId}>`).join('\n');
        await ctx.editReply(`**Level Roles:**\n${lines}`);
        return;
      }

      const level = ctx.getInteger('level');
      if (level === null) {
        await ctx.editReply('❌ You must specify a level.');
        return;
      }

      if (action === 'remove') {
        await LevelingRepository.removeLevelRole(ctx.guild.id, level);
        await ctx.editReply(`✅ Removed level role for level **${level}**.`);
        return;
      }

      if (action === 'add') {
        const role = ctx.getRole('role');
        if (!role) {
          await ctx.editReply('❌ You must specify a role.');
          return;
        }
        await LevelingRepository.setLevelRole(ctx.guild.id, level, role.id);
        await ctx.editReply(`✅ Members reaching level **${level}** will receive <@&${role.id}>.`);
        return;
      }
    }

    // ── XP ADMIN ────────────────────────────────────────────

    if (sub === 'xp') {
      const action = ctx.getString('action', true) ?? '';
      const targetUser = await ctx.getUser('user');
      if (!targetUser) {
        await ctx.editReply('❌ You must specify a user.');
        return;
      }

      if (action === 'reset') {
        await LevelingRepository.resetMember(ctx.guild.id, targetUser.id);
        await ctx.editReply(`✅ XP reset for **${targetUser.username}**.`);
        return;
      }

      const amount = ctx.getInteger('amount');
      if (amount === null) {
        await ctx.editReply('❌ You must specify an amount.');
        return;
      }

      if (action === 'add') {
        await LevelingRepository.upsertMemberXp(ctx.guild.id, targetUser.id, amount);
        await ctx.editReply(`✅ Added **${amount} XP** to ${targetUser.username}.`);
      } else if (action === 'remove') {
        const current = await LevelingRepository.getMemberXp(ctx.guild.id, targetUser.id);
        const newXp = Math.max(0, (current?.xp ?? 0) - amount);
        await LevelingRepository.setMemberXp(ctx.guild.id, targetUser.id, newXp);
        await ctx.editReply(`✅ Removed **${amount} XP** from ${targetUser.username}. New total: ${newXp.toLocaleString()}`);
      } else if (action === 'set') {
        await LevelingRepository.setMemberXp(ctx.guild.id, targetUser.id, amount);
        await ctx.editReply(`✅ Set XP for ${targetUser.username} to **${amount}**.`);
      }
    }
  },
};
