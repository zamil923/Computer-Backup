import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { AutoModRepository } from '../../repositories/autoModRepository.js';

export const blacklistCommand: Command = {
  name: 'blacklist',
  description: 'Manage blacklisted words and punishment actions',
  category: 'AutoMod / Security',
  usage: 'blacklist <add|remove|list> [word] [action: delete|warn|timeout|delete_warn|delete_timeout] [match: exact|contains]',
  examples: [
    '/blacklist add word:badword action:delete match:exact',
    '/blacklist remove word:badword',
    '/blacklist list',
    '^blacklist add scam delete_warn contains',
    '^blacklist remove scam',
    '^blacklist list',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('Manage blacklisted words')
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add a word to the blacklist')
        .addStringOption(opt => opt.setName('word').setDescription('Word or phrase to blacklist').setRequired(true))
        .addStringOption(opt =>
          opt
            .setName('action')
            .setDescription('Action to take on detection')
            .setRequired(false)
            .addChoices(
              { name: 'Delete Message', value: 'DELETE' },
              { name: 'Warn Member', value: 'WARN' },
              { name: 'Timeout Member', value: 'TIMEOUT' },
              { name: 'Delete + Warn', value: 'DELETE_WARN' },
              { name: 'Delete + Timeout', value: 'DELETE_TIMEOUT' }
            )
        )
        .addStringOption(opt =>
          opt
            .setName('match')
            .setDescription('Matching rule: EXACT (whole word) or CONTAINS (substring)')
            .setRequired(false)
            .addChoices({ name: 'Exact Whole Word (Safest)', value: 'EXACT' }, { name: 'Contains Substring', value: 'CONTAINS' })
        )
        .addIntegerOption(opt =>
          opt.setName('timeout_seconds').setDescription('Timeout duration in seconds (if timeout action)').setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a word from the blacklist')
        .addStringOption(opt => opt.setName('word').setDescription('Word to remove').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('list').setDescription('List all blacklisted words')),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'list';
    await ctx.defer();

    if (subcommand === 'add') {
      const word = ctx.getString('word', true);
      if (!word) {
        await ctx.editReply('❌ Please specify a word to add.');
        return;
      }

      const action = (ctx.getString('action') || 'DELETE').toUpperCase() as
        | 'DELETE'
        | 'WARN'
        | 'TIMEOUT'
        | 'DELETE_WARN'
        | 'DELETE_TIMEOUT';
      const matchType = (ctx.getString('match') || 'EXACT').toUpperCase() as 'EXACT' | 'CONTAINS';
      const timeoutSeconds = ctx.getInteger('timeout_seconds') || 300;

      await AutoModRepository.addBlacklistedWord(ctx.guild.id, {
        word,
        action,
        matchType,
        timeoutSeconds,
      });

      await ctx.editReply(
        `✅ Blacklisted word **"${word}"** added!\n• **Match Type:** ${matchType}\n• **Action:** ${action}\n• **Timeout:** ${timeoutSeconds}s`
      );
      return;
    }

    if (subcommand === 'remove') {
      const word = ctx.getString('word', true);
      if (!word) {
        await ctx.editReply('❌ Please specify the word to remove.');
        return;
      }

      try {
        await AutoModRepository.removeBlacklistedWord(ctx.guild.id, word);
        await ctx.editReply(`✅ Removed **"${word}"** from the blacklist.`);
      } catch {
        await ctx.editReply(`❌ Word **"${word}"** was not found in the blacklist.`);
      }
      return;
    }

    // List
    const words = await AutoModRepository.listBlacklistedWords(ctx.guild.id);
    if (words.length === 0) {
      await ctx.editReply('ℹ️ There are no blacklisted words configured for this server.');
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🚫 Blacklisted Words — ${ctx.guild.name} (${words.length} total)`)
      .setColor(Colors.Red)
      .setDescription(
        words
          .map((bw, i) => `**${i + 1}.** \`${bw.word}\` — Match: \`${bw.matchType}\` | Action: \`${bw.action}\``)
          .join('\n')
      )
      .setFooter({ text: `Add words: ${ctx.prefix}blacklist add <word> [action] [match]` });

    await ctx.editReply({ embeds: [embed] });
  },
};
