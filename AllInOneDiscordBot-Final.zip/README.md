# 🤖 All-in-One Discord Server Management Bot

A powerful, production-ready Discord server management bot built with **Node.js**, **TypeScript**, **discord.js v14**, **PostgreSQL**, and **Prisma ORM**. Supports both `/slash commands` and `^prefix commands` with shared business logic.

---

## 📋 Table of Contents

1. [Requirements](#requirements)
2. [PostgreSQL Setup](#postgresql-setup)
3. [Environment Setup](#environment-setup)
4. [Discord Developer Portal Setup](#discord-developer-portal-setup)
5. [Required Gateway Intents](#required-gateway-intents)
6. [Installation](#installation)
7. [Prisma Database Migration](#prisma-database-migration)
8. [Slash Command Registration](#slash-command-registration)
9. [Running the Bot](#running-the-bot)
10. [Docker Deployment](#docker-deployment)
11. [Bot Configuration](#bot-configuration)
12. [Command Reference](#command-reference)
13. [Architecture Overview](#architecture-overview)
14. [Troubleshooting](#troubleshooting)

---

## Requirements

| Requirement | Minimum Version |
|---|---|
| Node.js | `>= 20.0.0` |
| npm | `>= 10.0.0` |
| PostgreSQL | `>= 14` |
| TypeScript | `>= 5.6` |

> **Note:** You can use Docker Compose to automatically provision PostgreSQL — see [Docker Deployment](#docker-deployment).

---

## PostgreSQL Setup

### Option A — Local PostgreSQL

1. Install PostgreSQL from https://www.postgresql.org/download/
2. Start the PostgreSQL service
3. Create a database and user:

```sql
CREATE DATABASE discord_bot;
CREATE USER bot_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE discord_bot TO bot_user;
```

4. Your connection string will be:
```
postgresql://bot_user:your_secure_password@localhost:5432/discord_bot
```

### Option B — Docker PostgreSQL (Recommended)

Use the provided `docker-compose.yml` — see [Docker Deployment](#docker-deployment).

---

## Environment Setup

1. Copy the example environment file:

```bash
cp .env.example .env
```

2. Edit `.env` and fill in your values:

```env
# ─── Discord ──────────────────────────────────────────────────────────────────
DISCORD_TOKEN=your_discord_bot_token_here
DISCORD_CLIENT_ID=your_application_client_id_here

# ─── Global Bot Owners ────────────────────────────────────────────────────────
# Comma-separated Discord User IDs of global bot owners
# These users have unrestricted access to all owner-level commands
BOT_OWNER_IDS=123456789012345678,987654321098765432

# ─── Database ─────────────────────────────────────────────────────────────────
DATABASE_URL=postgresql://bot_user:your_secure_password@localhost:5432/discord_bot

# ─── Runtime ──────────────────────────────────────────────────────────────────
NODE_ENV=production
LOG_LEVEL=info
```

> **Security:** Never commit your `.env` file. It is listed in `.gitignore`.

> **BOT_OWNER_IDS:** These must be actual Discord User IDs — never usernames or display names. Find your User ID by enabling Developer Mode in Discord → right-click your name → Copy ID.

---

## Discord Developer Portal Setup

### Step 1 — Create an Application

1. Go to https://discord.com/developers/applications
2. Click **New Application**
3. Give it a name (e.g., "My Server Bot")
4. Go to the **Bot** tab

### Step 2 — Create a Bot User

1. Click **Add Bot** on the Bot tab
2. Copy the **Token** → paste into `.env` as `DISCORD_TOKEN`

### Step 3 — Copy the Application (Client) ID

1. Go to the **General Information** tab
2. Copy **Application ID** → paste into `.env` as `DISCORD_CLIENT_ID`

### Step 4 — Enable Privileged Gateway Intents

On the **Bot** tab, scroll to **Privileged Gateway Intents** and enable **all three**:

| Intent | Required For |
|---|---|
| **PRESENCE INTENT** | Optional — enable if tracking member presence |
| **SERVER MEMBERS INTENT** | Welcome, Leave, AutoRole, Member events |
| **MESSAGE CONTENT INTENT** | **Required for `^prefix commands`** |

> ⚠️ Without `MESSAGE CONTENT INTENT`, all prefix (`^`) commands will be completely non-functional. The bot will only operate via slash commands.

### Step 5 — Invite the Bot to Your Server

Generate an invite URL with the required scopes and permissions:

1. Go to **OAuth2 → URL Generator**
2. Select scopes: `bot` and `applications.commands`
3. Select bot permissions:
   - Manage Roles
   - Manage Channels
   - Kick Members
   - Ban Members
   - Moderate Members (Timeout)
   - Read Messages / View Channels
   - Send Messages
   - Manage Messages
   - Embed Links
   - Attach Files
   - Read Message History
   - Add Reactions
   - Use Slash Commands
4. Copy the generated URL → open in browser → select server → Authorize

---

## Required Gateway Intents

The bot requests these intents at startup:

| Intent | Purpose |
|---|---|
| `Guilds` | Core guild events and channel data |
| `GuildMembers` ⚠️ | Welcome/leave events, AutoRole |
| `GuildMessages` | Detecting prefix command messages |
| `MessageContent` ⚠️ | Reading prefix command content |
| `GuildVoiceStates` | Voice channel statistics |
| `GuildModeration` | Audit log and ban events |

> ⚠️ = **Privileged Intent** — must be enabled in the Discord Developer Portal.

---

## Installation

```bash
# 1. Clone or extract the project
cd "Dc Bot All in one"

# 2. Install dependencies
npm install

# 3. Generate Prisma client
npm run db:generate
```

---

## Prisma Database Migration

> Ensure your `DATABASE_URL` in `.env` is set correctly before running migrations.

### Apply Initial Migration (Production)

```bash
# Applies the migration to your database and generates the Prisma client
npx prisma migrate deploy
```

### Development Migrations

```bash
# Creates and applies a new migration with a name
npm run db:migrate -- --name init

# Or push schema directly without migration history (development only)
npm run db:push
```

### Inspect the Database

```bash
# Opens the Prisma Studio GUI
npx prisma studio
```

---

## Slash Command Registration

Slash commands must be registered with Discord before they appear in the UI.

```bash
# Register slash commands globally (may take up to 1 hour to propagate)
node dist/scripts/registerCommands.js

# Or use the owner bot command after the bot is running:
# /owner synccommands
# ^owner synccommands
```

> **Tip:** During development, register commands to a specific guild for instant updates:
> Add `GUILD_ID=your_guild_id` to `.env` and the bot will register guild-scoped commands on ready.

---

## Running the Bot

### Development Mode (with hot-reload)

```bash
npm run dev
```

### Production Mode

```bash
# 1. Build TypeScript to JavaScript
npm run build

# 2. Start the bot
npm start
```

### TypeScript Type Check (no build output)

```bash
npm run typecheck
```

### Run Automated Tests

```bash
npm test
```

---

## Docker Deployment

### Quick Start

```bash
# 1. Copy and configure environment
cp .env.example .env
# Edit .env with your DISCORD_TOKEN, DISCORD_CLIENT_ID, BOT_OWNER_IDS

# 2. Start the entire stack (bot + PostgreSQL)
docker compose up -d

# 3. Run database migrations inside the container
docker compose exec bot npx prisma migrate deploy

# 4. View logs
docker compose logs -f bot
```

### docker-compose.yml Overview

The `docker-compose.yml` defines:

| Service | Description |
|---|---|
| `bot` | The Discord bot (Node.js application) |
| `postgres` | PostgreSQL 15 database |

- PostgreSQL data is persisted in a named Docker volume (`postgres_data`)
- The bot service depends on the postgres service being healthy
- Environment variables are loaded from `.env`

### Building the Image Manually

```bash
docker build -t discord-bot:latest .
```

### Stopping the Stack

```bash
docker compose down

# To also remove the database volume (WARNING: deletes all data):
docker compose down -v
```

---

## Bot Configuration

All configuration is performed through Discord commands. No web dashboard required.

### Initial Server Setup

```
/setup          — Run the guided server setup wizard
^setup
```

### Prefix Configuration

The default command prefix is `^`. (Per-server prefix customization is architecturally supported and planned for Session 2.)

---

## Command Reference

### Dual Command Support

Every command supports both slash (`/`) and prefix (`^`) interfaces:

```
/help           ←→    ^help
/ban @user      ←→    ^ban @user
/ticket create  ←→    ^ticket create
```

### General

| Command | Description |
|---|---|
| `/help` | Interactive help center with category navigation |
| `/ping` | Bot latency and status check |
| `/stats` | Bot and server statistics |

### Setup

| Command | Description |
|---|---|
| `/setup` | Guided server configuration wizard |

### Welcome / Leave / Boost

| Command | Description |
|---|---|
| `/welcome enable` | Enable welcome messages |
| `/welcome disable` | Disable welcome messages |
| `/welcome channel #channel` | Set welcome channel |
| `/welcome template <name>` | Assign a saved message template |
| `/welcome text <message>` | Set plain text welcome message |
| `/welcome test` | Preview the current welcome message |
| `/welcome view` | View current welcome configuration |
| `/welcome reset` | Reset welcome configuration |
| `/leave enable\|disable\|channel\|template\|text\|test\|view\|reset` | Leave message configuration |
| `/boost enable\|disable\|channel\|template\|text\|test\|view\|reset` | Boost announcement configuration |

### Moderation

| Command | Description |
|---|---|
| `/ban @user [reason]` | Ban a member |
| `/unban <userId> [reason]` | Unban a user |
| `/kick @user [reason]` | Kick a member |
| `/timeout @user <duration> [reason]` | Timeout a member |
| `/warn @user <reason>` | Issue a warning |
| `/warnings @user` | View a member's warnings |
| `/cases [user]` | View moderation case history |
| `/purge <count>` | Bulk delete messages |
| `/slowmode <seconds>` | Set channel slowmode |
| `/lock [channel]` | Lock a channel |
| `/unlock [channel]` | Unlock a channel |

### AutoMod / Security

| Command | Description |
|---|---|
| `/automod enable\|disable` | Toggle AutoMod system |
| `/automod antispam` | Configure spam detection |
| `/automod antilink` | Configure link filtering |
| `/automod antiraid` | Configure raid detection |
| `/automod view` | View AutoMod configuration |
| `/blacklist add <word>` | Add a blacklisted word |
| `/blacklist remove <word>` | Remove a blacklisted word |
| `/blacklist view` | View the blacklist |

### Embeds & Messages

| Command | Description |
|---|---|
| `/embed create` | Create a new embed template (opens modal) |
| `/embed edit <name>` | Edit an existing template |
| `/embed preview <name>` | Preview a template |
| `/embed send <name> [channel]` | Send a template to a channel |
| `/embed list` | List all saved templates |
| `/embed duplicate <name>` | Duplicate a template |
| `/embed delete <name>` | Delete a template |

### Tickets

| Command | Description |
|---|---|
| `/ticket setup` | Configure the ticket system |
| `/ticket panel` | Create a ticket panel |
| `/ticket close` | Close the current ticket |
| `/ticket claim` | Claim a ticket |
| `/ticket add @user` | Add a user to a ticket |
| `/ticket remove @user` | Remove a user from a ticket |
| `/ticket rename <name>` | Rename the ticket channel |
| `/ticket transcript` | Generate a transcript |

### Roles

| Command | Description |
|---|---|
| `/autorole add <role>` | Add an auto-assigned role |
| `/autorole remove <role>` | Remove an auto-assigned role |
| `/autorole list` | List auto-roles |
| `/rolepanel create` | Create a role selection panel |
| `/rolepanel edit <name>` | Edit a role panel |
| `/rolepanel delete <name>` | Delete a role panel |

### Auto Responder

| Command | Description |
|---|---|
| `/autoresponder add` | Add an auto-response trigger |
| `/autoresponder remove <trigger>` | Remove an auto-response |
| `/autoresponder list` | List all auto-responses |
| `/autoresponder edit <trigger>` | Edit an auto-response |

### Configuration / Permissions

| Command | Description |
|---|---|
| `/config prefix <prefix>` | View/set command prefix |
| `/config view` | View guild configuration |
| `/config reset` | Reset configuration |
| `/permissions set <command>` | Configure command permissions |
| `/permissions allow role <role> <command>` | Allow a role to use a command |
| `/permissions deny role <role> <command>` | Deny a role from a command |
| `/permissions view <command>` | View command permissions |
| `/permissions reset <command>` | Reset command permissions |

### Owner (Global Bot Owners Only)

| Command | Description |
|---|---|
| `/owner info` | Bot information and diagnostics |
| `/owner guilds` | List guilds the bot is in |
| `/owner synccommands` | Synchronize slash commands |
| `/owner maintenance` | Toggle maintenance mode |
| `/owner presence` | Set bot presence/activity |
| `/owner setusername` | Change bot username |
| `/owner setavatar` | Change bot avatar |
| `/owner inspect <guildId>` | Inspect guild configuration |
| `/owner reload` | Reload runtime configuration |

---

## Template Variables

Templates (welcome, leave, boost, embeds) support these safe variables:

| Variable | Description |
|---|---|
| `{user}` | Username |
| `{username}` | Username |
| `{displayName}` | Display name / nickname |
| `{userId}` | Discord User ID |
| `{userMention}` | `<@userId>` mention |
| `{avatar}` | User avatar URL |
| `{server}` | Server name |
| `{serverName}` | Server name |
| `{serverId}` | Server ID |
| `{serverIcon}` | Server icon URL |
| `{memberCount}` | Current member count |
| `{boostCount}` | Current boost count |
| `{boostTier}` | Current boost tier |

---

## Architecture Overview

```
src/
├── commands/           # Slash + prefix command definitions
│   ├── general/        # help, ping, stats
│   ├── setup/          # setup wizard
│   ├── welcome/        # welcome, leave, boost
│   ├── moderation/     # ban, kick, timeout, warn, etc.
│   ├── automod/        # automod, blacklist
│   ├── embeds/         # embed builder
│   ├── tickets/        # ticket system
│   ├── roles/          # autorole, rolepanel
│   ├── autoresponder/  # auto responder
│   ├── configuration/  # config, permissions
│   ├── owner/          # global owner commands
│   ├── argParser.ts    # Prefix argument tokenizer
│   ├── context.ts      # Unified CommandContext interface
│   ├── registry.ts     # Command registry
│   └── index.ts        # Registration entry point
├── components/
│   └── router.ts       # Persistent button/select menu handler
├── config/
│   └── env.ts          # Validated environment configuration
├── database/
│   └── prisma.ts       # Prisma client singleton
├── events/             # Discord.js event handlers
├── permissions/
│   └── permissionManager.ts  # 8-tier permission system
├── repositories/       # Database access layer (per feature)
├── services/           # Business logic layer (per feature)
├── types/              # Shared TypeScript type definitions
├── utils/              # Logger, variable engine, embed builder, etc.
└── index.ts            # Application bootstrap
```

---

## Troubleshooting

### Bot doesn't respond to prefix commands

- Ensure `MESSAGE CONTENT INTENT` is enabled in the Discord Developer Portal
- Verify the bot has permission to read messages in the channel

### Slash commands not appearing

- Run `/owner synccommands` or restart the bot (commands register on ready)
- Global slash commands can take up to 1 hour to propagate

### `P1001: Can't reach database server`

- Verify your `DATABASE_URL` in `.env`
- Ensure PostgreSQL is running
- Check firewall rules if using a remote database

### `P3009: migrate found failed migrations`

```bash
npx prisma migrate resolve --rolled-back "0_init"
npx prisma migrate deploy
```

### Permission errors on moderation commands

- Ensure the bot role is positioned **above** the target roles in Server Settings → Roles
- Grant the bot the required Discord permissions (Kick Members, Ban Members, etc.)

### Bot appears offline

- Double-check `DISCORD_TOKEN` — it should not have spaces or quotes
- Regenerate the token in the Developer Portal if compromised

---

## License

MIT License — See [LICENSE](LICENSE) for details.
