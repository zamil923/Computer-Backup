import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationRepository } from '../../repositories/moderationRepository.js';

export const casesCommand: Command = {
  name: 'cases',
  description: 'View moderation cases history or inspect a specific case',
  category: 'Moderation',
  usage: 'cases [caseNumber | user: @user]',
  examples: ['/cases', '/cases number:5', '/cases user:@member', '^cases', '^cases 5', '^cases @member'],
  requiredPermission: PermissionLevel.MODERATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('cases')
    .setDescription('View moderation case history')
    .addIntegerOption(opt => opt.setName('number').setDescription('Specific Case Number to inspect').setRequired(false))
    .addUserOption(opt => opt.setName('user').setDescription('Filter cases by user').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild) return;

    await ctx.defer();
    const caseNum = ctx.getInteger('number');
    const filterUser = await ctx.getUser('user');

    // 1. Inspect specific case
    if (caseNum) {
      const c = await ModerationRepository.getCase(ctx.guild.id, caseNum);
      if (!c) {
        await ctx.editReply(`❌ Moderation Case #${caseNum} does not exist in this server.`);
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ Moderation Case #${c.caseNumber} — ${c.action}`)
        .setColor(Colors.Blue)
        .addFields(
          { name: 'Target', value: `<@${c.targetId}> (${c.targetTag})`, inline: true },
          { name: 'Moderator', value: `<@${c.moderatorId}> (${c.moderatorTag})`, inline: true },
          { name: 'Status', value: c.status, inline: true },
          { name: 'Reason', value: c.reason, inline: false }
        )
        .setTimestamp(c.createdAt);

      if (c.duration) {
        embed.addFields({ name: 'Duration', value: c.duration, inline: true });
      }

      await ctx.editReply({ embeds: [embed] });
      return;
    }

    // 2. Cases for specific user
    if (filterUser) {
      const cases = await ModerationRepository.getCasesForUser(ctx.guild.id, filterUser.id, 10);
      if (cases.length === 0) {
        await ctx.editReply(`ℹ️ No moderation history found for **${filterUser.tag}**.`);
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ Moderation History: ${filterUser.tag} (${cases.length} cases)`)
        .setColor(Colors.Yellow)
        .setDescription(
          cases
            .map(
              c =>
                `• **#${c.caseNumber} [${c.action}]** by <@${c.moderatorId}>: ${c.reason} (<t:${Math.floor(c.createdAt.getTime() / 1000)}:R>)`
            )
            .join('\n\n')
        )
        .setTimestamp();

      await ctx.editReply({ embeds: [embed] });
      return;
    }

    // 3. Recent server cases list
    const cases = await ModerationRepository.listCases(ctx.guild.id, 10);
    const total = await ModerationRepository.countCases(ctx.guild.id);

    if (cases.length === 0) {
      await ctx.editReply('ℹ️ There are no recorded moderation cases for this server yet.');
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🛡️ Moderation Cases — ${ctx.guild.name} (${total} total)`)
      .setColor(Colors.Blue)
      .setDescription(
        cases
          .map(
            c =>
              `**Case #${c.caseNumber}** • \`${c.action}\`\nTarget: <@${c.targetId}> (${c.targetTag})\nMod: <@${c.moderatorId}>\nReason: ${c.reason}`
          )
          .join('\n\n')
      )
      .setFooter({ text: `Inspect a case: ${ctx.prefix}cases <number>` })
      .setTimestamp();

    await ctx.editReply({ embeds: [embed] });
  },
};
