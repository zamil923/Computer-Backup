import { Guild, GuildMember, PermissionFlagsBits, User } from 'discord.js';
import { env } from '../config/env.js';
import { Command, CommandContext, PermissionLevel } from '../types/command.js';
import { GuildRepository } from '../repositories/guildRepository.js';

export class PermissionManager {
  /**
   * Check if a user is a designated Global Bot Owner
   */
  public static isGlobalBotOwner(userId: string): boolean {
    return env.BOT_OWNER_IDS.includes(userId);
  }

  /**
   * Check if user is the Discord server owner
   */
  public static isServerOwner(guild: Guild, userId: string): boolean {
    return guild.ownerId === userId;
  }

  /**
   * Check if member has Discord Administrator permission or a configured Admin role
   */
  public static isAdministrator(member: GuildMember, adminRoleIds: string[] = []): boolean {
    if (member.permissions.has(PermissionFlagsBits.Administrator)) {
      return true;
    }
    return member.roles.cache.some(role => adminRoleIds.includes(role.id));
  }

  /**
   * Check if member is a Moderator (either via Admin status or configured Mod roles)
   */
  public static isModerator(member: GuildMember, adminRoleIds: string[] = [], modRoleIds: string[] = []): boolean {
    if (this.isAdministrator(member, adminRoleIds)) {
      return true;
    }
    if (
      member.permissions.has(PermissionFlagsBits.BanMembers) ||
      member.permissions.has(PermissionFlagsBits.KickMembers) ||
      member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
      member.permissions.has(PermissionFlagsBits.ManageMessages)
    ) {
      return true;
    }
    return member.roles.cache.some(role => modRoleIds.includes(role.id));
  }

  /**
   * Evaluate the user's highest effective PermissionLevel
   */
  public static async getUserPermissionLevel(
    member: GuildMember | null,
    user: User,
    guild: Guild | null
  ): Promise<PermissionLevel> {
    if (this.isGlobalBotOwner(user.id)) {
      return PermissionLevel.GLOBAL_BOT_OWNER;
    }

    if (!guild || !member) {
      return PermissionLevel.EVERYONE;
    }

    if (this.isServerOwner(guild, user.id)) {
      return PermissionLevel.DISCORD_SERVER_OWNER;
    }

    const adminRoleIds = await GuildRepository.getAdminRoleIds(guild.id);
    if (this.isAdministrator(member, adminRoleIds)) {
      return PermissionLevel.ADMINISTRATOR;
    }

    const modRoleIds = await GuildRepository.getModRoleIds(guild.id);
    if (this.isModerator(member, adminRoleIds, modRoleIds)) {
      return PermissionLevel.MODERATOR;
    }

    return PermissionLevel.MEMBER;
  }

  /**
   * Comprehensive validation for command execution
   */
  public static async checkCommandAccess(
    command: Command,
    ctx: CommandContext
  ): Promise<{ allowed: boolean; reason?: string }> {
    const isOwner = this.isGlobalBotOwner(ctx.user.id);

    // 1. Global Owner Only Commands - strictly guarded server-side
    if (command.ownerOnly || command.requiredPermission === PermissionLevel.GLOBAL_BOT_OWNER) {
      if (!isOwner) {
        return {
          allowed: false,
          reason: 'This command is restricted to Global Bot Owners.',
        };
      }
      return { allowed: true };
    }

    // If global owner is running any command, always allow
    if (isOwner) {
      return { allowed: true };
    }

    // 2. Guild Only check
    if (command.guildOnly && !ctx.guild) {
      return {
        allowed: false,
        reason: 'This command can only be used in a Discord server.',
      };
    }

    // DM commands (if any)
    if (!ctx.guild || !ctx.member) {
      return { allowed: true };
    }

    // 3. Discord Server Owner bypass for all guild-level commands
    const isGuildOwner = this.isServerOwner(ctx.guild, ctx.user.id);
    if (isGuildOwner) {
      return { allowed: true };
    }

    // 4. Command Permission Override Checks from Database
    const override = await GuildRepository.getCommandOverride(ctx.guild.id, command.name);
    if (override) {
      // If command explicitly disabled in guild
      if (!override.enabled) {
        return {
          allowed: false,
          reason: `The \`${command.name}\` command is disabled in this server.`,
        };
      }

      // Check denied channels
      if (ctx.channel && override.deniedChannelIds.includes(ctx.channel.id)) {
        return {
          allowed: false,
          reason: 'This command is not permitted in this channel.',
        };
      }

      // Check allowed channels
      if (
        ctx.channel &&
        override.allowedChannelIds.length > 0 &&
        !override.allowedChannelIds.includes(ctx.channel.id)
      ) {
        return {
          allowed: false,
          reason: 'This command is restricted to specific channels in this server.',
        };
      }

      // Check denied users
      if (override.deniedUserIds.includes(ctx.user.id)) {
        return {
          allowed: false,
          reason: 'You are explicitly denied from using this command.',
        };
      }

      // Check denied roles
      const hasDeniedRole = ctx.member.roles.cache.some(role => override.deniedRoleIds.includes(role.id));
      if (hasDeniedRole) {
        return {
          allowed: false,
          reason: 'One of your roles is denied from using this command.',
        };
      }

      // Check allowed users (explicit grant)
      if (override.allowedUserIds.includes(ctx.user.id)) {
        return { allowed: true };
      }

      // Check allowed roles (explicit grant)
      const hasAllowedRole = ctx.member.roles.cache.some(role => override.allowedRoleIds.includes(role.id));
      if (hasAllowedRole) {
        return { allowed: true };
      }
    }

    // 5. Discord Native Permissions check
    if (command.discordPermissions && command.discordPermissions.length > 0) {
      for (const perm of command.discordPermissions) {
        if (!ctx.member.permissions.has(perm)) {
          return {
            allowed: false,
            reason: `You are missing the required Discord permission: \`${perm.toString()}\`.`,
          };
        }
      }
    }

    // 6. Base Level check
    const adminRoles = await GuildRepository.getAdminRoleIds(ctx.guild.id);
    const modRoles = await GuildRepository.getModRoleIds(ctx.guild.id);

    switch (command.requiredPermission) {
      case PermissionLevel.DISCORD_SERVER_OWNER:
        if (!isGuildOwner) {
          return { allowed: false, reason: 'This command is restricted to the Server Owner.' };
        }
        break;

      case PermissionLevel.ADMINISTRATOR:
        if (!this.isAdministrator(ctx.member, adminRoles)) {
          return { allowed: false, reason: 'You must be a Server Administrator to use this command.' };
        }
        break;

      case PermissionLevel.MODERATOR:
        if (!this.isModerator(ctx.member, adminRoles, modRoles)) {
          return { allowed: false, reason: 'You must be a Moderator to use this command.' };
        }
        break;

      default:
        // Member / Everyone
        break;
    }

    return { allowed: true };
  }

  /**
   * Check Discord role hierarchy between executor, target and bot
   */
  public static checkRoleHierarchy(
    executor: GuildMember,
    target: GuildMember,
    botMember?: GuildMember
  ): { allowed: boolean; reason?: string } {
    // Cannot moderate server owner
    if (target.guild.ownerId === target.id) {
      return {
        allowed: false,
        reason: 'You cannot perform moderation actions against the Server Owner.',
      };
    }

    // Cannot moderate self
    if (executor.id === target.id) {
      return {
        allowed: false,
        reason: 'You cannot perform moderation actions on yourself.',
      };
    }

    // Executor hierarchy check (server owner can moderate anyone except themselves)
    if (executor.guild.ownerId !== executor.id) {
      if (executor.roles.highest.position <= target.roles.highest.position) {
        return {
          allowed: false,
          reason: 'You cannot moderate this user because their highest role is equal to or higher than yours.',
        };
      }
    }

    // Bot hierarchy check
    if (botMember) {
      if (botMember.roles.highest.position <= target.roles.highest.position) {
        return {
          allowed: false,
          reason: 'I cannot moderate this user because their highest role is equal to or higher than my highest role.',
        };
      }
    }

    return { allowed: true };
  }
}
