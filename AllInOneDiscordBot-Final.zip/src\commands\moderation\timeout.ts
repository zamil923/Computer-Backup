import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';
import { Formatters } from '../../utils/formatters.js';

export const timeoutCommand: Command = {
  name: 'timeout',
  description: 'Timeout (mute) or remove timeout from a member',
  category: 'Moderation',
  usage: 'timeout <@user|id> [duration: 10m|1h|24h|remove] [reason]',
  examples: [
    '/timeout user:@member duration:1h reason:Spamming chat',
    '^timeout @member 30m Disrespectful behavior',
    '^timeout @member remove Resolved',
  ],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.ModerateMembers],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout or remove timeout from a member')
    .addUserOption(opt => opt.setName('user').setDescription('Target member').setRequired(true))
    .addStringOption(opt =>
      opt
        .setName('duration')
        .setDescription('Duration (e.g. 5m, 1h, 1d) or "remove"')
        .setRequired(true)
    )
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for timeout').setRequired(false)),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member) return;

    const member = await ctx.getMember('user', true);
    if (!member) {
      await ctx.reply('❌ Please specify a member currently in the server.');
      return;
    }

    const durationInput = ctx.getString('duration', true) || '10m';
    const reason = ctx.getString('reason') || 'No reason provided';
    await ctx.defer();

    if (durationInput.toLowerCase() === 'remove' || durationInput.toLowerCase() === 'unmute') {
      const result = await ModerationService.removeTimeout(ctx.guild, ctx.member, member, reason);
      await ctx.editReply(result.message);
      return;
    }

    const seconds = Formatters.parseDuration(durationInput);
    if (!seconds || seconds <= 0) {
      await ctx.editReply('❌ Invalid duration. Please use formats like `10s`, `15m`, `2h`, `1d`, `7d`, or `remove`.');
      return;
    }

    const durationMs = seconds * 1000;
    const durationStr = Formatters.formatDuration(seconds);

    const result = await ModerationService.timeout(ctx.guild, ctx.member, member, durationMs, durationStr, reason);
    await ctx.editReply(result.message);
  },
};
