import {
  Guild,
  GuildMember,
  User,
  PermissionFlagsBits,
  TextChannel,
  NewsChannel,
  ThreadChannel,
} from 'discord.js';
import { PermissionManager } from '../permissions/permissionManager.js';
import { ModerationRepository } from '../repositories/moderationRepository.js';
import { LoggingService } from './loggingService.js';
import { ModCase, Warning } from '@prisma/client';

export interface ModActionResult {
  success: boolean;
  message: string;
  modCase?: ModCase;
  warning?: Warning;
}

export class ModerationService {
  /**
   * BAN user
   */
  public static async ban(
    guild: Guild,
    moderator: GuildMember,
    targetUser: User,
    reason: string,
    deleteMessageSeconds = 0
  ): Promise<ModActionResult> {
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.BanMembers)) {
      return { success: false, message: 'I do not have Discord permission to ban members.' };
    }

    const targetMember = guild.members.cache.get(targetUser.id) ?? (await guild.members.fetch(targetUser.id).catch(() => null));
    if (targetMember) {
      const hierarchyCheck = PermissionManager.checkRoleHierarchy(moderator, targetMember, botMember);
      if (!hierarchyCheck.allowed) {
        return { success: false, message: hierarchyCheck.reason! };
      }
    }

    // Try to DM user prior to ban
    await targetUser.send(`You have been banned from **${guild.name}**.\nReason: ${reason}`).catch(() => null);

    await guild.bans.create(targetUser.id, {
      reason: `${moderator.user.tag}: ${reason}`,
      deleteMessageSeconds,
    });

    const modCase = await ModerationRepository.createCase({
      guildId: guild.id,
      action: 'BAN',
      targetId: targetUser.id,
      targetTag: targetUser.tag,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    await LoggingService.logModCase(guild, modCase);

    return {
      success: true,
      message: `Successfully banned **${targetUser.tag}** (Case #${modCase.caseNumber}). Reason: ${reason}`,
      modCase,
    };
  }

  /**
   * UNBAN user
   */
  public static async unban(
    guild: Guild,
    moderator: GuildMember,
    targetUserId: string,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.BanMembers)) {
      return { success: false, message: 'I do not have Discord permission to unban members.' };
    }

    const ban = await guild.bans.fetch(targetUserId).catch(() => null);
    if (!ban) {
      return { success: false, message: 'This user is not banned in this server.' };
    }

    await guild.bans.remove(targetUserId, `${moderator.user.tag}: ${reason}`);

    const modCase = await ModerationRepository.createCase({
      guildId: guild.id,
      action: 'UNBAN',
      targetId: ban.user.id,
      targetTag: ban.user.tag,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    await LoggingService.logModCase(guild, modCase);

    return {
      success: true,
      message: `Successfully unbanned **${ban.user.tag}** (Case #${modCase.caseNumber}). Reason: ${reason}`,
      modCase,
    };
  }

  /**
   * KICK member
   */
  public static async kick(
    guild: Guild,
    moderator: GuildMember,
    targetMember: GuildMember,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.KickMembers)) {
      return { success: false, message: 'I do not have Discord permission to kick members.' };
    }

    const hierarchyCheck = PermissionManager.checkRoleHierarchy(moderator, targetMember, botMember);
    if (!hierarchyCheck.allowed) {
      return { success: false, message: hierarchyCheck.reason! };
    }

    await targetMember.user.send(`You have been kicked from **${guild.name}**.\nReason: ${reason}`).catch(() => null);
    await targetMember.kick(`${moderator.user.tag}: ${reason}`);

    const modCase = await ModerationRepository.createCase({
      guildId: guild.id,
      action: 'KICK',
      targetId: targetMember.id,
      targetTag: targetMember.user.tag,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    await LoggingService.logModCase(guild, modCase);

    return {
      success: true,
      message: `Successfully kicked **${targetMember.user.tag}** (Case #${modCase.caseNumber}). Reason: ${reason}`,
      modCase,
    };
  }

  /**
   * TIMEOUT member
   */
  public static async timeout(
    guild: Guild,
    moderator: GuildMember,
    targetMember: GuildMember,
    durationMs: number,
    durationStr: string,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return { success: false, message: 'I do not have Discord permission to timeout members.' };
    }

    const hierarchyCheck = PermissionManager.checkRoleHierarchy(moderator, targetMember, botMember);
    if (!hierarchyCheck.allowed) {
      return { success: false, message: hierarchyCheck.reason! };
    }

    // Maximum timeout is 28 days
    const maxMs = 28 * 24 * 60 * 60 * 1000;
    if (durationMs > maxMs) {
      return { success: false, message: 'Timeout duration cannot exceed 28 days.' };
    }

    await targetMember.timeout(durationMs, `${moderator.user.tag}: ${reason}`);

    const expiresAt = new Date(Date.now() + durationMs);
    const modCase = await ModerationRepository.createCase({
      guildId: guild.id,
      action: 'TIMEOUT',
      targetId: targetMember.id,
      targetTag: targetMember.user.tag,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
      duration: durationStr,
      expiresAt,
    });

    await LoggingService.logModCase(guild, modCase);

    return {
      success: true,
      message: `Successfully timed out **${targetMember.user.tag}** for ${durationStr} (Case #${modCase.caseNumber}). Reason: ${reason}`,
      modCase,
    };
  }

  /**
   * REMOVE TIMEOUT
   */
  public static async removeTimeout(
    guild: Guild,
    moderator: GuildMember,
    targetMember: GuildMember,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return { success: false, message: 'I do not have Discord permission to moderate members.' };
    }

    const hierarchyCheck = PermissionManager.checkRoleHierarchy(moderator, targetMember, botMember);
    if (!hierarchyCheck.allowed) {
      return { success: false, message: hierarchyCheck.reason! };
    }

    if (!targetMember.communicationDisabledUntilTimestamp) {
      return { success: false, message: 'This member is not currently timed out.' };
    }

    await targetMember.timeout(null, `${moderator.user.tag}: ${reason}`);

    const modCase = await ModerationRepository.createCase({
      guildId: guild.id,
      action: 'REMOVE_TIMEOUT',
      targetId: targetMember.id,
      targetTag: targetMember.user.tag,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    await LoggingService.logModCase(guild, modCase);

    return {
      success: true,
      message: `Successfully removed timeout for **${targetMember.user.tag}** (Case #${modCase.caseNumber}).`,
      modCase,
    };
  }

  /**
   * WARN member
   */
  public static async warn(
    guild: Guild,
    moderator: GuildMember,
    targetMember: GuildMember,
    reason: string
  ): Promise<ModActionResult> {
    const hierarchyCheck = PermissionManager.checkRoleHierarchy(moderator, targetMember);
    if (!hierarchyCheck.allowed) {
      return { success: false, message: hierarchyCheck.reason! };
    }

    const modCase = await ModerationRepository.createCase({
      guildId: guild.id,
      action: 'WARN',
      targetId: targetMember.id,
      targetTag: targetMember.user.tag,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    const warning = await ModerationRepository.createWarning(
      guild.id,
      targetMember.id,
      moderator.id,
      reason,
      modCase.id
    );

    await targetMember.user
      .send(`You have received a warning in **${guild.name}**.\nReason: ${reason}`)
      .catch(() => null);

    await LoggingService.logModCase(guild, modCase);

    const count = await ModerationRepository.countWarnings(guild.id, targetMember.id);

    return {
      success: true,
      message: `Warned **${targetMember.user.tag}** (Case #${modCase.caseNumber}, Total Warnings: ${count}). Reason: ${reason}`,
      modCase,
      warning,
    };
  }

  /**
   * PURGE messages
   */
  public static async purge(
    channel: TextChannel | NewsChannel | ThreadChannel,
    amount: number,
    moderator: GuildMember,
    targetUser?: User
  ): Promise<{ success: boolean; count: number; message: string }> {
    const botMember = channel.guild.members.me;
    if (!botMember?.permissionsIn(channel.id).has(PermissionFlagsBits.ManageMessages)) {
      return { success: false, count: 0, message: 'I do not have permission to manage messages in this channel.' };
    }

    const messages = await channel.messages.fetch({ limit: Math.min(amount, 100) });
    let toDelete = messages;

    if (targetUser) {
      toDelete = messages.filter(m => m.author.id === targetUser.id);
    }

    // Filter out messages older than 14 days (Discord limit for bulkDelete)
    const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
    toDelete = toDelete.filter(m => m.createdTimestamp > twoWeeksAgo);

    const deleted = await channel.bulkDelete(toDelete, true);

    const modCase = await ModerationRepository.createCase({
      guildId: channel.guild.id,
      action: 'PURGE',
      targetId: targetUser ? targetUser.id : channel.id,
      targetTag: targetUser ? targetUser.tag : `#${channel.name}`,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason: `Purged ${deleted.size} messages in #${channel.name}`,
    });

    await LoggingService.logModCase(channel.guild, modCase);

    return {
      success: true,
      count: deleted.size,
      message: `Successfully deleted ${deleted.size} messages.`,
    };
  }

  /**
   * SLOWMODE
   */
  public static async slowmode(
    channel: TextChannel | NewsChannel | ThreadChannel,
    seconds: number,
    moderator: GuildMember,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = channel.guild.members.me;
    if (!botMember?.permissionsIn(channel.id).has(PermissionFlagsBits.ManageChannels)) {
      return { success: false, message: 'I do not have permission to manage this channel.' };
    }

    if (seconds < 0 || seconds > 21600) {
      return { success: false, message: 'Slowmode must be between 0 seconds and 6 hours (21600s).' };
    }

    await channel.setRateLimitPerUser(seconds, `${moderator.user.tag}: ${reason}`);

    return {
      success: true,
      message:
        seconds === 0
          ? `Slowmode disabled in <#${channel.id}>.`
          : `Set slowmode in <#${channel.id}> to **${seconds}s**.`,
    };
  }

  /**
   * LOCK channel
   */
  public static async lock(
    channel: TextChannel | NewsChannel,
    moderator: GuildMember,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = channel.guild.members.me;
    if (!botMember?.permissionsIn(channel).has(PermissionFlagsBits.ManageChannels)) {
      return { success: false, message: 'I do not have permission to manage this channel.' };
    }

    const everyoneRole = channel.guild.roles.everyone;
    await channel.permissionOverwrites.edit(everyoneRole, {
      SendMessages: false,
      AddReactions: false,
    }, { reason: `${moderator.user.tag}: ${reason}` });

    const modCase = await ModerationRepository.createCase({
      guildId: channel.guild.id,
      action: 'LOCK',
      targetId: channel.id,
      targetTag: `#${channel.name}`,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    await LoggingService.logModCase(channel.guild, modCase);

    return {
      success: true,
      message: `🔒 Locked <#${channel.id}>. Reason: ${reason}`,
      modCase,
    };
  }

  /**
   * UNLOCK channel
   */
  public static async unlock(
    channel: TextChannel | NewsChannel,
    moderator: GuildMember,
    reason: string
  ): Promise<ModActionResult> {
    const botMember = channel.guild.members.me;
    if (!botMember?.permissionsIn(channel).has(PermissionFlagsBits.ManageChannels)) {
      return { success: false, message: 'I do not have permission to manage this channel.' };
    }

    const everyoneRole = channel.guild.roles.everyone;
    await channel.permissionOverwrites.edit(everyoneRole, {
      SendMessages: null,
      AddReactions: null,
    }, { reason: `${moderator.user.tag}: ${reason}` });

    const modCase = await ModerationRepository.createCase({
      guildId: channel.guild.id,
      action: 'UNLOCK',
      targetId: channel.id,
      targetTag: `#${channel.name}`,
      moderatorId: moderator.id,
      moderatorTag: moderator.user.tag,
      reason,
    });

    await LoggingService.logModCase(channel.guild, modCase);

    return {
      success: true,
      message: `🔓 Unlocked <#${channel.id}>.`,
      modCase,
    };
  }
}
