import { prisma } from '../database/prisma.js';
import { ModCase, Warning } from '@prisma/client';
import { GuildRepository } from './guildRepository.js';

export interface CreateCaseInput {
  guildId: string;
  action: string;
  targetId: string;
  targetTag: string;
  moderatorId: string;
  moderatorTag: string;
  reason?: string;
  duration?: string;
  expiresAt?: Date;
}

export class ModerationRepository {
  public static async createCase(input: CreateCaseInput): Promise<ModCase> {
    await GuildRepository.getOrCreate(input.guildId);

    // Calculate next case number atomically for the guild
    const lastCase = await prisma.modCase.findFirst({
      where: { guildId: input.guildId },
      orderBy: { caseNumber: 'desc' },
      select: { caseNumber: true },
    });

    const nextNumber = (lastCase?.caseNumber ?? 0) + 1;

    return prisma.modCase.create({
      data: {
        guildId: input.guildId,
        caseNumber: nextNumber,
        action: input.action,
        targetId: input.targetId,
        targetTag: input.targetTag,
        moderatorId: input.moderatorId,
        moderatorTag: input.moderatorTag,
        reason: input.reason || 'No reason provided',
        duration: input.duration,
        expiresAt: input.expiresAt,
        status: 'ACTIVE',
      },
    });
  }

  public static async getCase(guildId: string, caseNumber: number): Promise<ModCase | null> {
    return prisma.modCase.findUnique({
      where: { guildId_caseNumber: { guildId, caseNumber } },
      include: { warning: true },
    });
  }

  public static async getCasesForUser(guildId: string, targetId: string, limit = 10): Promise<ModCase[]> {
    return prisma.modCase.findMany({
      where: { guildId, targetId },
      orderBy: { caseNumber: 'desc' },
      take: limit,
    });
  }

  public static async listCases(guildId: string, limit = 20, offset = 0): Promise<ModCase[]> {
    return prisma.modCase.findMany({
      where: { guildId },
      orderBy: { caseNumber: 'desc' },
      take: limit,
      skip: offset,
    });
  }

  public static async countCases(guildId: string): Promise<number> {
    return prisma.modCase.count({
      where: { guildId },
    });
  }

  // --- Warnings ---

  public static async createWarning(
    guildId: string,
    userId: string,
    moderatorId: string,
    reason: string,
    caseId?: string
  ): Promise<Warning> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.warning.create({
      data: {
        guildId,
        userId,
        moderatorId,
        reason,
        caseId,
      },
    });
  }

  public static async getWarnings(guildId: string, userId: string): Promise<Warning[]> {
    return prisma.warning.findMany({
      where: { guildId, userId },
      orderBy: { createdAt: 'desc' },
    });
  }

  public static async countWarnings(guildId: string, userId: string): Promise<number> {
    return prisma.warning.count({
      where: { guildId, userId },
    });
  }

  public static async deleteWarning(warningId: string): Promise<Warning | null> {
    return prisma.warning.delete({
      where: { id: warningId },
    });
  }
}
