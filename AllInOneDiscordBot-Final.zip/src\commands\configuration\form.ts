import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { FormRepository } from '../../repositories/formRepository.js';


export const formCommand: Command = {
  name: 'form',
  description: 'Manage custom forms',
  category: 'Configuration',
  usage: 'form <subcommand>',
  examples: ['/form create', '/form list'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('form')
    .setDescription('Manage custom forms')
    .addSubcommand(sub =>
      sub
        .setName('create')
        .setDescription('Create a new form')
        .addStringOption(opt => opt.setName('name').setDescription('Form name').setRequired(true))
        .addStringOption(opt => opt.setName('description').setDescription('Form description').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all forms')
    )
    .addSubcommand(sub =>
      sub
        .setName('delete')
        .setDescription('Delete a form')
        .addStringOption(opt => opt.setName('name').setDescription('Form name').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('addquestion')
        .setDescription('Add a question to a form')
        .addStringOption(opt => opt.setName('form').setDescription('Form name').setRequired(true))
        .addStringOption(opt => opt.setName('label').setDescription('Question text').setRequired(true))
        .addStringOption(opt => opt.setName('type').setDescription('Question type').setRequired(true).addChoices(
          { name: 'Short Text', value: 'SHORT_TEXT' },
          { name: 'Long Text', value: 'LONG_TEXT' }
        ))
        .addBooleanOption(opt => opt.setName('required').setDescription('Is required?').setRequired(false))
    )
    .addSubcommand(sub =>
      sub
        .setName('publish')
        .setDescription('Post the form panel to the current channel')
        .addStringOption(opt => opt.setName('name').setDescription('Form name').setRequired(true))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand();

    if (subcommand === 'create') {
      const name = ctx.getString('name', true) ?? '';
      const desc = ctx.getString('description') || undefined;

      const existing = await FormRepository.getFormByName(ctx.guild.id, name);
      if (existing) {
        await ctx.reply(`❌ A form named **${name}** already exists.`);
        return;
      }

      await FormRepository.createForm(ctx.guild.id, name, desc);
      await ctx.reply(`✅ Form **${name}** created! Use \`/form addquestion\` to add questions.`);
    }

    if (subcommand === 'list') {
      const forms = await FormRepository.listForms(ctx.guild.id);
      if (!forms.length) {
        await ctx.reply('No forms found.');
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle('Server Forms')
        .setColor(Colors.Blue)
        .setDescription(forms.map(f => `• **${f.name}** (${f._count.questions} questions, ${f._count.submissions} submissions)`).join('\n'));
      
      await ctx.reply({ embeds: [embed] });
    }

    if (subcommand === 'delete') {
      const name = ctx.getString('name', true) ?? '';
      const form = await FormRepository.getFormByName(ctx.guild.id, name);
      if (!form) {
        await ctx.reply(`❌ Form **${name}** not found.`);
        return;
      }

      await FormRepository.deleteForm(form.id);
      await ctx.reply(`✅ Form **${name}** deleted.`);
    }

    if (subcommand === 'addquestion') {
      const formName = ctx.getString('form', true) ?? '';
      const label = ctx.getString('label', true) ?? '';
      const type = ctx.getString('type', true) ?? '';
      const required = ctx.getBoolean('required') ?? true;

      const form = await FormRepository.getFormByName(ctx.guild.id, formName);
      if (!form) {
        await ctx.reply(`❌ Form **${formName}** not found.`);
        return;
      }

      const order = form.questions.length;
      await FormRepository.addQuestion(form.id, label, type, required, order);

      await ctx.reply(`✅ Question added to **${formName}**.`);
    }

    if (subcommand === 'publish') {
      const formName = ctx.getString('name', true) ?? '';
      const form = await FormRepository.getFormByName(ctx.guild.id, formName);
      if (!form) {
        await ctx.reply(`❌ Form **${formName}** not found.`);
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle(form.name)
        .setDescription(form.description || 'Click the button below to submit this form.')
        .setColor(Colors.Green);
      
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(`form_open_${form.id}`)
          .setLabel('Open Form')
          .setStyle(ButtonStyle.Primary)
      );

      if (ctx.channel && 'send' in ctx.channel) {
        await ctx.channel.send({ embeds: [embed], components: [row] });
        await ctx.reply({ content: '✅ Form published.', ephemeral: true });
      } else {
        await ctx.reply('❌ Cannot publish in this channel.');
      }
    }
  }
};
