import { GuildMember, Message } from 'discord.js';
import { LevelingRepository } from '../repositories/levelingRepository.js';
import { VariableEngine } from '../utils/variables.js';
import { MessageBuilder } from '../utils/embedBuilder.js';
import { TemplateRepository } from '../repositories/templateRepository.js';
import { logger } from '../utils/logger.js';

// In-memory cooldown tracking: guildId:userId -> timestamp
const cooldownMap = new Map<string, number>();

export class LevelingService {
  /**
   * Process a message for XP gain with spam/cooldown protection.
   */
  public static async processMessage(message: Message): Promise<void> {
    if (!message.guild || message.author.bot) return;

    const guildId = message.guild.id;
    const userId = message.author.id;

    const config = await LevelingRepository.getConfig(guildId);
    if (!config || !config.enabled) return;

    // Check ignored channels
    if (config.ignoredChannelIds.includes(message.channelId)) return;

    // Check ignored roles
    const member = message.member;
    if (member) {
      for (const roleId of config.ignoredRoleIds) {
        if (member.roles.cache.has(roleId)) return;
      }
    }

    // XP cooldown check
    const cooldownKey = `${guildId}:${userId}`;
    const lastXp = cooldownMap.get(cooldownKey) ?? 0;
    const now = Date.now();
    if (now - lastXp < config.cooldownSeconds * 1000) return;

    // Anti-spam: skip very short messages (< 5 chars)
    if (message.content.trim().length < 5) return;

    // Calculate XP to award
    const xpGain = Math.floor(
      Math.random() * (config.xpMax - config.xpMin + 1) + config.xpMin
    );
    cooldownMap.set(cooldownKey, now);

    try {
      const result = await LevelingRepository.upsertMemberXp(guildId, userId, xpGain);

      if (result.level > result.prevLevel) {
        await this.handleLevelUp(message, result.level, result.xp, config);
        if (member) {
          await this.applyLevelRoles(member, result.level, config.stackRoles, guildId);
        }
      }
    } catch (err) {
      logger.error('LevelingService', `XP processing failed for ${userId}`, err);
    }
  }

  private static async handleLevelUp(
    message: Message,
    newLevel: number,
    totalXp: number,
    config: { levelUpChannelId: string | null; levelUpMessage: string | null; levelUpTemplateId: string | null }
  ): Promise<void> {
    if (!message.guild) return;

    const context = {
      user: message.author,
      member: message.member ?? undefined,
      guild: message.guild,
      extra: {
        level: String(newLevel),
        xp: String(totalXp),
      },
    };

    let channel = message.channel;
    if (config.levelUpChannelId) {
      const configured = message.guild.channels.cache.get(config.levelUpChannelId);
      if (configured && 'send' in configured) {
        channel = configured as any;
      }
    }

    if (!channel || !('send' in channel)) return;

    // Template message
    if (config.levelUpTemplateId) {
      const template = await TemplateRepository.getById(config.levelUpTemplateId);
      if (template) {
        const payload = MessageBuilder.buildPayload(
          { content: template.content ?? undefined, embeds: template.embedData ? [template.embedData as any] : undefined },
          context
        );
        await (channel as any).send(payload).catch(() => null);
        return;
      }
    }

    // Plain text level-up message
    const text = config.levelUpMessage
      ? VariableEngine.replace(config.levelUpMessage, context)
      : `🎉 <@${message.author.id}> has reached **Level ${newLevel}**!`;

    await (channel as any).send(text).catch(() => null);
  }

  private static async applyLevelRoles(
    member: GuildMember,
    level: number,
    stackRoles: boolean,
    guildId: string
  ): Promise<void> {
    const levelRoles = await LevelingRepository.getLevelRoles(guildId);
    if (!levelRoles.length) return;

    // Roles for levels <= current
    const earned = levelRoles.filter(lr => lr.level <= level);
    if (!earned.length) return;

    const guild = member.guild;
    const botMember = guild.members.me;

    if (stackRoles) {
      // Add all earned roles
      for (const lr of earned) {
        if (member.roles.cache.has(lr.roleId)) continue;
        const role = guild.roles.cache.get(lr.roleId);
        if (!role || !botMember) continue;
        if (botMember.roles.highest.position <= role.position) continue;
        await member.roles.add(lr.roleId, `Level ${lr.level} reward`).catch(() => null);
      }
    } else {
      // Only apply highest earned, remove lower ones
      const highest = earned[earned.length - 1];
      if (!highest) return;
      for (const lr of levelRoles) {
        if (lr.roleId === highest.roleId) {
          if (!member.roles.cache.has(lr.roleId)) {
            const role = guild.roles.cache.get(lr.roleId);
            if (role && botMember && botMember.roles.highest.position > role.position) {
              await member.roles.add(lr.roleId, `Level ${lr.level} reward`).catch(() => null);
            }
          }
        } else {
          if (member.roles.cache.has(lr.roleId)) {
            await member.roles.remove(lr.roleId, 'Level role replaced').catch(() => null);
          }
        }
      }
    }
  }
}
