import { describe, it, expect } from 'vitest';
import { ServerTemplateService, type ServerTemplateData } from '../../src/services/serverTemplateService.js';

// Minimal fixture data representing a guild structure
const fixtureTemplate: ServerTemplateData = {
  version: '1.0',
  roles: [
    {
      id: 'role_staff_old',
      name: 'Staff',
      color: 0xff0000,
      hoist: true,
      mentionable: false,
      permissions: '8',
      position: 2,
    },
    {
      id: 'role_member_old',
      name: 'Member',
      color: 0x0000ff,
      hoist: false,
      mentionable: true,
      permissions: '0',
      position: 1,
    },
  ],
  channels: [
    {
      id: 'cat_info_old',
      name: 'INFORMATION',
      type: 4, // GuildCategory
      position: 0,
      permissionOverwrites: [],
    },
    {
      id: 'ch_rules_old',
      name: 'rules',
      type: 0, // GuildText
      parentId: 'cat_info_old',
      position: 0,
      permissionOverwrites: [
        { id: 'role_member_old', type: 0, allow: '1024', deny: '0' },
        { id: 'everyone', type: 0, allow: '0', deny: '1024' },
      ],
    },
  ],
};

describe('Server Template Schema Validation', () => {
  it('fixture has correct version', () => {
    expect(fixtureTemplate.version).toBe('1.0');
  });

  it('fixture has roles', () => {
    expect(fixtureTemplate.roles.length).toBeGreaterThan(0);
  });

  it('fixture has channels', () => {
    expect(fixtureTemplate.channels.length).toBeGreaterThan(0);
  });

  it('roles have required fields', () => {
    for (const role of fixtureTemplate.roles) {
      expect(role.id).toBeTruthy();
      expect(role.name).toBeTruthy();
      expect(typeof role.color).toBe('number');
      expect(typeof role.permissions).toBe('string');
    }
  });

  it('channel with parentId references a known channel id', () => {
    const parentIds = fixtureTemplate.channels
      .filter(c => c.parentId)
      .map(c => c.parentId!);
    
    const allIds = new Set(fixtureTemplate.channels.map(c => c.id));
    for (const pid of parentIds) {
      expect(allIds.has(pid)).toBe(true);
    }
  });

  it('permission overwrite "everyone" sentinel is used correctly', () => {
    const rulesChannel = fixtureTemplate.channels.find(c => c.name === 'rules');
    expect(rulesChannel).toBeTruthy();
    const everyoneOw = rulesChannel!.permissionOverwrites.find(ow => ow.id === 'everyone');
    expect(everyoneOw).toBeTruthy();
  });

  it('managed roles are NOT in the fixture (no @everyone)', () => {
    const everyoneRole = fixtureTemplate.roles.find(r => r.name === '@everyone');
    expect(everyoneRole).toBeUndefined();
  });

  it('safe build does not mark categories for deletion', () => {
    // In safe mode, we only add missing resources, never delete
    // This is a logic/intent test rather than a live API test
    const categories = fixtureTemplate.channels.filter(c => c.type === 4);
    // Safe build should attempt to create each category — no deletion
    expect(categories.length).toBe(1);
    expect(categories[0]!.name).toBe('INFORMATION');
  });
});

describe('Template Reference Mapping', () => {
  it('channel parentId can be resolved from channel list', () => {
    const byId = new Map(fixtureTemplate.channels.map(c => [c.id, c]));
    const child = fixtureTemplate.channels.find(c => c.parentId);
    if (child) {
      expect(byId.has(child.parentId!)).toBe(true);
    }
  });

  it('overwrites reference roles from the role list', () => {
    const roleIds = new Set([...fixtureTemplate.roles.map(r => r.id), 'everyone']);
    for (const channel of fixtureTemplate.channels) {
      for (const ow of channel.permissionOverwrites) {
        expect(roleIds.has(ow.id)).toBe(true);
      }
    }
  });
});
