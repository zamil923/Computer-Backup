import { prisma } from '../database/prisma.js';
import { GuildConfig, LoggingConfig } from '@prisma/client';

export class GuildRepository {
  public static async getOrCreate(guildId: string): Promise<GuildConfig> {
    return prisma.guildConfig.upsert({
      where: { guildId },
      update: {},
      create: {
        guildId,
        prefix: process.env['DEFAULT_PREFIX'] || '^',
      },
    });
  }

  public static async get(guildId: string) {
    return prisma.guildConfig.findUnique({
      where: { guildId },
      include: {
        adminRoles: true,
        modRoles: true,
        permissionOverrides: true,
        welcomeConfig: true,
        leaveConfig: true,
        boostConfig: true,
        loggingConfig: true,
        autoModConfig: true,
        statsConfig: true,
      },
    });
  }

  public static async updatePrefix(guildId: string, prefix: string): Promise<GuildConfig> {
    return prisma.guildConfig.upsert({
      where: { guildId },
      update: { prefix },
      create: { guildId, prefix },
    });
  }

  public static async getAdminRoleIds(guildId: string): Promise<string[]> {
    const roles = await prisma.guildAdminRole.findMany({
      where: { guildId },
      select: { roleId: true },
    });
    return roles.map(r => r.roleId);
  }

  public static async addAdminRole(guildId: string, roleId: string) {
    await this.getOrCreate(guildId);
    return prisma.guildAdminRole.upsert({
      where: { guildId_roleId: { guildId, roleId } },
      update: {},
      create: { guildId, roleId },
    });
  }

  public static async removeAdminRole(guildId: string, roleId: string) {
    return prisma.guildAdminRole.deleteMany({
      where: { guildId, roleId },
    });
  }

  public static async getModRoleIds(guildId: string): Promise<string[]> {
    const roles = await prisma.guildModRole.findMany({
      where: { guildId },
      select: { roleId: true },
    });
    return roles.map(r => r.roleId);
  }

  public static async addModRole(guildId: string, roleId: string) {
    await this.getOrCreate(guildId);
    return prisma.guildModRole.upsert({
      where: { guildId_roleId: { guildId, roleId } },
      update: {},
      create: { guildId, roleId },
    });
  }

  public static async removeModRole(guildId: string, roleId: string) {
    return prisma.guildModRole.deleteMany({
      where: { guildId, roleId },
    });
  }

  public static async getCommandOverride(guildId: string, commandName: string) {
    return prisma.commandPermissionOverride.findUnique({
      where: { guildId_commandName: { guildId, commandName } },
    });
  }

  public static async setCommandOverride(
    guildId: string,
    commandName: string,
    data: {
      enabled?: boolean;
      allowedRoleIds?: string[];
      deniedRoleIds?: string[];
      allowedUserIds?: string[];
      deniedUserIds?: string[];
      allowedChannelIds?: string[];
      deniedChannelIds?: string[];
    }
  ) {
    await this.getOrCreate(guildId);
    return prisma.commandPermissionOverride.upsert({
      where: { guildId_commandName: { guildId, commandName } },
      update: data,
      create: {
        guildId,
        commandName,
        enabled: data.enabled ?? true,
        allowedRoleIds: data.allowedRoleIds ?? [],
        deniedRoleIds: data.deniedRoleIds ?? [],
        allowedUserIds: data.allowedUserIds ?? [],
        deniedUserIds: data.deniedUserIds ?? [],
        allowedChannelIds: data.allowedChannelIds ?? [],
        deniedChannelIds: data.deniedChannelIds ?? [],
      },
    });
  }

  public static async getLoggingConfig(guildId: string): Promise<LoggingConfig | null> {
    return prisma.loggingConfig.findUnique({
      where: { guildId },
    });
  }

  public static async updateLoggingConfig(
    guildId: string,
    data: Partial<Omit<LoggingConfig, 'id' | 'guildId'>>
  ): Promise<LoggingConfig> {
    await this.getOrCreate(guildId);
    return prisma.loggingConfig.upsert({
      where: { guildId },
      update: data,
      create: {
        guildId,
        ...data,
      },
    });
  }
}
