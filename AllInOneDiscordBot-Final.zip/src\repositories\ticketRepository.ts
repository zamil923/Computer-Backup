import { prisma } from '../database/prisma.js';
import { TicketConfig, TicketCategory, TicketPanel, Ticket, TicketTranscript } from '@prisma/client';
import { GuildRepository } from './guildRepository.js';

export class TicketRepository {
  public static async getConfig(guildId: string): Promise<TicketConfig> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.ticketConfig.upsert({
      where: { guildId },
      update: {},
      create: { guildId },
    });
  }

  public static async updateConfig(guildId: string, data: Partial<Omit<TicketConfig, 'id' | 'guildId'>>): Promise<TicketConfig> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.ticketConfig.upsert({
      where: { guildId },
      update: data,
      create: { guildId, ...data },
    });
  }

  // --- Categories ---

  public static async createCategory(
    guildId: string,
    data: {
      name: string;
      emoji?: string;
      description?: string;
      discordCategoryId?: string;
      supportRoleIds?: string[];
      pingRoleIds?: string[];
      namingFormat?: string;
      welcomeMessage?: string;
      welcomeTemplateId?: string;
    }
  ): Promise<TicketCategory> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.ticketCategory.create({
      data: {
        guildId,
        name: data.name,
        emoji: data.emoji,
        description: data.description,
        discordCategoryId: data.discordCategoryId,
        supportRoleIds: data.supportRoleIds ?? [],
        pingRoleIds: data.pingRoleIds ?? [],
        namingFormat: data.namingFormat ?? 'ticket-{username}',
        welcomeMessage: data.welcomeMessage,
        welcomeTemplateId: data.welcomeTemplateId,
      },
    });
  }

  public static async getCategory(id: string): Promise<TicketCategory | null> {
    return prisma.ticketCategory.findUnique({ where: { id } });
  }

  public static async listCategories(guildId: string): Promise<TicketCategory[]> {
    return prisma.ticketCategory.findMany({
      where: { guildId },
      orderBy: { name: 'asc' },
    });
  }

  public static async deleteCategory(id: string): Promise<TicketCategory> {
    return prisma.ticketCategory.delete({ where: { id } });
  }

  // --- Panels ---

  public static async createPanel(
    guildId: string,
    data: {
      channelId: string;
      messageId?: string;
      title: string;
      description: string;
      categoryIds: string[];
      displayMode?: 'BUTTON' | 'SELECT_MENU';
      templateId?: string;
    }
  ): Promise<TicketPanel> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.ticketPanel.create({
      data: {
        guildId,
        channelId: data.channelId,
        messageId: data.messageId,
        title: data.title,
        description: data.description,
        categoryIds: data.categoryIds,
        displayMode: data.displayMode ?? 'BUTTON',
        templateId: data.templateId,
      },
    });
  }

  public static async getPanel(id: string): Promise<TicketPanel | null> {
    return prisma.ticketPanel.findUnique({ where: { id } });
  }

  public static async updatePanelMessageId(id: string, messageId: string): Promise<TicketPanel> {
    return prisma.ticketPanel.update({
      where: { id },
      data: { messageId },
    });
  }

  public static async listPanels(guildId: string): Promise<TicketPanel[]> {
    return prisma.ticketPanel.findMany({
      where: { guildId },
    });
  }

  public static async deletePanel(id: string): Promise<TicketPanel> {
    return prisma.ticketPanel.delete({ where: { id } });
  }

  // --- Tickets ---

  public static async createTicket(data: {
    guildId: string;
    channelId: string;
    categoryId?: string;
    openerId: string;
    openerTag: string;
  }): Promise<Ticket> {
    await GuildRepository.getOrCreate(data.guildId);
    return prisma.ticket.create({
      data: {
        guildId: data.guildId,
        channelId: data.channelId,
        categoryId: data.categoryId,
        openerId: data.openerId,
        openerTag: data.openerTag,
        status: 'OPEN',
      },
    });
  }

  public static async getTicketByChannel(channelId: string) {
    return prisma.ticket.findUnique({
      where: { channelId },
      include: { category: true, transcript: true },
    });
  }

  public static async getTicketById(id: string) {
    return prisma.ticket.findUnique({
      where: { id },
      include: { category: true, transcript: true },
    });
  }

  public static async countOpenTicketsForUser(guildId: string, openerId: string): Promise<number> {
    return prisma.ticket.count({
      where: {
        guildId,
        openerId,
        status: 'OPEN',
      },
    });
  }

  public static async countTotalTickets(guildId: string): Promise<number> {
    return prisma.ticket.count({
      where: { guildId },
    });
  }

  public static async claimTicket(channelId: string, claimerId: string): Promise<Ticket> {
    return prisma.ticket.update({
      where: { channelId },
      data: { claimerId },
    });
  }

  public static async unclaimTicket(channelId: string): Promise<Ticket> {
    return prisma.ticket.update({
      where: { channelId },
      data: { claimerId: null },
    });
  }

  public static async closeTicket(
    channelId: string,
    closedBy: string,
    reason?: string
  ): Promise<Ticket> {
    return prisma.ticket.update({
      where: { channelId },
      data: {
        status: 'CLOSED',
        closedBy,
        closedAt: new Date(),
        closeReason: reason || 'Ticket closed by staff',
      },
    });
  }

  public static async saveRating(ticketId: string, rating: number, feedback?: string): Promise<Ticket> {
    return prisma.ticket.update({
      where: { id: ticketId },
      data: {
        rating,
        ratingFeedback: feedback,
      },
    });
  }

  public static async saveTranscript(data: {
    ticketId: string;
    guildId: string;
    content: string;
    format: string;
    messageCount: number;
    generatedBy: string;
  }): Promise<TicketTranscript> {
    return prisma.ticketTranscript.upsert({
      where: { ticketId: data.ticketId },
      update: {
        content: data.content,
        format: data.format,
        messageCount: data.messageCount,
        generatedBy: data.generatedBy,
      },
      create: {
        ticketId: data.ticketId,
        guildId: data.guildId,
        content: data.content,
        format: data.format,
        messageCount: data.messageCount,
        generatedBy: data.generatedBy,
      },
    });
  }
}
