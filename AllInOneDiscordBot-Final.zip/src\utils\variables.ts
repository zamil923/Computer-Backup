import { Guild, GuildMember, User } from 'discord.js';

export interface VariableContext {
  user?: User;
  member?: GuildMember;
  guild?: Guild;
  extra?: Record<string, string | number>;
}

export class VariableEngine {
  /**
   * Safe replacement of predefined variable tokens.
   * Does NOT evaluate arbitrary code or expressions.
   */
  public static replace(text: string, context: VariableContext): string {
    if (!text || typeof text !== 'string') return '';

    const user = context.user ?? context.member?.user;
    const member = context.member;
    const guild = context.guild ?? context.member?.guild;

    const values: Record<string, string> = {
      '{user}': user ? user.username : '',
      '{username}': user ? user.username : '',
      '{displayName}': member ? member.displayName : user ? user.displayName || user.username : '',
      '{userId}': user ? user.id : '',
      '{userMention}': user ? `<@${user.id}>` : '',
      '{avatar}': user && typeof user.displayAvatarURL === 'function' ? user.displayAvatarURL({ size: 512 }) : '',
      '{server}': guild ? guild.name : '',
      '{serverName}': guild ? guild.name : '',
      '{serverId}': guild ? guild.id : '',
      '{serverIcon}': guild && typeof guild.iconURL === 'function' ? guild.iconURL() ?? '' : '',
      '{memberCount}': guild ? String(guild.memberCount) : '0',
      '{boostCount}': guild?.premiumSubscriptionCount ? String(guild.premiumSubscriptionCount) : '0',
      '{boostTier}': guild?.premiumTier ? String(guild.premiumTier) : '0',
    };

    if (context.extra) {
      for (const [key, val] of Object.entries(context.extra)) {
        values[`{${key}}`] = String(val);
      }
    }

    // Replace all known tokens safely
    return text.replace(/\{[a-zA-Z0-9_]+\}/g, match => {
      if (Object.prototype.hasOwnProperty.call(values, match)) {
        return values[match] ?? '';
      }
      return match;
    });
  }

  /**
   * Recursively replace variables in any string or object structure
   */
  public static replaceDeep<T>(data: T, context: VariableContext): T {
    if (typeof data === 'string') {
      return this.replace(data, context) as unknown as T;
    }

    if (Array.isArray(data)) {
      return data.map(item => this.replaceDeep(item, context)) as unknown as T;
    }

    if (data !== null && typeof data === 'object') {
      const result: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(data)) {
        result[key] = this.replaceDeep(value, context);
      }
      return result as unknown as T;
    }

    return data;
  }
}
