import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { LevelingRepository } from '../../repositories/levelingRepository.js';

const PAGE_SIZE = 10;

export const leaderboardCommand: Command = {
  name: 'leaderboard',
  description: 'View the server XP leaderboard',
  category: 'Leveling',
  usage: 'leaderboard [page]',
  examples: ['/leaderboard', '^leaderboard 2'],
  requiredPermission: PermissionLevel.EVERYONE,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the XP leaderboard')
    .addIntegerOption(opt =>
      opt.setName('page').setDescription('Page number').setMinValue(1).setRequired(false)
    ),

  async execute(ctx) {
    if (!ctx.guild) return;
    await ctx.defer();

    const config = await LevelingRepository.getConfig(ctx.guild.id);
    if (!config?.enabled) {
      await ctx.editReply('❌ Leveling is not enabled on this server.');
      return;
    }

    const page = Math.max(1, ctx.getInteger('page') ?? 1);
    const offset = (page - 1) * PAGE_SIZE;
    const entries = await LevelingRepository.getLeaderboard(ctx.guild.id, PAGE_SIZE, offset);

    if (!entries.length) {
      await ctx.editReply('No XP data found yet.');
      return;
    }

    const lines: string[] = [];
    for (let i = 0; i < entries.length; i++) {
      const pos = offset + i + 1;
      const entry = entries[i];
      if (!entry) continue;
      const medal = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : `**${pos}.**`;
      lines.push(`${medal} <@${entry.userId}> — Level **${entry.level}** · ${entry.xp.toLocaleString()} XP`);
    }

    const embed = new EmbedBuilder()
      .setTitle(`🏆 ${ctx.guild.name} XP Leaderboard — Page ${page}`)
      .setColor(Colors.Gold)
      .setDescription(lines.join('\n'))
      .setFooter({ text: `Use /leaderboard page:${page + 1} to see more` });

    await ctx.editReply({ embeds: [embed] });
  },
};
