import { describe, it, expect } from 'vitest';
import { LevelingRepository } from '../src/repositories/levelingRepository.js';

describe('Leveling Calculations', () => {
  it('calculates level 0 for 0 xp', () => {
    expect(LevelingRepository.calculateLevel(0)).toBe(0);
  });

  it('calculates level 1 at 100 xp', () => {
    expect(LevelingRepository.calculateLevel(100)).toBe(1);
  });

  it('calculates level 3 at 900 xp', () => {
    expect(LevelingRepository.calculateLevel(900)).toBe(3);
  });

  it('requires 100 xp for level 1', () => {
    expect(LevelingRepository.xpRequiredForLevel(1)).toBe(100);
  });

  it('requires 400 xp for level 2', () => {
    expect(LevelingRepository.xpRequiredForLevel(2)).toBe(400);
  });

  it('next level xp is correct', () => {
    expect(LevelingRepository.xpRequiredForNextLevel(1)).toBe(400);
  });

  it('level 10 requires 10000 xp', () => {
    expect(LevelingRepository.xpRequiredForLevel(10)).toBe(10000);
  });
});
