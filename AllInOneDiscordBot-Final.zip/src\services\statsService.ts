import { Guild, Client, VoiceChannel, PermissionFlagsBits } from 'discord.js';
import { StatsRepository } from '../repositories/statsRepository.js';
import { TicketRepository } from '../repositories/ticketRepository.js';
import { ModerationRepository } from '../repositories/moderationRepository.js';
import { logger } from '../utils/logger.js';

export interface ServerStatsData {
  totalMembers: number;
  humans: number;
  bots: number;
  online: number;
  boosts: number;
  boostTier: number;
  textChannels: number;
  voiceChannels: number;
  totalChannels: number;
  rolesCount: number;
  totalTickets: number;
  totalModCases: number;
}

export class StatsService {
  /**
   * Compute complete server statistics
   */
  public static async getServerStats(guild: Guild): Promise<ServerStatsData> {
    // Ensure members cache is populated if possible
    const members = await guild.members.fetch().catch(() => guild.members.cache);
    const totalMembers = guild.memberCount;
    const bots = members.filter(m => m.user.bot).size;
    const humans = totalMembers - bots;

    const online = members.filter(m => m.presence?.status && m.presence.status !== 'offline').size;
    const boosts = guild.premiumSubscriptionCount ?? 0;
    const boostTier = guild.premiumTier;

    const channels = guild.channels.cache;
    const textChannels = channels.filter(c => c.isTextBased() && !c.isVoiceBased()).size;
    const voiceChannels = channels.filter(c => c.isVoiceBased()).size;
    const totalChannels = channels.size;

    const rolesCount = guild.roles.cache.size;

    const totalTickets = await TicketRepository.countTotalTickets(guild.id);
    const totalModCases = await ModerationRepository.countCases(guild.id);

    return {
      totalMembers,
      humans,
      bots,
      online,
      boosts,
      boostTier,
      textChannels,
      voiceChannels,
      totalChannels,
      rolesCount,
      totalTickets,
      totalModCases,
    };
  }

  /**
   * Periodic updater for voice channel statistics
   * Rate limited: only updates channels whose count actually changed, with cooldown
   */
  public static async updateVoiceStats(client: Client): Promise<void> {
    for (const guild of client.guilds.cache.values()) {
      try {
        const voiceChannels = await StatsRepository.listVoiceStatChannels(guild.id);
        if (voiceChannels.length === 0) continue;

        const stats = await this.getServerStats(guild);

        for (const vsc of voiceChannels) {
          const channel = guild.channels.cache.get(vsc.channelId) as VoiceChannel | undefined;
          if (!channel) continue;

          let targetValue = 0;
          let label = 'Members';

          switch (vsc.statType.toUpperCase()) {
            case 'MEMBERS':
              targetValue = stats.totalMembers;
              label = '👥 Members';
              break;
            case 'HUMANS':
              targetValue = stats.humans;
              label = '👤 Humans';
              break;
            case 'BOTS':
              targetValue = stats.bots;
              label = '🤖 Bots';
              break;
            case 'ONLINE':
              targetValue = stats.online;
              label = '🟢 Online';
              break;
            case 'BOOSTS':
              targetValue = stats.boosts;
              label = '🚀 Boosts';
              break;
            case 'CHANNELS':
              targetValue = stats.totalChannels;
              label = '📁 Channels';
              break;
            case 'ROLES':
              targetValue = stats.rolesCount;
              label = '🏷️ Roles';
              break;
            case 'TICKETS':
              targetValue = stats.totalTickets;
              label = '🎫 Tickets';
              break;
            default:
              targetValue = stats.totalMembers;
              break;
          }

          // If count hasn't changed, don't waste Discord rate limit
          if (vsc.lastValue === targetValue && channel.name.includes(String(targetValue))) {
            continue;
          }

          const botMember = guild.members.me;
          if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) continue;

          const newName = vsc.formatString
            .replace('{count}', targetValue.toLocaleString())
            .replace('{label}', label);

          if (channel.name !== newName) {
            await channel.setName(newName).catch(err => {
              logger.warn('StatsService', `Rate limited or failed updating voice stat channel ${channel.id}`, err);
            });
            await StatsRepository.updateVoiceStatChannelValue(vsc.id, targetValue);
          }
        }
      } catch (err) {
        logger.error('StatsService', `Failed updating voice stats for guild ${guild.id}`, err);
      }
    }
  }
}
