import {
  ChatInputCommandInteraction,
  Message,
  Guild,
  GuildMember,
  User,
  GuildTextBasedChannel,
  Channel,
  Role,
  InteractionReplyOptions,
  MessageReplyOptions,
  SlashCommandBuilder,
  SlashCommandSubcommandsOnlyBuilder,
  SlashCommandOptionsOnlyBuilder,
  PermissionResolvable,
  Client,
  InteractionResponse,
} from 'discord.js';

export enum PermissionLevel {
  GLOBAL_BOT_OWNER = 1,
  DISCORD_SERVER_OWNER = 2,
  ADMINISTRATOR = 3,
  MODERATOR = 4,
  CUSTOM_ALLOWED_ROLE = 5,
  CUSTOM_ALLOWED_USER = 6,
  MEMBER = 7,
  EVERYONE = 8,
}

export type CommandCategory =
  | 'General'
  | 'Setup'
  | 'Welcome / Leave / Boost'
  | 'Moderation'
  | 'AutoMod / Security'
  | 'Embeds & Messages'
  | 'Tickets'
  | 'Roles'
  | 'Statistics'
  | 'Auto Responder'
  | 'Configuration'
  | 'Leveling'
  | 'Server Templates'
  | 'Owner';

export interface CommandContext {
  readonly client: Client;
  readonly isSlash: boolean;
  readonly interaction?: ChatInputCommandInteraction;
  readonly message?: Message;
  readonly guild: Guild | null;
  readonly member: GuildMember | null;
  readonly user: User;
  readonly channel: GuildTextBasedChannel | null;
  readonly prefix: string;

  // Output operations
  reply(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message | InteractionResponse>;
  defer(ephemeral?: boolean): Promise<void>;
  editReply(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message>;
  followUp(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message>;

  // Option getters (works seamlessly across slash options & parsed prefix args)
  getString(name: string, required?: boolean): string | null;
  getInteger(name: string, required?: boolean): number | null;
  getBoolean(name: string, required?: boolean): boolean | null;
  getUser(name: string, required?: boolean): Promise<User | null>;
  getMember(name: string, required?: boolean): Promise<GuildMember | null>;
  getChannel(name: string, required?: boolean): Channel | null;
  getRole(name: string, required?: boolean): Role | null;
  getSubcommand(required?: boolean): string | null;
  getSubcommandGroup(): string | null;
}

export interface CommandOptionInfo {
  name: string;
  description: string;
  type: 'STRING' | 'INTEGER' | 'BOOLEAN' | 'USER' | 'CHANNEL' | 'ROLE';
  required?: boolean;
}

export interface Command {
  name: string;
  description: string;
  category: CommandCategory;
  usage: string;
  examples: string[];
  requiredPermission: PermissionLevel;
  discordPermissions?: PermissionResolvable[];
  guildOnly?: boolean;
  ownerOnly?: boolean;
  cooldown?: number; // seconds
  slashBuilder:
    | SlashCommandBuilder
    | SlashCommandSubcommandsOnlyBuilder
    | SlashCommandOptionsOnlyBuilder
    | Omit<SlashCommandBuilder, 'addSubcommand' | 'addSubcommandGroup'>;
  execute(ctx: CommandContext): Promise<void>;
}
