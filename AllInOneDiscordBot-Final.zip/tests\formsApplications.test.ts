import { describe, it, expect } from 'vitest';

// Simulate form submission state machine
type SubmissionStatus = 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED' | 'WITHDRAWN';

function isValidTransition(from: SubmissionStatus, to: SubmissionStatus): boolean {
  const allowed: Record<SubmissionStatus, SubmissionStatus[]> = {
    PENDING: ['UNDER_REVIEW', 'REJECTED', 'WITHDRAWN'],
    UNDER_REVIEW: ['APPROVED', 'REJECTED', 'PENDING'],
    APPROVED: [],
    REJECTED: [],
    WITHDRAWN: [],
  };
  return allowed[from].includes(to);
}

describe('Application State Transitions', () => {
  it('PENDING can move to UNDER_REVIEW', () => {
    expect(isValidTransition('PENDING', 'UNDER_REVIEW')).toBe(true);
  });

  it('PENDING can be REJECTED', () => {
    expect(isValidTransition('PENDING', 'REJECTED')).toBe(true);
  });

  it('PENDING can be WITHDRAWN', () => {
    expect(isValidTransition('PENDING', 'WITHDRAWN')).toBe(true);
  });

  it('UNDER_REVIEW can be APPROVED', () => {
    expect(isValidTransition('UNDER_REVIEW', 'APPROVED')).toBe(true);
  });

  it('UNDER_REVIEW can be REJECTED', () => {
    expect(isValidTransition('UNDER_REVIEW', 'REJECTED')).toBe(true);
  });

  it('APPROVED cannot be changed', () => {
    expect(isValidTransition('APPROVED', 'REJECTED')).toBe(false);
    expect(isValidTransition('APPROVED', 'PENDING')).toBe(false);
  });

  it('REJECTED cannot be changed', () => {
    expect(isValidTransition('REJECTED', 'APPROVED')).toBe(false);
    expect(isValidTransition('REJECTED', 'PENDING')).toBe(false);
  });

  it('WITHDRAWN cannot be changed', () => {
    expect(isValidTransition('WITHDRAWN', 'PENDING')).toBe(false);
  });
});

describe('Form Validation', () => {
  interface FormQuestion {
    label: string;
    type: 'SHORT_TEXT' | 'LONG_TEXT';
    required: boolean;
  }

  function validateAnswers(
    questions: FormQuestion[],
    answers: Record<string, string>
  ): { valid: boolean; missingRequired: string[] } {
    const missingRequired: string[] = [];
    for (const q of questions) {
      if (q.required && !answers[q.label]?.trim()) {
        missingRequired.push(q.label);
      }
    }
    return { valid: missingRequired.length === 0, missingRequired };
  }

  const sampleQuestions: FormQuestion[] = [
    { label: 'Why do you want to join?', type: 'LONG_TEXT', required: true },
    { label: 'Age', type: 'SHORT_TEXT', required: true },
    { label: 'Referral (optional)', type: 'SHORT_TEXT', required: false },
  ];

  it('accepts fully filled required answers', () => {
    const answers = {
      'Why do you want to join?': 'Because I love this community.',
      'Age': '22',
    };
    const result = validateAnswers(sampleQuestions, answers);
    expect(result.valid).toBe(true);
  });

  it('rejects missing required field', () => {
    const answers = {
      'Why do you want to join?': '',
      'Age': '22',
    };
    const result = validateAnswers(sampleQuestions, answers);
    expect(result.valid).toBe(false);
    expect(result.missingRequired).toContain('Why do you want to join?');
  });

  it('passes when optional field is empty', () => {
    const answers = {
      'Why do you want to join?': 'I want to help moderate.',
      'Age': '25',
      'Referral (optional)': '',
    };
    const result = validateAnswers(sampleQuestions, answers);
    expect(result.valid).toBe(true);
  });
});

describe('Rebuild Confirmation Token Expiry', () => {
  function makeToken(expiryMs: number) {
    return {
      token: 'TEST123',
      expiry: Date.now() + expiryMs,
    };
  }

  it('token within 5 minutes is valid', () => {
    const t = makeToken(5 * 60 * 1000);
    expect(Date.now() < t.expiry).toBe(true);
  });

  it('expired token is rejected', () => {
    const t = makeToken(-1); // already expired
    expect(Date.now() > t.expiry).toBe(true);
  });

  it('token from different guild is invalid', () => {
    const token = { guildId: 'guild_A', executorId: 'user_1', expiry: Date.now() + 60000 };
    const requestingGuildId = 'guild_B';
    expect(token.guildId !== requestingGuildId).toBe(true);
  });

  it('token from different user is invalid', () => {
    const token = { guildId: 'guild_A', executorId: 'user_1', expiry: Date.now() + 60000 };
    const requestingUserId = 'user_2';
    expect(token.executorId !== requestingUserId).toBe(true);
  });
});
