import { SlashCommandBuilder, EmbedBuilder, Colors, PermissionFlagsBits } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { RolePanelRepository } from '../../repositories/rolePanelRepository.js';

export const autoroleCommand: Command = {
  name: 'autorole',
  description: 'Manage automatic role assignment for newly joined members',
  category: 'Roles',
  usage: 'autorole <add|remove|list> [role] [target: all|human|bot] [delay: seconds]',
  examples: [
    '/autorole add role:@Member target:human',
    '/autorole add role:@Bots target:bot',
    '/autorole remove role:@Member',
    '/autorole list',
    '^autorole add @Member human',
    '^autorole remove @Member',
    '^autorole list',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  discordPermissions: [PermissionFlagsBits.ManageRoles],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Configure automatic roles for new members')
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add an automatic role')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to assign').setRequired(true))
        .addStringOption(opt =>
          opt
            .setName('target')
            .setDescription('Target member type')
            .setRequired(false)
            .addChoices(
              { name: 'All Members', value: 'ALL' },
              { name: 'Humans Only', value: 'HUMAN' },
              { name: 'Bots Only', value: 'BOT' }
            )
        )
        .addIntegerOption(opt =>
          opt.setName('delay').setDescription('Delay in seconds before assigning role').setRequired(false)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove an automatic role')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true))
        .addStringOption(opt =>
          opt
            .setName('target')
            .setDescription('Target type')
            .setRequired(false)
            .addChoices(
              { name: 'All Members', value: 'ALL' },
              { name: 'Humans Only', value: 'HUMAN' },
              { name: 'Bots Only', value: 'BOT' }
            )
        )
    )
    .addSubcommand(sub => sub.setName('list').setDescription('List all configured auto roles')),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'list';
    await ctx.defer();

    // 1. ADD AUTO ROLE
    if (subcommand === 'add') {
      const role = ctx.getRole('role', true);
      if (!role) {
        await ctx.editReply('❌ Please specify a valid role.');
        return;
      }

      const botMember = ctx.guild.members.me;
      if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles)) {
        await ctx.editReply('❌ I do not have permission to manage roles in this server.');
        return;
      }

      // Check hierarchy
      if (botMember.roles.highest.position <= role.position) {
        await ctx.editReply('❌ I cannot assign this role because it is higher than or equal to my highest role.');
        return;
      }

      // Check managed
      if (role.managed) {
        await ctx.editReply('❌ I cannot assign managed or integration roles (e.g. bot-specific roles or booster roles).');
        return;
      }

      const target = (ctx.getString('target') || 'ALL').toUpperCase();
      const delay = ctx.getInteger('delay') || 0;

      await RolePanelRepository.addAutoRole(ctx.guild.id, role.id, target, delay);
      await ctx.editReply(`✅ Added <@&${role.id}> as an auto-role for **${target}** (delay: ${delay}s).`);
      return;
    }

    // 2. REMOVE AUTO ROLE
    if (subcommand === 'remove') {
      const role = ctx.getRole('role', true);
      if (!role) {
        await ctx.editReply('❌ Please specify a valid role.');
        return;
      }

      const target = (ctx.getString('target') || 'ALL').toUpperCase();
      const removed = await RolePanelRepository.removeAutoRole(ctx.guild.id, role.id, target);

      if (!removed) {
        await ctx.editReply('❌ That role was not configured as an auto role.');
        return;
      }

      await ctx.editReply(`✅ Removed <@&${role.id}> from auto-roles.`);
      return;
    }

    // 3. LIST AUTO ROLES
    const roles = await RolePanelRepository.listAutoRoles(ctx.guild.id);
    if (roles.length === 0) {
      await ctx.editReply('ℹ️ No automatic roles are currently configured for this server.');
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle(`🏷️ Configured Auto Roles — ${ctx.guild.name}`)
      .setColor(Colors.Blue)
      .setDescription(
        roles
          .map((ar, i) => `**${i + 1}.** <@&${ar.roleId}> — Target: \`${ar.targetType}\` | Delay: \`${ar.delaySeconds}s\``)
          .join('\n')
      )
      .setFooter({ text: `Add role: ${ctx.prefix}autorole add @Role [target] [delay]` });

    await ctx.editReply({ embeds: [embed] });
  },
};
