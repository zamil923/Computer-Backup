import { Guild, TextChannel, VoiceChannel, ChannelType } from 'discord.js';
import { logger } from '../utils/logger.js';

export interface SerializedRole {
  id: string;
  name: string;
  color: number;
  hoist: boolean;
  mentionable: boolean;
  permissions: string;
  position: number;
}

export interface SerializedPermissionOverwrite {
  id: string; // role ID or "everyone"
  type: number; // 0 for role, 1 for member
  allow: string;
  deny: string;
}

export interface SerializedChannel {
  id: string;
  name: string;
  type: number;
  parentId?: string;
  position: number;
  topic?: string;
  nsfw?: boolean;
  rateLimitPerUser?: number;
  userLimit?: number;
  bitrate?: number;
  permissionOverwrites: SerializedPermissionOverwrite[];
}

export interface ServerTemplateData {
  version: string;
  roles: SerializedRole[];
  channels: SerializedChannel[];
}

export class ServerTemplateService {
  /**
   * Export the current server structure
   */
  public static async exportGuild(guild: Guild): Promise<ServerTemplateData> {
    const roles: SerializedRole[] = [];
    
    // Sort roles by position descending so highest roles are first in data, though we create them properly
    const sortedRoles = guild.roles.cache.sort((a, b) => b.position - a.position);
    for (const [, role] of sortedRoles) {
      if (role.managed || role.name === '@everyone' || role.id === guild.roles.everyone.id) continue;
      
      roles.push({
        id: role.id,
        name: role.name,
        color: role.color,
        hoist: role.hoist,
        mentionable: role.mentionable,
        permissions: role.permissions.bitfield.toString(),
        position: role.position,
      });
    }

    const channels: SerializedChannel[] = [];
    // Cache all guild channels — only non-thread guild channels have position
    for (const [, channel] of guild.channels.cache) {
      // Skip threads — they don't have a stable position/parent in the same way
      if (channel.isThread()) continue;
      // Only export channels that have position (non-thread guild channels)
      if (!('position' in channel)) continue;
      const pos = (channel as { position: number }).position;
      const overwrites: SerializedPermissionOverwrite[] = [];
      if ('permissionOverwrites' in channel) {
        const permOw = (channel as { permissionOverwrites: { cache: Map<string, { id: string; type: number; allow: { bitfield: bigint }; deny: { bitfield: bigint } }> } }).permissionOverwrites;
        for (const [, ow] of permOw.cache) {
          if (ow.type !== 0) continue; // 0 = role overwrite

          let idStr = ow.id;
          if (ow.id === guild.roles.everyone.id) idStr = 'everyone';

          overwrites.push({
            id: idStr,
            type: 0,
            allow: ow.allow.bitfield.toString(),
            deny: ow.deny.bitfield.toString(),
          });
        }
      }

      const chanData: SerializedChannel = {
        id: channel.id,
        name: channel.name,
        type: channel.type,
        parentId: 'parentId' in channel ? (channel as { parentId: string | null }).parentId ?? undefined : undefined,
        position: pos,
        permissionOverwrites: overwrites,
      };

      if (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildAnnouncement) {
        const textChannel = channel as TextChannel;
        chanData.topic = textChannel.topic || undefined;
        chanData.nsfw = textChannel.nsfw;
        chanData.rateLimitPerUser = textChannel.rateLimitPerUser || undefined;
      } else if (channel.type === ChannelType.GuildVoice) {
        const voiceChannel = channel as VoiceChannel;
        chanData.userLimit = voiceChannel.userLimit;
        chanData.bitrate = voiceChannel.bitrate;
      }

      channels.push(chanData);
    }

    return {
      version: '1.0',
      roles,
      channels,
    };
  }

  /**
   * Apply template safely (SAFE BUILD)
   */
  public static async safeBuild(guild: Guild, data: ServerTemplateData): Promise<void> {
    await this.applyTemplate(guild, data, false);
  }

  /**
   * Apply template completely (FULL REBUILD)
   */
  public static async fullRebuild(guild: Guild, data: ServerTemplateData): Promise<void> {
    await this.applyTemplate(guild, data, true);
  }

  private static async applyTemplate(guild: Guild, data: ServerTemplateData, isFullRebuild: boolean): Promise<void> {
    const roleMap = new Map<string, string>(); // oldId -> newId
    
    // Reverse roles to create from lowest to highest so hierarchy makes sense
    const rolesToCreate = [...data.roles].sort((a, b) => a.position - b.position);

    for (const r of rolesToCreate) {
      try {
        const existing = guild.roles.cache.find(role => role.name === r.name && role.color === r.color);
        if (existing) {
          roleMap.set(r.id, existing.id);
          continue;
        }

        const newRole = await guild.roles.create({
          name: r.name,
          color: r.color,
          hoist: r.hoist,
          mentionable: r.mentionable,
          permissions: BigInt(r.permissions),
          reason: 'Template Build',
        });
        roleMap.set(r.id, newRole.id);
        await this.delay(500); // Rate limit protection
      } catch (err) {
        logger.error('ServerTemplateService', `Failed to create role ${r.name}`, err);
      }
    }

    const categoryMap = new Map<string, string>(); // oldId -> newId
    const categoriesToCreate = data.channels.filter(c => c.type === ChannelType.GuildCategory);

    for (const c of categoriesToCreate) {
      try {
        const existing = guild.channels.cache.find(chan => chan.name === c.name && chan.type === ChannelType.GuildCategory);
        if (existing) {
          categoryMap.set(c.id, existing.id);
        } else {
          const newCat = await guild.channels.create({
            name: c.name,
            type: ChannelType.GuildCategory,
            permissionOverwrites: this.mapOverwrites(guild, c.permissionOverwrites, roleMap),
            reason: 'Template Build',
          });
          categoryMap.set(c.id, newCat.id);
          await this.delay(1000);
        }
      } catch (err) {
        logger.error('ServerTemplateService', `Failed to create category ${c.name}`, err);
      }
    }

    const childChannels = data.channels.filter(c => c.type !== ChannelType.GuildCategory);
    for (const c of childChannels) {
      try {
        const existing = guild.channels.cache.find(chan => chan.name === c.name && chan.type === c.type);
        if (existing) continue;

        let parentId: string | undefined;
        if (c.parentId) {
          parentId = categoryMap.get(c.parentId);
        }

        const createData: any = {
          name: c.name,
          type: c.type,
          parent: parentId,
          permissionOverwrites: this.mapOverwrites(guild, c.permissionOverwrites, roleMap),
          reason: 'Template Build',
        };

        if (c.topic !== undefined) createData.topic = c.topic;
        if (c.nsfw !== undefined) createData.nsfw = c.nsfw;
        if (c.rateLimitPerUser !== undefined) createData.rateLimitPerUser = c.rateLimitPerUser;
        if (c.userLimit !== undefined) createData.userLimit = c.userLimit;
        if (c.bitrate !== undefined) createData.bitrate = c.bitrate;

        await guild.channels.create(createData);
        await this.delay(1500);
      } catch (err) {
        logger.error('ServerTemplateService', `Failed to create channel ${c.name}`, err);
      }
    }

    if (isFullRebuild) {
      // Destructive phase
      // Delete old channels not in the template (heuristic: if we didn't just map them or match their names)
      const templateChannelNames = new Set(data.channels.map(c => c.name));
      const templateRoleNames = new Set(data.roles.map(r => r.name));

      for (const [, channel] of guild.channels.cache) {
        if (!templateChannelNames.has(channel.name)) {
          await channel.delete('Full Rebuild Mode').catch(() => null);
          await this.delay(500);
        }
      }

      for (const [, role] of guild.roles.cache) {
        if (!role.managed && role.id !== guild.roles.everyone.id && role.id !== guild.roles.botRoleFor(guild.client.user!)?.id) {
          if (!templateRoleNames.has(role.name)) {
             await role.delete('Full Rebuild Mode').catch(() => null);
             await this.delay(500);
          }
        }
      }
    }
  }

  private static mapOverwrites(guild: Guild, overwrites: SerializedPermissionOverwrite[], roleMap: Map<string, string>) {
    const mapped = [];
    for (const ow of overwrites) {
      let mappedId = roleMap.get(ow.id);
      if (ow.id === 'everyone') mappedId = guild.roles.everyone.id;
      
      if (mappedId) {
        mapped.push({
          id: mappedId,
          allow: BigInt(ow.allow),
          deny: BigInt(ow.deny),
        });
      }
    }
    return mapped;
  }

  private static delay(ms: number) {
    return new Promise(r => setTimeout(r, ms));
  }
}
