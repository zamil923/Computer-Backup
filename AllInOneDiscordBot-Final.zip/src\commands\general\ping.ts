import { SlashCommandBuilder } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';

export const pingCommand: Command = {
  name: 'ping',
  description: 'Check bot latency and Discord API responsiveness',
  category: 'General',
  usage: 'ping',
  examples: ['/ping', '^ping'],
  requiredPermission: PermissionLevel.EVERYONE,
  slashBuilder: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot latency and Discord API responsiveness'),

  async execute(ctx) {
    const start = Date.now();
    await ctx.reply('🏓 Pinging...');
    const latency = Date.now() - start;
    const wsPing = ctx.client.ws.ping;

    await ctx.editReply(`🏓 **Pong!**\n• Latency: \`${latency}ms\`\n• WebSocket API: \`${wsPing}ms\``);
  },
};
