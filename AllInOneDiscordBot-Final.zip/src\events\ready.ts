import { Client } from 'discord.js';
import { logger } from '../utils/logger.js';
import { StatsService } from '../services/statsService.js';

export function handleReady(client: Client): void {
  logger.info('Bot', `Logged in as ${client.user?.tag} (${client.user?.id})!`);
  logger.info('Bot', `Serving ${client.guilds.cache.size} guilds and ${client.users.cache.size} cached users.`);

  // Periodic Voice Stat Channel updates (every 10 minutes)
  setInterval(async () => {
    try {
      await StatsService.updateVoiceStats(client);
    } catch (err) {
      logger.error('StatsWorker', 'Error updating voice channel stats', err);
    }
  }, 10 * 60 * 1000);
}
