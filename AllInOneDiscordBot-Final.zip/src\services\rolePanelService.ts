import {
  GuildMember,
  Role,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  StringSelectMenuBuilder,
  TextChannel,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { RolePanelRepository } from '../repositories/rolePanelRepository.js';
import { MessageBuilder } from '../utils/embedBuilder.js';
import { TemplateRepository } from '../repositories/templateRepository.js';
import { UniversalEmbedData } from '../types/templates.js';

export class RolePanelService {
  /**
   * Post role panel into target channel
   */
  public static async postPanel(
    panelId: string,
    channel: TextChannel
  ): Promise<{ success: boolean; message: string; messageId?: string }> {
    const panel = await RolePanelRepository.getPanel(panelId);
    if (!panel) {
      return { success: false, message: 'Role panel not found.' };
    }

    if (panel.options.length === 0) {
      return { success: false, message: 'Role panel has no role options configured.' };
    }

    let embed: EmbedBuilder;
    if (panel.templateId) {
      const template = await TemplateRepository.getById(panel.templateId);
      if (template && template.embedData) {
        embed = MessageBuilder.buildEmbed(template.embedData as unknown as UniversalEmbedData, {
          guild: channel.guild,
        });
      } else {
        embed = new EmbedBuilder()
          .setTitle(panel.title)
          .setDescription(panel.description || 'Select roles below:')
          .setColor(Colors.Blue);
      }
    } else {
      embed = new EmbedBuilder()
        .setTitle(panel.title)
        .setDescription(panel.description || 'Click the buttons or choose from the menu below to assign your roles:')
        .setColor(Colors.Blue);
    }

    // Build components
    if (panel.panelType === 'SELECT_MENU') {
      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId(`role_select:${panel.id}`)
        .setPlaceholder('Choose your roles...')
        .setMinValues(panel.minSelect)
        .setMaxValues(Math.min(panel.maxSelect, panel.options.length));

      for (const opt of panel.options.slice(0, 25)) {
        selectMenu.addOptions({
          label: opt.label.slice(0, 100),
          value: opt.roleId,
          description: opt.description ? opt.description.slice(0, 100) : undefined,
          emoji: opt.emoji || undefined,
        });
      }

      const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);
      const sent = await channel.send({ embeds: [embed], components: [row] });
      await RolePanelRepository.updatePanelMessageId(panel.id, sent.id);
      return { success: true, message: 'Role panel posted successfully.', messageId: sent.id };
    } else {
      // Button rows (up to 5 buttons per row, up to 5 rows)
      const rows: ActionRowBuilder<ButtonBuilder>[] = [];
      let currentRow = new ActionRowBuilder<ButtonBuilder>();

      for (let i = 0; i < panel.options.length && i < 25; i++) {
        if (i > 0 && i % 5 === 0) {
          rows.push(currentRow);
          currentRow = new ActionRowBuilder<ButtonBuilder>();
        }

        const opt = panel.options[i];
        if (!opt) continue;

        const btn = new ButtonBuilder()
          .setCustomId(`role_toggle:${panel.id}:${opt.roleId}`)
          .setLabel(opt.label.slice(0, 80))
          .setStyle(MessageBuilder.mapButtonStyle(opt.buttonStyle));

        if (opt.emoji) {
          btn.setEmoji(opt.emoji);
        }

        currentRow.addComponents(btn);
      }

      if (currentRow.components.length > 0) {
        rows.push(currentRow);
      }

      const sent = await channel.send({ embeds: [embed], components: rows });
      await RolePanelRepository.updatePanelMessageId(panel.id, sent.id);
      return { success: true, message: 'Role panel posted successfully.', messageId: sent.id };
    }
  }

  /**
   * Handle user toggling a single role via button
   */
  public static async handleRoleToggle(
    member: GuildMember,
    panelId: string,
    roleId: string
  ): Promise<{ added: boolean; roleName: string; message: string }> {
    const guild = member.guild;
    const role = guild.roles.cache.get(roleId);
    if (!role) {
      return { added: false, roleName: 'Unknown', message: 'This role no longer exists on the server.' };
    }

    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return { added: false, roleName: role.name, message: 'I do not have permission to manage roles.' };
    }

    if (botMember.roles.highest.position <= role.position) {
      return {
        added: false,
        roleName: role.name,
        message: 'I cannot grant or remove this role because it is higher than my highest role.',
      };
    }

    const panel = await RolePanelRepository.getPanel(panelId);
    const option = panel?.options.find(o => o.roleId === roleId);

    // If user already has the role -> Remove it (toggle behavior)
    if (member.roles.cache.has(roleId)) {
      await member.roles.remove(role);
      return { added: false, roleName: role.name, message: `Removed **${role.name}** role from you.` };
    }

    // Required roles check
    if (option?.requiredRoleIds && option.requiredRoleIds.length > 0) {
      const hasRequired = option.requiredRoleIds.some(rId => member.roles.cache.has(rId));
      if (!hasRequired) {
        const requiredNames = option.requiredRoleIds
          .map(rId => guild.roles.cache.get(rId)?.name ?? rId)
          .join(', ');
        return {
          added: false,
          roleName: role.name,
          message: `You must have at least one of these roles to get this: **${requiredNames}**.`,
        };
      }
    }

    // Forbidden roles check
    if (option?.forbiddenRoleIds && option.forbiddenRoleIds.length > 0) {
      const hasForbidden = option.forbiddenRoleIds.some(rId => member.roles.cache.has(rId));
      if (hasForbidden) {
        return {
          added: false,
          roleName: role.name,
          message: 'You have a conflicting role that prevents you from obtaining this role.',
        };
      }
    }

    // Max selectable roles check
    if (panel && panel.maxSelect > 0) {
      const currentSelected = panel.options.filter(o => member.roles.cache.has(o.roleId)).length;
      if (currentSelected >= panel.maxSelect) {
        return {
          added: false,
          roleName: role.name,
          message: `You can only select up to **${panel.maxSelect}** role(s) from this panel.`,
        };
      }
    }

    await member.roles.add(role);
    return { added: true, roleName: role.name, message: `Added **${role.name}** role to you!` };
  }

  /**
   * Handle select menu selection
   */
  public static async handleRoleSelect(
    member: GuildMember,
    panelId: string,
    selectedRoleIds: string[]
  ): Promise<{ message: string }> {
    const panel = await RolePanelRepository.getPanel(panelId);
    if (!panel) {
      return { message: 'Role panel not found.' };
    }

    const guild = member.guild;
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return { message: 'I do not have permission to manage roles.' };
    }

    const panelRoleIds = panel.options.map(o => o.roleId);
    const addedRoles: Role[] = [];
    const removedRoles: Role[] = [];

    for (const opt of panel.options) {
      const role = guild.roles.cache.get(opt.roleId);
      if (!role) continue;
      if (botMember.roles.highest.position <= role.position) continue;

      const isSelected = selectedRoleIds.includes(opt.roleId);
      const hasRole = member.roles.cache.has(opt.roleId);

      if (isSelected && !hasRole) {
        await member.roles.add(role).catch(() => null);
        addedRoles.push(role);
      } else if (!isSelected && hasRole && panelRoleIds.includes(opt.roleId)) {
        await member.roles.remove(role).catch(() => null);
        removedRoles.push(role);
      }
    }

    const parts: string[] = [];
    if (addedRoles.length > 0) {
      parts.push(`Added: ${addedRoles.map(r => `**${r.name}**`).join(', ')}`);
    }
    if (removedRoles.length > 0) {
      parts.push(`Removed: ${removedRoles.map(r => `**${r.name}**`).join(', ')}`);
    }

    return {
      message: parts.length > 0 ? parts.join('\n') : 'No role changes made.',
    };
  }
}
