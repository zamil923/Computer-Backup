import {
  ChatInputCommandInteraction,
  Message,
  Guild,
  GuildMember,
  User,
  GuildTextBasedChannel,
  Channel,
  Role,
  InteractionReplyOptions,
  MessageReplyOptions,
  Client,
  InteractionResponse,
} from 'discord.js';
import { CommandContext } from '../types/command.js';
import { ParsedArgs } from './argParser.js';

export class SlashCommandContext implements CommandContext {
  public readonly isSlash = true;
  public readonly client: Client;
  public readonly interaction: ChatInputCommandInteraction;
  public readonly guild: Guild | null;
  public readonly member: GuildMember | null;
  public readonly user: User;
  public readonly channel: GuildTextBasedChannel | null;
  public readonly prefix = '/';

  constructor(interaction: ChatInputCommandInteraction) {
    this.interaction = interaction;
    this.client = interaction.client;
    this.guild = interaction.guild;
    this.member = interaction.member as GuildMember | null;
    this.user = interaction.user;
    this.channel = interaction.channel as GuildTextBasedChannel | null;
  }

  public async reply(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message | InteractionResponse> {
    if (this.interaction.deferred || this.interaction.replied) {
      return this.interaction.editReply(options as any);
    }
    return this.interaction.reply(options as InteractionReplyOptions);
  }

  public async defer(ephemeral = false): Promise<void> {
    if (!this.interaction.deferred && !this.interaction.replied) {
      await this.interaction.deferReply({ ephemeral });
    }
  }

  public async editReply(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message> {
    return this.interaction.editReply(options as any);
  }

  public async followUp(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message> {
    return this.interaction.followUp(options as InteractionReplyOptions);
  }

  public getString(name: string, required = false): string | null {
    return this.interaction.options.getString(name, required);
  }

  public getInteger(name: string, required = false): number | null {
    return this.interaction.options.getInteger(name, required);
  }

  public getBoolean(name: string, required = false): boolean | null {
    return this.interaction.options.getBoolean(name, required);
  }

  public async getUser(name: string, required = false): Promise<User | null> {
    return this.interaction.options.getUser(name, required);
  }

  public async getMember(name: string, required = false): Promise<GuildMember | null> {
    const member = this.interaction.options.getMember(name);
    if (member) return member as GuildMember;
    const user = this.interaction.options.getUser(name, required);
    if (!user || !this.guild) return null;
    return this.guild.members.fetch(user.id).catch(() => null);
  }

  public getChannel(name: string, required = false): Channel | null {
    return this.interaction.options.getChannel(name, required) as Channel | null;
  }

  public getRole(name: string, required = false): Role | null {
    return this.interaction.options.getRole(name, required) as Role | null;
  }

  public getSubcommand(required = false): string | null {
    try {
      return this.interaction.options.getSubcommand(required);
    } catch {
      return null;
    }
  }

  public getSubcommandGroup(): string | null {
    try {
      return this.interaction.options.getSubcommandGroup(false);
    } catch {
      return null;
    }
  }
}

export class PrefixCommandContext implements CommandContext {
  public readonly isSlash = false;
  public readonly client: Client;
  public readonly message: Message;
  public readonly guild: Guild | null;
  public readonly member: GuildMember | null;
  public readonly user: User;
  public readonly channel: GuildTextBasedChannel | null;
  public readonly prefix: string;
  public readonly args: ParsedArgs;

  private repliedMessage: Message | null = null;
  private isDeferred = false;
  private deferredMsg: Message | null = null;

  // Registered option order for positional fallback
  private optionIndexMap = new Map<string, number>();

  constructor(message: Message, prefix: string, args: ParsedArgs) {
    this.message = message;
    this.client = message.client;
    this.guild = message.guild;
    this.member = message.member;
    this.user = message.author;
    this.channel = message.channel as GuildTextBasedChannel | null;
    this.prefix = prefix;
    this.args = args;
  }

  public setOptionOrder(options: string[]): void {
    options.forEach((opt, idx) => {
      this.optionIndexMap.set(opt.toLowerCase(), idx);
    });
  }

  public async reply(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message> {
    const payload = typeof options === 'string' ? { content: options } : (options as MessageReplyOptions);

    if (this.isDeferred && this.deferredMsg) {
      this.repliedMessage = await this.deferredMsg.edit(payload as any);
      return this.repliedMessage;
    }

    if (this.repliedMessage) {
      return this.repliedMessage.edit(payload as any);
    }

    this.repliedMessage = await this.message.reply(payload);
    return this.repliedMessage;
  }

  public async defer(_ephemeral = false): Promise<void> {
    this.isDeferred = true;
    if (this.channel) {
      await this.channel.sendTyping().catch(() => null);
    }
  }

  public async editReply(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message> {
    const payload = typeof options === 'string' ? { content: options } : (options as MessageReplyOptions);
    if (this.repliedMessage) {
      return this.repliedMessage.edit(payload as any);
    }
    if (this.deferredMsg) {
      this.repliedMessage = await this.deferredMsg.edit(payload as any);
      return this.repliedMessage;
    }
    this.repliedMessage = await this.message.reply(payload);
    return this.repliedMessage;
  }

  public async followUp(options: string | MessageReplyOptions | InteractionReplyOptions): Promise<Message> {
    const payload = typeof options === 'string' ? { content: options } : (options as MessageReplyOptions);
    if (!this.channel) throw new Error('No channel available');
    return this.channel.send(payload);
  }

  public getString(name: string, _required = false): string | null {
    const lower = name.toLowerCase();

    // 1. Check named flag (--name value)
    if (this.args.flags[lower] && typeof this.args.flags[lower] === 'string') {
      return this.args.flags[lower] as string;
    }

    // 2. Check positional index
    const index = this.optionIndexMap.get(lower);
    if (index !== undefined && this.args.positional[index]) {
      return this.args.positional[index] ?? null;
    }

    // Fallback: If only 1 argument requested or remaining
    return this.args.positional[0] ?? null;
  }

  public getInteger(name: string, _required = false): number | null {
    const str = this.getString(name);
    if (!str) return null;
    const parsed = parseInt(str, 10);
    return isNaN(parsed) ? null : parsed;
  }

  public getBoolean(name: string, _required = false): boolean | null {
    const lower = name.toLowerCase();
    if (this.args.flags[lower] !== undefined) {
      return Boolean(this.args.flags[lower]);
    }
    const str = this.getString(name);
    if (!str) return null;
    return str.toLowerCase() === 'true' || str === '1' || str.toLowerCase() === 'yes';
  }

  public async getUser(name: string, _required = false): Promise<User | null> {
    // 1. Check message mentions
    const firstMention = this.message.mentions.users.first();
    if (firstMention) return firstMention;

    // 2. Check string argument
    const raw = this.getString(name);
    if (!raw) return null;

    const cleanId = raw.replace(/[<@!>]/g, '');
    return this.client.users.fetch(cleanId).catch(() => null);
  }

  public async getMember(name: string, _required = false): Promise<GuildMember | null> {
    if (!this.guild) return null;

    const firstMention = this.message.mentions.members?.first();
    if (firstMention) return firstMention;

    const raw = this.getString(name);
    if (!raw) return null;

    const cleanId = raw.replace(/[<@!>]/g, '');
    return this.guild.members.fetch(cleanId).catch(() => null);
  }

  public getChannel(name: string, _required = false): Channel | null {
    if (!this.guild) return null;

    const firstMention = this.message.mentions.channels.first();
    if (firstMention) return firstMention;

    const raw = this.getString(name);
    if (!raw) return null;

    const cleanId = raw.replace(/[<#>]/g, '');
    return this.guild.channels.cache.get(cleanId) ?? null;
  }

  public getRole(name: string, _required = false): Role | null {
    if (!this.guild) return null;

    const firstMention = this.message.mentions.roles.first();
    if (firstMention) return firstMention;

    const raw = this.getString(name);
    if (!raw) return null;

    const cleanId = raw.replace(/[<@&>]/g, '');
    return this.guild.roles.cache.get(cleanId) ?? null;
  }

  public getSubcommand(_required = false): string | null {
    return this.args.subcommand ?? null;
  }

  public getSubcommandGroup(): string | null {
    return this.args.subcommandGroup ?? null;
  }
}
