import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ColorResolvable,
  BaseMessageOptions,
} from 'discord.js';
import {
  UniversalEmbedData,
  UniversalMessagePayload,
  UniversalComponentData,
  UniversalButtonData,
  UniversalSelectMenuData,
} from '../types/templates.js';
import { VariableContext, VariableEngine } from './variables.js';

export class MessageBuilder {
  /**
   * Discord API limits
   */
  public static readonly LIMITS = {
    TITLE: 256,
    DESCRIPTION: 4096,
    FIELDS: 25,
    FIELD_NAME: 256,
    FIELD_VALUE: 1024,
    FOOTER_TEXT: 2048,
    AUTHOR_NAME: 256,
    TOTAL_CHARACTERS: 6000,
    CONTENT: 2000,
    MAX_ACTION_ROWS: 5,
    MAX_BUTTONS_PER_ROW: 5,
  };

  /**
   * Parse hex string or decimal number into ColorResolvable
   */
  public static parseColor(color?: string | number): ColorResolvable | null {
    if (!color) return null;
    if (typeof color === 'number') return color;
    const clean = color.trim().replace(/^#/, '');
    const parsed = parseInt(clean, 16);
    if (!isNaN(parsed) && parsed >= 0 && parsed <= 0xffffff) {
      return parsed;
    }
    return null;
  }

  /**
   * Convert UniversalEmbedData into discord.js EmbedBuilder with safe limits
   */
  public static buildEmbed(data: UniversalEmbedData, context?: VariableContext): EmbedBuilder {
    const embed = new EmbedBuilder();
    const processed: UniversalEmbedData = context ? VariableEngine.replaceDeep(data, context) : data;

    if (processed.title) {
      embed.setTitle(processed.title.slice(0, MessageBuilder.LIMITS.TITLE));
    }

    if (processed.description) {
      embed.setDescription(processed.description.slice(0, MessageBuilder.LIMITS.DESCRIPTION));
    }

    if (processed.url && MessageBuilder.isValidUrl(processed.url)) {
      embed.setURL(processed.url);
    }

    if (processed.color) {
      const col = MessageBuilder.parseColor(processed.color);
      if (col !== null) {
        embed.setColor(col);
      }
    }

    if (processed.author && processed.author.name) {
      embed.setAuthor({
        name: processed.author.name.slice(0, MessageBuilder.LIMITS.AUTHOR_NAME),
        iconURL: processed.author.iconURL && MessageBuilder.isValidUrl(processed.author.iconURL) ? processed.author.iconURL : undefined,
        url: processed.author.url && MessageBuilder.isValidUrl(processed.author.url) ? processed.author.url : undefined,
      });
    }

    if (processed.footer && processed.footer.text) {
      embed.setFooter({
        text: processed.footer.text.slice(0, MessageBuilder.LIMITS.FOOTER_TEXT),
        iconURL: processed.footer.iconURL && MessageBuilder.isValidUrl(processed.footer.iconURL) ? processed.footer.iconURL : undefined,
      });
    }

    if (processed.thumbnail && MessageBuilder.isValidUrl(processed.thumbnail)) {
      embed.setThumbnail(processed.thumbnail);
    }

    if (processed.image && MessageBuilder.isValidUrl(processed.image)) {
      embed.setImage(processed.image);
    }

    if (processed.timestamp) {
      if (typeof processed.timestamp === 'string') {
        const parsed = new Date(processed.timestamp);
        if (!isNaN(parsed.getTime())) {
          embed.setTimestamp(parsed);
        } else {
          embed.setTimestamp();
        }
      } else {
        embed.setTimestamp();
      }
    }

    if (processed.fields && Array.isArray(processed.fields)) {
      const validFields = processed.fields.slice(0, MessageBuilder.LIMITS.FIELDS);
      for (const field of validFields) {
        if (field.name && field.value) {
          embed.addFields({
            name: field.name.slice(0, MessageBuilder.LIMITS.FIELD_NAME),
            value: field.value.slice(0, MessageBuilder.LIMITS.FIELD_VALUE),
            inline: Boolean(field.inline),
          });
        }
      }
    }

    return embed;
  }

  /**
   * Convert component definitions into Discord ActionRowBuilders
   */
  public static buildComponents(
    componentsData: UniversalComponentData[][],
    context?: VariableContext
  ): ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>[] {
    const rows: ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>[] = [];
    const processedData = context ? VariableEngine.replaceDeep(componentsData, context) : componentsData;

    const rowLimit = Math.min(processedData.length, MessageBuilder.LIMITS.MAX_ACTION_ROWS);

    for (let r = 0; r < rowLimit; r++) {
      const rowItems = processedData[r];
      if (!rowItems || rowItems.length === 0) continue;

      const firstItem = rowItems[0];
      if (!firstItem) continue;

      if (firstItem.type === 'SELECT_MENU') {
        // Action row can only have 1 select menu
        const menuData = firstItem as UniversalSelectMenuData;
        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId(menuData.customId)
          .setPlaceholder(menuData.placeholder || 'Select an option')
          .setDisabled(Boolean(menuData.disabled))
          .setMinValues(menuData.minValues ?? 1)
          .setMaxValues(Math.min(menuData.maxValues ?? 1, menuData.options.length));

        for (const opt of menuData.options.slice(0, 25)) {
          selectMenu.addOptions({
            label: opt.label.slice(0, 100),
            value: opt.value.slice(0, 100),
            description: opt.description ? opt.description.slice(0, 100) : undefined,
            emoji: opt.emoji || undefined,
            default: opt.default,
          });
        }

        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);
        rows.push(row);
      } else if (firstItem.type === 'BUTTON') {
        // Action row can have up to 5 buttons
        const buttonRow = new ActionRowBuilder<ButtonBuilder>();
        const buttonCount = Math.min(rowItems.length, MessageBuilder.LIMITS.MAX_BUTTONS_PER_ROW);

        for (let b = 0; b < buttonCount; b++) {
          const btnData = rowItems[b] as UniversalButtonData;
          const btn = new ButtonBuilder();

          if (btnData.label) {
            btn.setLabel(btnData.label.slice(0, 80));
          }

          if (btnData.emoji) {
            btn.setEmoji(btnData.emoji);
          }

          if (btnData.disabled) {
            btn.setDisabled(true);
          }

          if (btnData.style === 'LINK' && btnData.url && MessageBuilder.isValidUrl(btnData.url)) {
            btn.setStyle(ButtonStyle.Link).setURL(btnData.url);
          } else {
            const style = MessageBuilder.mapButtonStyle(btnData.style);
            btn.setStyle(style);
            btn.setCustomId(btnData.customId || `btn_${Date.now()}_${b}`);
          }

          buttonRow.addComponents(btn);
        }

        rows.push(buttonRow);
      }
    }

    return rows;
  }

  /**
   * Convert UniversalMessagePayload to Discord BaseMessageOptions
   */
  public static buildPayload(payload: UniversalMessagePayload, context?: VariableContext): BaseMessageOptions {
    const result: BaseMessageOptions = {};

    if (payload.content) {
      const content = context ? VariableEngine.replace(payload.content, context) : payload.content;
      result.content = content.slice(0, MessageBuilder.LIMITS.CONTENT);
    }

    if (payload.embeds && payload.embeds.length > 0) {
      result.embeds = payload.embeds.slice(0, 10).map(e => MessageBuilder.buildEmbed(e, context));
    }

    if (payload.components && payload.components.length > 0) {
      result.components = MessageBuilder.buildComponents(payload.components, context);
    }

    return result;
  }

  public static isValidUrl(url: string): boolean {
    try {
      const parsed = new URL(url);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  }

  public static mapButtonStyle(style: string): ButtonStyle {
    switch (style.toUpperCase()) {
      case 'PRIMARY':
        return ButtonStyle.Primary;
      case 'SECONDARY':
        return ButtonStyle.Secondary;
      case 'SUCCESS':
        return ButtonStyle.Success;
      case 'DANGER':
        return ButtonStyle.Danger;
      case 'LINK':
        return ButtonStyle.Link;
      default:
        return ButtonStyle.Primary;
    }
  }
}
