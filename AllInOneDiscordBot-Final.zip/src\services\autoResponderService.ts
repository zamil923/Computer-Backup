import { Message } from 'discord.js';
import { AutoResponderRepository } from '../repositories/autoResponderRepository.js';
import { TemplateRepository } from '../repositories/templateRepository.js';
import { MessageBuilder } from '../utils/embedBuilder.js';
import { UniversalEmbedData, UniversalComponentData } from '../types/templates.js';
import { logger } from '../utils/logger.js';

export class AutoResponderService {
  private static userCooldowns = new Map<string, number>();

  /**
   * Check incoming message against auto-responder triggers
   */
  public static async processMessage(message: Message): Promise<boolean> {
    if (!message.guild || message.author.bot || !message.member) return false;

    try {
      const responders = await AutoResponderRepository.listEnabled(message.guild.id);
      if (responders.length === 0) return false;

      const rawContent = message.content.trim();
      const lowerContent = rawContent.toLowerCase();

      for (const responder of responders) {
        // Channel restrictions
        if (responder.allowedChannelIds.length > 0 && !responder.allowedChannelIds.includes(message.channel.id)) {
          continue;
        }

        // Exempt roles
        if (message.member.roles.cache.some(r => responder.exemptRoleIds.includes(r.id))) {
          continue;
        }

        const triggerTarget = responder.caseSensitive ? rawContent : lowerContent;
        const triggerPattern = responder.caseSensitive ? responder.trigger : responder.trigger.toLowerCase();

        let matched = false;
        if (responder.matchType === 'EXACT') {
          matched = triggerTarget === triggerPattern;
        } else {
          matched = triggerTarget.includes(triggerPattern);
        }

        if (matched) {
          // Check cooldown
          const cooldownKey = `${message.guild.id}:${message.author.id}:${responder.id}`;
          const lastUsed = this.userCooldowns.get(cooldownKey) ?? 0;
          const now = Date.now();

          if (now - lastUsed < responder.cooldownSeconds * 1000) {
            return false;
          }

          this.userCooldowns.set(cooldownKey, now);

          const context = {
            member: message.member,
            user: message.author,
            guild: message.guild,
          };

          // If linked to a template
          if (responder.templateId) {
            const template = await TemplateRepository.getById(responder.templateId);
            if (template) {
              const payload = MessageBuilder.buildPayload(
                {
                  content: template.content || undefined,
                  embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
                  components: template.componentsData
                    ? (template.componentsData as unknown as UniversalComponentData[][])
                    : undefined,
                },
                context
              );
              if (message.channel.isSendable()) {
                await message.channel.send(payload);
              }
              return true;
            }
          }

          // Plain text response
          if (responder.responseText) {
            const payload = MessageBuilder.buildPayload({ content: responder.responseText }, context);
            if (message.channel.isSendable()) {
              await message.channel.send(payload);
            }
            return true;
          }
        }
      }
    } catch (err) {
      logger.error('AutoResponderService', `Error evaluating auto responder in ${message.guild.id}`, err);
    }

    return false;
  }
}
