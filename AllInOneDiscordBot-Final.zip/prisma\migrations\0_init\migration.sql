-- CreateTable
CREATE TABLE "GuildConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "prefix" TEXT NOT NULL DEFAULT '^',
    "isConfigured" BOOLEAN NOT NULL DEFAULT false,
    "setupStep" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GuildConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GuildAdminRole" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "GuildAdminRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GuildModRole" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "GuildModRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommandPermissionOverride" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "commandName" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "allowedRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "deniedRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "allowedUserIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "deniedUserIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "allowedChannelIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "deniedChannelIds" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "CommandPermissionOverride_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MessageTemplate" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "content" TEXT,
    "embedData" JSONB,
    "componentsData" JSONB,
    "createdBy" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MessageTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WelcomeConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "channelId" TEXT,
    "plainText" TEXT,
    "templateId" TEXT,
    "sendDm" BOOLEAN NOT NULL DEFAULT false,
    "dmPlainText" TEXT,
    "dmTemplateId" TEXT,

    CONSTRAINT "WelcomeConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LeaveConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "channelId" TEXT,
    "plainText" TEXT,
    "templateId" TEXT,

    CONSTRAINT "LeaveConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BoostConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "channelId" TEXT,
    "plainText" TEXT,
    "templateId" TEXT,

    CONSTRAINT "BoostConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoRole" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,
    "targetType" TEXT NOT NULL DEFAULT 'ALL',
    "delaySeconds" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "AutoRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RolePanel" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "messageId" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "panelType" TEXT NOT NULL DEFAULT 'BUTTON',
    "minSelect" INTEGER NOT NULL DEFAULT 0,
    "maxSelect" INTEGER NOT NULL DEFAULT 1,
    "templateId" TEXT,

    CONSTRAINT "RolePanel_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RolePanelOption" (
    "id" TEXT NOT NULL,
    "panelId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "emoji" TEXT,
    "description" TEXT,
    "buttonStyle" TEXT NOT NULL DEFAULT 'PRIMARY',
    "requiredRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "forbiddenRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "order" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "RolePanelOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "logChannelId" TEXT,
    "categoryChannelId" TEXT,
    "maxOpenTicketsPerUser" INTEGER NOT NULL DEFAULT 3,
    "enableRatings" BOOLEAN NOT NULL DEFAULT true,
    "transcriptFormat" TEXT NOT NULL DEFAULT 'HTML',

    CONSTRAINT "TicketConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketCategory" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "emoji" TEXT,
    "description" TEXT,
    "discordCategoryId" TEXT,
    "supportRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "pingRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "namingFormat" TEXT NOT NULL DEFAULT 'ticket-{username}',
    "welcomeMessage" TEXT,
    "welcomeTemplateId" TEXT,

    CONSTRAINT "TicketCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketPanel" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "messageId" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "categoryIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "displayMode" TEXT NOT NULL DEFAULT 'BUTTON',
    "templateId" TEXT,

    CONSTRAINT "TicketPanel_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Ticket" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "categoryId" TEXT,
    "openerId" TEXT NOT NULL,
    "openerTag" TEXT NOT NULL,
    "claimerId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "closeReason" TEXT,
    "closedBy" TEXT,
    "closedAt" TIMESTAMP(3),
    "rating" INTEGER,
    "ratingFeedback" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Ticket_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketTranscript" (
    "id" TEXT NOT NULL,
    "ticketId" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "format" TEXT NOT NULL DEFAULT 'HTML',
    "messageCount" INTEGER NOT NULL DEFAULT 0,
    "generatedBy" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TicketTranscript_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ModCase" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "caseNumber" INTEGER NOT NULL,
    "action" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "targetTag" TEXT NOT NULL,
    "moderatorId" TEXT NOT NULL,
    "moderatorTag" TEXT NOT NULL,
    "reason" TEXT NOT NULL DEFAULT 'No reason provided',
    "duration" TEXT,
    "expiresAt" TIMESTAMP(3),
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ModCase_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Warning" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "moderatorId" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "caseId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Warning_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BlacklistedWord" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "word" TEXT NOT NULL,
    "matchType" TEXT NOT NULL DEFAULT 'EXACT',
    "action" TEXT NOT NULL DEFAULT 'DELETE',
    "timeoutSeconds" INTEGER NOT NULL DEFAULT 300,
    "exemptRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "exemptChannelIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BlacklistedWord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoModConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "spamEnabled" BOOLEAN NOT NULL DEFAULT false,
    "spamThreshold" INTEGER NOT NULL DEFAULT 5,
    "spamIntervalSeconds" INTEGER NOT NULL DEFAULT 5,
    "repeatedEnabled" BOOLEAN NOT NULL DEFAULT false,
    "repeatedThreshold" INTEGER NOT NULL DEFAULT 3,
    "mentionSpamEnabled" BOOLEAN NOT NULL DEFAULT false,
    "mentionThreshold" INTEGER NOT NULL DEFAULT 5,
    "inviteFilterEnabled" BOOLEAN NOT NULL DEFAULT false,
    "linkFilterEnabled" BOOLEAN NOT NULL DEFAULT false,
    "allowedLinks" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "capsFilterEnabled" BOOLEAN NOT NULL DEFAULT false,
    "capsPercentageThreshold" INTEGER NOT NULL DEFAULT 70,
    "minCapsLength" INTEGER NOT NULL DEFAULT 10,
    "blacklistedWordsEnabled" BOOLEAN NOT NULL DEFAULT true,
    "defaultAction" TEXT NOT NULL DEFAULT 'DELETE',
    "defaultTimeoutSeconds" INTEGER NOT NULL DEFAULT 300,
    "exemptRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "exemptChannelIds" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "AutoModConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoResponder" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "trigger" TEXT NOT NULL,
    "matchType" TEXT NOT NULL DEFAULT 'EXACT',
    "caseSensitive" BOOLEAN NOT NULL DEFAULT false,
    "responseText" TEXT,
    "templateId" TEXT,
    "cooldownSeconds" INTEGER NOT NULL DEFAULT 5,
    "exemptRoleIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "allowedChannelIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AutoResponder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StatsConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "updateIntervalMinutes" INTEGER NOT NULL DEFAULT 10,
    "lastUpdated" TIMESTAMP(3),

    CONSTRAINT "StatsConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VoiceStatChannel" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "statType" TEXT NOT NULL,
    "formatString" TEXT NOT NULL DEFAULT '{label}: {count}',
    "lastValue" INTEGER NOT NULL DEFAULT 0,
    "lastUpdated" TIMESTAMP(3),

    CONSTRAINT "VoiceStatChannel_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LoggingConfig" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "modLogsChannelId" TEXT,
    "automodLogsChannelId" TEXT,
    "ticketLogsChannelId" TEXT,
    "joinLeaveLogsChannelId" TEXT,
    "serverLogsChannelId" TEXT,
    "memberLogsChannelId" TEXT,
    "enabledEvents" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "LoggingConfig_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "GuildConfig_guildId_key" ON "GuildConfig"("guildId");

-- CreateIndex
CREATE INDEX "GuildConfig_guildId_idx" ON "GuildConfig"("guildId");

-- CreateIndex
CREATE INDEX "GuildAdminRole_guildId_idx" ON "GuildAdminRole"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "GuildAdminRole_guildId_roleId_key" ON "GuildAdminRole"("guildId", "roleId");

-- CreateIndex
CREATE INDEX "GuildModRole_guildId_idx" ON "GuildModRole"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "GuildModRole_guildId_roleId_key" ON "GuildModRole"("guildId", "roleId");

-- CreateIndex
CREATE INDEX "CommandPermissionOverride_guildId_idx" ON "CommandPermissionOverride"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "CommandPermissionOverride_guildId_commandName_key" ON "CommandPermissionOverride"("guildId", "commandName");

-- CreateIndex
CREATE INDEX "MessageTemplate_guildId_idx" ON "MessageTemplate"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "MessageTemplate_guildId_name_key" ON "MessageTemplate"("guildId", "name");

-- CreateIndex
CREATE UNIQUE INDEX "WelcomeConfig_guildId_key" ON "WelcomeConfig"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "LeaveConfig_guildId_key" ON "LeaveConfig"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "BoostConfig_guildId_key" ON "BoostConfig"("guildId");

-- CreateIndex
CREATE INDEX "AutoRole_guildId_idx" ON "AutoRole"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "AutoRole_guildId_roleId_targetType_key" ON "AutoRole"("guildId", "roleId", "targetType");

-- CreateIndex
CREATE INDEX "RolePanel_guildId_idx" ON "RolePanel"("guildId");

-- CreateIndex
CREATE INDEX "RolePanelOption_panelId_idx" ON "RolePanelOption"("panelId");

-- CreateIndex
CREATE UNIQUE INDEX "TicketConfig_guildId_key" ON "TicketConfig"("guildId");

-- CreateIndex
CREATE INDEX "TicketCategory_guildId_idx" ON "TicketCategory"("guildId");

-- CreateIndex
CREATE INDEX "TicketPanel_guildId_idx" ON "TicketPanel"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "Ticket_channelId_key" ON "Ticket"("channelId");

-- CreateIndex
CREATE INDEX "Ticket_guildId_idx" ON "Ticket"("guildId");

-- CreateIndex
CREATE INDEX "Ticket_openerId_idx" ON "Ticket"("openerId");

-- CreateIndex
CREATE UNIQUE INDEX "TicketTranscript_ticketId_key" ON "TicketTranscript"("ticketId");

-- CreateIndex
CREATE INDEX "TicketTranscript_guildId_idx" ON "TicketTranscript"("guildId");

-- CreateIndex
CREATE INDEX "ModCase_guildId_idx" ON "ModCase"("guildId");

-- CreateIndex
CREATE INDEX "ModCase_targetId_idx" ON "ModCase"("targetId");

-- CreateIndex
CREATE UNIQUE INDEX "ModCase_guildId_caseNumber_key" ON "ModCase"("guildId", "caseNumber");

-- CreateIndex
CREATE UNIQUE INDEX "Warning_caseId_key" ON "Warning"("caseId");

-- CreateIndex
CREATE INDEX "Warning_guildId_idx" ON "Warning"("guildId");

-- CreateIndex
CREATE INDEX "Warning_userId_idx" ON "Warning"("userId");

-- CreateIndex
CREATE INDEX "BlacklistedWord_guildId_idx" ON "BlacklistedWord"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "BlacklistedWord_guildId_word_key" ON "BlacklistedWord"("guildId", "word");

-- CreateIndex
CREATE UNIQUE INDEX "AutoModConfig_guildId_key" ON "AutoModConfig"("guildId");

-- CreateIndex
CREATE INDEX "AutoResponder_guildId_idx" ON "AutoResponder"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "AutoResponder_guildId_trigger_key" ON "AutoResponder"("guildId", "trigger");

-- CreateIndex
CREATE UNIQUE INDEX "StatsConfig_guildId_key" ON "StatsConfig"("guildId");

-- CreateIndex
CREATE INDEX "VoiceStatChannel_guildId_idx" ON "VoiceStatChannel"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "VoiceStatChannel_guildId_channelId_key" ON "VoiceStatChannel"("guildId", "channelId");

-- CreateIndex
CREATE UNIQUE INDEX "LoggingConfig_guildId_key" ON "LoggingConfig"("guildId");

-- AddForeignKey
ALTER TABLE "GuildAdminRole" ADD CONSTRAINT "GuildAdminRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GuildModRole" ADD CONSTRAINT "GuildModRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommandPermissionOverride" ADD CONSTRAINT "CommandPermissionOverride_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MessageTemplate" ADD CONSTRAINT "MessageTemplate_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WelcomeConfig" ADD CONSTRAINT "WelcomeConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LeaveConfig" ADD CONSTRAINT "LeaveConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BoostConfig" ADD CONSTRAINT "BoostConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoRole" ADD CONSTRAINT "AutoRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RolePanel" ADD CONSTRAINT "RolePanel_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RolePanelOption" ADD CONSTRAINT "RolePanelOption_panelId_fkey" FOREIGN KEY ("panelId") REFERENCES "RolePanel"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketConfig" ADD CONSTRAINT "TicketConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketCategory" ADD CONSTRAINT "TicketCategory_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketPanel" ADD CONSTRAINT "TicketPanel_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Ticket" ADD CONSTRAINT "Ticket_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "TicketCategory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Ticket" ADD CONSTRAINT "Ticket_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketTranscript" ADD CONSTRAINT "TicketTranscript_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES "Ticket"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ModCase" ADD CONSTRAINT "ModCase_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Warning" ADD CONSTRAINT "Warning_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "ModCase"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Warning" ADD CONSTRAINT "Warning_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BlacklistedWord" ADD CONSTRAINT "BlacklistedWord_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoModConfig" ADD CONSTRAINT "AutoModConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoResponder" ADD CONSTRAINT "AutoResponder_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StatsConfig" ADD CONSTRAINT "StatsConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VoiceStatChannel" ADD CONSTRAINT "VoiceStatChannel_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LoggingConfig" ADD CONSTRAINT "LoggingConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "GuildConfig"("guildId") ON DELETE CASCADE ON UPDATE CASCADE;

