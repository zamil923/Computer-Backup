import dotenv from 'dotenv';
dotenv.config();

export interface EnvConfig {
  DISCORD_TOKEN: string;
  CLIENT_ID: string;
  BOT_OWNER_IDS: string[];
  DATABASE_URL: string;
  DEFAULT_PREFIX: string;
  DEV_GUILD_ID?: string;
  NODE_ENV: 'development' | 'production' | 'test';
}

function parseEnv(): EnvConfig {
  const token = process.env['DISCORD_TOKEN'] ?? '';
  const clientId = process.env['CLIENT_ID'] ?? '';
  const rawOwnerIds = process.env['BOT_OWNER_IDS'] ?? '';
  const databaseUrl = process.env['DATABASE_URL'] ?? 'postgresql://postgres:postgres@localhost:5432/discord_bot?schema=public';
  const defaultPrefix = process.env['DEFAULT_PREFIX'] || '^';
  const devGuildId = process.env['DEV_GUILD_ID'] || undefined;
  const nodeEnv = (process.env['NODE_ENV'] as 'development' | 'production' | 'test') || 'development';

  const ownerIds = rawOwnerIds
    .split(',')
    .map(id => id.trim())
    .filter(id => id.length > 0);

  return {
    DISCORD_TOKEN: token,
    CLIENT_ID: clientId,
    BOT_OWNER_IDS: ownerIds,
    DATABASE_URL: databaseUrl,
    DEFAULT_PREFIX: defaultPrefix,
    DEV_GUILD_ID: devGuildId,
    NODE_ENV: nodeEnv,
  };
}

export const env = parseEnv();
