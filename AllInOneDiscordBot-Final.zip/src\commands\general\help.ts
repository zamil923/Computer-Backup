import {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { CommandRegistry } from '../registry.js';

export const helpCommand: Command = {
  name: 'help',
  description: 'View the interactive help center and command manual',
  category: 'General',
  usage: 'help [command]',
  examples: ['/help', '^help', '^help ban'],
  requiredPermission: PermissionLevel.EVERYONE,
  slashBuilder: new SlashCommandBuilder()
    .setName('help')
    .setDescription('View the interactive help center and command manual')
    .addStringOption(opt =>
      opt.setName('command').setDescription('Specific command to inspect').setRequired(false)
    ),

  async execute(ctx) {
    const specificCommandName = ctx.getString('command');

    // 1. If user requested a specific command details
    if (specificCommandName) {
      const cmd = CommandRegistry.get(specificCommandName);
      if (!cmd) {
        await ctx.reply({
          content: `❌ Command \`${specificCommandName}\` not found in the registry.`,
        });
        return;
      }

      const permName = getPermissionName(cmd.requiredPermission);
      const embed = new EmbedBuilder()
        .setTitle(`📖 Command: ${cmd.name}`)
        .setDescription(cmd.description)
        .setColor(Colors.Blue)
        .addFields(
          { name: 'Category', value: cmd.category, inline: true },
          { name: 'Required Permission', value: permName, inline: true },
          { name: 'Slash Syntax', value: `\`/${cmd.name}\``, inline: true },
          { name: 'Prefix Syntax', value: `\`${ctx.prefix}${cmd.usage}\``, inline: true },
          {
            name: 'Examples',
            value: cmd.examples.map(ex => `• \`${ex}\``).join('\n') || 'None',
            inline: false,
          }
        )
        .setFooter({ text: 'All commands support both Slash (/) and Prefix (^) syntax' });

      await ctx.reply({ embeds: [embed] });
      return;
    }

    // 2. Interactive Help Center with Category Select Menu
    const categories = CommandRegistry.getCategories();

    const menu = new StringSelectMenuBuilder()
      .setCustomId('help_category_select')
      .setPlaceholder('Select a category to view commands...')
      .addOptions(
        categories.map(cat => ({
          label: cat,
          value: cat,
          description: `View ${cat} commands`,
        }))
      );

    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);

    const allCommands = CommandRegistry.getAll();
    const overviewEmbed = new EmbedBuilder()
      .setTitle('📚 Server Management System — Help Center')
      .setDescription(
        `Welcome to the All-in-One Discord Bot manual!\n\n` +
          `• **Total Modules:** \`${categories.length}\`\n` +
          `• **Registered Commands:** \`${allCommands.size}\`\n` +
          `• **Current Prefix:** \`${ctx.prefix}\`\n\n` +
          `Select a category from the dropdown menu below or type \`${ctx.prefix}help <command>\` for detailed information.`
      )
      .setColor(Colors.Blurple)
      .addFields(
        categories.map(cat => ({
          name: cat,
          value: `${CommandRegistry.getByCategory(cat).length} command(s)`,
          inline: true,
        }))
      )
      .setFooter({ text: 'Use the dropdown menu below to explore each category.' });

    await ctx.reply({
      embeds: [overviewEmbed],
      components: [row],
    });
  },
};

function getPermissionName(level: PermissionLevel): string {
  switch (level) {
    case PermissionLevel.GLOBAL_BOT_OWNER:
      return 'Global Bot Owner';
    case PermissionLevel.DISCORD_SERVER_OWNER:
      return 'Server Owner';
    case PermissionLevel.ADMINISTRATOR:
      return 'Administrator';
    case PermissionLevel.MODERATOR:
      return 'Moderator';
    case PermissionLevel.CUSTOM_ALLOWED_ROLE:
      return 'Custom Allowed Role';
    case PermissionLevel.CUSTOM_ALLOWED_USER:
      return 'Custom Allowed User';
    case PermissionLevel.MEMBER:
      return 'Member';
    case PermissionLevel.EVERYONE:
    default:
      return 'Everyone';
  }
}
