export interface ParsedArgs {
  commandName: string;
  subcommand?: string;
  subcommandGroup?: string;
  positional: string[];
  flags: Record<string, string | boolean>;
}

export class ArgParser {
  /**
   * Parse message content into command name, subcommands, positional args, and flags
   * Supports quotes: `^embed create "My Title" --color #ff0000`
   */
  public static parse(content: string, prefix: string): ParsedArgs | null {
    if (!content.startsWith(prefix)) return null;

    const raw = content.slice(prefix.length).trim();
    if (!raw) return null;

    // Tokenize respecting double and single quotes
    const tokens: string[] = [];
    let current = '';
    let inQuote = false;
    let quoteChar = '';

    for (let i = 0; i < raw.length; i++) {
      const char = raw[i];

      if ((char === '"' || char === "'") && (!inQuote || quoteChar === char)) {
        inQuote = !inQuote;
        quoteChar = inQuote ? char : '';
        continue;
      }

      if (char === ' ' && !inQuote) {
        if (current.length > 0) {
          tokens.push(current);
          current = '';
        }
        continue;
      }

      current += char;
    }

    if (current.length > 0) {
      tokens.push(current);
    }

    if (tokens.length === 0) return null;

    const commandName = tokens[0]?.toLowerCase() ?? '';
    const remaining = tokens.slice(1);

    const positional: string[] = [];
    const flags: Record<string, string | boolean> = {};

    for (let i = 0; i < remaining.length; i++) {
      const token = remaining[i] ?? '';
      if (token.startsWith('--')) {
        const flagName = token.slice(2);
        const next = remaining[i + 1];
        if (next && !next.startsWith('-')) {
          flags[flagName] = next;
          i++;
        } else {
          flags[flagName] = true;
        }
      } else if (token.startsWith('-') && token.length === 2) {
        const flagName = token.slice(1);
        const next = remaining[i + 1];
        if (next && !next.startsWith('-')) {
          flags[flagName] = next;
          i++;
        } else {
          flags[flagName] = true;
        }
      } else {
        positional.push(token);
      }
    }

    return {
      commandName,
      subcommand: positional[0]?.toLowerCase(),
      positional,
      flags,
    };
  }
}
