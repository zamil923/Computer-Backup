export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
}

class Logger {
  private level: LogLevel = LogLevel.INFO;

  constructor() {
    if (process.env['NODE_ENV'] === 'development') {
      this.level = LogLevel.DEBUG;
    }
  }

  public setLevel(level: LogLevel): void {
    this.level = level;
  }

  private formatMessage(level: string, context: string, message: string): string {
    const timestamp = new Date().toISOString();
    return `[${timestamp}] [${level.toUpperCase()}] [${context}]: ${message}`;
  }

  public debug(context: string, message: string, ...meta: unknown[]): void {
    if (this.level <= LogLevel.DEBUG) {
      console.debug(this.formatMessage('DEBUG', context, message), ...meta);
    }
  }

  public info(context: string, message: string, ...meta: unknown[]): void {
    if (this.level <= LogLevel.INFO) {
      console.info(this.formatMessage('INFO', context, message), ...meta);
    }
  }

  public warn(context: string, message: string, ...meta: unknown[]): void {
    if (this.level <= LogLevel.WARN) {
      console.warn(this.formatMessage('WARN', context, message), ...meta);
    }
  }

  public error(context: string, message: string, error?: unknown): void {
    if (this.level <= LogLevel.ERROR) {
      console.error(this.formatMessage('ERROR', context, message));
      if (error) {
        console.error(error);
      }
    }
  }
}

export const logger = new Logger();
