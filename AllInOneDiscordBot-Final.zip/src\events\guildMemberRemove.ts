import { GuildMember, PartialGuildMember } from 'discord.js';
import { WelcomeService } from '../services/welcomeService.js';
import { logger } from '../utils/logger.js';

export async function handleGuildMemberRemove(member: GuildMember | PartialGuildMember): Promise<void> {
  try {
    if (member.partial) {
      // In case of partial member, we cannot retrieve full profile
      return;
    }
    await WelcomeService.handleMemberRemove(member as GuildMember);
  } catch (err) {
    logger.error('EventHandler', `Error handling guildMemberRemove in ${member.guild.id}`, err);
  }
}
