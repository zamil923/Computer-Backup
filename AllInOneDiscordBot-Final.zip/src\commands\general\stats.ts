import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { StatsService } from '../../services/statsService.js';

export const statsCommand: Command = {
  name: 'stats',
  description: 'Display server statistics and metrics',
  category: 'Statistics',
  usage: 'stats',
  examples: ['/stats', '^stats'],
  requiredPermission: PermissionLevel.EVERYONE,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Display server statistics and metrics'),

  async execute(ctx) {
    if (!ctx.guild) return;

    await ctx.defer();
    const stats = await StatsService.getServerStats(ctx.guild);

    const embed = new EmbedBuilder()
      .setTitle(`📊 Server Statistics — ${ctx.guild.name}`)
      .setThumbnail(ctx.guild.iconURL() ?? null)
      .setColor(Colors.Blue)
      .addFields(
        {
          name: '👥 Members',
          value: `• **Total:** ${stats.totalMembers.toLocaleString()}\n• **Humans:** ${stats.humans.toLocaleString()}\n• **Bots:** ${stats.bots.toLocaleString()}\n• **Online:** ${stats.online.toLocaleString()}`,
          inline: true,
        },
        {
          name: '🚀 Server Boosts',
          value: `• **Boosts:** ${stats.boosts}\n• **Tier:** Level ${stats.boostTier}`,
          inline: true,
        },
        {
          name: '📁 Channels & Roles',
          value: `• **Text Channels:** ${stats.textChannels}\n• **Voice Channels:** ${stats.voiceChannels}\n• **Total Roles:** ${stats.rolesCount}`,
          inline: true,
        },
        {
          name: '🛡️ System Activity',
          value: `• **Moderation Cases:** ${stats.totalModCases}\n• **Support Tickets:** ${stats.totalTickets}`,
          inline: true,
        }
      )
      .setFooter({ text: `Guild ID: ${ctx.guild.id}` })
      .setTimestamp();

    await ctx.editReply({ embeds: [embed] });
  },
};
