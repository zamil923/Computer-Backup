import { Message, PermissionFlagsBits } from 'discord.js';
import { AutoModRepository } from '../repositories/autoModRepository.js';
import { SlidingWindowRateLimiter } from '../utils/rateLimiter.js';
import { LoggingService } from './loggingService.js';
import { ModerationRepository } from '../repositories/moderationRepository.js';
import { logger } from '../utils/logger.js';

interface UserMessageHistory {
  lastContent: string;
  repeatCount: number;
}

export class AutoModService {
  private static spamLimiter = new SlidingWindowRateLimiter(5, 5); // 5 messages in 5 seconds default
  private static userHistories = new Map<string, UserMessageHistory>();

  /**
   * Process message against all active AutoMod filters
   * Returns true if message was intercepted/deleted, false if clean
   */
  public static async processMessage(message: Message): Promise<boolean> {
    if (!message.guild || message.author.bot || !message.member) return false;

    // Administrators bypass AutoMod
    if (message.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return false;
    }

    const config = await AutoModRepository.getConfig(message.guild.id);

    // Check exempt channels
    if (config.exemptChannelIds.includes(message.channel.id)) {
      return false;
    }

    // Check exempt roles
    const hasExemptRole = message.member.roles.cache.some(r => config.exemptRoleIds.includes(r.id));
    if (hasExemptRole) {
      return false;
    }

    // 1. Blacklisted Words Check
    if (config.blacklistedWordsEnabled) {
      const words = await AutoModRepository.listBlacklistedWords(message.guild.id);
      const content = message.content.toLowerCase();

      for (const bw of words) {
        // Check per-word exemptions
        if (bw.exemptChannelIds.includes(message.channel.id)) continue;
        if (message.member.roles.cache.some(r => bw.exemptRoleIds.includes(r.id))) continue;

        let matched = false;
        if (bw.matchType === 'EXACT') {
          // Word boundary matching to avoid accidental substrings (e.g. "ass" in "grass")
          const regex = new RegExp(`\\b${escapeRegex(bw.word)}\\b`, 'i');
          matched = regex.test(content);
        } else {
          matched = content.includes(bw.word);
        }

        if (matched) {
          await this.executeAction(
            message,
            'Blacklisted Word',
            bw.action,
            bw.timeoutSeconds,
            `Triggered blacklisted word: "${bw.word}"`
          );
          return true;
        }
      }
    }

    // 2. Invite Filtering
    if (config.inviteFilterEnabled) {
      const inviteRegex = /(discord\.gg|discord\.com\/invite|discordapp\.com\/invite)\/[a-zA-Z0-9]+/i;
      if (inviteRegex.test(message.content)) {
        await this.executeAction(
          message,
          'Discord Invite Link',
          config.defaultAction,
          config.defaultTimeoutSeconds,
          'Posted a Discord server invite link'
        );
        return true;
      }
    }

    // 3. Link Filtering
    if (config.linkFilterEnabled) {
      const linkRegex = /https?:\/\/[^\s]+/i;
      if (linkRegex.test(message.content)) {
        // Check allowed links
        const isAllowed = config.allowedLinks.some(allowed => message.content.includes(allowed));
        if (!isAllowed) {
          await this.executeAction(
            message,
            'Unauthorized Link',
            config.defaultAction,
            config.defaultTimeoutSeconds,
            'Posted an external link not on the allowlist'
          );
          return true;
        }
      }
    }

    // 4. Mention Spam
    if (config.mentionSpamEnabled) {
      const mentionCount = message.mentions.users.size + message.mentions.roles.size;
      if (mentionCount >= config.mentionThreshold) {
        await this.executeAction(
          message,
          'Mention Spam',
          config.defaultAction,
          config.defaultTimeoutSeconds,
          `Exceeded mention limit: ${mentionCount} mentions (threshold: ${config.mentionThreshold})`
        );
        return true;
      }
    }

    // 5. Excessive Caps
    if (config.capsFilterEnabled && message.content.length >= config.minCapsLength) {
      const letters = message.content.replace(/[^a-zA-Z]/g, '');
      if (letters.length >= config.minCapsLength) {
        const uppercase = letters.replace(/[^A-Z]/g, '');
        const percentage = Math.round((uppercase.length / letters.length) * 100);
        if (percentage >= config.capsPercentageThreshold) {
          await this.executeAction(
            message,
            'Excessive Caps',
            config.defaultAction,
            config.defaultTimeoutSeconds,
            `${percentage}% uppercase characters (threshold: ${config.capsPercentageThreshold}%)`
          );
          return true;
        }
      }
    }

    // 6. Message Spam (Fast messages)
    if (config.spamEnabled) {
      const rateLimitKey = `${message.guild.id}:${message.author.id}`;
      const check = this.spamLimiter.check(rateLimitKey);
      if (check.isLimited) {
        await this.executeAction(
          message,
          'Message Spam',
          config.defaultAction,
          config.defaultTimeoutSeconds,
          `Sent messages too quickly (rate limit triggered)`
        );
        return true;
      }
    }

    // 7. Repeated Messages
    if (config.repeatedEnabled) {
      const userKey = `${message.guild.id}:${message.author.id}`;
      const history = this.userHistories.get(userKey);
      const cleanContent = message.content.trim().toLowerCase();

      if (history && history.lastContent === cleanContent && cleanContent.length > 5) {
        history.repeatCount += 1;
        if (history.repeatCount >= config.repeatedThreshold) {
          history.repeatCount = 0;
          await this.executeAction(
            message,
            'Repeated Messages',
            config.defaultAction,
            config.defaultTimeoutSeconds,
            `Sent the same message ${config.repeatedThreshold} times in a row`
          );
          return true;
        }
      } else {
        this.userHistories.set(userKey, {
          lastContent: cleanContent,
          repeatCount: 1,
        });
      }
    }

    return false;
  }

  /**
   * Execute moderation action on violation
   */
  private static async executeAction(
    message: Message,
    rule: string,
    action: string,
    timeoutSeconds: number,
    details: string
  ): Promise<void> {
    const guild = message.guild;
    if (!guild || !message.member) return;

    try {
      // 1. Delete message
      if (
        action === 'DELETE' ||
        action === 'DELETE_WARN' ||
        action === 'DELETE_TIMEOUT' ||
        action === 'WARN' ||
        action === 'TIMEOUT'
      ) {
        await message.delete().catch(() => null);
      }

      // 2. Warn
      if (action === 'WARN' || action === 'DELETE_WARN') {
        const modCase = await ModerationRepository.createCase({
          guildId: guild.id,
          action: 'AUTOMOD_WARN',
          targetId: message.author.id,
          targetTag: message.author.tag,
          moderatorId: guild.client.user.id,
          moderatorTag: guild.client.user.tag,
          reason: `[AutoMod: ${rule}] ${details}`,
        });

        await ModerationRepository.createWarning(
          guild.id,
          message.author.id,
          guild.client.user.id,
          `[AutoMod: ${rule}] ${details}`,
          modCase.id
        );

        const warnChannel = message.channel.isSendable() ? message.channel : null;
        if (warnChannel) {
          await warnChannel
            .send(`⚠️ <@${message.author.id}>, your message violated server rules (**${rule}**) and you were warned.`)
            .then((m: { delete: () => Promise<unknown> }) => setTimeout(() => m.delete().catch(() => null), 6000));
        }
      }

      // 3. Timeout
      if (action === 'TIMEOUT' || action === 'DELETE_TIMEOUT') {
        const durationMs = timeoutSeconds * 1000;
        await message.member
          .timeout(durationMs, `[AutoMod: ${rule}] ${details}`)
          .catch(err => logger.warn('AutoModService', 'Failed to timeout member', err));

        const timeoutChannel = message.channel.isSendable() ? message.channel : null;
        if (timeoutChannel) {
          await timeoutChannel
            .send(`🔇 <@${message.author.id}> has been timed out for ${timeoutSeconds}s due to **${rule}**.`)
            .then((m: { delete: () => Promise<unknown> }) => setTimeout(() => m.delete().catch(() => null), 6000));
        }
      }

      // Log to automod channel
      await LoggingService.logAutoMod(guild, message.author.tag, message.author.id, rule, action, details);
    } catch (err) {
      logger.error('AutoModService', `Failed to execute automod action for ${message.author.tag}`, err);
    }
  }
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
