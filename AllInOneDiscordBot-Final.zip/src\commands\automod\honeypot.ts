import {
  SlashCommandBuilder,
  EmbedBuilder,
  Colors,
} from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { prisma } from '../../database/prisma.js';

export const honeypotCommand: Command = {
  name: 'honeypot',
  description: 'Configure the honeypot security system',
  category: 'AutoMod / Security',
  usage: 'honeypot <subcommand>',
  examples: ['/honeypot setup', '/honeypot enable', '^honeypot status'],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('honeypot')
    .setDescription('Configure the honeypot security channel')
    .addSubcommand(sub =>
      sub
        .setName('setup')
        .setDescription('Set the honeypot channel and action')
        .addChannelOption(opt => opt.setName('channel').setDescription('Honeypot trap channel').setRequired(true))
        .addStringOption(opt =>
          opt.setName('action').setDescription('Action to take on trigger').setRequired(true)
            .addChoices(
              { name: 'Log only', value: 'LOG' },
              { name: 'Warn', value: 'WARN' },
              { name: 'Timeout (1h)', value: 'TIMEOUT' },
              { name: 'Kick', value: 'KICK' },
              { name: 'Ban', value: 'BAN' },
            )
        )
    )
    .addSubcommand(sub =>
      sub.setName('enable').setDescription('Enable the honeypot')
    )
    .addSubcommand(sub =>
      sub.setName('disable').setDescription('Disable the honeypot')
    )
    .addSubcommand(sub =>
      sub.setName('status').setDescription('View current honeypot configuration')
    ),

  async execute(ctx) {
    if (!ctx.guild) return;
    await ctx.defer();

    const sub = ctx.getSubcommand();

    if (sub === 'setup') {
      const channel = ctx.getChannel('channel');
      const action = ctx.getString('action', true) ?? 'LOG';
      if (!channel) { await ctx.editReply('❌ Invalid channel.'); return; }

      await prisma.honeypotConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { channelId: channel.id, action, enabled: true },
        create: { guildId: ctx.guild.id, channelId: channel.id, action, enabled: true },
      });
      await ctx.editReply(`✅ Honeypot configured: <#${channel.id}> → **${action}**. Any message in that channel triggers the action.`);
    }

    if (sub === 'enable') {
      await prisma.honeypotConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { enabled: true },
        create: { guildId: ctx.guild.id, enabled: true },
      });
      await ctx.editReply('✅ Honeypot enabled.');
    }

    if (sub === 'disable') {
      await prisma.honeypotConfig.updateMany({ where: { guildId: ctx.guild.id }, data: { enabled: false } });
      await ctx.editReply('✅ Honeypot disabled.');
    }

    if (sub === 'status') {
      const config = await prisma.honeypotConfig.findUnique({ where: { guildId: ctx.guild.id } });

      if (!config) {
        await ctx.editReply('Honeypot not configured. Use `/honeypot setup` to configure it.');
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle('Honeypot Configuration')
        .setColor(config.enabled ? Colors.Green : Colors.Red)
        .addFields(
          { name: 'Status', value: config.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
          { name: 'Channel', value: config.channelId ? `<#${config.channelId}>` : 'Not set', inline: true },
          { name: 'Action', value: config.action, inline: true },
        )
        .setDescription('⚠️ Any non-exempt member who sends a message in the honeypot channel triggers the configured action.');

      await ctx.editReply({ embeds: [embed] });
    }
  },
};
