import { SlashCommandBuilder, PermissionFlagsBits, TextChannel } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { ModerationService } from '../../services/moderationService.js';

export const purgeCommand: Command = {
  name: 'purge',
  description: 'Delete a specified number of messages in the current channel',
  category: 'Moderation',
  usage: 'purge <amount: 1-100> [@user]',
  examples: ['/purge amount:20', '/purge amount:50 user:@spammer', '^purge 25', '^purge 30 @spammer'],
  requiredPermission: PermissionLevel.MODERATOR,
  discordPermissions: [PermissionFlagsBits.ManageMessages],
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete messages from the channel')
    .addIntegerOption(opt =>
      opt
        .setName('amount')
        .setDescription('Number of messages to delete (1-100)')
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true)
    )
    .addUserOption(opt =>
      opt.setName('user').setDescription('Filter deletion to a specific user').setRequired(false)
    ),

  async execute(ctx) {
    if (!ctx.guild || !ctx.member || !ctx.channel || !ctx.channel.isTextBased()) return;

    const amount = ctx.getInteger('amount', true) || 10;
    const targetUser = await ctx.getUser('user');

    await ctx.defer(true);
    const result = await ModerationService.purge(ctx.channel as TextChannel, amount, ctx.member, targetUser ?? undefined);

    await ctx.editReply(result.message);
  },
};
