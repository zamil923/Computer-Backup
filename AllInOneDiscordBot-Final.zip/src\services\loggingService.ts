import { Guild, EmbedBuilder, Colors, TextChannel } from 'discord.js';
import { GuildRepository } from '../repositories/guildRepository.js';
import { logger } from '../utils/logger.js';
import { ModCase } from '@prisma/client';

export class LoggingService {
  /**
   * Log moderation actions to the configured mod logs channel
   */
  public static async logModCase(guild: Guild, modCase: ModCase): Promise<void> {
    try {
      const config = await GuildRepository.getLoggingConfig(guild.id);
      if (!config || !config.modLogsChannelId) return;

      const channel = guild.channels.cache.get(config.modLogsChannelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      let color: number = Colors.Orange;
      if (modCase.action === 'BAN' || modCase.action === 'KICK') color = Colors.Red;
      if (modCase.action === 'UNBAN' || modCase.action === 'REMOVE_TIMEOUT' || modCase.action === 'REMOVE_WARN')
        color = Colors.Green;

      const embed = new EmbedBuilder()
        .setTitle(`[Case #${modCase.caseNumber}] ${modCase.action}`)
        .setColor(color)
        .addFields(
          { name: 'Target', value: `<@${modCase.targetId}> (${modCase.targetTag})`, inline: true },
          { name: 'Moderator', value: `<@${modCase.moderatorId}> (${modCase.moderatorTag})`, inline: true },
          { name: 'Reason', value: modCase.reason || 'No reason provided', inline: false }
        )
        .setTimestamp(modCase.createdAt);

      if (modCase.duration) {
        embed.addFields({ name: 'Duration', value: modCase.duration, inline: true });
      }

      await channel.send({ embeds: [embed] });
    } catch (err) {
      logger.error('LoggingService', `Failed to log mod case #${modCase.caseNumber} in guild ${guild.id}`, err);
    }
  }

  /**
   * Log AutoMod violation to the configured automod logs channel
   */
  public static async logAutoMod(
    guild: Guild,
    userTag: string,
    userId: string,
    rule: string,
    action: string,
    details?: string
  ): Promise<void> {
    try {
      const config = await GuildRepository.getLoggingConfig(guild.id);
      if (!config || !config.automodLogsChannelId) return;

      const channel = guild.channels.cache.get(config.automodLogsChannelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      const embed = new EmbedBuilder()
        .setTitle(`🛡️ AutoMod Action: ${rule}`)
        .setColor(Colors.DarkRed)
        .addFields(
          { name: 'User', value: `<@${userId}> (${userTag})`, inline: true },
          { name: 'Action Taken', value: action, inline: true },
          { name: 'Details', value: details || 'None', inline: false }
        )
        .setTimestamp();

      await channel.send({ embeds: [embed] });
    } catch (err) {
      logger.error('LoggingService', `Failed to log automod action in guild ${guild.id}`, err);
    }
  }

  /**
   * Log ticket creation / closure to ticket logs channel
   */
  public static async logTicketEvent(
    guild: Guild,
    title: string,
    description: string,
    color: number = Colors.Blue
  ): Promise<void> {
    try {
      const config = await GuildRepository.getLoggingConfig(guild.id);
      if (!config || !config.ticketLogsChannelId) return;

      const channel = guild.channels.cache.get(config.ticketLogsChannelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      const embed = new EmbedBuilder()
        .setTitle(`🎫 ${title}`)
        .setDescription(description)
        .setColor(color)
        .setTimestamp();

      await channel.send({ embeds: [embed] });
    } catch (err) {
      logger.error('LoggingService', `Failed to log ticket event in guild ${guild.id}`, err);
    }
  }

  /**
   * Log sensitive permission changes
   */
  public static async logPermissionChange(
    guild: Guild,
    actorTag: string,
    actorId: string,
    action: string,
    details: string
  ): Promise<void> {
    try {
      const config = await GuildRepository.getLoggingConfig(guild.id);
      const targetChannelId = config?.modLogsChannelId || config?.serverLogsChannelId;
      if (!targetChannelId) return;

      const channel = guild.channels.cache.get(targetChannelId) as TextChannel | undefined;
      if (!channel || !channel.isTextBased()) return;

      const embed = new EmbedBuilder()
        .setTitle(`🔑 Permission Configuration Changed`)
        .setColor(Colors.Gold)
        .addFields(
          { name: 'Administrator', value: `<@${actorId}> (${actorTag})`, inline: true },
          { name: 'Action', value: action, inline: true },
          { name: 'Details', value: details, inline: false }
        )
        .setTimestamp();

      await channel.send({ embeds: [embed] });
    } catch (err) {
      logger.error('LoggingService', `Failed to log permission change in guild ${guild.id}`, err);
    }
  }
}
