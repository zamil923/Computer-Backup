import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export class FormRepository {
  public static async createForm(guildId: string, name: string, description?: string) {
    return prisma.form.create({
      data: {
        guildId,
        name,
        description,
      },
    });
  }

  public static async getFormByName(guildId: string, name: string) {
    return prisma.form.findUnique({
      where: { guildId_name: { guildId, name } },
      include: { questions: { orderBy: { order: 'asc' } } },
    });
  }

  public static async getFormById(id: string) {
    return prisma.form.findUnique({
      where: { id },
      include: { questions: { orderBy: { order: 'asc' } } },
    });
  }

  public static async listForms(guildId: string) {
    return prisma.form.findMany({
      where: { guildId },
      orderBy: { createdAt: 'desc' },
      include: { _count: { select: { questions: true, submissions: true } } },
    });
  }

  public static async deleteForm(id: string) {
    return prisma.form.delete({ where: { id } });
  }

  public static async addQuestion(
    formId: string,
    label: string,
    type: string,
    required: boolean,
    order: number,
    choices: string[] = []
  ) {
    return prisma.formQuestion.create({
      data: {
        formId,
        label,
        type,
        required,
        order,
        choices,
      },
    });
  }

  public static async submitForm(
    guildId: string,
    formId: string,
    userId: string,
    userTag: string,
    answers: Record<string, any>
  ) {
    return prisma.formSubmission.create({
      data: {
        guildId,
        formId,
        userId,
        userTag,
        answers,
      },
    });
  }

  public static async getSubmissions(guildId: string, formId: string) {
    return prisma.formSubmission.findMany({
      where: { guildId, formId },
      orderBy: { submittedAt: 'desc' },
    });
  }

  public static async getSubmission(id: string) {
    return prisma.formSubmission.findUnique({ where: { id }, include: { form: true } });
  }

  public static async updateSubmissionStatus(
    id: string,
    status: string,
    reviewerId?: string,
    reviewerTag?: string,
    reviewNotes?: string,
    decisionReason?: string
  ) {
    return prisma.formSubmission.update({
      where: { id },
      data: {
        status,
        reviewerId,
        reviewerTag,
        reviewNotes,
        decisionReason,
        reviewedAt: new Date(),
      },
    });
  }

  // Application specific
  public static async createApplicationConfig(
    guildId: string,
    formId: string,
    reviewChannelId?: string,
    reviewerRoleIds: string[] = [],
    approveRoleIds: string[] = []
  ) {
    return prisma.applicationConfig.upsert({
      where: { formId },
      update: { reviewChannelId, reviewerRoleIds, approveRoleIds },
      create: { guildId, formId, reviewChannelId, reviewerRoleIds, approveRoleIds },
    });
  }

  public static async getApplicationConfig(formId: string) {
    return prisma.applicationConfig.findUnique({ where: { formId } });
  }
}
