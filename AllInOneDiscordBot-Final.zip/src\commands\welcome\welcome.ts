import { SlashCommandBuilder, EmbedBuilder, Colors, TextChannel } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { prisma } from '../../database/prisma.js';
import { TemplateRepository } from '../../repositories/templateRepository.js';
import { MessageBuilder } from '../../utils/embedBuilder.js';
import { UniversalEmbedData, UniversalComponentData } from '../../types/templates.js';

export const welcomeCommand: Command = {
  name: 'welcome',
  description: 'Configure and test the server member welcome system',
  category: 'Welcome / Leave / Boost',
  usage: 'welcome <status|enable|disable|channel|text|template|test|reset> [options]',
  examples: [
    '/welcome status',
    '/welcome enable',
    '/welcome channel channel:#welcome',
    '/welcome text text:"Welcome {user} to {server}! You are member #{memberCount}."',
    '/welcome template template:welcome_card',
    '/welcome test',
    '/welcome reset',
    '^welcome status',
    '^welcome enable',
    '^welcome channel #welcome',
    '^welcome test',
  ],
  requiredPermission: PermissionLevel.ADMINISTRATOR,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Configure member welcome messages')
    .addSubcommand(sub => sub.setName('status').setDescription('View current welcome configuration'))
    .addSubcommand(sub => sub.setName('enable').setDescription('Enable welcome announcements'))
    .addSubcommand(sub => sub.setName('disable').setDescription('Disable welcome announcements'))
    .addSubcommand(sub =>
      sub
        .setName('channel')
        .setDescription('Set the welcome channel')
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send welcome messages').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('text')
        .setDescription('Set plain text welcome message (supports variables like {user}, {server})')
        .addStringOption(opt => opt.setName('content').setDescription('Message text').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('template')
        .setDescription('Link a saved embed template to the welcome system')
        .addStringOption(opt => opt.setName('name').setDescription('Template name').setRequired(true))
    )
    .addSubcommand(sub => sub.setName('test').setDescription('Send a test welcome message'))
    .addSubcommand(sub => sub.setName('reset').setDescription('Reset welcome settings to default')),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'status';
    await ctx.defer();

    // 1. ENABLE / DISABLE
    if (subcommand === 'enable' || subcommand === 'disable') {
      const enabled = subcommand === 'enable';
      await prisma.welcomeConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { enabled },
        create: { guildId: ctx.guild.id, enabled },
      });
      await ctx.editReply(`✅ Welcome system has been **${enabled ? 'enabled' : 'disabled'}**.`);
      return;
    }

    // 2. CHANNEL
    if (subcommand === 'channel') {
      const channel = ctx.getChannel('channel', true);
      if (!channel || !channel.isTextBased()) {
        await ctx.editReply('❌ Please select a valid text channel.');
        return;
      }

      await prisma.welcomeConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { channelId: channel.id, enabled: true },
        create: { guildId: ctx.guild.id, channelId: channel.id, enabled: true },
      });

      await ctx.editReply(`✅ Welcome channel set to <#${channel.id}> (and system enabled).`);
      return;
    }

    // 3. TEXT
    if (subcommand === 'text') {
      const content = ctx.getString('content', true);
      if (!content) {
        await ctx.editReply('❌ Please provide the welcome message text.');
        return;
      }

      await prisma.welcomeConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { plainText: content, templateId: null },
        create: { guildId: ctx.guild.id, plainText: content },
      });

      await ctx.editReply(`✅ Plain text welcome message updated!`);
      return;
    }

    // 4. TEMPLATE
    if (subcommand === 'template') {
      const templateName = ctx.getString('name', true);
      if (!templateName) {
        await ctx.editReply('❌ Please provide a template name.');
        return;
      }

      const template = await TemplateRepository.getByName(ctx.guild.id, templateName);
      if (!template) {
        await ctx.editReply(`❌ Template **"${templateName}"** not found. Create one with \`${ctx.prefix}embed create\`.`);
        return;
      }

      await prisma.welcomeConfig.upsert({
        where: { guildId: ctx.guild.id },
        update: { templateId: template.id },
        create: { guildId: ctx.guild.id, templateId: template.id },
      });

      await ctx.editReply(`✅ Linked template **"${templateName}"** to the welcome system!`);
      return;
    }

    // 5. TEST
    if (subcommand === 'test') {
      const config = await prisma.welcomeConfig.findUnique({
        where: { guildId: ctx.guild.id },
      });

      if (!config || !config.channelId) {
        await ctx.editReply(`❌ No welcome channel configured. Set one with \`${ctx.prefix}welcome channel #channel\`.`);
        return;
      }

      const targetChannel = ctx.guild.channels.cache.get(config.channelId) as TextChannel | undefined;
      if (!targetChannel || !targetChannel.isTextBased()) {
        await ctx.editReply('❌ Configured welcome channel no longer exists.');
        return;
      }

      const context = {
        user: ctx.user,
        member: ctx.member ?? undefined,
        guild: ctx.guild,
      };

      if (config.templateId) {
        const template = await TemplateRepository.getById(config.templateId);
        if (template) {
          const payload = MessageBuilder.buildPayload(
            {
              content: template.content || undefined,
              embeds: template.embedData ? [template.embedData as unknown as UniversalEmbedData] : undefined,
              components: template.componentsData
                ? (template.componentsData as unknown as UniversalComponentData[][])
                : undefined,
            },
            context
          );
          await targetChannel.send(payload);
          await ctx.editReply(`✅ Test welcome template sent to <#${targetChannel.id}>!`);
          return;
        }
      }

      const msg = config.plainText || '👋 Welcome {user} to {server}! You are member #{memberCount}.';
      const payload = MessageBuilder.buildPayload({ content: msg }, context);
      await targetChannel.send(payload);
      await ctx.editReply(`✅ Test welcome message sent to <#${targetChannel.id}>!`);
      return;
    }

    // 6. RESET
    if (subcommand === 'reset') {
      await prisma.welcomeConfig.deleteMany({
        where: { guildId: ctx.guild.id },
      });
      await ctx.editReply('✅ Welcome configuration has been reset to defaults.');
      return;
    }

    // 7. STATUS
    const config = await prisma.welcomeConfig.findUnique({
      where: { guildId: ctx.guild.id },
    });

    let templateName = 'None';
    if (config?.templateId) {
      const tmpl = await TemplateRepository.getById(config.templateId);
      if (tmpl) templateName = tmpl.name;
    }

    const embed = new EmbedBuilder()
      .setTitle(`👋 Welcome Configuration — ${ctx.guild.name}`)
      .setColor(Colors.Green)
      .addFields(
        { name: 'Status', value: config?.enabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
        { name: 'Channel', value: config?.channelId ? `<#${config.channelId}>` : 'Not set', inline: true },
        { name: 'Linked Template', value: templateName, inline: true },
        {
          name: 'Plain Text',
          value: config?.plainText ? `\`${config.plainText.slice(0, 200)}\`` : 'Default welcome text',
          inline: false,
        }
      )
      .setFooter({ text: `Test welcome message: ${ctx.prefix}welcome test` });

    await ctx.editReply({ embeds: [embed] });
  },
};
