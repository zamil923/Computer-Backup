$content = (Get-Content -Path "prisma\schema.prisma" -Raw)
$content = $content -replace "(?s)// 11\. FORMS & APPLICATIONS.*", ""
$content = $content -replace "(?m)^\s*forms\s+Form\[\].*$", ""
$content = $content -replace "(?m)^\s*formSubmissions\s+FormSubmission\[\].*$", ""
$content = $content -replace "(?m)^\s*appConfigs\s+ApplicationConfig\[\].*$", ""
$content = $content -replace "(?m)^\s*levelConfig\s+LevelConfig\?.*$", ""
$content = $content -replace "(?m)^\s*levelRoles\s+LevelRole\[\].*$", ""
$content = $content -replace "(?m)^\s*memberXp\s+MemberXp\[\].*$", ""
$content = $content -replace "(?m)^\s*honeypotConfig\s+HoneypotConfig\?.*$", ""
$content = $content -replace "(?m)^\s*autoModEscalations\s+AutoModEscalation\[\].*$", ""
$content = $content -replace "(?m)^\s*serverTemplates\s+ServerTemplate\[\].*$", ""
$content = $content -replace "(?m)^\s*templateLogs\s+TemplateLog\[\].*$", ""
Set-Content -Path "prisma\old_schema.prisma" -Value $content
