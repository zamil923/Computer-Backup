import { prisma } from '../database/prisma.js';
import { AutoModConfig, BlacklistedWord } from '@prisma/client';
import { GuildRepository } from './guildRepository.js';

export class AutoModRepository {
  public static async getConfig(guildId: string): Promise<AutoModConfig> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.autoModConfig.upsert({
      where: { guildId },
      update: {},
      create: { guildId },
    });
  }

  public static async updateConfig(
    guildId: string,
    data: Partial<Omit<AutoModConfig, 'id' | 'guildId'>>
  ): Promise<AutoModConfig> {
    await GuildRepository.getOrCreate(guildId);
    return prisma.autoModConfig.upsert({
      where: { guildId },
      update: data,
      create: { guildId, ...data },
    });
  }

  // --- Blacklisted Words ---

  public static async listBlacklistedWords(guildId: string): Promise<BlacklistedWord[]> {
    return prisma.blacklistedWord.findMany({
      where: { guildId },
      orderBy: { createdAt: 'desc' },
    });
  }

  public static async addBlacklistedWord(
    guildId: string,
    data: {
      word: string;
      matchType?: 'EXACT' | 'CONTAINS';
      action?: 'DELETE' | 'WARN' | 'TIMEOUT' | 'DELETE_WARN' | 'DELETE_TIMEOUT';
      timeoutSeconds?: number;
      exemptRoleIds?: string[];
      exemptChannelIds?: string[];
    }
  ): Promise<BlacklistedWord> {
    await GuildRepository.getOrCreate(guildId);
    const normalizedWord = data.word.toLowerCase().trim();

    return prisma.blacklistedWord.upsert({
      where: { guildId_word: { guildId, word: normalizedWord } },
      update: {
        matchType: data.matchType ?? 'EXACT',
        action: data.action ?? 'DELETE',
        timeoutSeconds: data.timeoutSeconds ?? 300,
        exemptRoleIds: data.exemptRoleIds ?? [],
        exemptChannelIds: data.exemptChannelIds ?? [],
      },
      create: {
        guildId,
        word: normalizedWord,
        matchType: data.matchType ?? 'EXACT',
        action: data.action ?? 'DELETE',
        timeoutSeconds: data.timeoutSeconds ?? 300,
        exemptRoleIds: data.exemptRoleIds ?? [],
        exemptChannelIds: data.exemptChannelIds ?? [],
      },
    });
  }

  public static async removeBlacklistedWord(guildId: string, word: string): Promise<BlacklistedWord> {
    const normalizedWord = word.toLowerCase().trim();
    return prisma.blacklistedWord.delete({
      where: { guildId_word: { guildId, word: normalizedWord } },
    });
  }
}
