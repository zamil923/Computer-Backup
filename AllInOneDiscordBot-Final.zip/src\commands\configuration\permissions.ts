import { SlashCommandBuilder, EmbedBuilder, Colors } from 'discord.js';
import { Command, PermissionLevel } from '../../types/command.js';
import { GuildRepository } from '../../repositories/guildRepository.js';
import { LoggingService } from '../../services/loggingService.js';

export const permissionsCommand: Command = {
  name: 'permissions',
  description: 'Manage bot roles, command overrides, and authorization levels',
  category: 'Configuration',
  usage: 'permissions <view|addadmin|removeadmin|addmod|removemod|override> [options]',
  examples: [
    '/permissions view',
    '/permissions addadmin role:@ServerManagers',
    '/permissions addmod role:@TrialMods',
    '/permissions override command:ban allow_role:@SeniorMods',
    '^permissions view',
    '^permissions addadmin @ServerManagers',
  ],
  requiredPermission: PermissionLevel.DISCORD_SERVER_OWNER,
  guildOnly: true,
  slashBuilder: new SlashCommandBuilder()
    .setName('permissions')
    .setDescription('Configure command access and bot authority roles')
    .addSubcommand(sub => sub.setName('view').setDescription('View current configured admin and mod roles'))
    .addSubcommand(sub =>
      sub
        .setName('addadmin')
        .setDescription('Designate a role as a Bot Administrator role')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to designate as Admin').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('removeadmin')
        .setDescription('Remove a role from Bot Administrator roles')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('addmod')
        .setDescription('Designate a role as a Bot Moderator role')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to designate as Mod').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('removemod')
        .setDescription('Remove a role from Bot Moderator roles')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('override')
        .setDescription('Configure per-command access rules')
        .addStringOption(opt => opt.setName('command').setDescription('Command name').setRequired(true))
        .addBooleanOption(opt => opt.setName('enabled').setDescription('Enable/Disable command entirely').setRequired(false))
        .addRoleOption(opt => opt.setName('allow_role').setDescription('Role to grant access').setRequired(false))
        .addRoleOption(opt => opt.setName('deny_role').setDescription('Role to deny access').setRequired(false))
    ),

  async execute(ctx) {
    if (!ctx.guild) return;

    const subcommand = ctx.getSubcommand() || 'view';
    await ctx.defer();

    // 1. ADD ADMIN ROLE
    if (subcommand === 'addadmin') {
      const role = ctx.getRole('role', true);
      if (!role) {
        await ctx.editReply('❌ Role parameter required.');
        return;
      }

      await GuildRepository.addAdminRole(ctx.guild.id, role.id);
      await LoggingService.logPermissionChange(
        ctx.guild,
        ctx.user.tag,
        ctx.user.id,
        'Added Admin Role',
        `Role: <@&${role.id}> (${role.name})`
      );

      await ctx.editReply(`✅ Designated <@&${role.id}> as a Bot Administrator role.`);
      return;
    }

    // 2. REMOVE ADMIN ROLE
    if (subcommand === 'removeadmin') {
      const role = ctx.getRole('role', true);
      if (!role) {
        await ctx.editReply('❌ Role parameter required.');
        return;
      }

      await GuildRepository.removeAdminRole(ctx.guild.id, role.id);
      await LoggingService.logPermissionChange(
        ctx.guild,
        ctx.user.tag,
        ctx.user.id,
        'Removed Admin Role',
        `Role: <@&${role.id}> (${role.name})`
      );

      await ctx.editReply(`✅ Removed <@&${role.id}> from Bot Administrator roles.`);
      return;
    }

    // 3. ADD MOD ROLE
    if (subcommand === 'addmod') {
      const role = ctx.getRole('role', true);
      if (!role) {
        await ctx.editReply('❌ Role parameter required.');
        return;
      }

      await GuildRepository.addModRole(ctx.guild.id, role.id);
      await LoggingService.logPermissionChange(
        ctx.guild,
        ctx.user.tag,
        ctx.user.id,
        'Added Moderator Role',
        `Role: <@&${role.id}> (${role.name})`
      );

      await ctx.editReply(`✅ Designated <@&${role.id}> as a Bot Moderator role.`);
      return;
    }

    // 4. REMOVE MOD ROLE
    if (subcommand === 'removemod') {
      const role = ctx.getRole('role', true);
      if (!role) {
        await ctx.editReply('❌ Role parameter required.');
        return;
      }

      await GuildRepository.removeModRole(ctx.guild.id, role.id);
      await LoggingService.logPermissionChange(
        ctx.guild,
        ctx.user.tag,
        ctx.user.id,
        'Removed Moderator Role',
        `Role: <@&${role.id}> (${role.name})`
      );

      await ctx.editReply(`✅ Removed <@&${role.id}> from Bot Moderator roles.`);
      return;
    }

    // 5. COMMAND OVERRIDE
    if (subcommand === 'override') {
      const commandName = ctx.getString('command', true)?.toLowerCase();
      if (!commandName) {
        await ctx.editReply('❌ Command name required.');
        return;
      }

      const enabled = ctx.getBoolean('enabled');
      const allowRole = ctx.getRole('allow_role');
      const denyRole = ctx.getRole('deny_role');

      const existing = await GuildRepository.getCommandOverride(ctx.guild.id, commandName);
      const allowedRoleIds = existing ? [...existing.allowedRoleIds] : [];
      const deniedRoleIds = existing ? [...existing.deniedRoleIds] : [];

      if (allowRole && !allowedRoleIds.includes(allowRole.id)) {
        allowedRoleIds.push(allowRole.id);
      }
      if (denyRole && !deniedRoleIds.includes(denyRole.id)) {
        deniedRoleIds.push(denyRole.id);
      }

      await GuildRepository.setCommandOverride(ctx.guild.id, commandName, {
        enabled: enabled !== null ? enabled : existing?.enabled ?? true,
        allowedRoleIds,
        deniedRoleIds,
      });

      await LoggingService.logPermissionChange(
        ctx.guild,
        ctx.user.tag,
        ctx.user.id,
        `Updated Command Override: ${commandName}`,
        `Enabled: ${enabled !== null ? enabled : 'unchanged'}, Allowed: ${allowRole ? `<@&${allowRole.id}>` : 'none'}, Denied: ${denyRole ? `<@&${denyRole.id}>` : 'none'}`
      );

      await ctx.editReply(`✅ Access rules for command \`${commandName}\` updated.`);
      return;
    }

    // 6. VIEW
    const adminRoleIds = await GuildRepository.getAdminRoleIds(ctx.guild.id);
    const modRoleIds = await GuildRepository.getModRoleIds(ctx.guild.id);

    const embed = new EmbedBuilder()
      .setTitle(`🔑 Permission Configuration — ${ctx.guild.name}`)
      .setColor(Colors.Gold)
      .setDescription(
        'Staff role authorization hierarchy. Users with Discord Administrator permission or Server Ownership retain full administrative access.'
      )
      .addFields(
        {
          name: '👑 Bot Administrator Roles',
          value: adminRoleIds.length > 0 ? adminRoleIds.map(id => `<@&${id}>`).join(', ') : 'None configured',
          inline: false,
        },
        {
          name: '🛡️ Bot Moderator Roles',
          value: modRoleIds.length > 0 ? modRoleIds.map(id => `<@&${id}>`).join(', ') : 'None configured',
          inline: false,
        }
      )
      .setFooter({ text: `Configure roles: ${ctx.prefix}permissions addadmin|addmod @Role` });

    await ctx.editReply({ embeds: [embed] });
  },
};
