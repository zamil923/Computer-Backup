import { GuildMember, PartialGuildMember } from 'discord.js';
import { WelcomeService } from '../services/welcomeService.js';
import { logger } from '../utils/logger.js';

export async function handleGuildMemberUpdate(
  oldMember: GuildMember | PartialGuildMember,
  newMember: GuildMember
): Promise<void> {
  try {
    // Only trigger if member newly became a booster
    const wasBooster = Boolean(oldMember.premiumSinceTimestamp);
    const isBooster = Boolean(newMember.premiumSinceTimestamp);

    if (!wasBooster && isBooster) {
      await WelcomeService.handleMemberBoost(newMember);
    }
  } catch (err) {
    logger.error('EventHandler', `Error handling guildMemberUpdate in ${newMember.guild.id}`, err);
  }
}
