plugins {
    java
}

group = "me.qfie"
version = "1.0.0"

repositories {
    mavenCentral()
    maven {
        name = "PaperMC"
        url = uri("https://repo.papermc.io/repository/maven-public/")
    }
}

dependencies {
    compileOnly("com.velocitypowered:velocity-api:3.4.0-SNAPSHOT")
    implementation("org.yaml:snakeyaml:2.4")
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release = 21
}

tasks.processResources {
    filesMatching("config.yml") {
        expand("version" to project.version)
    }
}

tasks.jar {
    archiveBaseName = "QfieBroadcast"
    manifest {
        attributes["Implementation-Version"] = project.version
    }
}
