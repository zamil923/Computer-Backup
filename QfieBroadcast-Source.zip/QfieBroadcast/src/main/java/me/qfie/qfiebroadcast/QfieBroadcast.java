package me.qfie.qfiebroadcast;

import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandManager;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.proxy.ProxyServer;
import me.qfie.qfiebroadcast.command.BroadcastCommand;
import me.qfie.qfiebroadcast.config.BroadcastConfig;
import org.slf4j.Logger;

import java.nio.file.Files;
import java.nio.file.Path;

@Plugin(
        id = "qfiebroadcast",
        name = "QfieBroadcast",
        version = "1.0.0",
        authors = {"Qfie"},
        description = "A Velocity proxy broadcast plugin that can send messages to players on a specific backend server or to every player connected to the proxy."
)
public final class QfieBroadcast {

    private final ProxyServer proxyServer;
    private final Logger logger;
    private final Path dataDirectory;

    private BroadcastConfig config;

    @Inject
    public QfieBroadcast(
            ProxyServer proxyServer,
            Logger logger,
            @com.velocitypowered.api.plugin.annotation.DataDirectory Path dataDirectory
    ) {
        this.proxyServer = proxyServer;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialization(ProxyInitializeEvent event) {
        try {
            Files.createDirectories(dataDirectory);
            this.config = new BroadcastConfig(dataDirectory.resolve("config.yml"));
            this.config.load();

            CommandManager commandManager = proxyServer.getCommandManager();
            BroadcastCommand command = new BroadcastCommand(proxyServer, logger, this);

            commandManager.register(
                    commandManager.metaBuilder("prbroadcast")
                            .plugin(this)
                            .build(),
                    command
            );

            logger.info("QfieBroadcast 1.0.0 enabled.");
        } catch (Exception exception) {
            logger.error("Failed to initialize QfieBroadcast.", exception);
        }
    }

    public void reloadConfiguration() throws Exception {
        config.load();
    }

    public BroadcastConfig getConfig() {
        return config;
    }

    public ProxyServer getProxyServer() {
        return proxyServer;
    }
}
