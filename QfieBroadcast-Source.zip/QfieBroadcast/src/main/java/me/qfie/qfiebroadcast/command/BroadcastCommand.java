package me.qfie.qfiebroadcast.command;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import me.qfie.qfiebroadcast.QfieBroadcast;
import me.qfie.qfiebroadcast.util.MessageUtil;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

public final class BroadcastCommand implements SimpleCommand {

    private static final String PERMISSION_BROADCAST = "qfiebroadcast.broadcast";
    private static final String PERMISSION_ALL = "qfiebroadcast.all";
    private static final String PERMISSION_LIST = "qfiebroadcast.list";
    private static final String PERMISSION_RELOAD = "qfiebroadcast.reload";

    private final ProxyServer proxyServer;
    private final Logger logger;
    private final QfieBroadcast plugin;

    public BroadcastCommand(ProxyServer proxyServer, Logger logger, QfieBroadcast plugin) {
        this.proxyServer = proxyServer;
        this.logger = logger;
        this.plugin = plugin;
    }

    @Override
    public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        String[] args = invocation.arguments();

        if (args.length == 0) {
            sendUsage(source);
            return;
        }

        String subcommand = args[0];

        if (equalsIgnoreCase(subcommand, "help")) {
            sendHelp(source);
            return;
        }

        if (equalsIgnoreCase(subcommand, "list")) {
            if (!hasPermission(source, PERMISSION_LIST)) {
                sendConfigured(source, "no-permission");
                return;
            }
            sendServerList(source);
            return;
        }

        if (equalsIgnoreCase(subcommand, "reload")) {
            if (!hasPermission(source, PERMISSION_RELOAD)) {
                sendConfigured(source, "no-permission");
                return;
            }
            reload(source);
            return;
        }

        if (args.length < 2) {
            if (args.length == 1) {
                sendConfigured(source, "message-required");
            } else {
                sendUsage(source);
            }
            return;
        }

        String message = joinArguments(args, 1);
        if (message.isBlank()) {
            sendConfigured(source, "message-required");
            return;
        }

        if (equalsIgnoreCase(subcommand, "all")) {
            if (!hasPermission(source, PERMISSION_ALL)) {
                sendConfigured(source, "no-permission");
                return;
            }
            broadcastAll(source, message);
            return;
        }

        if (!hasPermission(source, PERMISSION_BROADCAST)) {
            sendConfigured(source, "no-permission");
            return;
        }

        broadcastServer(source, subcommand, message);
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();

        if (args.length == 0) {
            return firstArgumentSuggestions("");
        }

        if (args.length == 1) {
            return firstArgumentSuggestions(args[0]);
        }

        return List.of();
    }

    private List<String> firstArgumentSuggestions(String input) {
        String prefix = input == null ? "" : input;
        List<String> suggestions = new ArrayList<>(List.of("all", "list", "reload", "help"));

        proxyServer.getAllServers().stream()
                .map(RegisteredServer::getServerInfo)
                .map(info -> info.getName())
                .forEach(suggestions::add);

        return suggestions.stream()
                .distinct()
                .filter(value -> value.regionMatches(
                        true,
                        0,
                        prefix,
                        0,
                        prefix.length()
                ))
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .collect(Collectors.toList());
    }

    private void broadcastServer(CommandSource source, String requestedName, String message) {
        Optional<RegisteredServer> server = findServer(requestedName);

        if (server.isEmpty()) {
            sendServerNotFound(source, requestedName);
            return;
        }

        Collection<Player> players = server.get().getPlayersConnected();
        if (players.isEmpty()) {
            sendConfiguredServerMessage(source, "no-players", server.get().getServerInfo().getName());
            return;
        }

        Component component = MessageUtil.parse(message);
        players.forEach(player -> player.sendMessage(component));

        sendSenderConfirmation(source, server.get().getServerInfo().getName(), players.size());
    }

    private void broadcastAll(CommandSource source, String message) {
        Component component = MessageUtil.parse(message);
        Collection<Player> players = proxyServer.getAllPlayers();

        if (players.isEmpty()) {
            sendConfigured(source, "no-players");
            return;
        }

        players.forEach(player -> player.sendMessage(component));
        sendSenderConfirmation(source, "all connected players", players.size());
    }

    private void sendServerList(CommandSource source) {
        sendConfigured(source, "prefix");

        List<String> names = proxyServer.getAllServers().stream()
                .map(RegisteredServer::getServerInfo)
                .map(info -> info.getName())
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .toList();

        source.sendMessage(MessageUtil.parse("<aqua>Connected backend servers:</aqua>"));

        if (names.isEmpty()) {
            source.sendMessage(MessageUtil.parse("<gray>• none</gray>"));
            return;
        }

        for (String name : names) {
            source.sendMessage(MessageUtil.parse("<gray>• <white>" + escapeForMiniMessage(name) + "</white></gray>"));
        }
    }

    private void sendHelp(CommandSource source) {
        for (String line : plugin.getConfig().getHelpLines()) {
            source.sendMessage(MessageUtil.parse(line));
        }
    }

    private void reload(CommandSource source) {
        try {
            plugin.reloadConfiguration();
            sendConfigured(source, "reload-success");
        } catch (Exception exception) {
            logger.error("Failed to reload QfieBroadcast configuration.", exception);
            sendConfigured(source, "reload-success");
        }
    }

    private Optional<RegisteredServer> findServer(String requestedName) {
        boolean caseSensitive = plugin.getConfig().isCaseSensitiveServerNames();

        return proxyServer.getAllServers().stream()
                .filter(server -> {
                    String actualName = server.getServerInfo().getName();
                    return caseSensitive
                            ? actualName.equals(requestedName)
                            : actualName.equalsIgnoreCase(requestedName);
                })
                .findFirst();
    }

    private boolean hasPermission(CommandSource source, String permission) {
        if (source instanceof com.velocitypowered.api.proxy.ConsoleCommandSource) {
            return true;
        }
        return source.hasPermission(permission);
    }

    private void sendUsage(CommandSource source) {
        sendConfigured(source, "usage");
    }

    private void sendConfigured(CommandSource source, String key) {
        String message = plugin.getConfig().getMessage(key);
        source.sendMessage(MessageUtil.parse(message));
    }

    private void sendConfiguredServerMessage(CommandSource source, String key, String serverName) {
        String message = plugin.getConfig().getMessage(key);
        source.sendMessage(MessageUtil.parseWithServer(message, serverName));
    }

    private void sendServerNotFound(CommandSource source, String serverName) {
        String message = plugin.getConfig().getMessage("server-not-found");
        source.sendMessage(MessageUtil.parseWithServer(message, serverName));
    }

    private void sendSenderConfirmation(CommandSource source, String destination, int playerCount) {
        source.sendMessage(
                MessageUtil.parse(
                        "<green>Broadcast sent to <yellow>"
                                + escapeForMiniMessage(destination)
                                + "</yellow> for <yellow>"
                                + playerCount
                                + "</yellow> player(s).</green>"
                )
        );
    }

    private static String joinArguments(String[] args, int start) {
        StringBuilder builder = new StringBuilder();
        for (int i = start; i < args.length; i++) {
            if (i > start) {
                builder.append(' ');
            }
            builder.append(args[i]);
        }
        return builder.toString();
    }

    private static boolean equalsIgnoreCase(String first, String second) {
        return first.equalsIgnoreCase(second);
    }

    private static String escapeForMiniMessage(String input) {
        return input
                .replace("<", "\\<")
                .replace(">", "\\>");
    }
}
