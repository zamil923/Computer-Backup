package me.qfie.qfiebroadcast.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;

public final class MessageUtil {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();

    private MessageUtil() {
    }

    public static Component parse(String input) {
        if (input == null || input.isEmpty()) {
            return Component.empty();
        }

        try {
            return MINI_MESSAGE.deserialize(input);
        } catch (RuntimeException ignored) {
            return Component.text(input);
        }
    }

    public static Component parseWithServer(String template, String serverName) {
        if (template == null || template.isEmpty()) {
            return Component.empty();
        }

        try {
            return MINI_MESSAGE.deserialize(
                    template,
                    Placeholder.unparsed("server", serverName)
            );
        } catch (RuntimeException ignored) {
            return Component.text(template.replace("<server>", serverName));
        }
    }
}
