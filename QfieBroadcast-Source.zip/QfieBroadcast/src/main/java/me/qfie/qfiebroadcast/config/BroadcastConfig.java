package me.qfie.qfiebroadcast.config;

import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BroadcastConfig {

    private final Path file;

    private Map<String, Object> values = new LinkedHashMap<>();

    public BroadcastConfig(Path file) {
        this.file = file;
    }

    public void load() throws IOException {
        if (Files.notExists(file)) {
            try (InputStream input = BroadcastConfig.class.getResourceAsStream("/config.yml")) {
                if (input == null) {
                    throw new IOException("Bundled config.yml was not found.");
                }
                Files.copy(input, file);
            }
        }

        Yaml yaml = new Yaml();

        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            Map<String, Object> loaded = yaml.load(reader);
            values = loaded == null ? new LinkedHashMap<>() : loaded;
        }
    }

    public String getMessage(String key) {
        Object messages = values.get("messages");
        if (!(messages instanceof Map<?, ?> messageMap)) {
            return "";
        }

        Object value = messageMap.get(key);
        return value == null ? "" : String.valueOf(value);
    }

    public List<String> getHelpLines() {
        Object messages = values.get("messages");
        if (!(messages instanceof Map<?, ?> messageMap)) {
            return Collections.emptyList();
        }

        Object help = messageMap.get("help");
        if (!(help instanceof List<?> list)) {
            return Collections.emptyList();
        }

        List<String> lines = new ArrayList<>();
        for (Object line : list) {
            if (line != null) {
                lines.add(String.valueOf(line));
            }
        }
        return Collections.unmodifiableList(lines);
    }

    public boolean isCaseSensitiveServerNames() {
        Object settings = values.get("settings");
        if (!(settings instanceof Map<?, ?> settingsMap)) {
            return false;
        }

        Object value = settingsMap.get("case-sensitive-server-names");
        return value instanceof Boolean bool ? bool : Boolean.parseBoolean(String.valueOf(value));
    }

    public Path getFile() {
        return file;
    }
}
