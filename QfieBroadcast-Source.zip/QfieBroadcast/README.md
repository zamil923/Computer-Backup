# QfieBroadcast

QfieBroadcast is a Velocity proxy broadcast plugin for sending MiniMessage-formatted messages to players on one backend server or to every player connected to the proxy.

## Requirements

- Velocity proxy using a modern Velocity API (the project targets Velocity API 3.4.0-SNAPSHOT).
- Java 21.
- No QfieBroadcast installation is required on backend Paper/Leaf servers.

## Installation

1. Build the project with your normal Gradle installation.
2. Put the resulting `QfieBroadcast.jar` in the Velocity proxy's `plugins/` directory.
3. Start/restart the Velocity proxy.
4. Edit `plugins/qfiebroadcast/config.yml` if desired.
5. Use `/prbroadcast`.

Example:

```text
Proxy:
plugins/
└── QfieBroadcast.jar

Backend:
No QfieBroadcast plugin required.
```

The plugin communicates with backend servers through Velocity's proxy/player APIs. It does not connect directly to Paper/Leaf servers.

## Configuration

`config.yml` contains configurable MiniMessage messages and server-name matching settings.

```yaml
messages:
  prefix: "<gray>[<aqua>QfieBroadcast</aqua>]</gray> "
  no-permission: "<red>You don't have permission to use this command.</red>"
  player-only: "<red>This command cannot be used from the console.</red>"
  server-not-found: "<red>Server <yellow><server></yellow> was not found.</red>"
  message-required: "<red>Please provide a message.</red>"
  reload-success: "<green>QfieBroadcast configuration reloaded.</green>"
  no-players: "<yellow>No players are currently connected to <server>.</yellow>"
  usage: "<yellow>Usage: /prbroadcast <server> <message></yellow>"
  help:
    - "<aqua>QfieBroadcast Commands</aqua>"
    - "<gray>/prbroadcast <server> <message> <white>- Broadcast to a server"
    - "<gray>/prbroadcast all <message> <white>- Broadcast to everyone"
    - "<gray>/prbroadcast list <white>- List backend servers"
    - "<gray>/prbroadcast reload <white>- Reload configuration"
    - "<gray>/prbroadcast help <white>- Show help"

settings:
  case-sensitive-server-names: false
```

Messages are parsed with Adventure MiniMessage. User-supplied broadcast text is preserved as MiniMessage, so tags such as `<red>`, `<green>`, `<bold>`, and `<italic>` work.

## Commands

| Command | Description |
|---|---|
| `/prbroadcast <server> <message>` | Send a message to players on one backend server |
| `/prbroadcast all <message>` | Send a message to every connected player |
| `/prbroadcast list` | List all registered Velocity backend servers |
| `/prbroadcast reload` | Reload QfieBroadcast's own configuration |
| `/prbroadcast help` | Show the command help |

## Permissions

- `qfiebroadcast.broadcast`
- `qfiebroadcast.all`
- `qfiebroadcast.list`
- `qfiebroadcast.reload`

The console is treated as an administrative source and is allowed to use the command.

## Examples

```text
/prbroadcast survival Hello Survival players!
/prbroadcast lobby Welcome to the Lobby!
/prbroadcast skyblock Welcome Skyblock players!
/prbroadcast all Server restart in 5 minutes!
/prbroadcast list
/prbroadcast reload
/prbroadcast help
```

MiniMessage is retained:

```text
/prbroadcast survival <green>Hello Survival!</green>
/prbroadcast all <bold><aqua>Server restart soon!</aqua></bold>
```

## Building

This repository contains source only. Build it yourself with a normal Gradle installation:

```text
gradle build
```

The project intentionally does not include a Gradle wrapper, generated JAR, `build/` directory, or `.gradle/` directory.

## Notes

- Backend server names come dynamically from the Velocity proxy configuration.
- Server matching is case-insensitive by default.
- A server with zero connected players is handled without throwing an exception.
- Malformed MiniMessage is handled safely and falls back to a plain-text component.
