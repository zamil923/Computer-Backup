# Add project specific ProGuard rules here.
-keep class com.myschool.app.data.entity.** { *; }
