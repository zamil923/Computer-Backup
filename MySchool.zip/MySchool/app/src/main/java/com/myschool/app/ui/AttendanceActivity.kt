package com.myschool.app.ui

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Attendance
import com.myschool.app.data.entity.AttendanceStatus
import com.myschool.app.data.entity.Role
import com.myschool.app.data.entity.User
import com.myschool.app.ui.adapter.AttendanceMarkAdapter
import com.myschool.app.ui.adapter.AttendanceRecordAdapter
import com.myschool.app.util.IdGenerator
import com.myschool.app.util.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

class AttendanceActivity : AppCompatActivity() {

    private val periodOptions = listOf("Whole Day", "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8")
    private val statusMap = mutableMapOf<String, AttendanceStatus>()
    private var approvedStudents: List<User> = emptyList()
    private lateinit var markAdapter: AttendanceMarkAdapter
    private lateinit var recordAdapter: AttendanceRecordAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attendance)

        val classId = intent.getStringExtra("classId") ?: run { finish(); return }
        val className = intent.getStringExtra("className") ?: ""
        val canManage = intent.getBooleanExtra("canManage", false)

        findViewById<TextView>(R.id.tvTitle).text = "Attendance — $className"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val etDate = findViewById<TextInputEditText>(R.id.etDate)
        etDate.setText(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(System.currentTimeMillis()))

        val spinnerPeriod = findViewById<Spinner>(R.id.spinnerPeriod)
        spinnerPeriod.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, periodOptions)

        val recyclerView = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerView)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        val btnSave = findViewById<MaterialButton>(R.id.btnSaveAttendance)

        val db = AppDatabase.getInstance(this)
        val session = SessionManager(this)

        if (canManage && session.getRole() != Role.STUDENT) {
            // Teacher/Principal marking mode.
            markAdapter = AttendanceMarkAdapter(emptyList(), statusMap)
            recyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
            recyclerView.adapter = markAdapter
            btnSave.visibility = View.VISIBLE

            db.userDao().getApprovedStudentsInClass(classId).observe(this) { students ->
                approvedStudents = students
                markAdapter.submitList(students)
                tvEmpty.text = "No approved students in this class yet"
                tvEmpty.visibility = if (students.isEmpty()) View.VISIBLE else View.GONE
            }

            btnSave.setOnClickListener {
                val date = etDate.text.toString().trim()
                if (date.isEmpty()) {
                    Toast.makeText(this, "Please enter a date", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (approvedStudents.isEmpty()) {
                    Toast.makeText(this, "No students to mark attendance for", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val periodIndex = spinnerPeriod.selectedItemPosition // 0 = Whole day
                lifecycleScope.launch {
                    approvedStudents.forEach { student ->
                        val status = statusMap[student.uniqueId] ?: AttendanceStatus.PRESENT
                        db.attendanceDao().insert(
                            Attendance(
                                id = IdGenerator.genericId(),
                                classId = classId,
                                studentId = student.uniqueId,
                                studentName = student.name,
                                date = date,
                                period = periodIndex,
                                status = status
                            )
                        )
                    }
                    Toast.makeText(this@AttendanceActivity, "Attendance saved for ${approvedStudents.size} students", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            // Student view mode: read-only attendance history.
            findViewById<View>(R.id.controlsBar).visibility = View.GONE
            btnSave.visibility = View.GONE

            recordAdapter = AttendanceRecordAdapter(emptyList())
            recyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
            recyclerView.adapter = recordAdapter

            val studentId = session.getUserId()
            if (studentId != null) {
                db.attendanceDao().getForStudent(studentId).observe(this) { list ->
                    recordAdapter.submitList(list)
                    tvEmpty.text = "No attendance records yet"
                    tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }
}
