package com.myschool.app.ui

import android.os.Bundle
import android.view.View
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Role
import com.myschool.app.data.entity.User
import com.myschool.app.util.IdGenerator
import kotlinx.coroutines.launch

class AddTeacherActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_form)

        findViewById<TextView>(R.id.tvHeaderTitle).text = "Add Teacher"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val etName = findViewById<TextInputEditText>(R.id.etField1)
        etName.hint = "Teacher's full name"

        val tilField2 = findViewById<View>(R.id.tilField2)
        tilField2.visibility = View.VISIBLE
        val etPassword = findViewById<TextInputEditText>(R.id.etField2)
        etPassword.hint = "Set a temporary password"
        etPassword.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

        val rgGender = findViewById<RadioGroup>(R.id.rgGender)
        rgGender.visibility = View.VISIBLE

        val tvResult = findViewById<TextView>(R.id.tvResult)
        val btnSave = findViewById<MaterialButton>(R.id.btnSave)
        btnSave.text = "Create Teacher Account"

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val gender = if (rgGender.checkedRadioButtonId == R.id.rbBoy) "Male" else "Female"

            if (name.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newId = IdGenerator.teacherId()
            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.userDao().insert(
                    User(
                        uniqueId = newId,
                        name = name,
                        gender = gender,
                        password = password,
                        role = Role.TEACHER,
                        approved = true
                    )
                )
                tvResult.visibility = View.VISIBLE
                tvResult.text = "Teacher account created!\nUnique ID: $newId\nShare this ID + password with the teacher to log in."
                etName.text?.clear()
                etPassword.text?.clear()
            }
        }
    }
}
