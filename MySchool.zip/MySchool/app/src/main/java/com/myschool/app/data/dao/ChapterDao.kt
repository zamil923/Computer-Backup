package com.myschool.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.myschool.app.data.entity.Chapter

@Dao
interface ChapterDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(chapter: Chapter)

    @Query("SELECT * FROM chapters WHERE classId = :classId ORDER BY timestamp DESC")
    fun getForClass(classId: String): LiveData<List<Chapter>>
}
