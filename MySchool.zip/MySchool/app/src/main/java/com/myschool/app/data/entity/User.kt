package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents any person in the system: Principal, Teacher, or Student.
 * A unique ID is auto-generated at creation time for every account.
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey val uniqueId: String,
    val name: String,
    val gender: String,           // "Boy" / "Girl" / "Male" / "Female"
    val password: String,
    val role: Role,
    val classId: String? = null,  // class the student belongs to (null for teacher/principal until assigned)
    val approved: Boolean = false,// students must be approved by teacher/principal to join a class
    val createdAt: Long = System.currentTimeMillis()
)
