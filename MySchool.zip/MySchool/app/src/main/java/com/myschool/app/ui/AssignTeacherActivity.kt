package com.myschool.app.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.User
import kotlinx.coroutines.launch

class AssignTeacherActivity : AppCompatActivity() {

    private var teachers: List<User> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_assign_teacher)

        val classId = intent.getStringExtra("classId") ?: return
        val className = intent.getStringExtra("className") ?: ""

        findViewById<TextView>(R.id.tvHeaderTitle).text = "Assign Teacher"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val spinner = findViewById<Spinner>(R.id.spinnerTeacher)
        val db = AppDatabase.getInstance(this)

        db.userDao().getAllTeachers().observe(this) { list ->
            teachers = list
            val names = if (list.isEmpty()) listOf("No teachers yet - add one first") else list.map { "${it.name} (${it.uniqueId})" }
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        }

        findViewById<MaterialButton>(R.id.btnAssign).setOnClickListener {
            if (teachers.isEmpty()) {
                Toast.makeText(this, "Please add a teacher first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val selected = teachers[spinner.selectedItemPosition]
            lifecycleScope.launch {
                val schoolClass = db.schoolClassDao().getById(classId)
                if (schoolClass != null) {
                    db.schoolClassDao().update(schoolClass.copy(classTeacherId = selected.uniqueId))
                }
                Toast.makeText(
                    this@AssignTeacherActivity,
                    "${selected.name} assigned as class teacher for $className",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        }
    }
}
