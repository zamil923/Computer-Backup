package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.myschool.app.R

class ClassDetailActivity : AppCompatActivity() {

    private lateinit var classId: String
    private var className: String = ""
    private var canManage: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_class_detail)

        classId = intent.getStringExtra("classId") ?: run { finish(); return }
        className = intent.getStringExtra("className") ?: "My Class"
        canManage = intent.getBooleanExtra("isTeacherOrPrincipal", false)

        findViewById<TextView>(R.id.tvClassName).text = className
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val container = findViewById<LinearLayout>(R.id.containerMenu)

        val items = listOf(
            Triple("🗓️", "Weekly Timetable") {
                open(TimetableActivity::class.java)
            },
            Triple("🧑‍🎓", "Students in Class") {
                open(StudentListActivity::class.java)
            },
            Triple("📝", "Attendance") {
                open(AttendanceActivity::class.java)
            },
            Triple("📖", "Daily Chapters") {
                open(ChapterListActivity::class.java)
            },
            Triple("📚", "Homework") {
                open(HomeworkListActivity::class.java)
            }
        )

        items.forEach { (icon, title, action) ->
            val view = LayoutInflater.from(this).inflate(R.layout.item_dashboard_card, container, false)
            view.findViewById<TextView>(R.id.tvIcon).text = icon
            view.findViewById<TextView>(R.id.tvTitle).text = title
            view.findViewById<TextView>(R.id.tvSubtitle).text =
                if (canManage) "Tap to view or manage" else "Tap to view"
            view.setOnClickListener { action() }
            container.addView(view)
        }
    }

    private fun open(activityClass: Class<*>) {
        val intent = Intent(this, activityClass)
        intent.putExtra("classId", classId)
        intent.putExtra("className", className)
        intent.putExtra("canManage", canManage)
        startActivity(intent)
    }
}
