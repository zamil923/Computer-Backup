package com.myschool.app.util

import kotlin.random.Random

/**
 * Generates readable, unique IDs for accounts and records, e.g. STU-4821, TCH-1092, CLS-3305.
 */
object IdGenerator {
    fun generate(prefix: String): String {
        val number = Random.nextInt(1000, 9999)
        val timePart = (System.currentTimeMillis() % 1000)
        return "$prefix-$number$timePart"
    }

    fun studentId() = generate("STU")
    fun teacherId() = generate("TCH")
    fun classId() = generate("CLS")
    fun genericId() = generate("ID")
}
