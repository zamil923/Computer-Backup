package com.myschool.app.data.entity

enum class SchoolEventType {
    WORKING_DAY, LEAVE, ACTIVITY
}
