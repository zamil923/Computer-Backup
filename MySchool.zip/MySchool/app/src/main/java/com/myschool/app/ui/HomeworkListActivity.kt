package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.ui.adapter.HomeworkAdapter

class HomeworkListActivity : AppCompatActivity() {

    private lateinit var adapter: HomeworkAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generic_list)

        val classId = intent.getStringExtra("classId") ?: run { finish(); return }
        val className = intent.getStringExtra("className") ?: ""
        val canManage = intent.getBooleanExtra("canManage", false)

        findViewById<TextView>(R.id.tvTitle).text = "Homework — $className"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        val fab = findViewById<FloatingActionButton>(R.id.fabAdd)
        fab.visibility = if (canManage) View.VISIBLE else View.GONE
        fab.setOnClickListener {
            val intent = Intent(this, AddHomeworkActivity::class.java)
            intent.putExtra("classId", classId)
            startActivity(intent)
        }

        adapter = HomeworkAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val db = AppDatabase.getInstance(this)
        db.homeworkDao().getForClass(classId).observe(this) { list ->
            adapter.submitList(list)
            tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
