package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per student, per period, per day -> supports per-period attendance
 * as well as a simple daily view. `timestamp` records when attendance was taken.
 */
@Entity(tableName = "attendance")
data class Attendance(
    @PrimaryKey val id: String,
    val classId: String,
    val studentId: String,
    val studentName: String,
    val date: String,             // e.g. "2026-07-04"
    val period: Int,              // 0 = whole day, 1..N = period number
    val status: AttendanceStatus,
    val timestamp: Long = System.currentTimeMillis()
)
