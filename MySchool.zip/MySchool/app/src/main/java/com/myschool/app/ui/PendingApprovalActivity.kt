package com.myschool.app.ui

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Role
import com.myschool.app.data.entity.SchoolClass
import com.myschool.app.ui.adapter.PendingApprovalAdapter
import com.myschool.app.util.SessionManager
import kotlinx.coroutines.launch

/**
 * Only students approved here (by a Teacher for their own class, or by the Principal for any class)
 * can log in and join their class.
 */
class PendingApprovalActivity : AppCompatActivity() {

    private lateinit var adapter: PendingApprovalAdapter
    private var classMap: Map<String, SchoolClass> = emptyMap()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generic_list)

        findViewById<TextView>(R.id.tvTitle).text = "Pending Student Approvals"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }
        findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.fabAdd).visibility = View.GONE

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        tvEmpty.text = "No pending approvals right now"

        val db = AppDatabase.getInstance(this)
        val session = SessionManager(this)

        adapter = PendingApprovalAdapter(
            items = emptyList(),
            classNameFor = { classId -> classMap[classId]?.className ?: "Unknown" },
            onApprove = { user ->
                lifecycleScope.launch {
                    db.userDao().update(user.copy(approved = true))
                    Toast.makeText(this@PendingApprovalActivity, "${user.name} approved", Toast.LENGTH_SHORT).show()
                }
            },
            onReject = { user ->
                lifecycleScope.launch {
                    db.userDao().delete(user)
                    Toast.makeText(this@PendingApprovalActivity, "${user.name} rejected", Toast.LENGTH_SHORT).show()
                }
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        db.schoolClassDao().getAllClasses().observe(this) { classes ->
            classMap = classes.associateBy { it.classId }
        }

        val pendingLiveData = if (session.getRole() == Role.PRINCIPAL) {
            db.userDao().getPendingStudents()
        } else {
            // Teacher: only students who requested the class they teach.
            lifecycleScope.launch {
                val teacherClass = db.schoolClassDao().getClassForTeacher(session.getUserId() ?: "")
                val liveData = if (teacherClass != null) {
                    db.userDao().getPendingStudentsForClass(teacherClass.classId)
                } else {
                    db.userDao().getPendingStudents() // fallback, will just be filtered visually
                }
                liveData.observe(this@PendingApprovalActivity) { list ->
                    adapter.submitList(list)
                    tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
            null
        }

        pendingLiveData?.observe(this) { list ->
            adapter.submitList(list)
            tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
