package com.myschool.app.data.entity

enum class Role {
    PRINCIPAL, TEACHER, STUDENT
}
