package com.myschool.app.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Homework
import com.myschool.app.util.IdGenerator
import com.myschool.app.util.SessionManager
import kotlinx.coroutines.launch

class AddHomeworkActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_homework)

        val classId = intent.getStringExtra("classId") ?: run { finish(); return }
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val etSubject = findViewById<TextInputEditText>(R.id.etSubject)
        val etDescription = findViewById<TextInputEditText>(R.id.etDescription)
        val etDueDate = findViewById<TextInputEditText>(R.id.etDueDate)

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            val subject = etSubject.text.toString().trim()
            val description = etDescription.text.toString().trim()
            val dueDate = etDueDate.text.toString().trim()

            if (subject.isEmpty() || description.isEmpty() || dueDate.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val session = SessionManager(this)
            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.homeworkDao().insert(
                    Homework(
                        id = IdGenerator.genericId(),
                        classId = classId,
                        subject = subject,
                        description = description,
                        dueDate = dueDate,
                        uploadedBy = session.getUserName() ?: "Teacher"
                    )
                )
                Toast.makeText(this@AddHomeworkActivity, "Homework posted", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
