package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.myschool.app.data.AppDatabase
import kotlinx.coroutines.launch

class TeacherDashboardActivity : BaseDashboardActivity() {

    private var assignedClassId: String? = null
    private var assignedClassName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadAssignedClass()
    }

    private fun loadAssignedClass() {
        val db = AppDatabase.getInstance(this)
        lifecycleScope.launch {
            val teacherId = session.getUserId() ?: return@launch
            val schoolClass = db.schoolClassDao().getClassForTeacher(teacherId)
            assignedClassId = schoolClass?.classId
            assignedClassName = schoolClass?.className
        }
    }

    override fun roleLabel() = "Teacher"

    override fun buildMenu(): List<MenuItem> = listOf(
        MenuItem("📢", "Announcements", "View school announcements") {
            startActivity(Intent(this, AnnouncementListActivity::class.java))
        },
        MenuItem("📅", "Working Days & Events", "View leaves, working days & activities") {
            startActivity(Intent(this, SchoolEventListActivity::class.java))
        },
        MenuItem("🏫", "My Class", assignedClassName ?: "No class assigned yet") {
            openClassOrWarn()
        },
        MenuItem("✅", "Pending Approvals", "Approve students for your class") {
            startActivity(Intent(this, PendingApprovalActivity::class.java))
        }
    )

    private fun openClassOrWarn() {
        val classId = assignedClassId
        if (classId == null) {
            Toast.makeText(this, "You have not been assigned a class yet. Contact your Principal.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, ClassDetailActivity::class.java)
        intent.putExtra("classId", classId)
        intent.putExtra("className", assignedClassName)
        intent.putExtra("isTeacherOrPrincipal", true)
        startActivity(intent)
    }
}
