package com.myschool.app.ui

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Role
import com.myschool.app.data.entity.SchoolClass
import com.myschool.app.data.entity.User
import com.myschool.app.util.IdGenerator
import kotlinx.coroutines.launch

class RegisterStudentActivity : AppCompatActivity() {

    private var classList: List<SchoolClass> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_student)

        val etName = findViewById<TextInputEditText>(R.id.etName)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val rgGender = findViewById<RadioGroup>(R.id.rgGender)
        val spinnerClass = findViewById<Spinner>(R.id.spinnerClass)
        val tvMessage = findViewById<TextView>(R.id.tvMessage)
        val btnRegister = findViewById<MaterialButton>(R.id.btnRegister)

        val db = AppDatabase.getInstance(this)

        db.schoolClassDao().getAllClasses().observe(this) { classes ->
            classList = classes
            val names = if (classes.isEmpty()) listOf("No classes available yet") else classes.map { it.className }
            spinnerClass.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        }

        btnRegister.setOnClickListener {
            val name = etName.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val gender = if (rgGender.checkedRadioButtonId == R.id.rbBoy) "Boy" else "Girl"

            if (name.isEmpty() || password.isEmpty()) {
                showMessage(tvMessage, "Please fill in all fields")
                return@setOnClickListener
            }
            if (classList.isEmpty()) {
                showMessage(tvMessage, "No classes have been created yet. Ask your Principal to add one.")
                return@setOnClickListener
            }

            val selectedClass = classList[spinnerClass.selectedItemPosition]
            val newId = IdGenerator.studentId()

            lifecycleScope.launch {
                db.userDao().insert(
                    User(
                        uniqueId = newId,
                        name = name,
                        gender = gender,
                        password = password,
                        role = Role.STUDENT,
                        classId = selectedClass.classId,
                        approved = false
                    )
                )
                showMessage(
                    tvMessage,
                    "Registered! Your unique ID is $newId. Wait for teacher/principal approval before logging in."
                )
            }
        }
    }

    private fun showMessage(view: TextView, text: String) {
        view.text = text
        view.visibility = View.VISIBLE
    }
}
