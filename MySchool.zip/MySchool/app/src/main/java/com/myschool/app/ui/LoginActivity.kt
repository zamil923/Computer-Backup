package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import android.widget.TextView
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Role
import com.myschool.app.util.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var etUserId: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var tvError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etUserId = findViewById(R.id.etUserId)
        etPassword = findViewById(R.id.etPassword)
        tvError = findViewById(R.id.tvError)
        val btnLogin = findViewById<MaterialButton>(R.id.btnLogin)
        val tvRegister = findViewById<TextView>(R.id.tvRegisterStudent)

        btnLogin.setOnClickListener { attemptLogin() }
        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterStudentActivity::class.java))
        }
    }

    private fun attemptLogin() {
        val id = etUserId.text.toString().trim()
        val pass = etPassword.text.toString().trim()

        if (id.isEmpty() || pass.isEmpty()) {
            showError("Please enter both ID and password")
            return
        }

        val db = AppDatabase.getInstance(this)
        lifecycleScope.launch {
            val user = db.userDao().login(id, pass)
            if (user == null) {
                showError("Invalid ID or password")
                return@launch
            }
            if (user.role == Role.STUDENT && !user.approved) {
                showError("Your account is awaiting approval from your teacher/principal")
                return@launch
            }

            val session = SessionManager(this@LoginActivity)
            session.saveSession(user.uniqueId, user.name, user.role, user.classId)

            val target = when (user.role) {
                Role.PRINCIPAL -> PrincipalDashboardActivity::class.java
                Role.TEACHER -> TeacherDashboardActivity::class.java
                Role.STUDENT -> StudentDashboardActivity::class.java
            }
            startActivity(Intent(this@LoginActivity, target))
            finish()
        }
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }
}
