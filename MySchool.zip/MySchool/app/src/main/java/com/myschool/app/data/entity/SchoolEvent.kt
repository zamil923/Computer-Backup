package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "school_events")
data class SchoolEvent(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val type: SchoolEventType,
    val date: String,             // e.g. "2026-07-10"
    val timestamp: Long = System.currentTimeMillis()
)
