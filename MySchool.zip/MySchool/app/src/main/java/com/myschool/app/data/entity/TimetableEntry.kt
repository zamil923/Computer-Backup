package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timetable_entries")
data class TimetableEntry(
    @PrimaryKey val id: String,
    val classId: String,
    val day: String,              // Monday..Saturday
    val period: Int,
    val subject: String,
    val time: String              // e.g. "09:00 - 09:45"
)
