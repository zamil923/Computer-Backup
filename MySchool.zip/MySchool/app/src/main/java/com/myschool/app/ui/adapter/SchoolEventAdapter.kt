package com.myschool.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.SchoolEvent
import com.myschool.app.data.entity.SchoolEventType

class SchoolEventAdapter(private var items: List<SchoolEvent>) :
    RecyclerView.Adapter<SchoolEventAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvDescription: TextView = view.findViewById(R.id.tvDescription)
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvType: TextView = view.findViewById(R.id.tvType)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_school_event, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvTitle.text = item.title
        holder.tvDescription.text = item.description
        holder.tvDate.text = "Date: ${item.date}"
        holder.tvType.text = when (item.type) {
            SchoolEventType.WORKING_DAY -> "WORKING DAY"
            SchoolEventType.LEAVE -> "LEAVE"
            SchoolEventType.ACTIVITY -> "ACTIVITY"
        }
        val bg = when (item.type) {
            SchoolEventType.WORKING_DAY -> R.drawable.bg_pill_green
            SchoolEventType.LEAVE -> R.drawable.bg_pill_red
            SchoolEventType.ACTIVITY -> R.drawable.bg_pill_blue
        }
        holder.tvType.setBackgroundResource(bg)
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<SchoolEvent>) {
        items = newItems
        notifyDataSetChanged()
    }
}
