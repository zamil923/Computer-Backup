package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chapters")
data class Chapter(
    @PrimaryKey val id: String,
    val classId: String,
    val subject: String,
    val chapterTitle: String,
    val description: String,
    val date: String,
    val uploadedBy: String,
    val timestamp: Long = System.currentTimeMillis()
)
