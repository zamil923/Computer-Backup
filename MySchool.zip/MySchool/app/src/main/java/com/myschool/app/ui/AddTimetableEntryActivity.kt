package com.myschool.app.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.TimetableEntry
import com.myschool.app.util.IdGenerator
import kotlinx.coroutines.launch

class AddTimetableEntryActivity : AppCompatActivity() {

    private val days = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_timetable_entry)

        val classId = intent.getStringExtra("classId") ?: run { finish(); return }

        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val spinnerDay = findViewById<Spinner>(R.id.spinnerDay)
        spinnerDay.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, days)

        val etPeriod = findViewById<TextInputEditText>(R.id.etPeriod)
        val etSubject = findViewById<TextInputEditText>(R.id.etSubject)
        val etTime = findViewById<TextInputEditText>(R.id.etTime)

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            val day = days[spinnerDay.selectedItemPosition]
            val periodText = etPeriod.text.toString().trim()
            val subject = etSubject.text.toString().trim()
            val time = etTime.text.toString().trim()

            if (periodText.isEmpty() || subject.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.timetableDao().insert(
                    TimetableEntry(
                        id = IdGenerator.genericId(),
                        classId = classId,
                        day = day,
                        period = periodText.toIntOrNull() ?: 1,
                        subject = subject,
                        time = time
                    )
                )
                Toast.makeText(this@AddTimetableEntryActivity, "Timetable entry saved", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
