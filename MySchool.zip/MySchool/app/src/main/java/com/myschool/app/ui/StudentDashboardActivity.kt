package com.myschool.app.ui

import android.content.Intent

class StudentDashboardActivity : BaseDashboardActivity() {

    override fun roleLabel() = "Student"

    override fun buildMenu(): List<MenuItem> = listOf(
        MenuItem("📢", "Announcements", "View school announcements") {
            startActivity(Intent(this, AnnouncementListActivity::class.java))
        },
        MenuItem("📅", "Working Days & Events", "View leaves, working days & activities") {
            startActivity(Intent(this, SchoolEventListActivity::class.java))
        },
        MenuItem("🏫", "My Class", "Timetable, attendance, chapters & homework") {
            val classId = session.getClassId()
            if (classId == null) {
                android.widget.Toast.makeText(this, "You are not assigned to a class yet.", android.widget.Toast.LENGTH_LONG).show()
            } else {
                val intent = Intent(this, ClassDetailActivity::class.java)
                intent.putExtra("classId", classId)
                intent.putExtra("isTeacherOrPrincipal", false)
                startActivity(intent)
            }
        }
    )
}
