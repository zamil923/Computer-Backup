package com.myschool.app.data

import androidx.room.TypeConverter
import com.myschool.app.data.entity.AttendanceStatus
import com.myschool.app.data.entity.Role
import com.myschool.app.data.entity.SchoolEventType

class Converters {
    @TypeConverter
    fun fromRole(role: Role): String = role.name

    @TypeConverter
    fun toRole(value: String): Role = Role.valueOf(value)

    @TypeConverter
    fun fromEventType(type: SchoolEventType): String = type.name

    @TypeConverter
    fun toEventType(value: String): SchoolEventType = SchoolEventType.valueOf(value)

    @TypeConverter
    fun fromAttendanceStatus(status: AttendanceStatus): String = status.name

    @TypeConverter
    fun toAttendanceStatus(value: String): AttendanceStatus = AttendanceStatus.valueOf(value)
}
