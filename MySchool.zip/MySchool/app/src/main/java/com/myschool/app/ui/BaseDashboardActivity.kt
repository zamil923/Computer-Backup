package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.myschool.app.R
import com.myschool.app.util.SessionManager

/**
 * Shared scaffold for the Principal / Teacher / Student dashboards.
 * Subclasses just declare a list of menu items with an icon, title, subtitle and click action.
 */
abstract class BaseDashboardActivity : AppCompatActivity() {

    data class MenuItem(
        val icon: String,
        val title: String,
        val subtitle: String,
        val action: () -> Unit
    )

    protected lateinit var session: SessionManager
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        session = SessionManager(this)

        findViewById<TextView>(R.id.tvWelcome).text = "Hi, ${session.getUserName() ?: ""}"
        findViewById<TextView>(R.id.tvRoleLabel).text = roleLabel() + "  •  ID: ${session.getUserId()}"
        findViewById<TextView>(R.id.tvLogout).setOnClickListener {
            session.logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        container = findViewById(R.id.containerMenu)
    }

    override fun onResume() {
        super.onResume()
        // Rebuild menu each time in case counts/labels need refreshing.
        container.removeAllViews()
        buildMenu().forEach { item -> addMenuCard(item) }
    }

    private fun addMenuCard(item: MenuItem) {
        val view = LayoutInflater.from(this).inflate(R.layout.item_dashboard_card, container, false)
        view.findViewById<TextView>(R.id.tvIcon).text = item.icon
        view.findViewById<TextView>(R.id.tvTitle).text = item.title
        view.findViewById<TextView>(R.id.tvSubtitle).text = item.subtitle
        view.setOnClickListener { item.action() }
        container.addView(view)
    }

    protected abstract fun roleLabel(): String
    protected abstract fun buildMenu(): List<MenuItem>
}
