package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val postedByName: String,
    val timestamp: Long = System.currentTimeMillis()
)
