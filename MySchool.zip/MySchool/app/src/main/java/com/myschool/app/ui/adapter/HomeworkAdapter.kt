package com.myschool.app.ui.adapter

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.Homework

class HomeworkAdapter(private var items: List<Homework>) :
    RecyclerView.Adapter<HomeworkAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvSubject: TextView = view.findViewById(R.id.tvSubject)
        val tvDueDate: TextView = view.findViewById(R.id.tvDueDate)
        val tvDescription: TextView = view.findViewById(R.id.tvDescription)
        val tvMeta: TextView = view.findViewById(R.id.tvMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_homework, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvSubject.text = item.subject.uppercase()
        holder.tvDueDate.text = "Due: ${item.dueDate}"
        holder.tvDescription.text = item.description
        val time = DateFormat.format("dd MMM, hh:mm a", item.timestamp)
        holder.tvMeta.text = "By ${item.uploadedBy} • Posted $time"
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<Homework>) {
        items = newItems
        notifyDataSetChanged()
    }
}
