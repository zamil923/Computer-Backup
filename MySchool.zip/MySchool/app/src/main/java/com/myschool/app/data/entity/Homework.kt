package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey val id: String,
    val classId: String,
    val subject: String,
    val description: String,
    val dueDate: String,
    val uploadedBy: String,
    val timestamp: Long = System.currentTimeMillis()
)
