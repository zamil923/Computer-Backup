package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Role
import com.myschool.app.ui.adapter.AnnouncementAdapter
import com.myschool.app.util.SessionManager

class AnnouncementListActivity : AppCompatActivity() {

    private lateinit var adapter: AnnouncementAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generic_list)

        findViewById<TextView>(R.id.tvTitle).text = "Announcements"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        val fab = findViewById<FloatingActionButton>(R.id.fabAdd)

        adapter = AnnouncementAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val session = SessionManager(this)
        // Only the Principal can post new announcements.
        fab.visibility = if (session.getRole() == Role.PRINCIPAL) View.VISIBLE else View.GONE
        fab.setOnClickListener {
            startActivity(Intent(this, AddAnnouncementActivity::class.java))
        }

        val db = AppDatabase.getInstance(this)
        db.announcementDao().getAll().observe(this) { list ->
            adapter.submitList(list)
            tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
