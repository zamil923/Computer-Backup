package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.myschool.app.data.entity.Role
import com.myschool.app.util.SessionManager

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val session = SessionManager(this)

        val target = if (session.isLoggedIn()) {
            when (session.getRole()) {
                Role.PRINCIPAL -> PrincipalDashboardActivity::class.java
                Role.TEACHER -> TeacherDashboardActivity::class.java
                Role.STUDENT -> StudentDashboardActivity::class.java
                else -> LoginActivity::class.java
            }
        } else {
            LoginActivity::class.java
        }

        startActivity(Intent(this, target))
        finish()
    }
}
