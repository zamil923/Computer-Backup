package com.myschool.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.AttendanceStatus
import com.myschool.app.data.entity.User

/**
 * Lets a teacher/principal tap Present/Absent per student for the currently selected date+period.
 * Keeps an in-memory map of choices, defaulting everyone to PRESENT, which is read by the caller on Save.
 */
class AttendanceMarkAdapter(
    private var students: List<User>,
    private val statusMap: MutableMap<String, AttendanceStatus>
) : RecyclerView.Adapter<AttendanceMarkAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvPresent: TextView = view.findViewById(R.id.tvPresent)
        val tvAbsent: TextView = view.findViewById(R.id.tvAbsent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_attendance_mark, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val student = students[position]
        holder.tvName.text = student.name
        statusMap.putIfAbsent(student.uniqueId, AttendanceStatus.PRESENT)

        fun refreshHighlight() {
            val current = statusMap[student.uniqueId]
            holder.tvPresent.alpha = if (current == AttendanceStatus.PRESENT) 1f else 0.35f
            holder.tvAbsent.alpha = if (current == AttendanceStatus.ABSENT) 1f else 0.35f
        }
        refreshHighlight()

        holder.tvPresent.setOnClickListener {
            statusMap[student.uniqueId] = AttendanceStatus.PRESENT
            refreshHighlight()
        }
        holder.tvAbsent.setOnClickListener {
            statusMap[student.uniqueId] = AttendanceStatus.ABSENT
            refreshHighlight()
        }
    }

    override fun getItemCount() = students.size

    fun submitList(newItems: List<User>) {
        students = newItems
        notifyDataSetChanged()
    }
}
