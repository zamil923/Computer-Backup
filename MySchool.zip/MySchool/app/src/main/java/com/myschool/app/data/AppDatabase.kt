package com.myschool.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.myschool.app.data.dao.*
import com.myschool.app.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        SchoolClass::class,
        Announcement::class,
        SchoolEvent::class,
        TimetableEntry::class,
        Attendance::class,
        Chapter::class,
        Homework::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun schoolClassDao(): SchoolClassDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun schoolEventDao(): SchoolEventDao
    abstract fun timetableDao(): TimetableDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun chapterDao(): ChapterDao
    abstract fun homeworkDao(): HomeworkDao

    companion object {
        // Default Principal login seeded on first run.
        const val DEFAULT_PRINCIPAL_ID = "PRINCIPAL001"
        const val DEFAULT_PRINCIPAL_PASSWORD = "admin123"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "myschool_db"
                ).addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed a default Principal account so the app is usable on first launch.
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = INSTANCE
                            database?.userDao()?.insert(
                                User(
                                    uniqueId = DEFAULT_PRINCIPAL_ID,
                                    name = "Principal",
                                    gender = "N/A",
                                    password = DEFAULT_PRINCIPAL_PASSWORD,
                                    role = Role.PRINCIPAL,
                                    approved = true
                                )
                            )
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
