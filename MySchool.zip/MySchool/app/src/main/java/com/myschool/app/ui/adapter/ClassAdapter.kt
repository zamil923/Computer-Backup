package com.myschool.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.SchoolClass

class ClassAdapter(
    private var items: List<SchoolClass>,
    private var teacherNames: Map<String, String>,
    private val onClick: (SchoolClass) -> Unit,
    private val onAssignTeacher: (SchoolClass) -> Unit
) : RecyclerView.Adapter<ClassAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvClassName: TextView = view.findViewById(R.id.tvClassName)
        val tvTeacher: TextView = view.findViewById(R.id.tvTeacher)
        val tvAssign: TextView = view.findViewById(R.id.tvAssign)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_class, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvClassName.text = item.className
        val teacherName = item.classTeacherId?.let { teacherNames[it] }
        holder.tvTeacher.text = if (teacherName != null) "Class Teacher: $teacherName" else "No class teacher assigned"
        holder.itemView.setOnClickListener { onClick(item) }
        holder.tvAssign.setOnClickListener { onAssignTeacher(item) }
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<SchoolClass>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun updateTeacherNames(newMap: Map<String, String>) {
        teacherNames = newMap
        notifyDataSetChanged()
    }
}
