package com.myschool.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "school_classes")
data class SchoolClass(
    @PrimaryKey val classId: String,
    val className: String,        // e.g. "Grade 6 - A"
    val classTeacherId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
