package com.myschool.app.ui.adapter

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.Chapter

class ChapterAdapter(private var items: List<Chapter>) :
    RecyclerView.Adapter<ChapterAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvSubject: TextView = view.findViewById(R.id.tvSubject)
        val tvChapterTitle: TextView = view.findViewById(R.id.tvChapterTitle)
        val tvDescription: TextView = view.findViewById(R.id.tvDescription)
        val tvMeta: TextView = view.findViewById(R.id.tvMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvSubject.text = item.subject.uppercase()
        holder.tvChapterTitle.text = item.chapterTitle
        holder.tvDescription.text = item.description
        val time = DateFormat.format("dd MMM, hh:mm a", item.timestamp)
        holder.tvMeta.text = "Date: ${item.date} • By ${item.uploadedBy} • $time"
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<Chapter>) {
        items = newItems
        notifyDataSetChanged()
    }
}
