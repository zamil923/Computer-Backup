package com.myschool.app.ui

import android.content.Intent

class PrincipalDashboardActivity : BaseDashboardActivity() {

    override fun roleLabel() = "Principal"

    override fun buildMenu(): List<MenuItem> = listOf(
        MenuItem("📢", "Announcements", "Announce decisions to the whole school") {
            startActivity(Intent(this, AnnouncementListActivity::class.java))
        },
        MenuItem("📅", "Working Days & Events", "Manage leaves, working days & activities") {
            startActivity(Intent(this, SchoolEventListActivity::class.java))
        },
        MenuItem("🏫", "Classes", "Create classes & assign class teachers") {
            startActivity(Intent(this, ClassListActivity::class.java))
        },
        MenuItem("👩‍🏫", "Teachers", "Add teacher accounts") {
            startActivity(Intent(this, AddTeacherActivity::class.java))
        },
        MenuItem("✅", "Pending Approvals", "Approve students joining classes") {
            startActivity(Intent(this, PendingApprovalActivity::class.java))
        }
    )
}
