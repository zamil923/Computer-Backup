package com.myschool.app.ui.adapter

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.Attendance
import com.myschool.app.data.entity.AttendanceStatus

class AttendanceRecordAdapter(private var items: List<Attendance>) :
    RecyclerView.Adapter<AttendanceRecordAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvPeriodAndTime: TextView = view.findViewById(R.id.tvPeriodAndTime)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_attendance_record, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvDate.text = "${item.date} — ${item.studentName}"
        val periodLabel = if (item.period == 0) "Whole day" else "Period ${item.period}"
        val time = DateFormat.format("hh:mm a", item.timestamp)
        holder.tvPeriodAndTime.text = "$periodLabel • Recorded at $time"
        holder.tvStatus.text = item.status.name
        holder.tvStatus.setBackgroundResource(
            if (item.status == AttendanceStatus.PRESENT) R.drawable.bg_pill_green else R.drawable.bg_pill_red
        )
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<Attendance>) {
        items = newItems
        notifyDataSetChanged()
    }
}
