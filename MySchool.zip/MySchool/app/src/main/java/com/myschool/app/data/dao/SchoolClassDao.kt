package com.myschool.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.myschool.app.data.entity.SchoolClass

@Dao
interface SchoolClassDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(schoolClass: SchoolClass)

    @Update
    suspend fun update(schoolClass: SchoolClass)

    @Query("SELECT * FROM school_classes ORDER BY className ASC")
    fun getAllClasses(): LiveData<List<SchoolClass>>

    @Query("SELECT * FROM school_classes WHERE classId = :id LIMIT 1")
    suspend fun getById(id: String): SchoolClass?

    @Query("SELECT * FROM school_classes WHERE classTeacherId = :teacherId LIMIT 1")
    suspend fun getClassForTeacher(teacherId: String): SchoolClass?
}
