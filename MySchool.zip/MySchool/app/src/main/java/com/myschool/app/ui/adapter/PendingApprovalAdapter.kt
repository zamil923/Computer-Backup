package com.myschool.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.myschool.app.R
import com.myschool.app.data.entity.User

class PendingApprovalAdapter(
    private var items: List<User>,
    private val classNameFor: (String?) -> String,
    private val onApprove: (User) -> Unit,
    private val onReject: (User) -> Unit
) : RecyclerView.Adapter<PendingApprovalAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvMeta: TextView = view.findViewById(R.id.tvMeta)
        val btnApprove: MaterialButton = view.findViewById(R.id.btnApprove)
        val btnReject: MaterialButton = view.findViewById(R.id.btnReject)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pending_approval, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvMeta.text = "${item.gender} • ID: ${item.uniqueId} • Requested class: ${classNameFor(item.classId)}"
        holder.btnApprove.setOnClickListener { onApprove(item) }
        holder.btnReject.setOnClickListener { onReject(item) }
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<User>) {
        items = newItems
        notifyDataSetChanged()
    }
}
