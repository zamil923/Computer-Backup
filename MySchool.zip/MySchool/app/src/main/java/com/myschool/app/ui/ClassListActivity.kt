package com.myschool.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.ui.adapter.ClassAdapter

class ClassListActivity : AppCompatActivity() {

    private lateinit var adapter: ClassAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generic_list)

        findViewById<TextView>(R.id.tvTitle).text = "Classes"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        val fab = findViewById<FloatingActionButton>(R.id.fabAdd)
        fab.setOnClickListener { startActivity(Intent(this, AddClassActivity::class.java)) }

        val db = AppDatabase.getInstance(this)

        adapter = ClassAdapter(
            items = emptyList(),
            teacherNames = emptyMap(),
            onClick = { schoolClass ->
                val intent = Intent(this, ClassDetailActivity::class.java)
                intent.putExtra("classId", schoolClass.classId)
                intent.putExtra("className", schoolClass.className)
                intent.putExtra("isTeacherOrPrincipal", true)
                startActivity(intent)
            },
            onAssignTeacher = { schoolClass ->
                val intent = Intent(this, AssignTeacherActivity::class.java)
                intent.putExtra("classId", schoolClass.classId)
                intent.putExtra("className", schoolClass.className)
                startActivity(intent)
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        db.userDao().getAllTeachers().observe(this) { teachers ->
            adapter.updateTeacherNames(teachers.associate { it.uniqueId to it.name })
        }

        db.schoolClassDao().getAllClasses().observe(this) { classes ->
            adapter.submitList(classes)
            tvEmpty.visibility = if (classes.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
