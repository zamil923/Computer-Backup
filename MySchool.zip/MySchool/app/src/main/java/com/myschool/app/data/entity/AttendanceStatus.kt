package com.myschool.app.data.entity

enum class AttendanceStatus {
    PRESENT, ABSENT
}
