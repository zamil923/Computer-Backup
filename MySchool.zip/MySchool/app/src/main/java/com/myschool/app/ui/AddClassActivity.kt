package com.myschool.app.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.SchoolClass
import com.myschool.app.util.IdGenerator
import kotlinx.coroutines.launch

class AddClassActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_form)

        findViewById<TextView>(R.id.tvHeaderTitle).text = "Add Class"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val etField1 = findViewById<TextInputEditText>(R.id.etField1)
        etField1.hint = "Class name (e.g. Grade 6 - A)"

        val btnSave = findViewById<MaterialButton>(R.id.btnSave)
        btnSave.text = "Create Class"

        btnSave.setOnClickListener {
            val name = etField1.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.schoolClassDao().insert(
                    SchoolClass(classId = IdGenerator.classId(), className = name)
                )
                Toast.makeText(this@AddClassActivity, "Class created", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
