package com.myschool.app.ui

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Chapter
import com.myschool.app.util.IdGenerator
import com.myschool.app.util.SessionManager
import kotlinx.coroutines.launch

class AddChapterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_chapter)

        val classId = intent.getStringExtra("classId") ?: run { finish(); return }
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }

        val etSubject = findViewById<TextInputEditText>(R.id.etSubject)
        val etChapterTitle = findViewById<TextInputEditText>(R.id.etChapterTitle)
        val etDescription = findViewById<TextInputEditText>(R.id.etDescription)
        val etDate = findViewById<TextInputEditText>(R.id.etDate)

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            val subject = etSubject.text.toString().trim()
            val title = etChapterTitle.text.toString().trim()
            val description = etDescription.text.toString().trim()
            val date = etDate.text.toString().trim()

            if (subject.isEmpty() || title.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill in subject, title and date", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val session = SessionManager(this)
            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.chapterDao().insert(
                    Chapter(
                        id = IdGenerator.genericId(),
                        classId = classId,
                        subject = subject,
                        chapterTitle = title,
                        description = description,
                        date = date,
                        uploadedBy = session.getUserName() ?: "Teacher"
                    )
                )
                Toast.makeText(this@AddChapterActivity, "Chapter uploaded", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
