package com.myschool.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myschool.app.R
import com.myschool.app.data.entity.TimetableEntry

class TimetableAdapter(private var items: List<TimetableEntry>) :
    RecyclerView.Adapter<TimetableAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDay: TextView = view.findViewById(R.id.tvDay)
        val tvPeriod: TextView = view.findViewById(R.id.tvPeriod)
        val tvSubject: TextView = view.findViewById(R.id.tvSubject)
        val tvTime: TextView = view.findViewById(R.id.tvTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_timetable, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvDay.text = item.day
        holder.tvPeriod.text = "P${item.period}"
        holder.tvSubject.text = item.subject
        holder.tvTime.text = item.time
    }

    override fun getItemCount() = items.size

    fun submitList(newItems: List<TimetableEntry>) {
        items = newItems
        notifyDataSetChanged()
    }
}
