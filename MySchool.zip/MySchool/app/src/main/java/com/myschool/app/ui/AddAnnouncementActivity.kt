package com.myschool.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.Announcement
import com.myschool.app.util.IdGenerator
import com.myschool.app.util.SessionManager
import kotlinx.coroutines.launch

class AddAnnouncementActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_announcement)

        findViewById<android.widget.TextView>(R.id.tvBack).setOnClickListener { finish() }
        val etTitle = findViewById<TextInputEditText>(R.id.etTitle)
        val etMessage = findViewById<TextInputEditText>(R.id.etMessage)

        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnSave).setOnClickListener {
            val title = etTitle.text.toString().trim()
            val message = etMessage.text.toString().trim()
            if (title.isEmpty() || message.isEmpty()) {
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val session = SessionManager(this)
            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.announcementDao().insert(
                    Announcement(
                        id = IdGenerator.genericId(),
                        title = title,
                        message = message,
                        postedByName = session.getUserName() ?: "Principal"
                    )
                )
                Toast.makeText(this@AddAnnouncementActivity, "Announcement posted", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
