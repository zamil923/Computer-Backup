package com.myschool.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.myschool.app.data.entity.Role
import com.myschool.app.data.entity.User

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(user: User)

    @Update
    suspend fun update(user: User)

    @Query("SELECT * FROM users WHERE uniqueId = :id LIMIT 1")
    suspend fun getById(id: String): User?

    @Query("SELECT * FROM users WHERE uniqueId = :id AND password = :password LIMIT 1")
    suspend fun login(id: String, password: String): User?

    @Query("SELECT * FROM users WHERE role = :role ORDER BY name ASC")
    fun getByRole(role: Role): LiveData<List<User>>

    @Query("SELECT * FROM users WHERE classId = :classId AND role = 'STUDENT' AND approved = 1 ORDER BY name ASC")
    fun getApprovedStudentsInClass(classId: String): LiveData<List<User>>

    @Query("SELECT * FROM users WHERE role = 'STUDENT' AND approved = 0 ORDER BY createdAt DESC")
    fun getPendingStudents(): LiveData<List<User>>

    @Query("SELECT * FROM users WHERE role = 'STUDENT' AND approved = 0 AND classId = :classId ORDER BY createdAt DESC")
    fun getPendingStudentsForClass(classId: String): LiveData<List<User>>

    @Query("SELECT * FROM users WHERE role = 'TEACHER' ORDER BY name ASC")
    fun getAllTeachers(): LiveData<List<User>>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun countAll(): Int

    @Delete
    suspend fun delete(user: User)
}
