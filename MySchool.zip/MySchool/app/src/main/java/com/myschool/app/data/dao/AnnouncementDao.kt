package com.myschool.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Dao
import com.myschool.app.data.entity.Announcement

@Dao
interface AnnouncementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(announcement: Announcement)

    @Query("SELECT * FROM announcements ORDER BY timestamp DESC")
    fun getAll(): LiveData<List<Announcement>>
}
