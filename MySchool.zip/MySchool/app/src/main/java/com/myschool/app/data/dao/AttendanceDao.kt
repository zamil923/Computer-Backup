package com.myschool.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.myschool.app.data.entity.Attendance

@Dao
interface AttendanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(attendance: Attendance)

    @Query("SELECT * FROM attendance WHERE classId = :classId AND date = :date AND period = :period ORDER BY studentName ASC")
    fun getForClassDatePeriod(classId: String, date: String, period: Int): LiveData<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE studentId = :studentId ORDER BY timestamp DESC")
    fun getForStudent(studentId: String): LiveData<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE classId = :classId ORDER BY timestamp DESC")
    fun getForClass(classId: String): LiveData<List<Attendance>>
}
