package com.myschool.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.myschool.app.data.entity.SchoolEvent

@Dao
interface SchoolEventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: SchoolEvent)

    @Query("SELECT * FROM school_events ORDER BY date DESC")
    fun getAll(): LiveData<List<SchoolEvent>>
}
