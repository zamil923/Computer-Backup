package com.myschool.app.ui

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.ui.adapter.StudentAdapter

class StudentListActivity : AppCompatActivity() {

    private lateinit var adapter: StudentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generic_list)

        val classId = intent.getStringExtra("classId") ?: run { finish(); return }
        val className = intent.getStringExtra("className") ?: ""

        findViewById<TextView>(R.id.tvTitle).text = "Students — $className"
        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }
        findViewById<FloatingActionButton>(R.id.fabAdd).visibility = View.GONE

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)

        adapter = StudentAdapter(emptyList())
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val db = AppDatabase.getInstance(this)
        db.userDao().getApprovedStudentsInClass(classId).observe(this) { list ->
            adapter.submitList(list)
            tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            tvEmpty.text = "No approved students in this class yet"
        }
    }
}
