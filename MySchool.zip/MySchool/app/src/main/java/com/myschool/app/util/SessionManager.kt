package com.myschool.app.util

import android.content.Context
import com.myschool.app.data.entity.Role

/**
 * Simple SharedPreferences based session store for the currently logged in user.
 */
class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences("myschool_session", Context.MODE_PRIVATE)

    fun saveSession(userId: String, name: String, role: Role, classId: String?) {
        prefs.edit()
            .putString(KEY_ID, userId)
            .putString(KEY_NAME, name)
            .putString(KEY_ROLE, role.name)
            .putString(KEY_CLASS_ID, classId)
            .apply()
    }

    fun getUserId(): String? = prefs.getString(KEY_ID, null)
    fun getUserName(): String? = prefs.getString(KEY_NAME, null)
    fun getRole(): Role? = prefs.getString(KEY_ROLE, null)?.let { Role.valueOf(it) }
    fun getClassId(): String? = prefs.getString(KEY_CLASS_ID, null)

    fun isLoggedIn(): Boolean = getUserId() != null

    fun logout() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_ID = "id"
        private const val KEY_NAME = "name"
        private const val KEY_ROLE = "role"
        private const val KEY_CLASS_ID = "classId"
    }
}
