package com.myschool.app.ui

import android.os.Bundle
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.myschool.app.R
import com.myschool.app.data.AppDatabase
import com.myschool.app.data.entity.SchoolEvent
import com.myschool.app.data.entity.SchoolEventType
import com.myschool.app.util.IdGenerator
import kotlinx.coroutines.launch

class AddSchoolEventActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_school_event)

        findViewById<TextView>(R.id.tvBack).setOnClickListener { finish() }
        val rgType = findViewById<RadioGroup>(R.id.rgType)
        val etTitle = findViewById<TextInputEditText>(R.id.etTitle)
        val etDescription = findViewById<TextInputEditText>(R.id.etDescription)
        val etDate = findViewById<TextInputEditText>(R.id.etDate)

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            val title = etTitle.text.toString().trim()
            val description = etDescription.text.toString().trim()
            val date = etDate.text.toString().trim()

            if (title.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Title and date are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val type = when (rgType.checkedRadioButtonId) {
                R.id.rbLeave -> SchoolEventType.LEAVE
                R.id.rbActivity -> SchoolEventType.ACTIVITY
                else -> SchoolEventType.WORKING_DAY
            }

            val db = AppDatabase.getInstance(this)
            lifecycleScope.launch {
                db.schoolEventDao().insert(
                    SchoolEvent(
                        id = IdGenerator.genericId(),
                        title = title,
                        description = description,
                        type = type,
                        date = date
                    )
                )
                Toast.makeText(this@AddSchoolEventActivity, "Saved", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
