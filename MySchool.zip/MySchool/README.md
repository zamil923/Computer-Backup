# MY SCHOOL — Android App (Kotlin)

A complete school management app built natively in **Kotlin** for Android, using
**Room** (local SQLite database), **LiveData**, and Material Design components.
No backend/server needed — everything runs and is stored on the device.

## ✅ Features included

1. **Principal Announcements** — Principal posts decisions; everyone (teachers & students) can view them.
2. **Working days, leave & extra activities** — Principal manages a school calendar of Working Days, Leaves and Activities.
3. **Multiple classes** — Principal can create any number of classes (e.g. "Grade 6 - A").
4. **Accounts & unique IDs** — Every account (Principal-created Teacher, or self-registered Student) gets an auto-generated unique ID (e.g. `TCH-48213`, `STU-91027`) used to log in.
5. **Students assigned to classes** — Students pick their class at registration; each class stores its student roster (name + gender) and weekly timetable.
6. **Class teacher assignment** — Principal assigns a Class Teacher to each class from the list of registered teachers.
7. **Attendance** — Teachers record attendance per day **and per period**, with the exact time it was recorded shown to students in their history.
8. **Daily chapters & homework** — Teachers upload what was taught each day and assign homework; students view it in real time.
9. **Approval workflow** — New student accounts are "pending" until approved by their Teacher or the Principal — only approved students can log in and appear in the class roster.

## 🎨 Color Theme

School Blue (`#1565C0`) as the primary color with Fresh Green (`#2E7D32`) as the accent —
used throughout headers, buttons, and status indicators (present/absent, event types).
You can easily restyle the whole app by editing one file: `app/src/main/res/values/colors.xml`.

## 🔑 Default login

The app seeds one Principal account automatically the first time it runs:

```
ID:       PRINCIPAL001
Password: admin123
```

Log in as Principal to:
- Create classes (`Classes` menu)
- Add teacher accounts (`Teachers` menu) — this generates their unique ID
- Assign a class teacher to each class
- Post announcements and manage the school calendar
- Approve students once they self-register

Students self-register from the Login screen ("New student? Register here"), choosing
their class — they can log in only after a Teacher or Principal approves them.

## 📁 Project structure

```
MySchool/
├── app/
│   ├── build.gradle.kts              # App module Gradle config (Kotlin, Room, Material)
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/myschool/app/
│       │   ├── data/
│       │   │   ├── entity/           # Room entities (User, SchoolClass, Attendance, etc.)
│       │   │   ├── dao/               # Room DAOs (database queries)
│       │   │   ├── AppDatabase.kt     # Room database + seeds default Principal
│       │   │   └── Converters.kt      # Room type converters for enums
│       │   ├── ui/
│       │   │   ├── adapter/           # RecyclerView adapters
│       │   │   └── *Activity.kt       # All screens (login, dashboards, class detail, etc.)
│       │   └── util/
│       │       ├── SessionManager.kt  # Simple logged-in-user session (SharedPreferences)
│       │       └── IdGenerator.kt     # Generates unique IDs (STU-…, TCH-…, CLS-…)
│       └── res/
│           ├── layout/                # All XML screens
│           ├── values/                # colors.xml, strings.xml, themes.xml
│           ├── drawable/              # Shapes/icons
│           └── mipmap-anydpi-v26/     # Adaptive app icon
├── build.gradle.kts                   # Root Gradle config
├── settings.gradle.kts
└── gradle.properties
```

## 🛠 How to open & build the APK

You said you'll handle this part, but here's the quick path:

1. **Install Android Studio** (Hedgehog / 2023.1 or newer recommended) — https://developer.android.com/studio
2. **Open the project**: `File → Open` → select the extracted `MySchool` folder.
3. Android Studio will offer to generate the Gradle wrapper automatically on first sync
   (this project ships without the binary `gradle-wrapper.jar`, only the wrapper
   properties, to keep the download small — Android Studio fetches it for you, or you
   can run `gradle wrapper` yourself if you have Gradle installed locally).
4. Let Gradle Sync finish (downloads dependencies — needs internet the first time).
5. Build the APK:
   - Menu: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
   - Or from a terminal in the project folder: `./gradlew assembleDebug`
   - The APK will appear at: `app/build/outputs/apk/debug/app-debug.apk`
6. Install it on your phone (enable "Install from unknown sources" if needed) or drag it onto an emulator.

### Minimum requirements
- `minSdk 24` (Android 7.0+) — `targetSdk 34`
- Kotlin 1.9.23, Android Gradle Plugin 8.3.2, JDK 17

## 💡 Notes & possible next steps
- All data is stored locally on-device via Room (SQLite) — nothing leaves the phone.
- Passwords are stored as plain text for simplicity in this offline demo app; for a
  production/store release you'd want to hash them and consider a real backend so
  data syncs across devices.
- Feel free to ask for additions like: push notifications for homework/announcements,
  editing/deleting existing records, exporting attendance to Excel/PDF, profile photos, etc.
