# Timer App - Kotlin Android

A simple countdown timer application built with Kotlin for Android.

## Features
- ⏱️ Set minutes and seconds
- ▶️ Start/Pause timer functionality
- 🔄 Reset timer anytime
- 🔔 Alarm notification when timer finishes
- 📱 Clean and simple UI

## Project Structure
```
TimerApp/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── kotlin/com/example/timerapp/
│   │   │   │   └── MainActivity.kt        (Main activity with timer logic)
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   │   └── activity_main.xml  (UI layout)
│   │   │   │   ├── values/
│   │   │   │   │   ├── colors.xml         (Color definitions)
│   │   │   │   │   ├── strings.xml        (String resources)
│   │   │   │   │   └── themes.xml         (Theme styles)
│   │   │   │   └── drawable/
│   │   │   │       ├── input_background.xml   (Input field styling)
│   │   │   │       └── button_background.xml  (Button styling)
│   │   │   └── AndroidManifest.xml        (App manifest)
│   │   └── proguard-rules.pro
│   └── build.gradle.kts
├── gradle/
│   └── libs.versions.toml
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Building the APK

### Prerequisites
- Android Studio (latest version)
- Android SDK 34
- Minimum SDK 24
- Java 8 or higher

### Steps to Build

1. **Extract the ZIP file** to your desired location

2. **Open in Android Studio**
   - Launch Android Studio
   - Click "Open" and select the `TimerApp` folder
   - Let Gradle sync

3. **Build the APK**
   - Go to `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - Wait for the build to complete
   - APK will be located at: `app/build/outputs/apk/debug/app-debug.apk`

4. **Release Build (Optional)**
   - For a release build, go to `Build` → `Build Bundle(s) / APK(s)` → `Build Bundle(s)`
   - Or use terminal:
     ```bash
     ./gradlew assembleRelease
     ```

### Installing on Device/Emulator

1. Connect an Android device via USB or use an emulator
2. Run: `adb install app/build/outputs/apk/debug/app-debug.apk`
3. Or use Android Studio's Run button

## Using the App

1. Enter minutes and seconds in the input fields
2. Tap "START" to begin the countdown
3. Tap "PAUSE" to pause the timer
4. Tap "RESET" to reset the timer to zero
5. When timer reaches zero, an alarm notification will play

## Tech Stack
- **Language**: Kotlin
- **Minimum SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)
- **Architecture**: MVP (Model-View-Presenter)
- **Gradle Build System**: Kotlin DSL

## Customization

### Change App Name
Edit `app/src/main/res/values/strings.xml`:
```xml
<string name="app_name">Your App Name</string>
```

### Change Colors
Edit `app/src/main/res/values/colors.xml` to customize primary and accent colors

### Change Timer Display Size
Edit `app/src/main/res/layout/activity_main.xml`:
```xml
<TextView
    android:textSize="72sp"
    ... />
```

## Troubleshooting

- **Gradle sync failed**: Ensure Android SDK 34 is installed in Android Studio
- **Build errors**: Check that minimum SDK is 24
- **App crashes**: Verify all resources are properly linked in manifest

## License
Open source - feel free to modify and distribute

## Support
For issues or improvements, create an issue or submit a pull request.
