package com.example.timerapp

import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.media.MediaPlayer
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var timerDisplay: TextView
    private lateinit var inputMinutes: EditText
    private lateinit var inputSeconds: EditText
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var resetButton: Button

    private var countDownTimer: CountDownTimer? = null
    private var timeLeftInMillis: Long = 0
    private var isRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        timerDisplay = findViewById(R.id.timerDisplay)
        inputMinutes = findViewById(R.id.inputMinutes)
        inputSeconds = findViewById(R.id.inputSeconds)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        resetButton = findViewById(R.id.resetButton)

        // Set initial display
        timerDisplay.text = "00:00"

        // Start button click listener
        startButton.setOnClickListener {
            if (!isRunning) {
                if (timeLeftInMillis == 0L) {
                    // Get values from input fields
                    val minutes = inputMinutes.text.toString().toLongOrNull() ?: 0
                    val seconds = inputSeconds.text.toString().toLongOrNull() ?: 0
                    timeLeftInMillis = (minutes * 60 + seconds) * 1000

                    if (timeLeftInMillis <= 0) {
                        Toast.makeText(this, "Please enter a valid time", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                }
                startTimer()
            }
        }

        // Pause button click listener
        pauseButton.setOnClickListener {
            if (isRunning) {
                pauseTimer()
            }
        }

        // Reset button click listener
        resetButton.setOnClickListener {
            resetTimer()
        }
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateTimerDisplay()
            }

            override fun onFinish() {
                isRunning = false
                timerDisplay.text = "00:00"
                playAlarm()
                Toast.makeText(this@MainActivity, "Timer finished!", Toast.LENGTH_SHORT).show()
                timeLeftInMillis = 0
            }
        }.start()

        isRunning = true
        inputMinutes.isEnabled = false
        inputSeconds.isEnabled = false
        startButton.isEnabled = false
        pauseButton.isEnabled = true
    }

    private fun pauseTimer() {
        countDownTimer?.cancel()
        isRunning = false
        startButton.isEnabled = true
        pauseButton.isEnabled = false
    }

    private fun resetTimer() {
        countDownTimer?.cancel()
        isRunning = false
        timeLeftInMillis = 0
        timerDisplay.text = "00:00"
        inputMinutes.text.clear()
        inputSeconds.text.clear()
        inputMinutes.isEnabled = true
        inputSeconds.isEnabled = true
        startButton.isEnabled = true
        pauseButton.isEnabled = false
    }

    private fun updateTimerDisplay() {
        val minutes = timeLeftInMillis / 1000 / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        timerDisplay.text = String.format("%02d:%02d", minutes, seconds)
    }

    private fun playAlarm() {
        try {
            val alarm = MediaPlayer.create(this, android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM))
            alarm?.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}
