# Cycling Runner

A minimalist, black-and-white endless cycling runner for Android, built in
Kotlin with Jetpack Compose. One tap to start, one tap to jump, ride as far
as you can before a crash ends the run.

This README documents the complete, 10-session implementation and its
**actual, honestly-reported verification status** — see
[Verification Status](#verification-status) before assuming anything here
has been build- or runtime-tested.

---

## Game overview

- **Controls:** one tap. Tap to start, tap to jump (only while grounded —
  no double jump), tap to restart after a crash.
- **Core loop:** ride → jump over or avoid hazards → distance increases →
  difficulty increases → eventually you crash → Game Over shows your final
  distance and best distance → tap to restart instantly.
- **Visual identity:** the world is black & white, cycling automatically
  between Day and Night every 1000m of distance, with smooth transitions —
  never a manual toggle. As distance increases, selected obstacles
  gradually gain small, restrained color accents (rocks, barriers,
  vegetation, bridge details, vehicles) while the cyclist, bicycle, road
  line, and HUD stay monochrome throughout, by design.
- **Audio/haptics:** short, original, synthesized feedback tones (no
  copied or licensed audio) for jump/landing/crash/new-best, with optional
  haptic feedback. Both are togglable and persist.

---

## Implemented features (Sessions 1–9)

| Session | Feature area |
|---|---|
| 1 | Project foundation, core game loop, READY/RUNNING/PAUSED states, basic riding screen |
| 2 | Cyclist/wheel/pedal animation, shared world-speed model, road scrolling, parallax |
| 3 | One-tap bunny-hop jump physics, gravity, landing, no double jump |
| 4 | First obstacle set (rock, large rock, pothole, barrier, branch), procedural spawning, collision |
| 5 | Progressive difficulty, advanced obstacles (crate, bush, vehicles, moving dog), ramps, bridges, pattern-safety spacing |
| 6 | Collision → crash → GAME_OVER, final distance capture, Best Distance persistence, New Best detection/celebration, instant restart |
| 7 | Automatic Day/Night visual cycle with smooth transitions, centralized world palette, moon/stars |
| 8 | Selective, distance-gated, Day/Night-aware obstacle color accents (cyclist/road/HUD remain monochrome) |
| 9 | Synthesized jump/landing/crash/new-best sounds, optional haptics, persistent Sound/Haptics settings, accessibility labels |

All of the above are implemented in source. See
[Verification Status](#verification-status) for what has and hasn't been
confirmed to actually build and run.

---

## Architecture

Single-Activity Jetpack Compose app. The codebase is deliberately split
into a **pure, Android-free simulation layer** and an **Android-aware
rendering/integration layer**, so the former is unit-testable on a plain
JVM without any emulator or Android framework stub:

```
app/src/main/java/com/cyclingrunner/game/
├── MainActivity.kt           — single Activity host, immersive chrome
├── game/                     — PURE simulation + domain logic (no Android/Compose imports
│                                except Context for the two small DataStore-backed stores)
│   ├── GameEngine.kt          — the one authoritative per-frame update function
│   ├── GameViewModel.kt       — owns the loop, StateFlow<GameUiState>, SharedFlow<GameEvent>
│   ├── GameUiState.kt         — the single immutable state snapshot
│   ├── CyclistState / CyclistGeometry
│   ├── Obstacle / ObstacleType / ObstacleGeometry / ObstacleMotion / ObstacleSpawner
│   ├── CollisionSystem / TerrainSurface / PatternValidator
│   ├── DifficultyModel / DifficultyProfile / DifficultyTier
│   ├── DayNightModel / WorldPhase
│   ├── ColorProgressionModel / AccentCategory
│   ├── CrashState / RecordLogic / GameEvent
│   ├── FeedbackAction / FeedbackMapper
│   └── BestDistanceStore / GameSettingsStore   — the only two files here touching Android (Context, DataStore)
├── audio/                    — Android-aware feedback (SoundPool, Vibrator)
│   ├── ToneWavWriter.kt        — generates the 4 feedback sounds from scratch at runtime
│   ├── GameAudioManager.kt     — loads/plays them via SoundPool
│   ├── GameHapticController.kt — Vibrator wrapper with graceful fallback
│   └── GameFeedbackController.kt — observes GameEvents, drives audio+haptics; never a gameplay authority
└── ui/
    ├── theme/                 — WorldPalette (Day/Night colors), WorldAccents (Session 8 accent colors)
    ├── components/            — CyclistLayer, RoadLayer, BackgroundLayer, ObstacleLayer, HUD, overlays
    └── screens/GameScreen.kt  — composes everything, owns Compose-side animations (crash tilt, celebration)
```

**Key design decisions**, for anyone picking this project up:

- `GameEngine.advance(state, deltaSeconds, random)` is a pure function:
  `(GameUiState) -> GameUiState`. Everything — movement, physics,
  spawning, collision, difficulty, the crash transition — happens inside
  it or in a pure helper it calls. This is what makes most of the test
  suite runnable without Android at all.
- Day/Night phase and color-progression accents are **not stored as
  state** — they're pure functions of `distanceMeters` (and
  `finalDistanceMeters` once a run ends), recomputed each frame. This
  means pause/restart/backgrounding all produce the correct visual "for
  free," with nothing extra to desync or leak.
- All one-shot moments (jump started, landed, obstacle hit, new best) go
  through one `GameEvent` sealed interface and one `SharedFlow`, consumed
  by `GameFeedbackController` for audio/haptics — there's no second event
  bus.

---

## Requirements

- **Android Studio:** a recent stable release (Iguana/2023.2.1 or newer
  recommended, given AGP 8.5.2).
- **JDK:** 17 (set via Android Studio's embedded JDK, or `JAVA_HOME`).
- **Android Gradle Plugin:** 8.5.2 (declared in `build.gradle.kts`).
- **Kotlin:** 1.9.24.
- **Gradle:** 8.7 (declared in `gradle/wrapper/gradle-wrapper.properties`).
- **Compose compiler extension:** 1.5.14 (the officially documented pairing
  for Kotlin 1.9.24).
- **compileSdk / targetSdk:** 34. **minSdk:** 24 (Android 7.0+).

These versions were chosen for mutual compatibility based on their
publicly documented compatibility matrices, but — see below — have not
actually been exercised by a real Gradle build in the environment this
project was developed in.

---

## Building

> **The Gradle wrapper JAR is not included in this ZIP.** This project was
> developed in a sandboxed environment with no network access, so the
> wrapper jar could never be downloaded. **Opening the project in Android
> Studio will regenerate it automatically** the first time you sync. If
> you'd rather use the command line first, run `gradle wrapper` once with
> any locally-installed Gradle to generate `gradlew`/`gradlew.bat` and the
> jar, matching the version already specified in
> `gradle/wrapper/gradle-wrapper.properties`.

Once the wrapper is present:

```bash
# Clean build
./gradlew clean

# Build a debug APK
./gradlew :app:assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Run the unit test suite
./gradlew :app:testDebugUnitTest
# Report: app/build/reports/tests/testDebugUnitTest/index.html

# Build a release APK (unsigned — see Release signing below)
./gradlew :app:assembleRelease

# Build a release AAB (unsigned)
./gradlew :app:bundleRelease
```

Or simply open the project root folder in Android Studio and use
**Build → Make Project**, the **Run** button, and the **Gradle** tool
window's `app > Tasks > verification > testDebugUnitTest` task.

### Release signing

No signing configuration, keystore, or signing credentials are included
or referenced in this project — none were fabricated. To produce a signed
release build, generate your own keystore (**Build → Generate Signed Bundle
/ APK** in Android Studio, or `keytool`) and add a `signingConfigs` block
to `app/build.gradle.kts` referencing it. Keep the keystore and its
passwords out of version control.

---

## Running the unit tests

The test suite (`app/src/test/`) covers the pure simulation/domain layer
only — `game/` package classes and the Color-based `WorldPalette`/
`WorldAccents` resolvers, which are plain Kotlin/JVM and need no Android
framework stub or emulator:

```bash
./gradlew :app:testDebugUnitTest
```

15 test files, exercising: jump/gravity/landing physics, cyclist geometry,
obstacle movement/spawning/collision, difficulty progression, terrain
(ramp/bridge) surfaces and collision exemption, pattern-safety spacing,
crash/record logic and restart resets, Day/Night phase math, color
progression, the audio/haptic event mapper, and targeted regression
scenarios (restart after a midair crash, repeated crash/restart cycles,
pause while airborne, large frame-delta clamping).

**Not covered by this test suite:** `GameAudioManager`, `GameHapticController`,
`GameSettingsStore`, and `GameFeedbackController` all require real Android
framework classes (`SoundPool`, `Vibrator`, `DataStore`-with-`Context`)
that a plain JVM unit test can't exercise without adding Robolectric or
an instrumented test module — neither is currently set up in this
project. These would need either Robolectric-based unit tests or
`androidTest` instrumented tests on a real device/emulator as a follow-up.

---

## Offline behavior

The app makes no network requests anywhere in the codebase — gameplay,
audio, haptics, settings, and Best Distance all work fully offline. There
is no `INTERNET` permission in the manifest (confirmed absent
deliberately).

---

## Controls & settings

- **Tap anywhere:** start / jump / restart, depending on game state.
- **Pause button** (top-left during a run): pause/resume.
- **Pause overlay:** also shows `SOUND: ON/OFF` and `HAPTICS: ON/OFF`
  toggles — tap either to flip it. Both default to ON and persist across
  restarts and app relaunches.

---

## Known limitations

This is the most important section — read it before trusting any claim
elsewhere in this README or in prior session reports about this project.

- **No Gradle build has ever actually been executed** against this
  project, in any session. The sandboxed development environment had no
  network access and no pre-installed Android SDK, Gradle, or Kotlin
  compiler — confirmed by direct attempts (including a real, non-dry-run
  `apt-get install` against Ubuntu's own package archive, which returned
  `403 Forbidden`). All verification has been: (a) careful manual code
  review across every file, multiple passes, specifically re-auditing the
  highest-risk areas (the core engine, the ViewModel, and all of Session
  9's Android-specific audio/haptic/settings code) in this final session;
  (b) structural checks (brace/paren balance, import correctness, call-site
  signature matching) run programmatically against every source file; and
  (c) for the trickiest pure-logic pieces (jump physics, Day/Night
  transition math, collision geometry, the WAV audio format), independent
  numerical re-implementations in Python, cross-checked against the Kotlin
  logic by hand-tracing — which is **not** the same as compiling or running
  the actual Kotlin/Android code, and is reported as exactly that
  throughout this project's history.
- **No Kotlin/JUnit test in this project has ever actually executed.** The
  test files are real, complete, and (based on the same manual/numerical
  verification above) believed correct — but "believed correct" is not
  "passing," and is reported as such.
- **No emulator or physical device testing has occurred.** Nothing about
  touch responsiveness, frame pacing at 60/90/120Hz, screen-size/notch
  behavior, or actual visual appearance has been confirmed on a real
  screen.
- **Audio has never been heard; haptics have never been felt.** The WAV
  synthesis format was verified structurally (replicated in Python and
  round-tripped through Python's standard `wave` module to confirm valid
  headers, correct sample count, and no clipping) but not by listening to
  the actual output. Tone character, loudness, and haptic strength are
  chosen by reasoning, not by experiencing them.
- **No APK or AAB has been generated** — there is nothing to generate it
  with in this environment.
- **R8 minification is deliberately left disabled** in the release build
  type rather than enabled without being able to verify it. See the
  comment in `app/build.gradle.kts`.
- **The Gradle wrapper JAR is not included** (see Building, above).

### What to do with this

Everything above is a request for real verification, not a list of known
bugs. The recommended next step is exactly Session 10's own instructions:
open this project in a real Android Studio installation, let it sync
(regenerating the Gradle wrapper), run `./gradlew testDebugUnitTest` and
fix anything that doesn't compile or pass, then `./gradlew assembleDebug`
and play it on a device or emulator, listening for the sounds and feeling
the haptics, before trusting any claim of "it works" beyond what's
documented here.
