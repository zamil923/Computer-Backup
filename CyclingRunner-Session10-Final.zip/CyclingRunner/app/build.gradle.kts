plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cyclingrunner.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cyclingrunner.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        // "-rc1": all 10 sessions' features are implemented, but this has
        // never actually been Gradle-built, so it is a release candidate
        // pending real verification, not a claimed-stable 1.0.0. See the
        // README's "Known Limitations" section.
        versionName = "1.0.0-rc1"
    }

    buildTypes {
        release {
            // Left disabled deliberately: enabling R8 shrinking/obfuscation
            // is routine for a standard Compose app with no reflection-heavy
            // libraries, but it has never actually been exercised by a real
            // build in this environment (no Android SDK/Gradle access — see
            // README). Flipping this to true without being able to verify
            // the resulting APK still runs would risk a silent runtime
            // failure nobody catches before release. proguard-rules.pro
            // already has starter rules ready; see the README for exactly
            // how to enable and verify this.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.core:core-ktx:1.13.1")

    debugImplementation("androidx.compose.ui:ui-tooling")

    // JVM unit tests for the pure game-logic layer (GameEngine, ObstacleSpawner,
    // ObstacleMotion, CollisionSystem) — no Android framework or emulator needed.
    testImplementation("junit:junit:4.13.2")
}
