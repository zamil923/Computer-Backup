# Add project specific ProGuard rules here.
#
# Session 10: minification/shrinking is still disabled in app/build.gradle.kts
# (see the comment there for why — this hasn't been build-verified in this
# environment). These rules are prepared for when it is enabled, not
# currently exercised.
#
# This app has no reflection-based serialization of its own model classes
# (no Gson/Moshi/kotlinx.serialization on GameUiState, Obstacle, etc.), no
# dynamic class loading, and no JNI — so the realistic rule set is small.
# AndroidX Compose and DataStore ship their own consumer ProGuard rules
# bundled in their AARs, which R8 picks up automatically; nothing below
# duplicates those.

# Kotlin coroutines' internal use of reflection for some debugging features
# (safe to keep regardless of whether shrinking is on).
-dontwarn kotlinx.coroutines.debug.**

# If a future session adds data classes serialized via reflection (e.g. a
# save-state format), keep their fields here. None currently exist.
