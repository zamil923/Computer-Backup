package com.cyclingrunner.game.game

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Session 10: targeted regression tests for scenarios the spec singles
 * out as high-value but not yet explicitly covered — restart after a
 * midair crash, repeated crash/restart cycles, pause while airborne, and
 * abnormally large frame deltas (e.g. returning from a long background
 * period). These complement, rather than replace, the existing
 * session-by-session test files.
 */
class GameEngineRegressionTest {

    private val viewportWidth = 1000f
    private val viewportHeight = 500f

    @Test
    fun `restart after a midair crash returns the cyclist to a clean grounded state`() {
        val rearX = CyclistGeometry.rearWheelX(viewportWidth)
        val rock = Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = rearX - 10f, width = 120f, height = 40f)

        // Cyclist is mid-jump (not yet high enough to clear this rock) when it collides.
        val midairState = GameUiState(
            gameState = GameState.RUNNING,
            viewportWidthPx = viewportWidth,
            viewportHeightPx = viewportHeight,
            obstacleSpawnTimerSeconds = 999f,
            obstacles = listOf(rock),
            cyclist = CyclistState(isAirborne = true, verticalOffset = 10f, verticalVelocity = 400f)
        )

        val gameOverState = GameEngine.advance(midairState, 0.016f, Random(1))
        assertEquals(GameState.GAME_OVER, gameOverState.gameState)
        // The crash itself must not have teleported the cyclist to the ground first.
        assertTrue(gameOverState.cyclist.isAirborne || gameOverState.cyclist.verticalOffset > 0f)

        val freshState = GameEngine.freshRunState(gameOverState)
        assertEquals(GameState.RUNNING, freshState.gameState)
        assertFalse(freshState.cyclist.isAirborne)
        assertEquals(0f, freshState.cyclist.verticalOffset, 0.0001f)
        assertEquals(0f, freshState.cyclist.verticalVelocity, 0.0001f)
    }

    @Test
    fun `repeated crash-restart cycles keep best distance monotonically non-decreasing and never stale`() {
        val rearX = CyclistGeometry.rearWheelX(viewportWidth)
        var best = 0
        val runDistances = listOf(500, 300, 800, 800, 1200)

        for (distance in runDistances) {
            val rock = Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = rearX - 10f, width = 120f, height = 40f)
            val runningState = GameUiState(
                gameState = GameState.RUNNING,
                distanceMeters = distance,
                bestDistanceMeters = best,
                viewportWidthPx = viewportWidth,
                viewportHeightPx = viewportHeight,
                obstacleSpawnTimerSeconds = 999f,
                obstacles = listOf(rock)
            )

            val gameOverState = GameEngine.advance(runningState, 0.016f, Random(1))
            assertEquals(GameState.GAME_OVER, gameOverState.gameState)
            assertEquals(distance, gameOverState.finalDistanceMeters)
            assertEquals(RecordLogic.isNewBest(distance, best), gameOverState.isNewBest)

            // GameEngine never writes bestDistanceMeters itself (GameViewModel
            // does, via BestDistanceStore) — simulate that single write here,
            // exactly as onRunCompleted would.
            best = RecordLogic.updatedBest(distance, best)

            // Restart: next run must start from a clean slate with the
            // updated best carried over, nothing stale from this cycle.
            val freshState = GameEngine.freshRunState(gameOverState.copy(bestDistanceMeters = best))
            assertEquals(0, freshState.distanceMeters)
            assertEquals(best, freshState.bestDistanceMeters)
            assertEquals(null, freshState.finalDistanceMeters)
            assertFalse(freshState.isNewBest)
            assertTrue(freshState.obstacles.isEmpty())
        }

        assertEquals(1200, best)
    }

    @Test
    fun `pausing mid-air preserves the exact cyclist vertical state`() {
        val airborneCyclist = CyclistState(isAirborne = true, verticalOffset = 55f, verticalVelocity = 180f)
        val pausedState = GameUiState(
            gameState = GameState.PAUSED,
            viewportWidthPx = viewportWidth,
            viewportHeightPx = viewportHeight,
            cyclist = airborneCyclist
        )

        // Even a large elapsed delta must change nothing while PAUSED.
        val result = GameEngine.advance(pausedState, 2.0f, Random(1))

        assertEquals(pausedState, result)
        assertEquals(airborneCyclist, result.cyclist)
    }

    @Test
    fun `an abnormally large frame delta is clamped, not applied directly`() {
        val state = GameUiState(gameState = GameState.RUNNING)

        val oneClampedFrame = GameEngine.advance(state, GameConfig.MAX_FRAME_DELTA_SECONDS, Random(1))
        val oneHugeFrame = GameEngine.advance(state, 10.0f, Random(1))

        // A 10-second gap (e.g. after a long background period) must produce
        // exactly the same single-frame result as one ordinary clamped frame
        // — not a ~200x larger jump in distance/scroll.
        assertEquals(oneClampedFrame.distanceMeters, oneHugeFrame.distanceMeters)
        assertEquals(oneClampedFrame.roadScrollPx, oneHugeFrame.roadScrollPx, 0.0001f)
    }

    @Test
    fun `pause during a Day-Night transition freezes the visual phase along with distance`() {
        // Day/Night has no state of its own (Session 7) — it's a pure
        // function of distance, so "pausing during a transition" reduces to
        // "distance doesn't change while paused," which is already
        // guaranteed by advance()'s early return. This test documents that
        // connection explicitly rather than leaving it implicit.
        val transitionDistance = GameConfig.DAY_NIGHT_CYCLE_METERS // exactly mid-transition
        val pausedState = GameUiState(
            gameState = GameState.PAUSED,
            distanceMeters = transitionDistance,
            viewportWidthPx = viewportWidth,
            viewportHeightPx = viewportHeight
        )

        val phaseBefore = DayNightModel.transitionProgressForDistance(pausedState.distanceMeters)
        GameEngine.advance(pausedState, 5.0f, Random(1))
        val phaseAfter = DayNightModel.transitionProgressForDistance(pausedState.distanceMeters)

        assertEquals(phaseBefore, phaseAfter, 0.0001f)
    }
}
