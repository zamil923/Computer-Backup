package com.cyclingrunner.game.ui.theme

import androidx.compose.ui.graphics.luminance
import com.cyclingrunner.game.game.GameConfig
import com.cyclingrunner.game.game.ObstacleType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class WorldAccentsTest {

    @Test
    fun `never-accented types return null regardless of distance`() {
        val farDistance = GameConfig.COLOR_VEHICLE_UNLOCK_METERS + 1000
        assertNull(accentColorForObstacle(ObstacleType.POTHOLE, 1L, farDistance, DAY_PALETTE, 0f))
        assertNull(accentColorForObstacle(ObstacleType.RAMP, 1L, farDistance, DAY_PALETTE, 0f))
        assertNull(accentColorForObstacle(ObstacleType.MOVING_DOG, 1L, farDistance, DAY_PALETTE, 0f))
    }

    @Test
    fun `an accentable type returns null before its threshold`() {
        val accent = accentColorForObstacle(ObstacleType.SMALL_ROCK, 1L, 0, DAY_PALETTE, 0f)
        assertNull(accent)
    }

    @Test
    fun `an accentable type returns a color once unlocked`() {
        val fullyUnlocked = GameConfig.COLOR_STONE_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()
        val accent = accentColorForObstacle(ObstacleType.SMALL_ROCK, 1L, fullyUnlocked, DAY_PALETTE, 0f)
        assertNotEquals(null, accent)
    }

    @Test
    fun `resolved accent is clearly distinguishable from the monochrome foreground`() {
        val fullyUnlocked = GameConfig.COLOR_STONE_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()

        val dayAccent = accentColorForObstacle(ObstacleType.SMALL_ROCK, 1L, fullyUnlocked, DAY_PALETTE, nightAmount = 0f)!!
        assertTrue(abs(dayAccent.luminance() - DAY_PALETTE.foreground.luminance()) > 0.1f)

        val nightAccent = accentColorForObstacle(ObstacleType.SMALL_ROCK, 1L, fullyUnlocked, NIGHT_PALETTE, nightAmount = 1f)!!
        assertTrue(abs(nightAccent.luminance() - NIGHT_PALETTE.foreground.luminance()) > 0.1f)
    }

    @Test
    fun `day and night accents for the same category differ`() {
        val fullyUnlocked = GameConfig.COLOR_STONE_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()
        val dayAccent = accentColorForObstacle(ObstacleType.SMALL_ROCK, 1L, fullyUnlocked, DAY_PALETTE, nightAmount = 0f)!!
        val nightAccent = accentColorForObstacle(ObstacleType.SMALL_ROCK, 1L, fullyUnlocked, NIGHT_PALETTE, nightAmount = 1f)!!
        assertTrue(abs(dayAccent.luminance() - nightAccent.luminance()) > 0.01f)
    }

    @Test
    fun `the same obstacle type, id and distance always resolves to the same color`() {
        val fullyUnlocked = GameConfig.COLOR_VEGETATION_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()
        val a = accentColorForObstacle(ObstacleType.BUSH, 42L, fullyUnlocked, DAY_PALETTE, 0.3f)
        val b = accentColorForObstacle(ObstacleType.BUSH, 42L, fullyUnlocked, DAY_PALETTE, 0.3f)
        assertEquals(a, b)
    }

    @Test
    fun `vehicle color variation is deterministic by obstacle id`() {
        val fullyUnlocked = GameConfig.COLOR_VEHICLE_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()
        // Same id -> same color, called twice.
        val first = accentColorForObstacle(ObstacleType.PARKED_VEHICLE, 5L, fullyUnlocked, DAY_PALETTE, 0f)
        val second = accentColorForObstacle(ObstacleType.PARKED_VEHICLE, 5L, fullyUnlocked, DAY_PALETTE, 0f)
        assertEquals(first, second)

        // ids that differ by exactly 3 (the variant count) should also match,
        // since variant = id % 3.
        val idThreeApart = accentColorForObstacle(ObstacleType.PARKED_VEHICLE, 8L, fullyUnlocked, DAY_PALETTE, 0f)
        assertEquals(first, idThreeApart)
    }

    @Test
    fun `vehicle ids across a full cycle produce all three curated variants`() {
        val fullyUnlocked = GameConfig.COLOR_VEHICLE_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()
        val colors = (0L..2L).map {
            accentColorForObstacle(ObstacleType.SLOW_VEHICLE, it, fullyUnlocked, DAY_PALETTE, 0f)
        }
        // All three should be resolvable and pairwise distinct.
        assertEquals(3, colors.toSet().size)
    }
}
