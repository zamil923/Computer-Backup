package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ColorProgressionModelTest {

    @Test
    fun `0 meters is fully monochrome across every category`() {
        for (category in AccentCategory.entries) {
            assertEquals(0f, ColorProgressionModel.accentStrengthFor(category, 0), 0.0001f)
        }
    }

    @Test
    fun `early distance remains monochrome for every category`() {
        for (category in AccentCategory.entries) {
            assertEquals(0f, ColorProgressionModel.accentStrengthFor(category, 500), 0.0001f)
        }
    }

    @Test
    fun `stone (rock) unlocks at its intended threshold`() {
        assertFalse(ColorProgressionModel.isUnlocked(AccentCategory.STONE, GameConfig.COLOR_STONE_UNLOCK_METERS - 1))
        assertTrue(ColorProgressionModel.isUnlocked(AccentCategory.STONE, GameConfig.COLOR_STONE_UNLOCK_METERS))
    }

    @Test
    fun `rock obstacle types map to the stone category`() {
        assertEquals(AccentCategory.STONE, ColorProgressionModel.categoryFor(ObstacleType.SMALL_ROCK))
        assertEquals(AccentCategory.STONE, ColorProgressionModel.categoryFor(ObstacleType.LARGE_ROCK))
    }

    @Test
    fun `barrier remains monochrome before its threshold and unlocks at it`() {
        assertFalse(ColorProgressionModel.isUnlocked(AccentCategory.WARNING, GameConfig.COLOR_WARNING_UNLOCK_METERS - 1))
        assertTrue(ColorProgressionModel.isUnlocked(AccentCategory.WARNING, GameConfig.COLOR_WARNING_UNLOCK_METERS))
        assertEquals(AccentCategory.WARNING, ColorProgressionModel.categoryFor(ObstacleType.ROAD_BARRIER))
    }

    @Test
    fun `vegetation unlocks later than stone and warning`() {
        assertTrue(GameConfig.COLOR_VEGETATION_UNLOCK_METERS > GameConfig.COLOR_STONE_UNLOCK_METERS)
        assertTrue(GameConfig.COLOR_VEGETATION_UNLOCK_METERS > GameConfig.COLOR_WARNING_UNLOCK_METERS)
        assertFalse(ColorProgressionModel.isUnlocked(AccentCategory.VEGETATION, GameConfig.COLOR_VEGETATION_UNLOCK_METERS - 1))
        assertTrue(ColorProgressionModel.isUnlocked(AccentCategory.VEGETATION, GameConfig.COLOR_VEGETATION_UNLOCK_METERS))
        assertEquals(AccentCategory.VEGETATION, ColorProgressionModel.categoryFor(ObstacleType.BUSH))
    }

    @Test
    fun `structure (bridge) unlocks later than vegetation`() {
        assertTrue(GameConfig.COLOR_STRUCTURE_UNLOCK_METERS > GameConfig.COLOR_VEGETATION_UNLOCK_METERS)
        assertEquals(AccentCategory.STRUCTURE, ColorProgressionModel.categoryFor(ObstacleType.BRIDGE))
    }

    @Test
    fun `vehicles unlock at the latest stage`() {
        val allThresholds = listOf(
            GameConfig.COLOR_STONE_UNLOCK_METERS,
            GameConfig.COLOR_WARNING_UNLOCK_METERS,
            GameConfig.COLOR_VEGETATION_UNLOCK_METERS,
            GameConfig.COLOR_STRUCTURE_UNLOCK_METERS
        )
        assertTrue(allThresholds.all { it < GameConfig.COLOR_VEHICLE_UNLOCK_METERS })
        assertEquals(AccentCategory.VEHICLE, ColorProgressionModel.categoryFor(ObstacleType.PARKED_VEHICLE))
        assertEquals(AccentCategory.VEHICLE, ColorProgressionModel.categoryFor(ObstacleType.SLOW_VEHICLE))
    }

    @Test
    fun `a very large distance stays at valid full strength, never overshoots`() {
        assertEquals(1f, ColorProgressionModel.accentStrengthFor(AccentCategory.VEHICLE, 50_000_000), 0.0001f)
    }

    @Test
    fun `negative distance is handled safely and returns monochrome`() {
        for (category in AccentCategory.entries) {
            assertEquals(0f, ColorProgressionModel.accentStrengthFor(category, -500), 0.0001f)
        }
    }

    @Test
    fun `restart distance of 0 returns pure monochrome for every category`() {
        for (category in AccentCategory.entries) {
            assertFalse(ColorProgressionModel.isUnlocked(category, 0))
        }
    }

    @Test
    fun `accentStrength always stays within 0 and 1`() {
        var d = -1000
        while (d <= GameConfig.COLOR_VEHICLE_UNLOCK_METERS + 500) {
            for (category in AccentCategory.entries) {
                val strength = ColorProgressionModel.accentStrengthFor(category, d)
                assertTrue(strength in 0f..1f)
            }
            d += 37 // irregular step
        }
    }

    @Test
    fun `strength is exactly 0 right at the threshold, before the fade begins`() {
        assertEquals(0f, ColorProgressionModel.accentStrengthFor(AccentCategory.STONE, GameConfig.COLOR_STONE_UNLOCK_METERS), 0.0001f)
    }

    @Test
    fun `strength reaches exactly 1 once the transition range has fully elapsed`() {
        val fullyFaded = GameConfig.COLOR_STONE_UNLOCK_METERS + GameConfig.COLOR_ACCENT_TRANSITION_METERS.toInt()
        assertEquals(1f, ColorProgressionModel.accentStrengthFor(AccentCategory.STONE, fullyFaded), 0.0001f)
    }

    @Test
    fun `mid-transition produces a strictly intermediate strength`() {
        val halfway = GameConfig.COLOR_STONE_UNLOCK_METERS + (GameConfig.COLOR_ACCENT_TRANSITION_METERS / 2).toInt()
        val strength = ColorProgressionModel.accentStrengthFor(AccentCategory.STONE, halfway)
        assertTrue(strength > 0f && strength < 1f)
    }

    @Test
    fun `the same distance always produces the same strength (deterministic)`() {
        val a = ColorProgressionModel.accentStrengthFor(AccentCategory.VEGETATION, 3200)
        val b = ColorProgressionModel.accentStrengthFor(AccentCategory.VEGETATION, 3200)
        assertEquals(a, b, 0.0001f)
    }

    @Test
    fun `pothole, ramp and moving dog are never accented`() {
        assertNull(ColorProgressionModel.categoryFor(ObstacleType.POTHOLE))
        assertNull(ColorProgressionModel.categoryFor(ObstacleType.RAMP))
        assertNull(ColorProgressionModel.categoryFor(ObstacleType.MOVING_DOG))
    }

    @Test
    fun `fallen branch and crate map to the wood category`() {
        assertEquals(AccentCategory.WOOD, ColorProgressionModel.categoryFor(ObstacleType.FALLEN_BRANCH))
        assertEquals(AccentCategory.WOOD, ColorProgressionModel.categoryFor(ObstacleType.CRATE))
    }

    @Test
    fun `color progression never affects difficulty or world speed`() {
        val distance = GameConfig.COLOR_VEGETATION_UNLOCK_METERS + 40
        val speedBefore = DifficultyModel.worldSpeedFor(distance)
        val profileBefore = DifficultyModel.profileFor(distance)

        // Exercise every color-progression function at this distance.
        for (category in AccentCategory.entries) {
            ColorProgressionModel.accentStrengthFor(category, distance)
            ColorProgressionModel.isUnlocked(category, distance)
        }
        ObstacleType.entries.forEach { ColorProgressionModel.categoryFor(it) }

        val speedAfter = DifficultyModel.worldSpeedFor(distance)
        val profileAfter = DifficultyModel.profileFor(distance)

        assertEquals(speedBefore, speedAfter, 0.0001f)
        assertEquals(profileBefore, profileAfter)
    }

    @Test
    fun `color progression never affects collision geometry`() {
        val cyclistBounds = CyclistGeometry.Bounds(left = 100f, top = 400f, right = 220f, bottom = 800f)
        val obstacle = Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = 150f, width = 60f, height = 40f)

        val hitBefore = CollisionSystem.checkCollision(cyclistBounds, 0f, 800f, 30f, obstacle)

        // Exercise color progression at a distance where this obstacle's
        // category would be fully accented.
        ColorProgressionModel.accentStrengthFor(AccentCategory.STONE, GameConfig.COLOR_VEHICLE_UNLOCK_METERS)

        val hitAfter = CollisionSystem.checkCollision(cyclistBounds, 0f, 800f, 30f, obstacle)
        assertEquals(hitBefore, hitAfter)
    }
}
