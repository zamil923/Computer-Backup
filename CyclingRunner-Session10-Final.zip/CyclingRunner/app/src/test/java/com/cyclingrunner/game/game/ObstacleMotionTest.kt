package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObstacleMotionTest {

    @Test
    fun `obstacle moves left by worldSpeed times deltaTime`() {
        val obstacle = Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = 500f, width = 40f, height = 30f)
        val result = ObstacleMotion.advance(listOf(obstacle), worldSpeed = 200f, dt = 0.5f)
        assertEquals(400f, result.single().x, 0.0001f) // 500 - 200*0.5
    }

    @Test
    fun `obstacle is removed once fully past the left edge`() {
        val obstacle = Obstacle(id = 2, type = ObstacleType.SMALL_ROCK, x = 10f, width = 40f, height = 30f)
        // x -> 10 - 120*0.5 = -50; right edge -50+40 = -10 < 0 -> removed.
        val result = ObstacleMotion.advance(listOf(obstacle), worldSpeed = 120f, dt = 0.5f)
        assertTrue(result.isEmpty())
    }

    @Test
    fun `obstacle is kept while any part of it is still visible`() {
        val obstacle = Obstacle(id = 3, type = ObstacleType.SMALL_ROCK, x = 10f, width = 40f, height = 30f)
        // x -> 10 - 60*0.5 = -20; right edge -20+40 = 20 >= 0 -> kept.
        val result = ObstacleMotion.advance(listOf(obstacle), worldSpeed = 60f, dt = 0.5f)
        assertEquals(1, result.size)
        assertEquals(-20f, result.single().x, 0.0001f)
    }

    @Test
    fun `active list does not grow across many frames of scrolled-off obstacles`() {
        var obstacles = listOf(
            Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = 50f, width = 30f, height = 20f),
            Obstacle(id = 2, type = ObstacleType.LARGE_ROCK, x = 200f, width = 30f, height = 20f)
        )
        // Enough frames at this speed/dt to push both well past the left edge.
        repeat(50) {
            obstacles = ObstacleMotion.advance(obstacles, worldSpeed = 220f, dt = 0.05f)
        }
        assertTrue(obstacles.isEmpty())
    }

    @Test
    fun `a moving hazard closes the gap more slowly than a stationary obstacle at the same speed`() {
        val stationary = Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = 500f, width = 40f, height = 30f)
        val movingHazard = Obstacle(
            id = 2,
            type = ObstacleType.SLOW_VEHICLE,
            x = 500f,
            width = 40f,
            height = 30f,
            relativeVelocityDpPerSec = GameConfig.SLOW_VEHICLE_RELATIVE_VELOCITY_DP_PER_SEC
        )
        val worldSpeed = 220f
        val dt = 1f

        val stationaryAfter = ObstacleMotion.advance(listOf(stationary), worldSpeed, dt).single()
        val movingAfter = ObstacleMotion.advance(listOf(movingHazard), worldSpeed, dt).single()

        // screenSpeed = worldSpeed - relativeVelocity, so the moving hazard
        // travels less distance leftward than the stationary obstacle.
        assertEquals(500f - worldSpeed * dt, stationaryAfter.x, 0.0001f)
        assertEquals(500f - (worldSpeed - movingHazard.relativeVelocityDpPerSec) * dt, movingAfter.x, 0.0001f)
        assertTrue(movingAfter.x > stationaryAfter.x)
    }
}
