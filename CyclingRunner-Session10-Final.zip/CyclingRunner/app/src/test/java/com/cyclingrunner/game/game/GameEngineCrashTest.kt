package com.cyclingrunner.game.game

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Exercises the Session 6 collision-to-GAME_OVER transition end-to-end
 * through GameEngine.advance, and the pure restart reset in
 * [GameEngine.freshRunState].
 */
class GameEngineCrashTest {

    private val viewportWidth = 1000f
    private val viewportHeight = 500f

    private fun runningStateWithObstacleUnderCyclist(
        type: ObstacleType,
        bestDistanceMeters: Int = 0,
        distanceMeters: Int = 0
    ): GameUiState {
        val rearX = CyclistGeometry.rearWheelX(viewportWidth)
        val obstacle = Obstacle(id = 1, type = type, x = rearX - 10f, width = 120f, height = 40f)
        return GameUiState(
            gameState = GameState.RUNNING,
            distanceMeters = distanceMeters,
            bestDistanceMeters = bestDistanceMeters,
            viewportWidthPx = viewportWidth,
            viewportHeightPx = viewportHeight,
            obstacleSpawnTimerSeconds = 999f, // suppress any new spawn this frame
            obstacles = listOf(obstacle)
        )
    }

    @Test
    fun `small rock collision ends the run`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.SMALL_ROCK)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(GameState.GAME_OVER, result.gameState)
    }

    @Test
    fun `large rock collision ends the run`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.LARGE_ROCK)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(GameState.GAME_OVER, result.gameState)
    }

    @Test
    fun `barrier collision ends the run`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.ROAD_BARRIER)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(GameState.GAME_OVER, result.gameState)
    }

    @Test
    fun `moving vehicle collision ends the run`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.SLOW_VEHICLE)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(GameState.GAME_OVER, result.gameState)
    }

    @Test
    fun `moving dog collision ends the run`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.MOVING_DOG)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(GameState.GAME_OVER, result.gameState)
    }

    @Test
    fun `terrain never ends the run, even directly under the cyclist`() {
        for (type in listOf(ObstacleType.RAMP, ObstacleType.BRIDGE)) {
            val state = runningStateWithObstacleUnderCyclist(type)
            val result = GameEngine.advance(state, 0.016f, Random(1))
            assertEquals(GameState.RUNNING, result.gameState)
        }
    }

    @Test
    fun `final distance is captured exactly once and matches distance at the moment of impact`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.SMALL_ROCK, distanceMeters = 1842)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertNotNull(result.finalDistanceMeters)
        assertEquals(result.distanceMeters, result.finalDistanceMeters)
    }

    @Test
    fun `distance does not change on any further advance call after game over`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.SMALL_ROCK)
        val gameOverState = GameEngine.advance(state, 0.016f, Random(1))
        val frozenDistance = gameOverState.finalDistanceMeters

        // Even a large subsequent delta must not move anything, since
        // advance() no-ops entirely once gameState != RUNNING.
        val stillFrozen = GameEngine.advance(gameOverState, 5.0f, Random(1))

        assertEquals(gameOverState, stillFrozen)
        assertEquals(frozenDistance, stillFrozen.finalDistanceMeters)
    }

    @Test
    fun `crash state is set with the correct obstacle type`() {
        val state = runningStateWithObstacleUnderCyclist(ObstacleType.FALLEN_BRANCH)
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(ObstacleType.FALLEN_BRANCH, result.crashState?.obstacleType)
    }

    @Test
    fun `isNewBest is true when the final distance exceeds the previous best`() {
        val state = runningStateWithObstacleUnderCyclist(
            ObstacleType.SMALL_ROCK,
            bestDistanceMeters = 100,
            distanceMeters = 100
        )
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertTrue(result.isNewBest)
    }

    @Test
    fun `isNewBest is false when the final distance does not exceed the previous best`() {
        val state = runningStateWithObstacleUnderCyclist(
            ObstacleType.SMALL_ROCK,
            bestDistanceMeters = 999999,
            distanceMeters = 0
        )
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertFalse(result.isNewBest)
    }

    @Test
    fun `bestDistanceMeters itself is left untouched by GameEngine (persistence is GameViewModel's job)`() {
        val state = runningStateWithObstacleUnderCyclist(
            ObstacleType.SMALL_ROCK,
            bestDistanceMeters = 50,
            distanceMeters = 50
        )
        val result = GameEngine.advance(state, 0.016f, Random(1))
        assertEquals(50, result.bestDistanceMeters)
        assertTrue(result.isNewBest) // the comparison still correctly says it's an improvement
    }

    @Test
    fun `freshRunState preserves best distance and viewport, resets everything else`() {
        val finished = GameUiState(
            gameState = GameState.GAME_OVER,
            distanceMeters = 4200,
            bestDistanceMeters = 4200,
            finalDistanceMeters = 4200,
            isNewBest = true,
            crashState = CrashState(ObstacleType.LARGE_ROCK),
            obstacles = listOf(Obstacle(id = 7, type = ObstacleType.CRATE, x = 10f, width = 10f, height = 10f)),
            obstacleSpawnTimerSeconds = 0.2f,
            nextObstacleId = 9L,
            lastSpawnedObstacleType = ObstacleType.CRATE,
            cyclist = CyclistState(isAirborne = true, verticalOffset = 40f, verticalVelocity = 100f),
            worldSpeedDpPerSec = 300f,
            viewportWidthPx = 1234f,
            viewportHeightPx = 567f
        )

        val fresh = GameEngine.freshRunState(finished)

        assertEquals(GameState.RUNNING, fresh.gameState)
        assertEquals(4200, fresh.bestDistanceMeters)
        assertEquals(1234f, fresh.viewportWidthPx, 0.0001f)
        assertEquals(567f, fresh.viewportHeightPx, 0.0001f)

        assertEquals(0, fresh.distanceMeters)
        assertNull(fresh.finalDistanceMeters)
        assertFalse(fresh.isNewBest)
        assertNull(fresh.crashState)
        assertTrue(fresh.obstacles.isEmpty())
        assertEquals(GameConfig.OBSTACLE_INITIAL_GRACE_SECONDS, fresh.obstacleSpawnTimerSeconds, 0.0001f)
        assertEquals(0L, fresh.nextObstacleId)
        assertNull(fresh.lastSpawnedObstacleType)
        assertFalse(fresh.cyclist.isAirborne)
        assertEquals(0f, fresh.cyclist.verticalOffset, 0.0001f)
        assertEquals(0f, fresh.cyclist.verticalVelocity, 0.0001f)
        assertEquals(GameConfig.BASE_SCROLL_SPEED_DP_PER_SEC, fresh.worldSpeedDpPerSec, 0.0001f)
    }
}
