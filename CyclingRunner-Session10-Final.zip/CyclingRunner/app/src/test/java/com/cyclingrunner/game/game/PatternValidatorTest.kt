package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PatternValidatorTest {

    @Test
    fun `the very first obstacle only needs the absolute safety floor`() {
        assertTrue(
            PatternValidator.isGapSafe(
                previousType = null,
                nextType = ObstacleType.SMALL_ROCK,
                gapSeconds = GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS
            )
        )
        assertFalse(
            PatternValidator.isGapSafe(
                previousType = null,
                nextType = ObstacleType.SMALL_ROCK,
                gapSeconds = GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS - 0.1f
            )
        )
    }

    @Test
    fun `two ordinary static obstacles need only the base floor, no bonus`() {
        val required = PatternValidator.requiredRecoverySeconds(ObstacleType.SMALL_ROCK, ObstacleType.LARGE_ROCK)
        assertEquals(GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS, required, 0.0001f)
    }

    @Test
    fun `a recovery bonus is required after a moving hazard`() {
        val required = PatternValidator.requiredRecoverySeconds(ObstacleType.SLOW_VEHICLE, ObstacleType.SMALL_ROCK)
        assertEquals(
            GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS + GameConfig.RECOVERY_BONUS_SECONDS,
            required,
            0.0001f
        )
    }

    @Test
    fun `a recovery bonus is required after terrain`() {
        val required = PatternValidator.requiredRecoverySeconds(ObstacleType.BRIDGE, ObstacleType.SMALL_ROCK)
        assertEquals(
            GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS + GameConfig.RECOVERY_BONUS_SECONDS,
            required,
            0.0001f
        )
    }

    @Test
    fun `a recovery bonus is required when the next obstacle is itself moving`() {
        val required = PatternValidator.requiredRecoverySeconds(ObstacleType.SMALL_ROCK, ObstacleType.MOVING_DOG)
        assertEquals(
            GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS + GameConfig.RECOVERY_BONUS_SECONDS,
            required,
            0.0001f
        )
    }

    @Test
    fun `a gap exactly at the required minimum is accepted, one below is rejected`() {
        val required = PatternValidator.requiredRecoverySeconds(ObstacleType.SLOW_VEHICLE, ObstacleType.CRATE)
        assertTrue(PatternValidator.isGapSafe(ObstacleType.SLOW_VEHICLE, ObstacleType.CRATE, required))
        assertFalse(PatternValidator.isGapSafe(ObstacleType.SLOW_VEHICLE, ObstacleType.CRATE, required - 0.01f))
    }
}
