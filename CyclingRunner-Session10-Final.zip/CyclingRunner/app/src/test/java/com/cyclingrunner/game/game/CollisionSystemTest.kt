package com.cyclingrunner.game.game

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Bounds intersection, jump clearance, pothole clearance and the
 * forgiving-hitbox inset — CollisionSystem is a pure function of its
 * inputs, so none of this needs Android/Compose to verify.
 */
class CollisionSystemTest {

    private val groundY = 800f
    private val potholeClearance = 30f

    private fun groundedCyclistBounds(): CyclistGeometry.Bounds =
        CyclistGeometry.Bounds(left = 100f, top = 400f, right = 220f, bottom = groundY)

    private fun airborneCyclistBounds(verticalOffset: Float): CyclistGeometry.Bounds =
        CyclistGeometry.Bounds(
            left = 100f,
            top = 400f - verticalOffset,
            right = 220f,
            bottom = groundY - verticalOffset
        )

    @Test
    fun `grounded cyclist collides with an overlapping rock`() {
        val rock = Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = 150f, width = 60f, height = 40f)
        val hit = CollisionSystem.checkCollision(
            cyclistBounds = groundedCyclistBounds(),
            cyclistVerticalOffset = 0f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = rock
        )
        assertTrue(hit)
    }

    @Test
    fun `jumping cyclist clears a rock once wheel bottom rises above its top`() {
        // Obstacle top = groundY - 40 = 760. Clearing requires wheel bottom
        // (groundY - verticalOffset) to rise above that, i.e. verticalOffset >= 40.
        val rock = Obstacle(id = 2, type = ObstacleType.LARGE_ROCK, x = 150f, width = 60f, height = 40f)

        val stillTooLow = CollisionSystem.checkCollision(
            cyclistBounds = airborneCyclistBounds(20f),
            cyclistVerticalOffset = 20f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = rock
        )
        val cleared = CollisionSystem.checkCollision(
            cyclistBounds = airborneCyclistBounds(50f),
            cyclistVerticalOffset = 50f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = rock
        )

        assertTrue(stillTooLow)
        assertFalse(cleared)
    }

    @Test
    fun `no collision when there is no horizontal overlap`() {
        val distantRock = Obstacle(id = 3, type = ObstacleType.SMALL_ROCK, x = 1000f, width = 60f, height = 40f)
        val hit = CollisionSystem.checkCollision(
            cyclistBounds = groundedCyclistBounds(),
            cyclistVerticalOffset = 0f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = distantRock
        )
        assertFalse(hit)
    }

    @Test
    fun `forgiving hitbox ignores the outer edge of a wide obstacle`() {
        // Visual spans x=150..250 (width 100); with a 0.8 width factor the
        // actual collision box is the central 80%, i.e. x=160..240.
        val wideObstacle = Obstacle(id = 4, type = ObstacleType.FALLEN_BRANCH, x = 150f, width = 100f, height = 20f)
        val cyclistJustClippingVisualEdge =
            CyclistGeometry.Bounds(left = 100f, top = 400f, right = 152f, bottom = groundY)

        val hit = CollisionSystem.checkCollision(
            cyclistBounds = cyclistJustClippingVisualEdge,
            cyclistVerticalOffset = 0f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = wideObstacle
        )
        assertFalse(hit)
    }

    @Test
    fun `grounded cyclist fails to clear a pothole`() {
        val pothole = Obstacle(id = 5, type = ObstacleType.POTHOLE, x = 150f, width = 60f, height = 10f)
        val hit = CollisionSystem.checkCollision(
            cyclistBounds = groundedCyclistBounds(),
            cyclistVerticalOffset = 0f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = pothole
        )
        assertTrue(hit)
    }

    @Test
    fun `jumping cyclist clears a pothole once above the clearance threshold`() {
        val pothole = Obstacle(id = 6, type = ObstacleType.POTHOLE, x = 150f, width = 60f, height = 10f)
        val hit = CollisionSystem.checkCollision(
            cyclistBounds = airborneCyclistBounds(potholeClearance + 5f),
            cyclistVerticalOffset = potholeClearance + 5f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = pothole
        )
        assertFalse(hit)
    }

    @Test
    fun `an obstacle already marked hit never collides again`() {
        val alreadyHit = Obstacle(
            id = 7,
            type = ObstacleType.SMALL_ROCK,
            x = 150f,
            width = 60f,
            height = 40f,
            hasBeenHit = true
        )
        val hit = CollisionSystem.checkCollision(
            cyclistBounds = groundedCyclistBounds(),
            cyclistVerticalOffset = 0f,
            groundY = groundY,
            potholeClearance = potholeClearance,
            obstacle = alreadyHit
        )
        assertFalse(hit)
    }

    @Test
    fun `ramp and bridge terrain never register as a hazard hit, even directly under the cyclist`() {
        val ramp = Obstacle(id = 8, type = ObstacleType.RAMP, x = 150f, width = 60f, height = 200f)
        val bridge = Obstacle(id = 9, type = ObstacleType.BRIDGE, x = 150f, width = 60f, height = 200f)
        for (terrain in listOf(ramp, bridge)) {
            val hit = CollisionSystem.checkCollision(
                cyclistBounds = groundedCyclistBounds(),
                cyclistVerticalOffset = 0f,
                groundY = groundY,
                potholeClearance = potholeClearance,
                obstacle = terrain
            )
            assertFalse(hit)
        }
    }
}
