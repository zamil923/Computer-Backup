package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RecordLogicTest {

    @Test
    fun `lower final distance does not replace best`() {
        assertFalse(RecordLogic.isNewBest(finalDistanceMeters = 100, previousBestMeters = 500))
        assertEquals(500, RecordLogic.updatedBest(finalDistanceMeters = 100, previousBestMeters = 500))
    }

    @Test
    fun `equal final distance does not replace best`() {
        assertFalse(RecordLogic.isNewBest(finalDistanceMeters = 500, previousBestMeters = 500))
        assertEquals(500, RecordLogic.updatedBest(finalDistanceMeters = 500, previousBestMeters = 500))
    }

    @Test
    fun `higher final distance becomes the new best`() {
        assertTrue(RecordLogic.isNewBest(finalDistanceMeters = 600, previousBestMeters = 500))
        assertEquals(600, RecordLogic.updatedBest(finalDistanceMeters = 600, previousBestMeters = 500))
    }

    @Test
    fun `first completed run becomes the best when previous best is 0`() {
        assertTrue(RecordLogic.isNewBest(finalDistanceMeters = 42, previousBestMeters = 0))
        assertEquals(42, RecordLogic.updatedBest(finalDistanceMeters = 42, previousBestMeters = 0))
    }

    @Test
    fun `a distance of exactly 0 is not a new best over a previous best of 0`() {
        // Guards against showing a false NEW BEST before any real distance was covered.
        assertFalse(RecordLogic.isNewBest(finalDistanceMeters = 0, previousBestMeters = 0))
    }
}
