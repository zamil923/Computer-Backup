package com.cyclingrunner.game.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.cyclingrunner.game.game.GameConfig
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Colors are compared with a small tolerance rather than Color.equals()
 * throughout: androidx.compose.ui.graphics.lerp may perform an internal
 * color-space conversion, which could introduce tiny floating-point
 * rounding even exactly at fraction 0 or 1. What actually matters for
 * this game is that the endpoints are visually indistinguishable from the
 * named palettes and that mid-transition values sit between them — not
 * bit-for-bit identity.
 */
class WorldPaletteTest {

    private fun assertColorsClose(expected: Color, actual: Color, tolerance: Float = 0.02f) {
        assertTrue(abs(expected.red - actual.red) < tolerance)
        assertTrue(abs(expected.green - actual.green) < tolerance)
        assertTrue(abs(expected.blue - actual.blue) < tolerance)
    }

    @Test
    fun `day palette has strong foreground-background contrast`() {
        val contrast = abs(DAY_PALETTE.foreground.luminance() - DAY_PALETTE.background.luminance())
        assertTrue(contrast > 0.5f)
    }

    @Test
    fun `night palette has strong foreground-background contrast`() {
        val contrast = abs(NIGHT_PALETTE.foreground.luminance() - NIGHT_PALETTE.background.luminance())
        assertTrue(contrast > 0.5f)
    }

    @Test
    fun `day endpoint (distance 0) produces essentially the day palette`() {
        val palette = paletteForDistance(0)
        assertColorsClose(DAY_PALETTE.background, palette.background)
        assertColorsClose(DAY_PALETTE.foreground, palette.foreground)
        assertColorsClose(DAY_PALETTE.hud, palette.hud)
    }

    @Test
    fun `night endpoint (mid-night distance) produces essentially the night palette`() {
        val midNight = GameConfig.DAY_NIGHT_CYCLE_METERS + GameConfig.DAY_NIGHT_CYCLE_METERS / 2
        val palette = paletteForDistance(midNight)
        assertColorsClose(NIGHT_PALETTE.background, palette.background)
        assertColorsClose(NIGHT_PALETTE.foreground, palette.foreground)
        assertColorsClose(NIGHT_PALETTE.hud, palette.hud)
    }

    @Test
    fun `mid-transition produces a background luminance strictly between day and night`() {
        val boundary = GameConfig.DAY_NIGHT_CYCLE_METERS
        val palette = paletteForDistance(boundary)

        val dayLum = DAY_PALETTE.background.luminance()
        val nightLum = NIGHT_PALETTE.background.luminance()
        val midLum = palette.background.luminance()

        assertTrue(midLum in min(dayLum, nightLum)..max(dayLum, nightLum))
        // Genuinely mid-transition, not accidentally snapped to either endpoint.
        assertTrue(abs(midLum - dayLum) > 0.05f)
        assertTrue(abs(midLum - nightLum) > 0.05f)
    }
}
