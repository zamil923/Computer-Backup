package com.cyclingrunner.game.game

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObstacleSpawnerTest {

    private fun beginnerProfile() = DifficultyModel.profileFor(0)

    @Test
    fun `does not spawn while the timer has not elapsed`() {
        val result = ObstacleSpawner.update(
            obstacles = emptyList(),
            spawnTimerSeconds = 1.0f,
            nextId = 0L,
            dt = 0.1f,
            viewportWidthPx = 800f,
            viewportHeightPx = 400f,
            profile = beginnerProfile(),
            lastSpawnedType = null,
            random = Random(1)
        )
        assertTrue(result.obstacles.isEmpty())
        assertEquals(0.9f, result.spawnTimerSeconds, 0.0001f)
        assertEquals(0L, result.nextObstacleId)
    }

    @Test
    fun `spawns exactly one obstacle once the timer elapses`() {
        val profile = beginnerProfile()
        val result = ObstacleSpawner.update(
            obstacles = emptyList(),
            spawnTimerSeconds = 0.05f,
            nextId = 0L,
            dt = 0.1f,
            viewportWidthPx = 800f,
            viewportHeightPx = 400f,
            profile = profile,
            lastSpawnedType = null,
            random = Random(42)
        )
        assertEquals(1, result.obstacles.size)
        assertEquals(1L, result.nextObstacleId)
        assertTrue(
            result.spawnTimerSeconds >= profile.minSpawnIntervalSeconds &&
                result.spawnTimerSeconds <= profile.maxSpawnIntervalSeconds
        )
    }

    @Test
    fun `new obstacle spawns just off the right edge of the screen`() {
        val result = ObstacleSpawner.update(
            obstacles = emptyList(),
            spawnTimerSeconds = 0f,
            nextId = 5L,
            dt = 0.016f,
            viewportWidthPx = 1000f,
            viewportHeightPx = 500f,
            profile = beginnerProfile(),
            lastSpawnedType = null,
            random = Random(7)
        )
        val spawned = result.obstacles.single()
        assertEquals(5L, spawned.id)
        assertEquals(1000f + GameConfig.OBSTACLE_SPAWN_MARGIN_PX, spawned.x, 0.0001f)
        assertEquals(6L, result.nextObstacleId)
    }

    @Test
    fun `does not spawn when viewport size is not yet known`() {
        val result = ObstacleSpawner.update(
            obstacles = emptyList(),
            spawnTimerSeconds = 0f,
            nextId = 0L,
            dt = 0.016f,
            viewportWidthPx = 0f,
            viewportHeightPx = 0f,
            profile = beginnerProfile(),
            lastSpawnedType = null,
            random = Random(3)
        )
        assertTrue(result.obstacles.isEmpty())
    }

    @Test
    fun `the same seed produces the same obstacle sequence`() {
        val profile = beginnerProfile()
        val a = ObstacleSpawner.update(emptyList(), 0f, 0L, 0.016f, 800f, 400f, profile, null, Random(99))
        val b = ObstacleSpawner.update(emptyList(), 0f, 0L, 0.016f, 800f, 400f, profile, null, Random(99))
        assertEquals(a.obstacles.single().type, b.obstacles.single().type)
        assertEquals(a.spawnTimerSeconds, b.spawnTimerSeconds, 0.0001f)
    }

    @Test
    fun `only beginner-tier types spawn at distance 0`() {
        val profile = beginnerProfile()
        val random = Random(123)
        repeat(200) {
            val result = ObstacleSpawner.update(
                obstacles = emptyList(),
                spawnTimerSeconds = 0f,
                nextId = 0L,
                dt = 0.016f,
                viewportWidthPx = 1000f,
                viewportHeightPx = 500f,
                profile = profile,
                lastSpawnedType = null,
                random = random
            )
            val spawnedType = result.obstacles.single().type
            assertTrue(spawnedType in profile.allowedObstacleTypes)
            assertTrue(!spawnedType.isMoving) // moving hazards are unlocked only at ENDLESS
        }
    }

    @Test
    fun `moving hazards can appear once unlocked in the endless-tier profile`() {
        val profile = DifficultyModel.profileFor(GameConfig.DIFFICULTY_ENDLESS_START_METERS)
        val random = Random(55)
        var sawMoving = false
        repeat(500) {
            val result = ObstacleSpawner.update(
                obstacles = emptyList(), // only checking the type distribution, not list growth
                spawnTimerSeconds = 0f,
                nextId = 0L,
                dt = 0.016f,
                viewportWidthPx = 1000f,
                viewportHeightPx = 500f,
                profile = profile,
                lastSpawnedType = null,
                random = random
            )
            if (result.obstacles.single().type.isMoving) sawMoving = true
        }
        assertTrue(sawMoving)
    }

    @Test
    fun `spawn interval is never below the pattern-validated safe minimum`() {
        val profile = beginnerProfile()
        val random = Random(321)
        repeat(200) {
            val result = ObstacleSpawner.update(
                obstacles = emptyList(),
                spawnTimerSeconds = 0f,
                nextId = 0L,
                dt = 0.016f,
                viewportWidthPx = 1000f,
                viewportHeightPx = 500f,
                profile = profile,
                lastSpawnedType = ObstacleType.SLOW_VEHICLE, // worst case: previous was a moving hazard
                random = random
            )
            val requiredGap = PatternValidator.requiredRecoverySeconds(
                ObstacleType.SLOW_VEHICLE,
                result.obstacles.single().type
            )
            assertTrue(result.spawnTimerSeconds >= requiredGap)
        }
    }
}
