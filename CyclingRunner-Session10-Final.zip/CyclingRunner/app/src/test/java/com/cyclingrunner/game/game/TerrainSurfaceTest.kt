package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TerrainSurfaceTest {

    @Test
    fun `ramp elevation is 0 at the left edge and full height at the right edge`() {
        val ramp = Obstacle(id = 1, type = ObstacleType.RAMP, x = 100f, width = 100f, height = 40f)
        val atLeftEdge = TerrainSurface.evaluate(listOf(ramp), listOf(ramp), cyclistLeadingX = 100f, cyclistIsAirborne = false)
        val atRightEdge = TerrainSurface.evaluate(listOf(ramp), listOf(ramp), cyclistLeadingX = 200f, cyclistIsAirborne = false)
        assertEquals(0f, atLeftEdge.elevation, 0.001f)
        assertEquals(40f, atRightEdge.elevation, 0.001f)
    }

    @Test
    fun `ramp elevation rises monotonically while scrolling under a fixed point`() {
        var ramp = Obstacle(id = 1, type = ObstacleType.RAMP, x = 200f, width = 100f, height = 40f)
        val cyclistX = 150f
        var previousElevation = -1f
        var everOverlapped = false
        repeat(60) {
            val before = ramp
            ramp = ramp.copy(x = ramp.x - 100f * 0.05f) // worldSpeed=100, dt=0.05
            val result = TerrainSurface.evaluate(listOf(before), listOf(ramp), cyclistX, cyclistIsAirborne = false)
            if (result.elevation > 0f) {
                everOverlapped = true
                assertTrue(result.elevation >= previousElevation - 0.001f)
                previousElevation = result.elevation
            }
        }
        assertTrue(everOverlapped)
    }

    @Test
    fun `riding a ramp all the way off the end triggers a launch at the configured velocity`() {
        var ramp = Obstacle(id = 1, type = ObstacleType.RAMP, x = 200f, width = 100f, height = 40f)
        val cyclistX = 150f
        var launchVelocity: Float? = null
        repeat(80) {
            val before = ramp
            ramp = ramp.copy(x = ramp.x - 100f * 0.05f)
            val result = TerrainSurface.evaluate(listOf(before), listOf(ramp), cyclistX, cyclistIsAirborne = false)
            if (result.rampLaunchVelocity != null) {
                launchVelocity = result.rampLaunchVelocity
            }
        }
        assertEquals(GameConfig.RAMP_LAUNCH_VELOCITY_DP_PER_SEC, launchVelocity)
    }

    @Test
    fun `bridge elevation returns exactly to 0 at the exit, never snapping`() {
        val bridge = Obstacle(id = 2, type = ObstacleType.BRIDGE, x = 100f, width = 200f, height = 30f)
        // progress = 1.0 exactly at x = obstacle.x + width = 300
        val atExit = TerrainSurface.evaluate(listOf(bridge), listOf(bridge), cyclistLeadingX = 300f, cyclistIsAirborne = false)
        assertEquals(0f, atExit.elevation, 0.001f)
    }

    @Test
    fun `bridge elevation is flat across the middle deck`() {
        val bridge = Obstacle(id = 2, type = ObstacleType.BRIDGE, x = 100f, width = 200f, height = 30f)
        // progress = 0.5 (x = 200) sits within the flat deck window (0.25 to 0.75)
        val atMiddle = TerrainSurface.evaluate(listOf(bridge), listOf(bridge), cyclistLeadingX = 200f, cyclistIsAirborne = false)
        assertEquals(30f, atMiddle.elevation, 0.001f)
    }

    @Test
    fun `terrain has no effect while the cyclist is independently airborne`() {
        val ramp = Obstacle(id = 1, type = ObstacleType.RAMP, x = 100f, width = 100f, height = 40f)
        val result = TerrainSurface.evaluate(listOf(ramp), listOf(ramp), cyclistLeadingX = 200f, cyclistIsAirborne = true)
        assertEquals(0f, result.elevation, 0.001f)
        assertNull(result.rampLaunchVelocity)
    }

    @Test
    fun `hazard obstacles never contribute elevation`() {
        val rock = Obstacle(id = 3, type = ObstacleType.SMALL_ROCK, x = 100f, width = 50f, height = 40f)
        val result = TerrainSurface.evaluate(listOf(rock), listOf(rock), cyclistLeadingX = 120f, cyclistIsAirborne = false)
        assertEquals(0f, result.elevation, 0.001f)
        assertFalse(result.rampLaunchVelocity != null)
    }
}
