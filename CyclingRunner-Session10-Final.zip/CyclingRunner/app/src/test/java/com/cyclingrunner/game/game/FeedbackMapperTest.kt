package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Test

class FeedbackMapperTest {

    @Test
    fun `JumpStarted maps to JUMP feedback`() {
        assertEquals(FeedbackAction.JUMP, FeedbackMapper.map(GameEvent.JumpStarted))
    }

    @Test
    fun `Landed maps to LAND feedback`() {
        assertEquals(FeedbackAction.LAND, FeedbackMapper.map(GameEvent.Landed))
    }

    @Test
    fun `ObstacleHit maps to CRASH feedback regardless of which obstacle type hit`() {
        for (type in ObstacleType.entries) {
            assertEquals(FeedbackAction.CRASH, FeedbackMapper.map(GameEvent.ObstacleHit(type)))
        }
    }

    @Test
    fun `NewBest maps to NEW_BEST feedback`() {
        assertEquals(FeedbackAction.NEW_BEST, FeedbackMapper.map(GameEvent.NewBest))
    }

    @Test
    fun `mapping the same event repeatedly always produces the same action`() {
        val event = GameEvent.ObstacleHit(ObstacleType.LARGE_ROCK)
        val first = FeedbackMapper.map(event)
        val second = FeedbackMapper.map(event)
        assertEquals(first, second)
    }

    @Test
    fun `mapping never touches difficulty, speed, or collision state`() {
        // FeedbackMapper takes a GameEvent and returns a FeedbackAction —
        // it has no reference to DifficultyModel, GameEngine, or
        // CollisionSystem at all, so there is nothing here for it to
        // mutate. This test documents that guarantee the same way earlier
        // sessions did for their own visual-only additions.
        val distance = GameConfig.COLOR_VEHICLE_UNLOCK_METERS + 100
        val speedBefore = DifficultyModel.worldSpeedFor(distance)

        FeedbackMapper.map(GameEvent.JumpStarted)
        FeedbackMapper.map(GameEvent.Landed)
        FeedbackMapper.map(GameEvent.ObstacleHit(ObstacleType.SMALL_ROCK))
        FeedbackMapper.map(GameEvent.NewBest)

        val speedAfter = DifficultyModel.worldSpeedFor(distance)
        assertEquals(speedBefore, speedAfter, 0.0001f)
    }
}
