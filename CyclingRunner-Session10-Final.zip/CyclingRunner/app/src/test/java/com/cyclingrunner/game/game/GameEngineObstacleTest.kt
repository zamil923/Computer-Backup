package com.cyclingrunner.game.game

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Exercises GameEngine.advance end-to-end for the Session 4 obstacle
 * behaviors the spec calls out explicitly: the initial grace period,
 * freezing everything while not RUNNING (pause/backgrounding), and a
 * grounded cyclist actually colliding with a spawned obstacle.
 */
class GameEngineObstacleTest {

    private fun runningState(viewportWidth: Float = 1000f, viewportHeight: Float = 500f) = GameUiState(
        gameState = GameState.RUNNING,
        viewportWidthPx = viewportWidth,
        viewportHeightPx = viewportHeight
    )

    @Test
    fun `no obstacle spawns during the initial grace period`() {
        var state = runningState()
        // Advance well under the grace period in total.
        repeat(10) {
            state = GameEngine.advance(state, 0.05f, Random(1))
        }
        assertTrue(state.obstacles.isEmpty())
    }

    @Test
    fun `an obstacle eventually spawns once the grace period elapses`() {
        var state = runningState()
        val totalSeconds = GameConfig.OBSTACLE_INITIAL_GRACE_SECONDS + 0.5f
        var elapsed = 0f
        val step = 0.05f
        while (elapsed < totalSeconds) {
            state = GameEngine.advance(state, step, Random(1))
            elapsed += step
        }
        assertTrue(state.obstacles.isNotEmpty())
    }

    @Test
    fun `advance is a no-op while not RUNNING, freezing obstacles and the spawn timer`() {
        val paused = runningState().copy(
            gameState = GameState.PAUSED,
            obstacleSpawnTimerSeconds = 0.01f,
            obstacles = listOf(Obstacle(id = 1, type = ObstacleType.SMALL_ROCK, x = 300f, width = 30f, height = 20f))
        )
        val result = GameEngine.advance(paused, 1.0f, Random(1))
        assertEquals(paused, result)
    }

    @Test
    fun `grounded cyclist collides with a pre-placed obstacle directly under it`() {
        val viewportHeight = 500f
        val viewportWidth = 1000f
        val rearX = CyclistGeometry.rearWheelX(viewportWidth)

        // Place a rock spanning the cyclist's own footprint so the very
        // next advance() call must detect a collision.
        val rock = Obstacle(id = 42, type = ObstacleType.SMALL_ROCK, x = rearX - 10f, width = 120f, height = 40f)
        val state = runningState(viewportWidth, viewportHeight).copy(
            obstacleSpawnTimerSeconds = 999f, // suppress any new spawn this frame
            obstacles = listOf(rock)
        )

        val result = GameEngine.advance(state, 0.016f, Random(1))

        assertTrue(result.obstacles.single().hasBeenHit)
    }

    @Test
    fun `a cyclist already well into a jump clears an obstacle under it`() {
        val viewportHeight = 500f
        val viewportWidth = 1000f
        val rearX = CyclistGeometry.rearWheelX(viewportWidth)

        val rock = Obstacle(id = 43, type = ObstacleType.SMALL_ROCK, x = rearX - 10f, width = 120f, height = 40f)
        // Near the apex of a jump (60px up, momentarily near-zero vertical
        // velocity) — comfortably above the rock's 40px height, unlike the
        // instant right after takeoff, which is still too low to clear it.
        var state = runningState(viewportWidth, viewportHeight).copy(
            obstacleSpawnTimerSeconds = 999f,
            obstacles = listOf(rock),
            cyclist = CyclistState(isAirborne = true, verticalOffset = 60f, verticalVelocity = 0f)
        )
        state = GameEngine.advance(state, 0.016f, Random(1))

        assertFalse(state.obstacles.single().hasBeenHit)
    }
}
