package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DayNightModelTest {

    @Test
    fun `0 meters is Day`() {
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(0))
    }

    @Test
    fun `distance just before the first threshold is still Day`() {
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(GameConfig.DAY_NIGHT_CYCLE_METERS - 1))
    }

    @Test
    fun `the first interval is Night`() {
        assertEquals(WorldPhase.NIGHT, DayNightModel.phaseForDistance(GameConfig.DAY_NIGHT_CYCLE_METERS))
        assertEquals(WorldPhase.NIGHT, DayNightModel.phaseForDistance(GameConfig.DAY_NIGHT_CYCLE_METERS + 1))
    }

    @Test
    fun `the following interval returns to Day`() {
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(GameConfig.DAY_NIGHT_CYCLE_METERS * 2))
    }

    @Test
    fun `multiple later cycles keep alternating correctly`() {
        val cycle = GameConfig.DAY_NIGHT_CYCLE_METERS
        assertEquals(WorldPhase.NIGHT, DayNightModel.phaseForDistance(cycle * 3))
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(cycle * 4))
        assertEquals(WorldPhase.NIGHT, DayNightModel.phaseForDistance(cycle * 5))
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(cycle * 6))
    }

    @Test
    fun `a very large distance still produces a valid phase`() {
        val phase = DayNightModel.phaseForDistance(50_000_000)
        assertTrue(phase == WorldPhase.DAY || phase == WorldPhase.NIGHT)
    }

    @Test
    fun `negative distance is handled safely and treated as Day`() {
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(-500))
        assertEquals(0f, DayNightModel.transitionProgressForDistance(-500), 0.0001f)
    }

    @Test
    fun `restart distance of 0 always produces Day`() {
        assertEquals(WorldPhase.DAY, DayNightModel.phaseForDistance(0))
        assertEquals(0f, DayNightModel.transitionProgressForDistance(0), 0.0001f)
    }

    @Test
    fun `transition progress is exactly 0 at the very start, not mid-blend`() {
        // There is no "night before the game starts" to blend in from.
        assertEquals(0f, DayNightModel.transitionProgressForDistance(0), 0.0001f)
    }

    @Test
    fun `transition progress is 0 well inside a Day segment`() {
        assertEquals(0f, DayNightModel.transitionProgressForDistance(GameConfig.DAY_NIGHT_CYCLE_METERS / 2), 0.0001f)
    }

    @Test
    fun `transition progress is 1 well inside a Night segment`() {
        val midNight = GameConfig.DAY_NIGHT_CYCLE_METERS + GameConfig.DAY_NIGHT_CYCLE_METERS / 2
        assertEquals(1f, DayNightModel.transitionProgressForDistance(midNight), 0.0001f)
    }

    @Test
    fun `transition progress always stays clamped within 0 and 1`() {
        var d = 0
        while (d <= GameConfig.DAY_NIGHT_CYCLE_METERS * 6) {
            val progress = DayNightModel.transitionProgressForDistance(d)
            assertTrue(progress in 0f..1f)
            d += 7 // an irregular step so we sample more than just round numbers
        }
    }

    @Test
    fun `transition progress is continuous across every boundary in several cycles`() {
        val cycle = GameConfig.DAY_NIGHT_CYCLE_METERS
        for (boundaryIndex in 1..6) {
            val boundary = cycle * boundaryIndex
            val justBefore = DayNightModel.transitionProgressForDistance(boundary - 1)
            val at = DayNightModel.transitionProgressForDistance(boundary)
            val justAfter = DayNightModel.transitionProgressForDistance(boundary + 1)
            // No single-meter jump should ever exceed the transition window's
            // own per-meter rate (1 / DAY_NIGHT_TRANSITION_METERS) by more
            // than a small margin.
            val maxStep = 1f / GameConfig.DAY_NIGHT_TRANSITION_METERS + 0.01f
            assertTrue(Math.abs(at - justBefore) <= maxStep)
            assertTrue(Math.abs(justAfter - at) <= maxStep)
        }
    }

    @Test
    fun `phase calculation never touches difficulty, speed, or spawn spacing`() {
        // DayNightModel only reads GameConfig's DAY_NIGHT_* constants and
        // returns a value — it has no reference to DifficultyModel,
        // ObstacleSpawner, or GameEngine at all, so there is nothing for it
        // to mutate. This test documents that guarantee by exercising a
        // large distance range and confirming difficulty is unaffected by
        // anything here (computed independently, exactly as before).
        val distance = GameConfig.DAY_NIGHT_CYCLE_METERS * 3 + 40
        val speedBefore = DifficultyModel.worldSpeedFor(distance)
        DayNightModel.phaseForDistance(distance)
        DayNightModel.transitionProgressForDistance(distance)
        val speedAfter = DifficultyModel.worldSpeedFor(distance)
        assertEquals(speedBefore, speedAfter, 0.0001f)
    }

    @Test
    fun `the final phase for a completed run can be derived from final distance alone`() {
        val finalDistance = GameConfig.DAY_NIGHT_CYCLE_METERS + 250
        assertEquals(WorldPhase.NIGHT, DayNightModel.phaseForDistance(finalDistance))
    }
}
