package com.cyclingrunner.game.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DifficultyModelTest {

    @Test
    fun `speed at 0m equals the base scroll speed`() {
        assertEquals(GameConfig.BASE_SCROLL_SPEED_DP_PER_SEC, DifficultyModel.worldSpeedFor(0), 0.001f)
    }

    @Test
    fun `speed at the ramp distance equals the max speed`() {
        assertEquals(
            GameConfig.MAX_SCROLL_SPEED_DP_PER_SEC,
            DifficultyModel.worldSpeedFor(GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS.toInt()),
            0.001f
        )
    }

    @Test
    fun `speed never exceeds the max cap far beyond the ramp distance`() {
        val speed = DifficultyModel.worldSpeedFor(GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS.toInt() * 3)
        assertEquals(GameConfig.MAX_SCROLL_SPEED_DP_PER_SEC, speed, 0.001f)
    }

    @Test
    fun `speed is monotonically non-decreasing with distance`() {
        var previous = DifficultyModel.worldSpeedFor(0)
        var d = 0
        while (d <= GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS.toInt() + 1000) {
            val speed = DifficultyModel.worldSpeedFor(d)
            assertTrue(speed >= previous - 0.0001f)
            previous = speed
            d += 137 // an irregular step so we don't only sample suspiciously round numbers
        }
    }

    @Test
    fun `no tier boundary produces a larger jump than the ordinary per-meter change elsewhere`() {
        // The per-meter slope is constant everywhere (worldSpeed is a pure
        // linear function of distance, independent of tier), so the change
        // across any tier boundary must equal the same tiny per-meter
        // amount as anywhere else in the ramp range — never a special jump.
        val perMeterSlope = (GameConfig.MAX_SCROLL_SPEED_DP_PER_SEC - GameConfig.BASE_SCROLL_SPEED_DP_PER_SEC) /
            GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS

        val boundaries = listOf(
            GameConfig.DIFFICULTY_EASY_START_METERS,
            GameConfig.DIFFICULTY_MEDIUM_START_METERS,
            GameConfig.DIFFICULTY_HARD_START_METERS,
            GameConfig.DIFFICULTY_ENDLESS_START_METERS
        )
        for (boundary in boundaries) {
            val jump = DifficultyModel.worldSpeedFor(boundary) - DifficultyModel.worldSpeedFor(boundary - 1)
            assertEquals(perMeterSlope, jump, 0.0001f)
        }
    }

    @Test
    fun `tier is BEGINNER at 0m and steps at the configured thresholds`() {
        assertEquals(DifficultyTier.BEGINNER, DifficultyModel.tierFor(0))
        assertEquals(DifficultyTier.BEGINNER, DifficultyModel.tierFor(GameConfig.DIFFICULTY_EASY_START_METERS - 1))
        assertEquals(DifficultyTier.EASY, DifficultyModel.tierFor(GameConfig.DIFFICULTY_EASY_START_METERS))
        assertEquals(DifficultyTier.MEDIUM, DifficultyModel.tierFor(GameConfig.DIFFICULTY_MEDIUM_START_METERS))
        assertEquals(DifficultyTier.HARD, DifficultyModel.tierFor(GameConfig.DIFFICULTY_HARD_START_METERS))
        assertEquals(DifficultyTier.ENDLESS, DifficultyModel.tierFor(GameConfig.DIFFICULTY_ENDLESS_START_METERS))
    }

    @Test
    fun `advanced obstacles remain locked at distance 0`() {
        val allowed = DifficultyModel.allowedTypesFor(DifficultyTier.BEGINNER)
        assertFalse(ObstacleType.RAMP in allowed)
        assertFalse(ObstacleType.PARKED_VEHICLE in allowed)
        assertFalse(ObstacleType.SLOW_VEHICLE in allowed)
        assertFalse(ObstacleType.MOVING_DOG in allowed)
        assertTrue(allowed.none { it.isMoving })
    }

    @Test
    fun `each tier's pool is a superset of the previous tier's pool`() {
        val beginner = DifficultyModel.allowedTypesFor(DifficultyTier.BEGINNER)
        val easy = DifficultyModel.allowedTypesFor(DifficultyTier.EASY)
        val medium = DifficultyModel.allowedTypesFor(DifficultyTier.MEDIUM)
        val hard = DifficultyModel.allowedTypesFor(DifficultyTier.HARD)
        val endless = DifficultyModel.allowedTypesFor(DifficultyTier.ENDLESS)

        assertTrue(easy.containsAll(beginner))
        assertTrue(medium.containsAll(easy))
        assertTrue(hard.containsAll(medium))
        assertTrue(endless.containsAll(hard))
    }

    @Test
    fun `moving hazards unlock only at the endless tier`() {
        assertEquals(0f, DifficultyModel.profileFor(0).movingObstacleChance, 0.0001f)
        assertEquals(
            0f,
            DifficultyModel.profileFor(GameConfig.DIFFICULTY_HARD_START_METERS).movingObstacleChance,
            0.0001f
        )
        assertTrue(DifficultyModel.profileFor(GameConfig.DIFFICULTY_ENDLESS_START_METERS).movingObstacleChance > 0f)
    }
}
