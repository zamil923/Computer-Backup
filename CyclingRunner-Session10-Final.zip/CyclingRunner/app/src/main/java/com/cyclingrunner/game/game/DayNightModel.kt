package com.cyclingrunner.game.game

import kotlin.math.floor

/**
 * Distance in, phase/transition out — pure functions, no Android
 * dependency, directly unit-testable, and never called from GameEngine:
 * the whole Day/Night system is visual-only, computed by the UI layer
 * from the same [GameUiState.distanceMeters]/[GameUiState.finalDistanceMeters]
 * gameplay already tracks, rather than any new simulation state. Since
 * there is no separate stored timer, restart (distance back to 0) and
 * pause/backgrounding (distance frozen) both produce the correct visual
 * result automatically, with nothing to leak or desync.
 *
 * The world alternates Day/Night every [GameConfig.DAY_NIGHT_CYCLE_METERS],
 * starting in Day at distance 0, with a short smooth blend
 * ([GameConfig.DAY_NIGHT_TRANSITION_METERS] wide) centered on each
 * boundary rather than an instant cut.
 */
object DayNightModel {

    fun phaseForDistance(distanceMeters: Int): WorldPhase {
        val cycle = GameConfig.DAY_NIGHT_CYCLE_METERS
        val d = distanceMeters.coerceAtLeast(0)
        val segmentIndex = d / cycle
        return if (segmentIndex % 2 == 0) WorldPhase.DAY else WorldPhase.NIGHT
    }

    /**
     * 0.0 = fully Day, 1.0 = fully Night, continuous and clamped for any
     * input (including negative distance, handled defensively even though
     * [GameUiState.distanceMeters] never actually goes negative).
     *
     * Computed per half-cycle segment rather than with a single global
     * modulo: a naive `distance % (2*cycle)` wraps exactly on a Night->Day
     * boundary, which would otherwise make the transition jump discontinuously
     * right where it wraps. Handling each segment's start and end blend
     * independently keeps the value continuous everywhere, including across
     * that wrap and at distance 0 (which is deliberately NOT treated as
     * "mid-transition from the night before" — the run always starts in
     * pure Day, since there is no night before the first meter).
     */
    fun transitionProgressForDistance(distanceMeters: Int): Float {
        val cycle = GameConfig.DAY_NIGHT_CYCLE_METERS.toFloat()
        val transition = GameConfig.DAY_NIGHT_TRANSITION_METERS
        val halfTransition = transition / 2f
        val d = distanceMeters.toFloat().coerceAtLeast(0f)

        val segmentIndex = floor(d / cycle).toInt()
        val segmentStart = segmentIndex * cycle
        val positionInSegment = d - segmentStart
        val isDaySegment = segmentIndex % 2 == 0

        val distanceToSegmentEnd = cycle - positionInSegment
        val rampOut = ((halfTransition - distanceToSegmentEnd) / transition).coerceIn(0f, 1f)

        // No ramp-in for the very first segment: nothing precedes distance 0.
        val rampIn = if (segmentIndex > 0) {
            ((halfTransition - positionInSegment) / transition).coerceIn(0f, 1f)
        } else {
            0f
        }

        // At most one of rampIn/rampOut is ever meaningfully nonzero at once,
        // since the transition window is much shorter than a half-cycle.
        val otherPhaseBlend = (rampOut + rampIn).coerceIn(0f, 1f)

        val baseNightAmount = if (isDaySegment) 0f else 1f
        val otherNightAmount = if (isDaySegment) 1f else 0f
        return baseNightAmount + (otherNightAmount - baseNightAmount) * otherPhaseBlend
    }
}
