package com.cyclingrunner.game.game

/**
 * Distance in, accent category + strength out — pure functions, no
 * Android/Color dependency, directly unit-testable, and never called
 * from GameEngine: exactly the same "visual-only, derived from existing
 * distance, nothing new to leak on restart/pause" philosophy as
 * [DayNightModel]. The actual Color values live in `ui.theme` (Compose
 * `Color` doesn't belong in this package) and blend using the strength
 * this model computes.
 */
object ColorProgressionModel {

    /**
     * Which category, if any, [type] can ever gain a color accent for.
     * POTHOLE, RAMP and MOVING_DOG intentionally return null — they stay
     * monochrome for the entire run, per the spec's restraint guidance
     * (a hole shouldn't gain a color fill that undoes Session 7's
     * negative-space fix, a ramp shouldn't look like a collectible, and
     * the animal stays readable rather than decorative).
     */
    fun categoryFor(type: ObstacleType): AccentCategory? = when (type) {
        ObstacleType.SMALL_ROCK, ObstacleType.LARGE_ROCK -> AccentCategory.STONE
        ObstacleType.ROAD_BARRIER -> AccentCategory.WARNING
        ObstacleType.FALLEN_BRANCH, ObstacleType.CRATE -> AccentCategory.WOOD
        ObstacleType.BUSH -> AccentCategory.VEGETATION
        ObstacleType.BRIDGE -> AccentCategory.STRUCTURE
        ObstacleType.PARKED_VEHICLE, ObstacleType.SLOW_VEHICLE -> AccentCategory.VEHICLE
        ObstacleType.POTHOLE, ObstacleType.RAMP, ObstacleType.MOVING_DOG -> null
    }

    private fun unlockThresholdFor(category: AccentCategory): Int = when (category) {
        AccentCategory.STONE -> GameConfig.COLOR_STONE_UNLOCK_METERS
        AccentCategory.WARNING -> GameConfig.COLOR_WARNING_UNLOCK_METERS
        AccentCategory.WOOD, AccentCategory.VEGETATION -> GameConfig.COLOR_VEGETATION_UNLOCK_METERS
        AccentCategory.STRUCTURE -> GameConfig.COLOR_STRUCTURE_UNLOCK_METERS
        AccentCategory.VEHICLE -> GameConfig.COLOR_VEHICLE_UNLOCK_METERS
    }

    /**
     * 0.0 = fully monochrome, 1.0 = the category's accent at full
     * strength, smoothly ramping over [GameConfig.COLOR_ACCENT_TRANSITION_METERS]
     * once [distanceMeters] passes the category's unlock threshold.
     * Always clamped to 0..1, safe for negative or very large distances.
     */
    fun accentStrengthFor(category: AccentCategory, distanceMeters: Int): Float {
        val threshold = unlockThresholdFor(category)
        val d = distanceMeters.coerceAtLeast(0)
        if (d < threshold) return 0f
        val progressed = (d - threshold).toFloat()
        return (progressed / GameConfig.COLOR_ACCENT_TRANSITION_METERS).coerceIn(0f, 1f)
    }

    /** True once a category's accent has started appearing at all (strength > 0). */
    fun isUnlocked(category: AccentCategory, distanceMeters: Int): Boolean =
        accentStrengthFor(category, distanceMeters) > 0f
}
