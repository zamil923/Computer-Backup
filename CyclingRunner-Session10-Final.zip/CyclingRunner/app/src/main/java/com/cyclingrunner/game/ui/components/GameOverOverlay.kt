package com.cyclingrunner.game.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cyclingrunner.game.game.GameConfig
import com.cyclingrunner.game.ui.theme.WorldPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The whole Game Over presentation: no separate screen or Activity — this
 * is one overlay drawn on top of the still-visible, now-frozen game world,
 * so tap-to-restart (handled by GameScreen's existing whole-screen tap,
 * unchanged) is instant. All numbers come from already-captured state
 * ([finalDistanceMeters]/[bestDistanceMeters]/[isNewBest]) — nothing here
 * computes or mutates score.
 *
 * The celebration (brief scale pulse + a handful of small monochrome
 * sparkles) plays once over [GameConfig.NEW_BEST_CELEBRATION_DURATION_MS]
 * and never blocks input — it's a plain Compose animation layered on top
 * of content that's already tappable.
 *
 * Session 7: [palette] is whatever GameScreen resolved for the run's
 * final distance, so Game Over correctly stays Night-themed after a
 * Night crash rather than forcing Day colors just because the run ended.
 */
@Composable
fun GameOverOverlay(
    finalDistanceMeters: Int,
    bestDistanceMeters: Int,
    isNewBest: Boolean,
    palette: WorldPalette,
    modifier: Modifier = Modifier
) {
    // Keyed on finalDistanceMeters, not isNewBest: two consecutive new
    // bests can never share the same distance (the second must exceed the
    // first, which just became the saved best), so this reliably replays
    // the celebration every time, including back-to-back record runs.
    val celebration = remember(finalDistanceMeters) { Animatable(0f) }
    LaunchedEffect(finalDistanceMeters) {
        if (isNewBest) {
            celebration.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = GameConfig.NEW_BEST_CELEBRATION_DURATION_MS,
                    easing = FastOutSlowInEasing
                )
            )
        }
    }

    val accessibilityDescription = if (isNewBest) {
        "Game Over. New best distance ${finalDistanceMeters} meters. Tap to restart."
    } else {
        "Game Over. Distance ${finalDistanceMeters} meters. Best ${bestDistanceMeters} meters. Tap to restart."
    }

    Column(
        modifier = modifier
            .padding(24.dp)
            .clearAndSetSemantics { contentDescription = accessibilityDescription },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "GAME OVER",
            color = palette.overlay,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "DISTANCE ${formatMeters(finalDistanceMeters)} m",
            color = palette.overlay,
            fontSize = 15.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 8.dp)
        )

        Box(contentAlignment = Alignment.Center) {
            if (isNewBest) {
                Sparkles(progress = celebration.value, color = palette.secondaryForeground, modifier = Modifier.size(140.dp))
            }
            val pulse = if (isNewBest) 1f + 0.15f * sin(celebration.value * PI.toFloat()) else 1f
            Text(
                text = if (isNewBest) {
                    "NEW BEST ${formatMeters(finalDistanceMeters)} m"
                } else {
                    "BEST ${formatMeters(bestDistanceMeters)} m"
                },
                color = palette.overlay,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isNewBest) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier
                    .padding(top = 4.dp)
                    .scale(pulse)
            )
        }

        Text(
            text = "TAP TO RESTART",
            color = palette.overlay,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}

private fun formatMeters(meters: Int): String = meters.toString().padStart(5, '0')

/** A handful of small "+"-shaped marks radiating outward and fading, not a real particle system. */
@Composable
private fun Sparkles(progress: Float, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val maxRadius = size.minDimension / 2f
        val fade = (1f - progress).coerceIn(0f, 1f)
        val distanceOut = progress * maxRadius
        val angles = listOf(0f, 60f, 120f, 180f, 240f, 300f)

        angles.forEach { angleDeg ->
            val angle = Math.toRadians(angleDeg.toDouble())
            val x = cx + (cos(angle) * distanceOut).toFloat()
            val y = cy + (sin(angle) * distanceOut).toFloat()
            drawSparkle(center = Offset(x, y), armLength = 6f * fade, color = color, alpha = fade)
        }
    }
}

private fun DrawScope.drawSparkle(center: Offset, armLength: Float, color: Color, alpha: Float) {
    if (armLength <= 0f || alpha <= 0f) return
    val sparkleColor = color.copy(alpha = alpha)
    drawLine(sparkleColor, Offset(center.x - armLength, center.y), Offset(center.x + armLength, center.y), strokeWidth = 2f)
    drawLine(sparkleColor, Offset(center.x, center.y - armLength), Offset(center.x, center.y + armLength), strokeWidth = 2f)
}
