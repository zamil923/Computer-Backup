package com.cyclingrunner.game.game

/**
 * Distance in, [DifficultyProfile] out — pure function, no Android
 * dependency, directly unit-testable.
 *
 * Speed and spawn frequency ramp with a single linear interpolation over
 * [GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS], so they change smoothly at
 * every distance rather than stepping at tier boundaries — the spec's
 * explicit "1499m slow, 1500m instantly faster" failure mode is
 * structurally impossible here, since neither value is a function of the
 * tier at all. The tier ([DifficultyTier]) exists purely to gate which
 * [ObstacleType]s are allowed to spawn, which is content unlocking rather
 * than a physics change, and content unlocking at a threshold is fine.
 */
object DifficultyModel {

    private val beginnerPool = setOf(
        ObstacleType.SMALL_ROCK,
        ObstacleType.LARGE_ROCK,
        ObstacleType.FALLEN_BRANCH,
        ObstacleType.POTHOLE
    )
    private val easyAdditions = setOf(ObstacleType.ROAD_BARRIER, ObstacleType.CRATE, ObstacleType.BUSH)
    private val mediumAdditions = setOf(ObstacleType.RAMP, ObstacleType.BRIDGE)
    private val hardAdditions = setOf(ObstacleType.PARKED_VEHICLE)
    private val endlessAdditions = setOf(ObstacleType.SLOW_VEHICLE, ObstacleType.MOVING_DOG)

    fun tierFor(distanceMeters: Int): DifficultyTier = when {
        distanceMeters < GameConfig.DIFFICULTY_EASY_START_METERS -> DifficultyTier.BEGINNER
        distanceMeters < GameConfig.DIFFICULTY_MEDIUM_START_METERS -> DifficultyTier.EASY
        distanceMeters < GameConfig.DIFFICULTY_HARD_START_METERS -> DifficultyTier.MEDIUM
        distanceMeters < GameConfig.DIFFICULTY_ENDLESS_START_METERS -> DifficultyTier.HARD
        else -> DifficultyTier.ENDLESS
    }

    fun allowedTypesFor(tier: DifficultyTier): Set<ObstacleType> = when (tier) {
        DifficultyTier.BEGINNER -> beginnerPool
        DifficultyTier.EASY -> beginnerPool + easyAdditions
        DifficultyTier.MEDIUM -> beginnerPool + easyAdditions + mediumAdditions
        DifficultyTier.HARD -> beginnerPool + easyAdditions + mediumAdditions + hardAdditions
        DifficultyTier.ENDLESS -> beginnerPool + easyAdditions + mediumAdditions + hardAdditions + endlessAdditions
    }

    /** 0 at the start of a run, 1 once [GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS] is reached; never exceeds 1. */
    fun progressFraction(distanceMeters: Int): Float =
        (distanceMeters.toFloat() / GameConfig.DIFFICULTY_RAMP_DISTANCE_METERS).coerceIn(0f, 1f)

    fun worldSpeedFor(distanceMeters: Int): Float {
        val t = progressFraction(distanceMeters)
        return lerp(GameConfig.BASE_SCROLL_SPEED_DP_PER_SEC, GameConfig.MAX_SCROLL_SPEED_DP_PER_SEC, t)
    }

    fun profileFor(distanceMeters: Int): DifficultyProfile {
        val t = progressFraction(distanceMeters)
        val tier = tierFor(distanceMeters)
        return DifficultyProfile(
            tier = tier,
            worldSpeedDpPerSec = worldSpeedFor(distanceMeters),
            minSpawnIntervalSeconds = lerp(
                GameConfig.OBSTACLE_MIN_SPAWN_INTERVAL_SECONDS,
                GameConfig.MIN_SPAWN_INTERVAL_AT_MAX_DIFFICULTY_SECONDS,
                t
            ),
            maxSpawnIntervalSeconds = lerp(
                GameConfig.OBSTACLE_MAX_SPAWN_INTERVAL_SECONDS,
                GameConfig.MAX_SPAWN_INTERVAL_AT_MAX_DIFFICULTY_SECONDS,
                t
            ),
            allowedObstacleTypes = allowedTypesFor(tier),
            movingObstacleChance = if (tier == DifficultyTier.ENDLESS) {
                GameConfig.MOVING_OBSTACLE_CHANCE_AT_ENDLESS
            } else {
                0f
            }
        )
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
}
