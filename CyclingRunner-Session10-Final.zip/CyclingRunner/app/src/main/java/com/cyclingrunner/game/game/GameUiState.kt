package com.cyclingrunner.game.game

/**
 * Single immutable snapshot of everything the UI needs to render one frame.
 * [GameEngine.advance] produces the next snapshot from the previous one.
 *
 * [worldSpeedDpPerSec] is the single shared speed value that road scroll,
 * parallax layers, wheel rotation, pedal rotation and obstacle movement
 * are all derived from — see [GameEngine]. Since Session 5, it is
 * recomputed every frame from [distanceMeters] via [DifficultyModel]
 * rather than held fixed; it still lives in state (rather than being
 * read directly from DifficultyModel everywhere) so the renderer and
 * tests can read the current value without recomputing it themselves.
 *
 * [viewportWidthPx]/[viewportHeightPx] are 0 until the UI reports its
 * actual measured size (see GameViewModel.reportViewportSize). Obstacle
 * spawning, collision and terrain (ramp/bridge) evaluation are gated on
 * these being known; everything else (scroll, wheel/pedal rotation,
 * distance) never depended on viewport size and is untouched by that gate.
 *
 * [lastSpawnedObstacleType] feeds [PatternValidator] so the gap after a
 * moving or terrain hazard can be given extra recovery time.
 *
 * [finalDistanceMeters]/[isNewBest]/[crashState] are set exactly once —
 * atomically, in the same [GameEngine.advance] call that detects the
 * collision and flips [gameState] to [GameState.GAME_OVER] — and never
 * change again afterward, since that same state flip stops the
 * simulation loop entirely (see GameViewModel). [finalDistanceMeters] is
 * therefore immutable from the instant it's set: no later frame, no
 * background time, and no crash-animation time (which is handled purely
 * on the Compose side, not by this state) can move it.
 */
data class GameUiState(
    val gameState: GameState = GameState.READY,
    val distanceMeters: Int = 0,
    val bestDistanceMeters: Int = 0,
    val worldSpeedDpPerSec: Float = GameConfig.BASE_SCROLL_SPEED_DP_PER_SEC,
    val roadScrollPx: Float = 0f,
    val nearScrollPx: Float = 0f,
    val farScrollPx: Float = 0f,
    val cloudScrollPx: Float = 0f,
    val cyclist: CyclistState = CyclistState(),
    val obstacles: List<Obstacle> = emptyList(),
    val obstacleSpawnTimerSeconds: Float = GameConfig.OBSTACLE_INITIAL_GRACE_SECONDS,
    val nextObstacleId: Long = 0L,
    val lastSpawnedObstacleType: ObstacleType? = null,
    val viewportWidthPx: Float = 0f,
    val viewportHeightPx: Float = 0f,
    val finalDistanceMeters: Int? = null,
    val isNewBest: Boolean = false,
    val crashState: CrashState? = null
)
