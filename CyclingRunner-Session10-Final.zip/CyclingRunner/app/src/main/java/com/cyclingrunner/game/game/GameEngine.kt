package com.cyclingrunner.game.game

import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Pure, stateless per-frame update step: (state, deltaSeconds) -> next state.
 *
 * Deliberately has no Android or coroutine types in it, so it can be unit
 * tested on the JVM and reused unchanged as later sessions extend it.
 *
 * Session 2: road scroll, every parallax layer, wheel rotation and pedal
 * rotation are all computed from the single shared world speed, and the
 * body bob is recomputed each frame directly from the pedal phase rather
 * than accumulated on its own clock. Because everything is either a pure
 * function of the same speed or of an already-synchronized phase, nothing
 * can independently drift — including across pause/resume, since this
 * whole function is only ever called while RUNNING.
 *
 * Session 4: obstacle movement uses the same worldSpeed as everything else
 * ([ObstacleMotion]), spawning is delegated to [ObstacleSpawner] (with an
 * injectable [Random] for deterministic tests — production simply uses the
 * default), and collision is checked against the cyclist's already
 * jump-correct bounds ([CyclistGeometry.approximateBounds]). All of it is
 * gated on the viewport actually having been measured at least once.
 *
 * Session 5: world speed is now [DifficultyModel.worldSpeedFor] the
 * distance at the START of this frame (using this frame's own new distance
 * would be circular — speed determines how far this frame travels — and a
 * one-frame lag across a threshold is imperceptible), so it still remains
 * the one shared value everything above derives from; only its source
 * changed from a bare constant to a smooth function of distance. Ramp/
 * bridge terrain ([TerrainSurface]) is applied after gravity, overriding
 * [CyclistState.verticalOffset] only while grounded and launching a ramp
 * through the exact same isAirborne/verticalVelocity fields a manual jump
 * uses — no second ground-Y and no second jump-physics system.
 *
 * Session 6: a hazard collision detected this frame (any non-terrain
 * obstacle whose [Obstacle.hasBeenHit] just flipped true) ends the run
 * right here — [GameState.GAME_OVER], [GameUiState.finalDistanceMeters]
 * and [GameUiState.isNewBest] are all set atomically in the same return,
 * using this exact frame's already-computed values. Everything after that
 * point is frozen because [GameState.GAME_OVER] stops the loop that calls
 * this function (see [GameViewModel]) — there is no separate "freeze"
 * step to get wrong.
 */
object GameEngine {

    fun advance(state: GameUiState, deltaSecondsRaw: Float, random: Random = Random.Default): GameUiState {
        if (state.gameState != GameState.RUNNING) return state

        val dt = min(deltaSecondsRaw, GameConfig.MAX_FRAME_DELTA_SECONDS)
        if (dt <= 0f) return state

        val profile = DifficultyModel.profileFor(state.distanceMeters)
        val worldSpeed = profile.worldSpeedDpPerSec

        val roadScroll = state.roadScrollPx + worldSpeed * dt
        val nearScroll = state.nearScrollPx + worldSpeed * GameConfig.NEAR_LAYER_PARALLAX_FACTOR * dt
        val farScroll = state.farScrollPx + worldSpeed * GameConfig.FAR_LAYER_PARALLAX_FACTOR * dt
        val cloudScroll = state.cloudScrollPx + worldSpeed * GameConfig.CLOUD_LAYER_PARALLAX_FACTOR * dt

        val distanceDelta = worldSpeed * dt * GameConfig.METERS_PER_SCROLLED_DP
        val newDistance = (state.distanceMeters + distanceDelta).toInt().coerceAtLeast(state.distanceMeters)

        val gravityAdvancedCyclist = advanceCyclist(state.cyclist, worldSpeed, dt)

        val movedObstacles = ObstacleMotion.advance(state.obstacles, worldSpeed, dt)
        val spawnResult = ObstacleSpawner.update(
            obstacles = movedObstacles,
            spawnTimerSeconds = state.obstacleSpawnTimerSeconds,
            nextId = state.nextObstacleId,
            dt = dt,
            viewportWidthPx = state.viewportWidthPx,
            viewportHeightPx = state.viewportHeightPx,
            profile = profile,
            lastSpawnedType = state.lastSpawnedObstacleType,
            random = random
        )

        val viewportKnown = state.viewportWidthPx > 0f && state.viewportHeightPx > 0f

        // Ramp/bridge terrain: only meaningful once the viewport is known
        // (it needs the cyclist's real leading-edge X), and never overrides
        // a cyclist already airborne from a real jump.
        val terrainResult = if (viewportKnown) {
            val cyclistLeadingX = CyclistGeometry.frontWheelX(state.viewportWidthPx, state.viewportHeightPx)
            TerrainSurface.evaluate(state.obstacles, movedObstacles, cyclistLeadingX, gravityAdvancedCyclist.isAirborne)
        } else {
            TerrainSurface.Result(elevation = 0f, rampLaunchVelocity = null)
        }

        val advancedCyclist = when {
            gravityAdvancedCyclist.isAirborne -> gravityAdvancedCyclist
            terrainResult.rampLaunchVelocity != null -> gravityAdvancedCyclist.copy(
                verticalOffset = terrainResult.elevation,
                isAirborne = true,
                verticalVelocity = terrainResult.rampLaunchVelocity
            )
            else -> gravityAdvancedCyclist.copy(verticalOffset = terrainResult.elevation)
        }

        var crashedObstacleType: ObstacleType? = null
        val obstaclesAfterCollision = if (viewportKnown) {
            val groundY = CyclistGeometry.groundY(state.viewportHeightPx)
            val cyclistBounds = CyclistGeometry.approximateBounds(state.viewportWidthPx, state.viewportHeightPx, advancedCyclist)
            val potholeClearance = CyclistGeometry.wheelRadius(state.viewportHeightPx) * GameConfig.POTHOLE_CLEARANCE_FACTOR

            spawnResult.obstacles.map { obstacle ->
                val hit = CollisionSystem.checkCollision(
                    cyclistBounds = cyclistBounds,
                    cyclistVerticalOffset = advancedCyclist.verticalOffset,
                    groundY = groundY,
                    potholeClearance = potholeClearance,
                    obstacle = obstacle
                )
                if (hit) {
                    crashedObstacleType = obstacle.type
                    obstacle.copy(hasBeenHit = true)
                } else {
                    obstacle
                }
            }
        } else {
            spawnResult.obstacles
        }

        val advancedState = state.copy(
            worldSpeedDpPerSec = worldSpeed,
            roadScrollPx = roadScroll,
            nearScrollPx = nearScroll,
            farScrollPx = farScroll,
            cloudScrollPx = cloudScroll,
            distanceMeters = newDistance,
            cyclist = advancedCyclist,
            obstacles = obstaclesAfterCollision,
            obstacleSpawnTimerSeconds = spawnResult.spawnTimerSeconds,
            nextObstacleId = spawnResult.nextObstacleId,
            lastSpawnedObstacleType = spawnResult.lastSpawnedType
        )

        // A hazard collision this frame ends the run right here: everything
        // above (distance, speed, obstacles, cyclist pose) is frozen at
        // exactly its value at the moment of impact — finalDistanceMeters
        // is captured once, from advancedState.distanceMeters, and nothing
        // after this point can change it, since GAME_OVER stops the loop
        // that calls this function (see GameViewModel). isNewBest is a
        // pure comparison ([RecordLogic]) against the best known so far;
        // actually persisting an improved best is GameViewModel's job
        // (BestDistanceStore), not this pure function's — bestDistanceMeters
        // itself is left untouched here, exactly as before a crash.
        return crashedObstacleType?.let { type ->
            advancedState.copy(
                gameState = GameState.GAME_OVER,
                finalDistanceMeters = advancedState.distanceMeters,
                isNewBest = RecordLogic.isNewBest(advancedState.distanceMeters, state.bestDistanceMeters),
                crashState = CrashState(obstacleType = type)
            )
        } ?: advancedState
    }

    /**
     * The exact reset [GameViewModel.restart] applies: a brand-new run,
     * carrying over only the two pieces of state that aren't "this run's"
     * concern — the persisted best distance and the measured viewport
     * dimensions. Resetting viewport dimensions on restart was a real
     * Session 4 bug (it silently stopped obstacles from ever spawning
     * again until the next screen rotation); pulling this into a pure
     * function makes that exact behavior directly unit-testable.
     */
    fun freshRunState(previous: GameUiState): GameUiState = GameUiState(
        gameState = GameState.RUNNING,
        bestDistanceMeters = previous.bestDistanceMeters,
        viewportWidthPx = previous.viewportWidthPx,
        viewportHeightPx = previous.viewportHeightPx
    )

    private fun advanceCyclist(cyclist: CyclistState, worldSpeed: Float, dt: Float): CyclistState {
        val twoPi = 2f * Math.PI.toFloat()

        // wheelAngularVelocity = linearWorldSpeed / wheelRadius (conceptually;
        // see GameConfig.WHEEL_RADIUS_REFERENCE_DP for the simplification note).
        val wheelAngularVelocityRadPerSec = worldSpeed / GameConfig.WHEEL_RADIUS_REFERENCE_DP
        val wheelAngularVelocityDegPerSec = Math.toDegrees(wheelAngularVelocityRadPerSec.toDouble()).toFloat()
        val pedalAngularVelocityRadPerSec = wheelAngularVelocityRadPerSec / GameConfig.PEDAL_GEAR_RATIO

        val wheelRotation = (cyclist.wheelRotationDegrees + wheelAngularVelocityDegPerSec * dt) % 360f
        val pedalPhase = (cyclist.pedalPhase + pedalAngularVelocityRadPerSec * dt) % twoPi

        // Derived fresh from pedalPhase every frame (not its own accumulator),
        // so it is always exactly in sync with the legs — including the
        // instant after a resume.
        val bodyBobPhase = (pedalPhase * GameConfig.BODY_BOB_TO_PEDAL_RATIO) % twoPi

        // Jump physics. Session 1/2 built this integration in anticipation
        // of input; Session 3 is the first thing that actually sets
        // isAirborne (via applyJumpImpulse), so this loop's landing
        // detection now runs for real instead of always being a no-op.
        val wasAirborne = cyclist.isAirborne
        var verticalOffset = cyclist.verticalOffset
        var verticalVelocity = cyclist.verticalVelocity
        var isAirborne = cyclist.isAirborne

        if (isAirborne) {
            verticalVelocity -= GameConfig.GRAVITY_DP_PER_SEC2 * dt
            verticalOffset += verticalVelocity * dt
            if (verticalOffset <= 0f) {
                // Deterministic landing: clamp exactly to ground, no jitter,
                // no residual velocity to bounce on the next frame.
                verticalOffset = 0f
                verticalVelocity = 0f
                isAirborne = false
            }
        }

        // Purely cosmetic squash timer — never feeds back into the physics
        // above, so it cannot itself cause a bounce. Refreshed to full only
        // on the exact frame a landing just happened; otherwise it decays.
        val justLanded = wasAirborne && !isAirborne
        val landingSquashSeconds = if (justLanded) {
            GameConfig.LANDING_SQUASH_DURATION_SECONDS
        } else {
            (cyclist.landingSquashSeconds - dt).coerceAtLeast(0f)
        }

        return cyclist.copy(
            wheelRotationDegrees = wheelRotation,
            pedalPhase = pedalPhase,
            bodyBobPhase = bodyBobPhase,
            verticalOffset = verticalOffset,
            verticalVelocity = verticalVelocity,
            isAirborne = isAirborne,
            landingSquashSeconds = landingSquashSeconds
        )
    }

    /**
     * The single entry point for the jump input. Reused unchanged from its
     * Session 1/2 foundation: already grounded-only (no double/air jump —
     * returns [cyclist] as-is when already airborne, so rapid taps mid-air
     * are safely no-ops with no extra debouncing needed).
     */
    fun applyJumpImpulse(cyclist: CyclistState): CyclistState {
        if (cyclist.isAirborne) return cyclist
        return cyclist.copy(
            verticalVelocity = GameConfig.JUMP_IMPULSE_DP_PER_SEC,
            isAirborne = true
        )
    }

    /** Small helper the renderer can use for wobble/lean effects. */
    fun bobOffset(cyclist: CyclistState, amplitude: Float): Float = sin(cyclist.bodyBobPhase) * amplitude
}
