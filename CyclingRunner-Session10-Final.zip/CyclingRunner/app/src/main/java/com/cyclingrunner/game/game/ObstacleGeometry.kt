package com.cyclingrunner.game.game

/**
 * Obstacle footprint sizing, expressed as multiples of [CyclistGeometry.wheelRadius]
 * so obstacles scale responsively with screen size exactly like the cyclist
 * does, rather than using fixed pixel dimensions on one reference device.
 *
 * All hazard heights are comfortably within the standard jump's apex
 * (impulse²/(2*gravity), see GameConfig) so every obstacle is clearable by
 * the one-tap bunny hop with real margin — no obstacle here requires a
 * special or higher jump. For PARKED_VEHICLE/SLOW_VEHICLE, [heightFor] is
 * the actual gameplay collision height, deliberately shorter than how tall
 * the vehicle is drawn (see ObstacleLayer) — a forgiving vertical hitbox,
 * the same idea as [GameConfig.OBSTACLE_COLLISION_WIDTH_FACTOR]'s
 * horizontal forgiveness.
 */
object ObstacleGeometry {

    fun widthFor(type: ObstacleType, viewportHeightPx: Float): Float {
        val r = CyclistGeometry.wheelRadius(viewportHeightPx)
        return when (type) {
            ObstacleType.SMALL_ROCK -> r * 1.0f
            ObstacleType.LARGE_ROCK -> r * 1.7f
            ObstacleType.POTHOLE -> r * 1.9f
            ObstacleType.ROAD_BARRIER -> r * 1.3f
            ObstacleType.FALLEN_BRANCH -> r * 2.3f
            ObstacleType.CRATE -> r * 1.1f
            ObstacleType.BUSH -> r * 1.3f
            ObstacleType.PARKED_VEHICLE -> r * 2.6f
            ObstacleType.SLOW_VEHICLE -> r * 2.4f
            ObstacleType.MOVING_DOG -> r * 0.7f
            ObstacleType.RAMP -> r * 3.0f
            ObstacleType.BRIDGE -> r * 4.5f
        }
    }

    fun heightFor(type: ObstacleType, viewportHeightPx: Float): Float {
        val r = CyclistGeometry.wheelRadius(viewportHeightPx)
        return when (type) {
            ObstacleType.SMALL_ROCK -> r * 0.85f
            ObstacleType.LARGE_ROCK -> r * 1.6f
            // A pothole's "height" is only its visual depression — collision
            // uses CollisionSystem's clearance rule, not this value.
            ObstacleType.POTHOLE -> r * 0.35f
            ObstacleType.ROAD_BARRIER -> r * 1.35f
            ObstacleType.FALLEN_BRANCH -> r * 0.55f
            ObstacleType.CRATE -> r * 1.1f
            ObstacleType.BUSH -> r * 0.75f
            // Gameplay collision height only — the visual cabin/roof drawn
            // above this is intentionally forgiving, see class doc.
            ObstacleType.PARKED_VEHICLE -> r * 1.55f
            ObstacleType.SLOW_VEHICLE -> r * 1.5f
            ObstacleType.MOVING_DOG -> r * 0.5f
            // For RAMP/BRIDGE this is the terrain's peak elevation, not a
            // collision wall height — see TerrainSurface and CollisionSystem
            // (terrain types never register as a hazard hit).
            ObstacleType.RAMP -> r * 1.3f
            ObstacleType.BRIDGE -> r * 1.0f
        }
    }

    /** 0 for every stationary type; see [Obstacle.relativeVelocityDpPerSec]. */
    fun relativeVelocityFor(type: ObstacleType): Float = when (type) {
        ObstacleType.SLOW_VEHICLE -> GameConfig.SLOW_VEHICLE_RELATIVE_VELOCITY_DP_PER_SEC
        ObstacleType.MOVING_DOG -> GameConfig.MOVING_DOG_RELATIVE_VELOCITY_DP_PER_SEC
        else -> 0f
    }
}
