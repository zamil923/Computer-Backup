package com.cyclingrunner.game.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Generates the game's four feedback sounds entirely from scratch as
 * tiny PCM16 mono WAV files — original synthesized tones, not copied or
 * licensed audio of any kind. Deterministic: the same parameters always
 * produce byte-identical output. Each file is generated once, on first
 * use (see [GameAudioManager]), and cached — never regenerated per play
 * or per recomposition.
 *
 * Every tone uses a short linear attack (avoids the click a hard on/off
 * transition would produce) followed by an exponential decay, which is
 * what gives these their soft "pop"/"tick"/"thump" character rather than
 * a harsh buzz.
 */
object ToneWavWriter {

    private const val SAMPLE_RATE = 44100
    private const val ATTACK_SECONDS = 0.005

    /** A single decaying sine tone — used for Jump, Landing, and Crash (differing only in frequency/duration/amplitude). */
    fun writeToneWav(file: File, frequencyHz: Double, durationSeconds: Double, amplitude: Double) {
        val sampleCount = (SAMPLE_RATE * durationSeconds).toInt().coerceAtLeast(1)
        val samples = ShortArray(sampleCount)
        renderNoteInto(samples, offset = 0, count = sampleCount, frequencyHz = frequencyHz, amplitude = amplitude)
        writeWavFile(file, samples)
    }

    /** Two short ascending decaying tones back to back — the New Best chime. */
    fun writeChimeWav(file: File, firstHz: Double, secondHz: Double, noteDurationSeconds: Double, amplitude: Double) {
        val noteSamples = (SAMPLE_RATE * noteDurationSeconds).toInt().coerceAtLeast(1)
        val samples = ShortArray(noteSamples * 2)
        renderNoteInto(samples, offset = 0, count = noteSamples, frequencyHz = firstHz, amplitude = amplitude)
        renderNoteInto(samples, offset = noteSamples, count = noteSamples, frequencyHz = secondHz, amplitude = amplitude)
        writeWavFile(file, samples)
    }

    private fun renderNoteInto(target: ShortArray, offset: Int, count: Int, frequencyHz: Double, amplitude: Double) {
        val attackSamples = (SAMPLE_RATE * ATTACK_SECONDS).toInt().coerceAtLeast(1).coerceAtMost(count)
        val decaySpan = (count - attackSamples).coerceAtLeast(1)
        for (i in 0 until count) {
            val t = i.toDouble() / SAMPLE_RATE
            val envelope = if (i < attackSamples) {
                i.toDouble() / attackSamples
            } else {
                exp(-4.5 * (i - attackSamples) / decaySpan)
            }
            val sample = sin(2.0 * PI * frequencyHz * t) * amplitude * envelope
            target[offset + i] = (sample * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun writeWavFile(file: File, samples: ShortArray) {
        val byteRate = SAMPLE_RATE * 2 // mono, 16-bit
        val dataSize = samples.size * 2

        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(0)
            raf.writeAscii("RIFF")
            raf.writeIntLE(36 + dataSize)
            raf.writeAscii("WAVE")
            raf.writeAscii("fmt ")
            raf.writeIntLE(16)   // fmt chunk size
            raf.writeShortLE(1)  // PCM
            raf.writeShortLE(1)  // mono
            raf.writeIntLE(SAMPLE_RATE)
            raf.writeIntLE(byteRate)
            raf.writeShortLE(2)  // block align (channels * bytesPerSample)
            raf.writeShortLE(16) // bits per sample
            raf.writeAscii("data")
            raf.writeIntLE(dataSize)

            val buffer = ByteBuffer.allocate(dataSize).order(ByteOrder.LITTLE_ENDIAN)
            samples.forEach { buffer.putShort(it) }
            raf.write(buffer.array())
        }
    }

    private fun RandomAccessFile.writeAscii(text: String) = write(text.toByteArray(Charsets.US_ASCII))

    private fun RandomAccessFile.writeIntLE(value: Int) = write(
        byteArrayOf(
            (value and 0xFF).toByte(),
            ((value shr 8) and 0xFF).toByte(),
            ((value shr 16) and 0xFF).toByte(),
            ((value shr 24) and 0xFF).toByte()
        )
    )

    private fun RandomAccessFile.writeShortLE(value: Int) = write(
        byteArrayOf((value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte())
    )
}
