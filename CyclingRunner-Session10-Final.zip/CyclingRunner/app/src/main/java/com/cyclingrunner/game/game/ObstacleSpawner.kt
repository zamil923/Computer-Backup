package com.cyclingrunner.game.game

import kotlin.random.Random

/**
 * Decides when and what to spawn. Pure function of its inputs plus an
 * injected [Random] source — production code can pass nothing (defaults
 * to [Random.Default]) while tests pass a seeded instance for a
 * reproducible obstacle sequence, per the spec's determinism requirement.
 *
 * The spawn TIMER is expressed in seconds rather than a pixel gap so
 * spacing stays a fixed reaction-time budget even as world speed changes.
 *
 * Session 5: type selection is now gated by [DifficultyProfile.allowedObstacleTypes]
 * (only unlocked obstacles can spawn) and weighted by
 * [DifficultyProfile.movingObstacleChance] (moving hazards stay a
 * controlled minority of the pool rather than appearing as often as a
 * plain rock). The chosen interval is also clamped up to whatever
 * [PatternValidator] says is the minimum safe gap after the previous
 * obstacle — clamping rather than reject-and-resample, so this always
 * terminates in one pass.
 */
object ObstacleSpawner {

    data class SpawnResult(
        val obstacles: List<Obstacle>,
        val spawnTimerSeconds: Float,
        val nextObstacleId: Long,
        val lastSpawnedType: ObstacleType?
    )

    fun update(
        obstacles: List<Obstacle>,
        spawnTimerSeconds: Float,
        nextId: Long,
        dt: Float,
        viewportWidthPx: Float,
        viewportHeightPx: Float,
        profile: DifficultyProfile,
        lastSpawnedType: ObstacleType?,
        random: Random
    ): SpawnResult {
        val timer = spawnTimerSeconds - dt

        // Don't spawn against an unmeasured viewport (spawn X would be
        // meaningless before the UI has reported its actual size once).
        if (timer > 0f || viewportWidthPx <= 0f || viewportHeightPx <= 0f) {
            return SpawnResult(obstacles, timer, nextId, lastSpawnedType)
        }

        val type = pickType(profile, random)
        val width = ObstacleGeometry.widthFor(type, viewportHeightPx)
        val height = ObstacleGeometry.heightFor(type, viewportHeightPx)
        val relativeVelocity = ObstacleGeometry.relativeVelocityFor(type)
        val spawnX = viewportWidthPx + GameConfig.OBSTACLE_SPAWN_MARGIN_PX

        val spawned = Obstacle(
            id = nextId,
            type = type,
            x = spawnX,
            width = width,
            height = height,
            relativeVelocityDpPerSec = relativeVelocity
        )

        val rawInterval = random.nextDouble(
            profile.minSpawnIntervalSeconds.toDouble(),
            profile.maxSpawnIntervalSeconds.toDouble()
        ).toFloat()
        val requiredGap = PatternValidator.requiredRecoverySeconds(lastSpawnedType, type)
        val nextTimer = maxOf(rawInterval, requiredGap)

        return SpawnResult(obstacles + spawned, nextTimer, nextId + 1, type)
    }

    private fun pickType(profile: DifficultyProfile, random: Random): ObstacleType {
        val pool = profile.allowedObstacleTypes.ifEmpty { ObstacleType.entries.toSet() }
        val movingTypes = pool.filter { it.isMoving }
        val stationaryTypes = pool.filter { !it.isMoving }

        val useMoving = movingTypes.isNotEmpty() && random.nextFloat() < profile.movingObstacleChance
        val selectionPool = if (useMoving) movingTypes else stationaryTypes.ifEmpty { pool.toList() }

        return selectionPool[random.nextInt(selectionPool.size)]
    }
}
