package com.cyclingrunner.game.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.cyclingrunner.game.game.DayNightModel

/**
 * The full set of colors every gameplay renderer draws with. Centralizing
 * this is what lets Day/Night inversion (Session 7) — and later, Session
 * 8's per-object accent colors — reach every renderer through one plumbed
 * parameter instead of each Canvas file hard-coding [GameBlack]/[GameOffWhite]
 * and needing its own Day/Night branch.
 *
 * [overlay] is kept separate from [foreground] even though they're equal
 * in both palettes below, so a future session can differentiate overlay
 * text from world-drawing color without a structural change here.
 */
data class WorldPalette(
    val background: Color,
    val foreground: Color,
    val secondaryForeground: Color,
    val distantScenery: Color,
    val hud: Color,
    val overlay: Color
)

/** Existing Day look, unchanged from Sessions 1-6 — this is exactly [GameOffWhite]/[GameBlack]/etc. */
val DAY_PALETTE = WorldPalette(
    background = GameOffWhite,
    foreground = GameBlack,
    secondaryForeground = GameGray,
    distantScenery = GameLightGray,
    hud = GameBlack,
    overlay = GameBlack
)

/** Near-black/near-white rather than pure 0x000000/0xFFFFFF — easier on contrast and matches the Day palette's own off-white restraint. */
val NIGHT_PALETTE = WorldPalette(
    background = Color(0xFF0A0A0E),
    foreground = Color(0xFFF5F5F5),
    secondaryForeground = Color(0xFF9AA0A6),
    distantScenery = Color(0xFF2A2A30),
    hud = Color(0xFFF5F5F5),
    overlay = Color(0xFFF5F5F5)
)

private fun lerpPalette(from: WorldPalette, to: WorldPalette, fraction: Float): WorldPalette = WorldPalette(
    background = lerp(from.background, to.background, fraction),
    foreground = lerp(from.foreground, to.foreground, fraction),
    secondaryForeground = lerp(from.secondaryForeground, to.secondaryForeground, fraction),
    distantScenery = lerp(from.distantScenery, to.distantScenery, fraction),
    hud = lerp(from.hud, to.hud, fraction),
    overlay = lerp(from.overlay, to.overlay, fraction)
)

/**
 * The palette to draw with for a given distance — [DayNightModel] supplies
 * the pure 0..1 progress, this just blends colors from it. Not a
 * composable: it's plain color math, callable directly from any Canvas
 * draw scope or from [GameScreen] once per frame.
 *
 * Callers pass [GameUiState.finalDistanceMeters] once the run has ended
 * (falling back to [GameUiState.distanceMeters] before that) so the
 * Game Over/crash presentation reflects the phase at the moment the run
 * actually ended, and stays exactly that — stable, no further blending —
 * since a frozen distance can't move the transition progress either.
 */
fun paletteForDistance(distanceMeters: Int): WorldPalette {
    val nightAmount = DayNightModel.transitionProgressForDistance(distanceMeters)
    return lerpPalette(DAY_PALETTE, NIGHT_PALETTE, nightAmount)
}
