package com.cyclingrunner.game.audio

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

/**
 * Thin wrapper around Android's vibration APIs. Every path is defensive:
 * an unsupported device, a missing vibrator, or any exception simply
 * results in no haptic — never a crash, and never something gameplay
 * waits on (see [GameFeedbackController], which only ever calls these
 * methods as a side effect of an already-accepted gameplay event).
 *
 * Uses the modern [VibratorManager] path on API 31+ and the legacy
 * [Vibrator] system service below that, matching the two officially
 * supported ways to obtain a vibrator across the app's minSdk range.
 */
class GameHapticController(context: Context) {

    private val tag = "GameHapticController"

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (e: Exception) {
        Log.w(tag, "Vibrator unavailable on this device", e)
        null
    }

    /** Very light — accepted jump only; an ignored airborne tap never reaches this (see GameFeedbackController/GameViewModel). */
    fun jump() = vibrate(durationMillis = 12, amplitude = 60)

    /** Weaker than jump — a subtle landing contact, not meant to be very noticeable. */
    fun land() = vibrate(durationMillis = 8, amplitude = 30)

    /** Short but clearly stronger than jump/land — a crash impact, not a long buzz. */
    fun crash() = vibrate(durationMillis = 60, amplitude = 200)

    /** A brief, restrained positive confirmation — not a multi-pulse celebration pattern. */
    fun newBest() = vibrate(durationMillis = 20, amplitude = 120)

    private fun vibrate(durationMillis: Long, amplitude: Int) {
        val v = vibrator ?: return
        try {
            if (!v.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(durationMillis, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(durationMillis)
            }
        } catch (e: Exception) {
            Log.w(tag, "Failed to vibrate", e)
        }
    }
}
