package com.cyclingrunner.game.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import com.cyclingrunner.game.audio.GameFeedbackController
import com.cyclingrunner.game.game.DayNightModel
import com.cyclingrunner.game.game.GameConfig
import com.cyclingrunner.game.game.GameState
import com.cyclingrunner.game.game.GameViewModel
import com.cyclingrunner.game.ui.components.BackgroundLayer
import com.cyclingrunner.game.ui.components.CyclistLayer
import com.cyclingrunner.game.ui.components.DistanceHud
import com.cyclingrunner.game.ui.components.GameOverOverlay
import com.cyclingrunner.game.ui.components.ObstacleLayer
import com.cyclingrunner.game.ui.components.PauseButton
import com.cyclingrunner.game.ui.components.PausedOverlay
import com.cyclingrunner.game.ui.components.RoadLayer
import com.cyclingrunner.game.ui.components.StartOverlay
import com.cyclingrunner.game.ui.theme.paletteForDistance

/**
 * Whole-screen tap is the single control: starts the run from READY,
 * resumes from PAUSED, triggers a jump during RUNNING, and restarts
 * instantly from GAME_OVER (Session 6) — all via the same unconditional
 * [GameViewModel.onTapPrimary] call already wired below; no branching
 * needed here since GameViewModel already routes by state. The pause
 * button is a separate, smaller tap target that consumes its own click,
 * and is only ever placed in the tree during RUNNING/PAUSED, so it can
 * never intercept a Game Over restart tap.
 *
 * Session 4: reports the actual measured canvas size to the ViewModel via
 * onSizeChanged (GameEngine needs real viewport dimensions for obstacle
 * spawn position and collision — see GameViewModel.reportViewportSize),
 * and renders obstacles between the road and the cyclist so they sit on
 * the road but behind the rider.
 *
 * Session 6: the crash tilt is a purely cosmetic Compose animation owned
 * here, not by GameEngine/GameViewModel — it starts from the cyclist's
 * actual frozen pose (GameEngine stops updating it the instant GAME_OVER
 * is set) and never touches simulation state.
 *
 * Session 7: the world palette is resolved once here, from
 * [paletteForDistance] — a pure function of distance — and passed down to
 * every layer. It uses finalDistanceMeters once the run has ended (falling
 * back to the live distanceMeters before that), so Game Over reflects the
 * phase the run actually ended in and stays exactly that: since a frozen
 * distance can't move the transition progress, there is nothing left to
 * flicker or drift behind the overlay. There is deliberately no separate
 * phase/transition state anywhere in GameUiState/GameEngine — pause,
 * backgrounding and restart all produce the correct visual "for free"
 * simply because distance itself is frozen or reset, with nothing extra
 * to leak.
 *
 * Session 8: the same [effectiveDistanceForPalette] also drives
 * ObstacleLayer's selective color-accent progression — one shared
 * "effective distance" feeds both Day/Night and color progression, so
 * they can never disagree about what the world should look like right
 * now, including behind a frozen Game Over.
 *
 * Session 9: a single [GameFeedbackController] is created once (`remember`)
 * and collects [GameViewModel.events] in one `LaunchedEffect(Unit)` for as
 * long as this screen stays in composition — not a new collector per
 * event type, and released via `DisposableEffect` when the screen leaves
 * composition. It is a pure observer of already-accepted events: nothing
 * it does can affect gameplay, and disabling sound or haptics only
 * changes what GameFeedbackController itself does with an event, never
 * whether GameViewModel accepts one.
 */
@Composable
fun GameScreen(viewModel: GameViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    val effectiveDistanceForPalette = uiState.finalDistanceMeters ?: uiState.distanceMeters
    val palette = paletteForDistance(effectiveDistanceForPalette)
    val nightAmount = DayNightModel.transitionProgressForDistance(effectiveDistanceForPalette)

    val context = LocalContext.current
    val feedbackScope = rememberCoroutineScope()
    val feedbackController = remember { GameFeedbackController(context.applicationContext, feedbackScope) }
    DisposableEffect(Unit) {
        onDispose { feedbackController.release() }
    }
    LaunchedEffect(Unit) {
        viewModel.events.collect { event -> feedbackController.onEvent(event) }
    }
    LaunchedEffect(uiState.gameState) {
        feedbackController.onGameStateChanged(uiState.gameState)
    }
    val soundEnabled by feedbackController.soundEnabled.collectAsState()
    val hapticsEnabled by feedbackController.hapticsEnabled.collectAsState()

    // Keyed on finalDistanceMeters (not just "is there a crash"): two
    // different completed runs will essentially always end at different
    // distances, so this reliably restarts the tilt from 0 for each new
    // crash rather than only playing once ever.
    val crashTilt = remember { Animatable(0f) }
    LaunchedEffect(uiState.finalDistanceMeters) {
        if (uiState.crashState != null) {
            crashTilt.snapTo(0f)
            crashTilt.animateTo(
                targetValue = GameConfig.CRASH_TILT_DEGREES,
                animationSpec = tween(durationMillis = GameConfig.CRASH_ANIMATION_DURATION_MS, easing = FastOutSlowInEasing)
            )
        } else {
            crashTilt.snapTo(0f)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .onSizeChanged { size ->
                viewModel.reportViewportSize(size.width.toFloat(), size.height.toFloat())
            }
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { viewModel.onTapPrimary() }
    ) {
        BackgroundLayer(
            nearScrollPx = uiState.nearScrollPx,
            farScrollPx = uiState.farScrollPx,
            cloudScrollPx = uiState.cloudScrollPx,
            palette = palette,
            nightAmount = nightAmount,
            modifier = Modifier.fillMaxSize()
        )
        RoadLayer(scrollPx = uiState.roadScrollPx, palette = palette, modifier = Modifier.fillMaxSize())
        ObstacleLayer(
            obstacles = uiState.obstacles,
            palette = palette,
            distanceMeters = effectiveDistanceForPalette,
            nightAmount = nightAmount,
            modifier = Modifier.fillMaxSize()
        )
        CyclistLayer(
            cyclist = uiState.cyclist,
            palette = palette,
            crashTiltDegrees = crashTilt.value,
            modifier = Modifier.fillMaxSize()
        )

        if (uiState.gameState == GameState.RUNNING || uiState.gameState == GameState.PAUSED) {
            DistanceHud(
                distanceMeters = uiState.distanceMeters,
                bestDistanceMeters = uiState.bestDistanceMeters,
                palette = palette,
                modifier = Modifier.align(Alignment.TopEnd)
            )
            PauseButton(
                isPaused = uiState.gameState == GameState.PAUSED,
                onClick = { viewModel.togglePause() },
                palette = palette,
                modifier = Modifier.align(Alignment.TopStart)
            )
        }

        if (uiState.gameState == GameState.READY) {
            StartOverlay(palette = palette, modifier = Modifier.align(Alignment.Center))
        }

        if (uiState.gameState == GameState.PAUSED) {
            PausedOverlay(
                palette = palette,
                soundEnabled = soundEnabled,
                hapticsEnabled = hapticsEnabled,
                onToggleSound = { feedbackController.toggleSound() },
                onToggleHaptics = { feedbackController.toggleHaptics() },
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (uiState.gameState == GameState.GAME_OVER) {
            GameOverOverlay(
                finalDistanceMeters = uiState.finalDistanceMeters ?: uiState.distanceMeters,
                bestDistanceMeters = uiState.bestDistanceMeters,
                isNewBest = uiState.isNewBest,
                palette = palette,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}
