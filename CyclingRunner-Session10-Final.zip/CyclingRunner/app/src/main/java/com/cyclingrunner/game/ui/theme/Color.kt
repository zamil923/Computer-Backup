package com.cyclingrunner.game.ui.theme

import androidx.compose.ui.graphics.Color

// Day mode palette. Night mode (Session 7) will introduce an inverted
// palette alongside this one rather than replacing it.
val GameOffWhite = Color(0xFFFAFAFA)
val GameBlack = Color(0xFF111111)
val GameGray = Color(0xFFBDBDBD)
val GameLightGray = Color(0xFFE3E3E3)
