package com.cyclingrunner.game.game

/**
 * A single active obstacle instance, in the same viewport-pixel space
 * [CyclistGeometry] and the renderer already use.
 *
 * [x] is the obstacle's LEFT edge. It decreases each frame by
 * screenSpeed*dt, where screenSpeed = worldSpeed - [relativeVelocityDpPerSec]
 * (see [ObstacleMotion]) — a stationary obstacle (relativeVelocity = 0)
 * moves at exactly the shared world speed like the road; a moving hazard
 * (Session 5's SLOW_VEHICLE/MOVING_DOG) closes the gap more slowly, per
 * the spec's screenVelocity = -worldSpeed + relativeVelocity formula.
 * There is still only one shared world speed — this is a per-obstacle
 * offset from it, not a second speed system.
 *
 * [hasBeenHit] exists purely to prevent a single physical impact from
 * generating a collision event on every frame it remains overlapping —
 * once true, [CollisionSystem] always reports no further hit for this
 * instance. Session 6 owns whatever full crash/game-over response
 * eventually follows a hit; this only detects and flags it once.
 */
data class Obstacle(
    val id: Long,
    val type: ObstacleType,
    val x: Float,
    val width: Float,
    val height: Float,
    val hasBeenHit: Boolean = false,
    val relativeVelocityDpPerSec: Float = 0f
)
