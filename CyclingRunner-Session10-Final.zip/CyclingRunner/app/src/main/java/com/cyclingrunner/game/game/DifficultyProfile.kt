package com.cyclingrunner.game.game

/**
 * The full set of tuning values active at a given distance. [GameEngine]
 * requests one from [DifficultyModel] each frame rather than reading
 * scattered thresholds directly, so every difficulty-dependent system
 * (speed, spawn frequency, obstacle pool, moving-hazard chance) reads
 * from one consistent snapshot.
 */
data class DifficultyProfile(
    val tier: DifficultyTier,
    val worldSpeedDpPerSec: Float,
    val minSpawnIntervalSeconds: Float,
    val maxSpawnIntervalSeconds: Float,
    val allowedObstacleTypes: Set<ObstacleType>,
    val movingObstacleChance: Float
)
