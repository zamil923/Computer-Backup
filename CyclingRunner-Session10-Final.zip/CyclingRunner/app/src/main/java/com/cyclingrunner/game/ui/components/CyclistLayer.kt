package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.cyclingrunner.game.game.CyclistGeometry
import com.cyclingrunner.game.game.CyclistState
import com.cyclingrunner.game.game.GameConfig
import com.cyclingrunner.game.ui.theme.WorldPalette
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * An original, simplified cycling silhouette (helmet, head, torso, arm to
 * handlebar, upper/lower legs, frame, seat, two wheels, crank) — not a
 * copy of any existing game's character. Geometry (wheel positions,
 * radius, ground level) comes from [CyclistGeometry] so the renderer and
 * any future collision code always agree on where the cyclist actually is.
 *
 * Session 7: the whole silhouette is drawn in [palette].foreground rather
 * than a hard-coded color, so it inverts correctly between Day and Night
 * with no branching in this file — the palette is already the right
 * blended color for the current distance by the time it gets here.
 *
 * [crashTiltDegrees] is purely a Session 6 visual layer, driven by a
 * Compose-side animation in GameScreen (not by GameEngine/simulation
 * state) — 0 in normal gameplay, so this has zero effect and zero cost
 * outside of GAME_OVER. It rotates the whole silhouette around the rear
 * wheel's ground-contact point, starting from wherever the cyclist's pose
 * (including any mid-air verticalOffset) actually was at the moment of
 * impact — never snapped to the ground first.
 */
@Composable
fun CyclistLayer(
    cyclist: CyclistState,
    palette: WorldPalette,
    crashTiltDegrees: Float = 0f,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val wheelRadiusBase = CyclistGeometry.wheelRadius(height)
        val rearWheelX = CyclistGeometry.rearWheelX(width)
        val frontWheelX = CyclistGeometry.frontWheelX(width, height)
        val wheelBottom = CyclistGeometry.wheelBottomY(height, cyclist)

        // Brief, purely cosmetic squash right after landing: slightly
        // flattened wheels for a fraction of a second, never affecting
        // verticalOffset, so it can't reintroduce a physics bounce.
        val squashAmount = if (cyclist.landingSquashSeconds > 0f) {
            (cyclist.landingSquashSeconds / GameConfig.LANDING_SQUASH_DURATION_SECONDS) *
                GameConfig.LANDING_SQUASH_MAX_FACTOR
        } else {
            0f
        }
        val wheelRadius = wheelRadiusBase * (1f - squashAmount)
        val wheelY = wheelBottom - wheelRadius
        val cyclistColor = palette.foreground

        rotate(degrees = crashTiltDegrees, pivot = Offset(rearWheelX, wheelBottom)) {
            drawWheel(Offset(rearWheelX, wheelY), wheelRadius, cyclist.wheelRotationDegrees, cyclistColor)
            drawWheel(Offset(frontWheelX, wheelY), wheelRadius, cyclist.wheelRotationDegrees, cyclistColor)

            val seatX = rearWheelX + wheelRadius * 1.1f
            val seatY = wheelY - wheelRadius * 2.6f
            val pedalCenterX = (rearWheelX + frontWheelX) / 2f
            val pedalCenterY = wheelY

            val framePath = Path().apply {
                moveTo(rearWheelX, wheelY)
                lineTo(seatX, seatY)
                lineTo(frontWheelX, wheelY)
                moveTo(seatX, seatY)
                lineTo(pedalCenterX, pedalCenterY)
            }
            drawPath(
                path = framePath,
                color = cyclistColor,
                style = Stroke(width = wheelRadius * 0.22f, cap = StrokeCap.Round)
            )

            // Subtle riding bob, derived from the pedal phase (GameEngine) so
            // it can never drift out of sync with the legs, even across
            // pause/resume.
            val bob = sin(cyclist.bodyBobPhase) * (height * 0.004f)
            val hip = Offset(seatX, seatY - bob)
            val shoulder = Offset(hip.x - wheelRadius * 0.6f, hip.y - wheelRadius * 2.1f)
            val handlebar = Offset(frontWheelX - wheelRadius * 0.2f, wheelY - wheelRadius * 2.0f)
            val headCenter = Offset(shoulder.x - wheelRadius * 0.15f, shoulder.y - wheelRadius * 0.9f)

            // Legs first so the torso/arm silhouette reads cleanly on top at the hip.
            drawPedalingLegs(
                hip = hip,
                pedalCenter = Offset(pedalCenterX, pedalCenterY),
                crankRadius = wheelRadius * 0.7f,
                phase = cyclist.pedalPhase,
                strokeWidth = wheelRadius * 0.18f,
                color = cyclistColor
            )

            // Torso + arm. The hand end (handlebar) never animates
            // independently, so hands stay visually anchored to the
            // handlebar as required.
            val bodyPath = Path().apply {
                moveTo(hip.x, hip.y)
                lineTo(shoulder.x, shoulder.y)
                lineTo(handlebar.x, handlebar.y)
            }
            drawPath(
                path = bodyPath,
                color = cyclistColor,
                style = Stroke(width = wheelRadius * 0.2f, cap = StrokeCap.Round)
            )

            // Head + helmet as one filled circle — stays readable at small sizes.
            drawCircle(color = cyclistColor, radius = wheelRadius * 0.55f, center = headCenter)
        }
    }
}

private fun DrawScope.drawWheel(center: Offset, radius: Float, rotationDegrees: Float, color: Color) {
    drawCircle(
        color = color,
        radius = radius,
        center = center,
        style = Stroke(width = radius * 0.16f)
    )
    // A handful of spokes is enough to sell rotation without a busy 30-spoke wheel.
    val spokeCount = 3
    for (i in 0 until spokeCount) {
        val angle = Math.toRadians((rotationDegrees + i * (360f / spokeCount)).toDouble())
        val end = Offset(
            x = center.x + (cos(angle) * radius).toFloat(),
            y = center.y + (sin(angle) * radius).toFloat()
        )
        drawLine(color = color, start = center, end = end, strokeWidth = radius * 0.1f)
    }
}

private fun DrawScope.drawPedalingLegs(
    hip: Offset,
    pedalCenter: Offset,
    crankRadius: Float,
    phase: Float,
    strokeWidth: Float,
    color: Color
) {
    // Two legs, half a crank revolution out of phase, each foot tracing the
    // crank circle exactly so it never visibly detaches from the pedal.
    for (legIndex in 0..1) {
        val legPhase = phase + legIndex * Math.PI.toFloat()
        val foot = Offset(
            x = pedalCenter.x + cos(legPhase) * crankRadius,
            y = pedalCenter.y + sin(legPhase) * crankRadius * 0.6f
        )
        val knee = solveForwardKnee(hip, foot)

        val legPath = Path().apply {
            moveTo(hip.x, hip.y)
            lineTo(knee.x, knee.y)
            lineTo(foot.x, foot.y)
        }
        drawPath(
            path = legPath,
            color = color,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
    }
}

/**
 * Lightweight two-bone knee solve: treats hip->knee and knee->foot as equal
 * segments sized relative to the current hip-foot distance (not a fixed
 * leg length — exact IK isn't required for this style), and always bends
 * the knee toward the front of the bike so the leg never reads as bending
 * backward, no matter where the foot is on the crank circle.
 */
private fun solveForwardKnee(hip: Offset, foot: Offset): Offset {
    val dx = foot.x - hip.x
    val dy = foot.y - hip.y
    val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)

    val legSegment = dist * 0.52f
    val halfDist = dist / 2f
    val bendHeight = sqrt((legSegment * legSegment - halfDist * halfDist).coerceAtLeast(0f))

    val midX = (hip.x + foot.x) / 2f
    val midY = (hip.y + foot.y) / 2f

    // Perpendicular to hip->foot, sign-locked so the knee always sits
    // forward of the hip rather than flipping toward the rear wheel.
    var perpX = -dy / dist
    var perpY = dx / dist
    if (perpX < 0f) {
        perpX = -perpX
        perpY = -perpY
    }

    return Offset(midX + perpX * bendHeight, midY + perpY * bendHeight)
}
