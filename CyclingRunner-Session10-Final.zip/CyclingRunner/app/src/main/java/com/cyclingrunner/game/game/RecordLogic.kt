package com.cyclingrunner.game.game

/**
 * Pure best-distance comparison, kept separate from persistence
 * ([BestDistanceStore], which is the only place an actual write happens)
 * and from [GameEngine]'s broader collision-to-GAME_OVER transition, so
 * the comparison itself can be tested in isolation.
 *
 * A distance strictly greater than the previous best is a new best; equal
 * or lower is not (a tie doesn't count, and a first-ever completed run
 * with previousBestMeters = 0 naturally becomes the best the moment its
 * distance exceeds 0).
 */
object RecordLogic {

    fun isNewBest(finalDistanceMeters: Int, previousBestMeters: Int): Boolean =
        finalDistanceMeters > previousBestMeters

    fun updatedBest(finalDistanceMeters: Int, previousBestMeters: Int): Int =
        if (isNewBest(finalDistanceMeters, previousBestMeters)) finalDistanceMeters else previousBestMeters
}
