package com.cyclingrunner.game.audio

import android.content.Context
import com.cyclingrunner.game.game.FeedbackAction
import com.cyclingrunner.game.game.FeedbackMapper
import com.cyclingrunner.game.game.GameEvent
import com.cyclingrunner.game.game.GameSettingsStore
import com.cyclingrunner.game.game.GameState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Consumes existing [GameEvent]s (via [onEvent], called from a
 * `LaunchedEffect` collecting [com.cyclingrunner.game.game.GameViewModel.events]
 * in GameScreen) and turns them into audio/haptic feedback through
 * [GameAudioManager]/[GameHapticController]. Purely an observer: never
 * reads or writes [com.cyclingrunner.game.game.GameUiState], never calls
 * into [com.cyclingrunner.game.game.GameEngine], and never gates or
 * delays gameplay — the only delay anywhere in this class is the small,
 * fixed one below the celebratory chime for a genuine New Best, so it
 * doesn't collide with the crash sound firing in the same instant for a
 * record-breaking run. That delay never blocks Tap to Restart, which
 * keeps working immediately through the ordinary GameViewModel path this
 * controller has no part in.
 */
class GameFeedbackController(
    context: Context,
    private val scope: CoroutineScope,
    settingsStore: GameSettingsStore = GameSettingsStore(context)
) {
    private val audio = GameAudioManager(context)
    private val haptics = GameHapticController(context)
    private val settings = settingsStore

    val soundEnabled: StateFlow<Boolean> = settings.soundEnabledFlow
        .stateIn(scope, SharingStarted.Eagerly, true)
    val hapticsEnabled: StateFlow<Boolean> = settings.hapticsEnabledFlow
        .stateIn(scope, SharingStarted.Eagerly, true)

    private var pendingNewBestJob: Job? = null

    fun toggleSound() {
        scope.launch { settings.setSoundEnabled(!soundEnabled.value) }
    }

    fun toggleHaptics() {
        scope.launch { settings.setHapticsEnabled(!hapticsEnabled.value) }
    }

    fun onEvent(event: GameEvent) {
        when (FeedbackMapper.map(event)) {
            FeedbackAction.JUMP -> {
                if (soundEnabled.value) audio.playJump()
                if (hapticsEnabled.value) haptics.jump()
            }
            FeedbackAction.LAND -> {
                if (soundEnabled.value) audio.playLand()
                if (hapticsEnabled.value) haptics.land()
            }
            FeedbackAction.CRASH -> {
                if (soundEnabled.value) audio.playCrash()
                if (hapticsEnabled.value) haptics.crash()
            }
            FeedbackAction.NEW_BEST -> scheduleNewBestFeedback()
        }
    }

    private fun scheduleNewBestFeedback() {
        // Cancel-and-replace rather than accumulate: only one New Best
        // chime can ever be meaningfully pending at a time.
        pendingNewBestJob?.cancel()
        pendingNewBestJob = scope.launch {
            delay(NEW_BEST_DELAY_MILLIS)
            if (soundEnabled.value) audio.playNewBest()
            if (hapticsEnabled.value) haptics.newBest()
        }
    }

    /**
     * Called from a `LaunchedEffect(uiState.gameState)` in GameScreen.
     * The only way to observe RUNNING right after a pending New Best was
     * scheduled (which only ever happens on the way into GAME_OVER) is a
     * genuine restart — so this safely cancels a stale chime without
     * needing GameViewModel to expose a dedicated "restarted" signal.
     */
    fun onGameStateChanged(gameState: GameState) {
        if (gameState == GameState.RUNNING) {
            pendingNewBestJob?.cancel()
            pendingNewBestJob = null
        }
    }

    /** Call when the owning composable leaves composition. */
    fun release() {
        pendingNewBestJob?.cancel()
        audio.release()
    }

    private companion object {
        const val NEW_BEST_DELAY_MILLIS = 220L
    }
}
