package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cyclingrunner.game.ui.theme.WorldPalette

/**
 * Session 7: text color comes from [palette].overlay — if paused during
 * Night, this stays Night-colored (readable white-on-dark), rather than
 * forcing Day colors just because it's an overlay.
 *
 * Session 9: adds small SOUND/HAPTICS toggle rows below TAP TO RESUME —
 * the "small settings/pause panel" location the spec calls for, rather
 * than a separate settings screen. Each row has its own clickable
 * modifier, so tapping a toggle can never also resume the game through
 * GameScreen's whole-screen tap underneath (the same pattern PauseButton
 * already relies on). Toggling never touches gameplay state — see
 * GameFeedbackController, which only reads/writes its own settings store.
 */
@Composable
fun PausedOverlay(
    palette: WorldPalette,
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    onToggleSound: () -> Unit,
    onToggleHaptics: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "PAUSED",
            color = palette.overlay,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "TAP TO RESUME",
            color = palette.overlay,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 8.dp)
        )

        Row(modifier = Modifier.padding(top = 18.dp)) {
            SettingsToggle(
                label = "SOUND",
                enabled = soundEnabled,
                onClick = onToggleSound,
                palette = palette
            )
            SettingsToggle(
                label = "HAPTICS",
                enabled = hapticsEnabled,
                onClick = onToggleHaptics,
                palette = palette,
                modifier = Modifier.padding(start = 24.dp)
            )
        }
    }
}

@Composable
private fun SettingsToggle(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    palette: WorldPalette,
    modifier: Modifier = Modifier
) {
    val stateText = if (enabled) "ON" else "OFF"
    Text(
        text = "$label: $stateText",
        color = if (enabled) palette.overlay else palette.secondaryForeground,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        modifier = modifier
            // Padding first, so the actual touch target is comfortably
            // larger than the visible text alone.
            .padding(vertical = 10.dp, horizontal = 6.dp)
            .clickable { onClick() }
            .clearAndSetSemantics {
                contentDescription = "$label ${if (enabled) "on" else "off"}. Double tap to toggle."
            }
    )
}
