package com.cyclingrunner.game.game

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Owns the single source of truth ([uiState]) and the game loop.
 *
 * The loop is a simple delay-based coroutine using measured wall-clock
 * delta time (not a fixed step), so gameplay speed stays constant across
 * devices with different refresh rates. It only runs while
 * [GameState.RUNNING], and lifecycle callbacks route through
 * [onAppBackgrounded] so distance can't silently accumulate off-screen.
 *
 * Session 3: the same loop now also detects the isAirborne->grounded
 * transition each tick and emits [GameEvent.Landed] — there is no second
 * loop or coroutine for jump physics, it rides on the existing one.
 *
 * Session 4: the same loop also diffs obstacles by id to emit
 * [GameEvent.ObstacleHit] the instant [Obstacle.hasBeenHit] flips true —
 * still one loop, no per-obstacle coroutines or animations.
 *
 * Session 6: GameEngine itself detects the collision and flips
 * [GameState.GAME_OVER] (see [GameEngine.advance]); this loop only reacts
 * to that edge once — persisting an improved best via [BestDistanceStore]
 * and emitting [GameEvent.NewBest] — and then stops on its own next
 * condition check, since gameState is no longer RUNNING. No second loop,
 * no crash-animation timer here: the crash visual is handled entirely on
 * the Compose side (see GameScreen), driven by [GameUiState.crashState]
 * as a trigger key, not by anything this ViewModel ticks forward.
 */
class GameViewModel(
    private val bestDistanceStore: BestDistanceStore
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState

    private val _events = MutableSharedFlow<GameEvent>(extraBufferCapacity = 4)
    /** Consumed by GameFeedbackController (Session 9) for audio/haptics; also available for future one-shot UI reactions. */
    val events: SharedFlow<GameEvent> = _events

    private var loopJob: Job? = null

    init {
        viewModelScope.launch {
            bestDistanceStore.bestDistanceFlow.collect { best ->
                _uiState.update { it.copy(bestDistanceMeters = best) }
            }
        }
    }

    /** The screen's single tap target. Behavior depends on current state. */
    fun onTapPrimary() {
        when (_uiState.value.gameState) {
            GameState.READY -> startRun()
            GameState.PAUSED -> resume()
            GameState.RUNNING -> tryJump()
            GameState.GAME_OVER -> restart()
        }
    }

    fun togglePause() {
        when (_uiState.value.gameState) {
            GameState.RUNNING -> pause()
            GameState.PAUSED -> resume()
            else -> Unit
        }
    }

    fun restart() {
        stopLoop()
        // See GameEngine.freshRunState: preserves bestDistanceMeters and
        // viewport dimensions, resets everything else (distance, obstacles,
        // spawn timer, difficulty, cyclist vertical state, crash/final-
        // distance/isNewBest) to a brand-new run's defaults.
        _uiState.value = GameEngine.freshRunState(_uiState.value)
        startLoop()
    }

    /** Called from the Activity on ON_STOP so the run pauses instead of running hidden. */
    fun onAppBackgrounded() {
        if (_uiState.value.gameState == GameState.RUNNING) {
            pause()
        }
    }

    /**
     * Called from the Activity on ON_START. Deliberately does not
     * auto-resume — the player must tap, matching the explicit
     * pause/resume flow the spec calls for.
     */
    fun onAppForegrounded() = Unit

    /**
     * Called from GameScreen whenever Compose reports the actual measured
     * gameplay canvas size (via Modifier.onSizeChanged). GameEngine gates
     * obstacle spawning/collision on this being known, since a spawn or
     * hitbox position is meaningless before real screen dimensions exist.
     * Guarded against redundant writes since onSizeChanged can report the
     * same size more than once.
     */
    fun reportViewportSize(widthPx: Float, heightPx: Float) {
        _uiState.update {
            if (it.viewportWidthPx == widthPx && it.viewportHeightPx == heightPx) {
                it
            } else {
                it.copy(viewportWidthPx = widthPx, viewportHeightPx = heightPx)
            }
        }
    }

    /**
     * Grounded-only jump trigger. [GameEngine.applyJumpImpulse] already
     * no-ops when airborne, so this can't double/triple-jump; the extra
     * [CyclistState.isAirborne] check here just avoids emitting a spurious
     * [GameEvent.JumpStarted] for a tap that didn't actually do anything.
     */
    private fun tryJump() {
        val cyclist = _uiState.value.cyclist
        if (cyclist.isAirborne) return
        _uiState.update { it.copy(cyclist = GameEngine.applyJumpImpulse(it.cyclist)) }
        _events.tryEmit(GameEvent.JumpStarted)
    }

    private fun startRun() {
        _uiState.update { it.copy(gameState = GameState.RUNNING) }
        startLoop()
    }

    private fun pause() {
        // No special-casing for "paused mid-air": this only flips gameState
        // and stops the loop, so verticalOffset/verticalVelocity/isAirborne
        // are left exactly as they were — gravity simply won't advance them
        // again until resume restarts the loop.
        _uiState.update { it.copy(gameState = GameState.PAUSED) }
        stopLoop()
        viewModelScope.launch { bestDistanceStore.saveIfBetter(_uiState.value.distanceMeters) }
    }

    private fun resume() {
        _uiState.update { it.copy(gameState = GameState.RUNNING) }
        startLoop()
    }

    private fun startLoop() {
        if (loopJob?.isActive == true) return
        loopJob = viewModelScope.launch {
            var lastTimeNanos = System.nanoTime()
            while (isActive && _uiState.value.gameState == GameState.RUNNING) {
                delay(GameConfig.TARGET_FRAME_DELAY_MS)
                val now = System.nanoTime()
                val deltaSeconds = (now - lastTimeNanos) / 1_000_000_000f
                lastTimeNanos = now

                val previous = _uiState.value
                val next = GameEngine.advance(previous, deltaSeconds)
                _uiState.value = next

                if (previous.cyclist.isAirborne && !next.cyclist.isAirborne) {
                    _events.tryEmit(GameEvent.Landed)
                }
                emitNewObstacleHitEvents(previous.obstacles, next.obstacles)

                if (previous.gameState == GameState.RUNNING && next.gameState == GameState.GAME_OVER) {
                    onRunCompleted(next)
                }
            }
        }
    }

    /**
     * Fires exactly once per completed run, on the same frame GameEngine
     * detected the collision (the while-loop's own condition then stops
     * it, since gameState is no longer RUNNING — no separate stop call
     * needed here). [BestDistanceStore.saveIfBetter] only ever writes when
     * the new value is actually greater, so even if this were somehow
     * invoked twice for the same finalDistanceMeters it would still only
     * persist once — but the RUNNING->GAME_OVER edge this is gated on
     * cannot itself repeat without an intervening restart.
     */
    private fun onRunCompleted(finishedState: GameUiState) {
        val finalDistance = finishedState.finalDistanceMeters ?: finishedState.distanceMeters
        viewModelScope.launch { bestDistanceStore.saveIfBetter(finalDistance) }
        if (finishedState.isNewBest) {
            _events.tryEmit(GameEvent.NewBest)
        }
    }

    /**
     * Diffs hasBeenHit by obstacle id (the same before/after comparison
     * pattern used for Landed above) rather than having GameEngine return
     * events directly, keeping it a pure (state, dt) -> state function.
     * [Obstacle.hasBeenHit] itself already guarantees at most one
     * transition per obstacle instance, so this can't double-fire for the
     * same impact even across multiple frames of continued overlap.
     */
    private fun emitNewObstacleHitEvents(previous: List<Obstacle>, next: List<Obstacle>) {
        if (next.isEmpty()) return
        val previouslyHit = previous.filter { it.hasBeenHit }.map { it.id }.toSet()
        next.forEach { obstacle ->
            if (obstacle.hasBeenHit && obstacle.id !in previouslyHit) {
                _events.tryEmit(GameEvent.ObstacleHit(obstacle.type))
            }
        }
    }

    private fun stopLoop() {
        loopJob?.cancel()
        loopJob = null
    }

    override fun onCleared() {
        super.onCleared()
        stopLoop()
    }

    companion object {
        fun factory(context: Context): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return GameViewModel(BestDistanceStore(context.applicationContext)) as T
                }
            }
    }
}
