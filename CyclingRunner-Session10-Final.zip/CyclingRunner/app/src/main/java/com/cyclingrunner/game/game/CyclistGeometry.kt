package com.cyclingrunner.game.game

/**
 * Pure geometry helpers describing where the cyclist sits in the gameplay
 * viewport. Shared by the renderer (CyclistLayer/RoadLayer) so ground level
 * and cyclist position can never drift out of agreement between drawing
 * code and gameplay code, and ready for Session 4 to reuse for collision
 * bounds without re-deriving these numbers from scratch.
 */
object CyclistGeometry {

    data class Bounds(val left: Float, val top: Float, val right: Float, val bottom: Float)

    fun groundY(viewportHeight: Float): Float =
        viewportHeight * GameConfig.GROUND_Y_FRACTION

    fun wheelRadius(viewportHeight: Float): Float =
        viewportHeight * GameConfig.WHEEL_RADIUS_HEIGHT_FRACTION

    fun rearWheelX(viewportWidth: Float): Float =
        viewportWidth * GameConfig.CYCLIST_X_FRACTION

    fun frontWheelX(viewportWidth: Float, viewportHeight: Float): Float =
        rearWheelX(viewportWidth) + wheelRadius(viewportHeight) * GameConfig.WHEEL_SPACING_FACTOR

    /**
     * Current bottom edge of the wheels: ground level when grounded, and
     * rising above it while airborne. Exposed on its own (not just buried
     * in [approximateBounds]) since Session 4's obstacle clearance check
     * is fundamentally "is this value above the obstacle's top?".
     */
    fun wheelBottomY(viewportHeight: Float, cyclist: CyclistState): Float =
        groundY(viewportHeight) - cyclist.verticalOffset

    /** True when the cyclist is on the ground and could jump right now. */
    fun isGrounded(cyclist: CyclistState): Boolean = !cyclist.isAirborne

    /**
     * Approximate axis-aligned bounding box for the whole cyclist+bicycle
     * silhouette, in the same viewport pixel space the renderer draws in.
     * Not rendered anywhere (no debug overlay) — it exists purely so
     * Session 4's collision system has an already-agreed-upon shape
     * instead of reverse-engineering one from drawing code.
     *
     * [Bounds.bottom] now correctly follows [wheelBottomY] rather than a
     * fixed ground line: while [CyclistState.verticalOffset] was always 0
     * (Session 2, before jump input existed) those were the same value, so
     * this went unnoticed; now that a real jump can lift the cyclist off
     * the ground, distinguishing "on ground" from "airborne above an
     * obstacle" — which Session 4 needs — requires the box to actually rise.
     */
    fun approximateBounds(viewportWidth: Float, viewportHeight: Float, cyclist: CyclistState): Bounds {
        val radius = wheelRadius(viewportHeight)
        val rearX = rearWheelX(viewportWidth)
        val frontX = frontWheelX(viewportWidth, viewportHeight)
        val wheelBottom = wheelBottomY(viewportHeight, cyclist)
        val wheelY = wheelBottom - radius
        val headTopY = wheelY - radius * 4.6f

        return Bounds(
            left = rearX - radius,
            top = headTopY,
            right = frontX + radius,
            bottom = wheelBottom
        )
    }
}
