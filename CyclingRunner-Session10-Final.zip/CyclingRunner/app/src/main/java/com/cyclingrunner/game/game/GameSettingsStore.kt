package com.cyclingrunner.game.game

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Sound/Haptics ON-OFF preferences (Session 9), persisted in the exact
 * same DataStore file [BestDistanceStore] already established via
 * [Context.gameDataStore] — one small local preferences file for the
 * whole app, not a second parallel persistence system. Both default to
 * `true` (ON) per the spec.
 */
class GameSettingsStore(private val context: Context) {

    private val soundEnabledKey = booleanPreferencesKey("sound_enabled")
    private val hapticsEnabledKey = booleanPreferencesKey("haptics_enabled")

    val soundEnabledFlow: Flow<Boolean> = context.gameDataStore.data.map { prefs ->
        prefs[soundEnabledKey] ?: true
    }

    val hapticsEnabledFlow: Flow<Boolean> = context.gameDataStore.data.map { prefs ->
        prefs[hapticsEnabledKey] ?: true
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.gameDataStore.edit { prefs -> prefs[soundEnabledKey] = enabled }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.gameDataStore.edit { prefs -> prefs[hapticsEnabledKey] = enabled }
    }
}
