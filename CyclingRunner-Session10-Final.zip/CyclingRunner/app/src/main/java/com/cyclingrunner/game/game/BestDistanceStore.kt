package com.cyclingrunner.game.game

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Backing DataStore for all of the app's small local preferences —
 * best distance (below) and, since Session 9, sound/haptics settings
 * (see GameSettingsStore). `internal` rather than `private` specifically
 * so GameSettingsStore can share this exact same delegate instance:
 * Android's DataStore throws at runtime if two separate
 * `preferencesDataStore(name = ...)` delegates ever target the same file
 * name, so reusing one file means reusing one delegate, not just the
 * same string name in a second declaration.
 */
internal val Context.gameDataStore by preferencesDataStore(name = "cycling_runner_prefs")

/**
 * Minimal local persistence for the best distance, per the spec's note
 * that this may be included now "if it doesn't complicate Session 1".
 * Session 6 (game over flow) will be the main place that calls
 * [saveIfBetter]; Session 1 only needs it to survive app restarts.
 */
class BestDistanceStore(private val context: Context) {

    private val bestDistanceKey = intPreferencesKey("best_distance_meters")

    val bestDistanceFlow: Flow<Int> = context.gameDataStore.data.map { prefs ->
        prefs[bestDistanceKey] ?: 0
    }

    suspend fun saveIfBetter(distanceMeters: Int) {
        context.gameDataStore.edit { prefs ->
            val current = prefs[bestDistanceKey] ?: 0
            if (distanceMeters > current) {
                prefs[bestDistanceKey] = distanceMeters
            }
        }
    }
}
