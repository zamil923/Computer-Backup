package com.cyclingrunner.game.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CyclingRunnerColorScheme = lightColorScheme(
    background = GameOffWhite,
    surface = GameOffWhite,
    onBackground = GameBlack,
    onSurface = GameBlack,
    primary = GameBlack,
    onPrimary = GameOffWhite
)

@Composable
fun CyclingRunnerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CyclingRunnerColorScheme,
        content = content
    )
}
