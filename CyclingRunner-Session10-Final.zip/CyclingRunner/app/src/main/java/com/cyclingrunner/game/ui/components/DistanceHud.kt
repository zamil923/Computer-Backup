package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cyclingrunner.game.ui.theme.WorldPalette

/**
 * "DISTANCE 00042 m" / "BEST 05670 m" in a monospaced, digital-looking
 * style, placed in a safe HUD corner (caller aligns via [modifier]).
 *
 * Session 7: text color comes from [palette].hud rather than a hard-coded
 * color, so it stays readable in both Day and Night.
 */
@Composable
fun DistanceHud(
    distanceMeters: Int,
    bestDistanceMeters: Int,
    palette: WorldPalette,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(top = 20.dp, end = 20.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text(
            text = "DISTANCE ${distanceMeters.toString().padStart(5, '0')} m",
            color = palette.hud,
            fontSize = 16.sp,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.End
        )
        Text(
            text = "BEST ${bestDistanceMeters.toString().padStart(5, '0')} m",
            color = palette.hud,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.End
        )
    }
}
