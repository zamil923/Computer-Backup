package com.cyclingrunner.game.game

/**
 * The game's visual world phase — Day or Night. Purely a rendering
 * concern (see [DayNightModel]): nothing in the simulation layer reads
 * or branches on this. Never shown to the player as a "Level"; the ride
 * is one continuous endless run that just looks different over time.
 */
enum class WorldPhase {
    DAY,
    NIGHT
}
