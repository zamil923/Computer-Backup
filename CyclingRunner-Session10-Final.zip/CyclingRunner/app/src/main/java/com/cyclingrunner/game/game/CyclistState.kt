package com.cyclingrunner.game.game

/**
 * Physical + animation state of the cyclist.
 *
 * [verticalOffset], [verticalVelocity] and [isAirborne] are the jump physics
 * introduced conceptually in Session 1 and wired to real input in Session 3
 * (see [GameEngine.applyJumpImpulse] and [GameEngine.advanceCyclist]).
 *
 * [landingSquashSeconds] is a purely cosmetic, decaying timer — not physics —
 * that the renderer uses for a brief compression effect right after landing.
 * It never affects [verticalOffset] itself, so it can't reintroduce bouncing.
 */
data class CyclistState(
    val wheelRotationDegrees: Float = 0f,
    val pedalPhase: Float = 0f,
    val bodyBobPhase: Float = 0f,
    val verticalOffset: Float = 0f,
    val verticalVelocity: Float = 0f,
    val isAirborne: Boolean = false,
    val landingSquashSeconds: Float = 0f
)
