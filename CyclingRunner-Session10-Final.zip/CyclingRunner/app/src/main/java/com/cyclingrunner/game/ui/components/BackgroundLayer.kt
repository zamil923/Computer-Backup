package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.cyclingrunner.game.ui.theme.WorldPalette

/**
 * Layered parallax scenery. Each layer takes its own scroll offset —
 * [farScrollPx] (distant mountains, slowest), [nearScrollPx] (low near
 * terrain, medium) and [cloudScrollPx] (clouds, slowest of all) — all of
 * which GameEngine derives from the single shared world speed, so the
 * layers stay in correct relative motion to each other and to the road
 * without this composable doing any further scaling itself.
 *
 * Session 7: mountains/near-terrain/clouds are drawn in [palette]'s
 * distantScenery color instead of a hard-coded gray, and [nightAmount]
 * (0 = Day, 1 = Night, the same value the palette itself was blended
 * from) drives a moon and a handful of stars fading in — and clouds
 * partially fading down rather than vanishing — as Night approaches.
 * Nothing here resets any scroll offset, so parallax never jumps when
 * the phase changes; the existing offsets keep accumulating exactly as
 * before, this file just changes what color/opacity draws at them.
 */
@Composable
fun BackgroundLayer(
    nearScrollPx: Float,
    farScrollPx: Float,
    cloudScrollPx: Float,
    palette: WorldPalette,
    nightAmount: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        drawStars(cloudScrollPx, width, height, palette, nightAmount)
        drawMoon(cloudScrollPx, width, height, palette, nightAmount)
        drawClouds(cloudScrollPx, width, height, palette, nightAmount)
        drawMountains(farScrollPx, width, height, palette)
        drawNearTerrain(nearScrollPx, width, height, palette)
    }
}

private fun DrawScope.drawMountains(scrollPx: Float, width: Float, height: Float, palette: WorldPalette) {
    val horizonY = height * 0.62f
    val tileWidth = width * 0.9f
    val offset = scrollPx % tileWidth

    for (tile in -1..1) {
        val baseX = tile * tileWidth - offset
        val path = Path().apply {
            moveTo(baseX, horizonY)
            lineTo(baseX + tileWidth * 0.18f, horizonY - height * 0.10f)
            lineTo(baseX + tileWidth * 0.36f, horizonY - height * 0.03f)
            lineTo(baseX + tileWidth * 0.55f, horizonY - height * 0.14f)
            lineTo(baseX + tileWidth * 0.78f, horizonY - height * 0.05f)
            lineTo(baseX + tileWidth, horizonY)
            close()
        }
        drawPath(path = path, color = palette.distantScenery)
    }
}

/** A thin mid-distance terrain line — the "near" parallax layer between the
 *  mountains and the road, per the Session 2 layering request. */
private fun DrawScope.drawNearTerrain(scrollPx: Float, width: Float, height: Float, palette: WorldPalette) {
    val lineY = height * 0.74f
    val tileWidth = width * 0.5f
    val offset = scrollPx % tileWidth

    for (tile in -1..2) {
        val baseX = tile * tileWidth - offset
        val path = Path().apply {
            moveTo(baseX, lineY + height * 0.02f)
            lineTo(baseX + tileWidth * 0.3f, lineY)
            lineTo(baseX + tileWidth * 0.6f, lineY + height * 0.015f)
            lineTo(baseX + tileWidth, lineY + height * 0.02f)
        }
        drawPath(path = path, color = palette.distantScenery, style = Stroke(width = 2f))
    }
}

private fun DrawScope.drawClouds(scrollPx: Float, width: Float, height: Float, palette: WorldPalette, nightAmount: Float) {
    // Fade down (not away) toward Night, per spec: "do not abruptly remove them."
    val alpha = (1f - nightAmount * 0.6f).coerceIn(0.4f, 1f)
    val color = palette.distantScenery.copy(alpha = alpha)
    val offset = scrollPx % width
    drawCloud(Offset(width * 0.7f - offset, height * 0.18f), width * 0.09f, color)
    drawCloud(Offset(width * 1.3f - offset, height * 0.28f), width * 0.06f, color)
    drawCloud(Offset(width * 0.15f - offset, height * 0.22f), width * 0.07f, color)
}

private fun DrawScope.drawCloud(center: Offset, radius: Float, color: Color) {
    drawCircle(color = color, radius = radius, center = center)
    drawCircle(color = color, radius = radius * 0.7f, center = center.copy(x = center.x + radius * 0.9f))
    drawCircle(color = color, radius = radius * 0.6f, center = center.copy(x = center.x - radius * 0.8f))
}

/** One small crescent moon, subtle and away from HUD corners — visible only as Night approaches. */
private fun DrawScope.drawMoon(scrollPx: Float, width: Float, height: Float, palette: WorldPalette, nightAmount: Float) {
    if (nightAmount <= 0f) return
    // Slow parallax, same idea as clouds but even slower and fixed to one
    // general screen area rather than repeating tiles across the width.
    val driftX = (scrollPx * 0.05f) % (width * 0.4f)
    val center = Offset(width * 0.78f - driftX, height * 0.16f)
    val radius = height * 0.05f
    val color = palette.foreground.copy(alpha = nightAmount)

    drawCircle(color = color, radius = radius, center = center)
    // Crescent: cut a background-colored circle out of the moon, offset
    // slightly — negative-space technique, same one the pothole uses.
    drawCircle(
        color = palette.background.copy(alpha = nightAmount),
        radius = radius * 0.85f,
        center = center.copy(x = center.x + radius * 0.5f)
    )
}

/** A handful of small fixed stars — decoration, not a particle system. */
private fun DrawScope.drawStars(scrollPx: Float, width: Float, height: Float, palette: WorldPalette, nightAmount: Float) {
    if (nightAmount <= 0f) return
    val driftX = (scrollPx * 0.08f) % width
    val color = palette.foreground.copy(alpha = nightAmount * 0.85f)
    val starPositions = listOf(
        0.10f to 0.12f,
        0.28f to 0.22f,
        0.45f to 0.10f,
        0.58f to 0.30f,
        0.68f to 0.14f,
        0.90f to 0.25f
    )
    starPositions.forEach { (fx, fy) ->
        val x = (fx * width - driftX).let { if (it < 0f) it + width else it }
        drawCircle(color = color, radius = 1.6f, center = Offset(x, fy * height))
    }
}
