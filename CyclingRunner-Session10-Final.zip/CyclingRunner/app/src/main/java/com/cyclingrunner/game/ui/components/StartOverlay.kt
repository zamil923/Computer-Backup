package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cyclingrunner.game.ui.theme.WorldPalette

/**
 * Session 7: text color comes from [palette].overlay. In practice this is
 * always the Day palette — READY is only ever reached at distance 0
 * (app launch, or right after a restart), and the palette is a pure
 * function of distance, so it resolves to Day automatically with no
 * special-casing needed here or in GameScreen.
 */
@Composable
fun StartOverlay(palette: WorldPalette, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "CYCLING RUNNER",
            color = palette.overlay,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "TAP TO START",
            color = palette.overlay,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}
