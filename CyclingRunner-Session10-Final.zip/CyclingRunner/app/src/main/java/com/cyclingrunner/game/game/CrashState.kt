package com.cyclingrunner.game.game

/**
 * Marks that the run ended in a collision and records which obstacle type
 * caused it. Deliberately minimal: the cyclist's actual rendered pose at
 * the moment of impact (position, wheel angle, etc.) is already frozen
 * naturally once [GameState.GAME_OVER] stops the simulation loop — this
 * doesn't need to duplicate any of that. [obstacleType] is kept for
 * Session 9 (a crash sound could plausibly vary by obstacle) and for
 * accessibility/debugging context; the visual crash presentation itself
 * is intentionally generic regardless of type (including for animal
 * obstacles — no injury depiction, per spec).
 */
data class CrashState(
    val obstacleType: ObstacleType
)
