package com.cyclingrunner.game.game

/**
 * Pure, no Android dependency: (GameEvent) -> FeedbackAction. This is the
 * one part of Session 9's feedback system that's directly unit-testable
 * without an emulator/device — the actual audio/haptic execution (in the
 * `audio` package) just consumes the action this produces, and is an
 * observer only: it never influences [map]'s result and never touches
 * gameplay state.
 */
object FeedbackMapper {
    fun map(event: GameEvent): FeedbackAction = when (event) {
        is GameEvent.JumpStarted -> FeedbackAction.JUMP
        is GameEvent.Landed -> FeedbackAction.LAND
        is GameEvent.ObstacleHit -> FeedbackAction.CRASH
        is GameEvent.NewBest -> FeedbackAction.NEW_BEST
    }
}
