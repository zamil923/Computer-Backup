package com.cyclingrunner.game.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.cyclingrunner.game.game.AccentCategory
import com.cyclingrunner.game.game.ColorProgressionModel
import com.cyclingrunner.game.game.ObstacleType

/**
 * Muted, restrained accent colors per [AccentCategory] — never full
 * saturation, never neon. Two instances below (Day/Night) are blended by
 * [accentColorForObstacle] using the same continuous nightAmount value
 * [WorldPalette] itself blends from, so an accent's Day↔Night variant
 * transitions exactly as smoothly as the rest of the world does — no
 * separate, potentially out-of-sync animation.
 *
 * Vehicle categories get three curated variants (see
 * [accentColorForObstacle]'s deterministic obstacle.id-based selection)
 * rather than one fixed color, for a little variety without randomness.
 */
data class WorldAccents(
    val stone: Color,
    val wood: Color,
    val vegetation: Color,
    val warning: Color,
    val structure: Color,
    val vehiclePrimary: Color,
    val vehicleSecondary: Color,
    val vehicleTertiary: Color
)

val DAY_ACCENTS = WorldAccents(
    stone = Color(0xFF8A7A68),
    wood = Color(0xFF9C7A52),
    vegetation = Color(0xFF6B8A5C),
    warning = Color(0xFFC98A4A),
    structure = Color(0xFF7C8FA0),
    vehiclePrimary = Color(0xFF5E7DA3),
    vehicleSecondary = Color(0xFFA05E5E),
    vehicleTertiary = Color(0xFFA08A54)
)

val NIGHT_ACCENTS = WorldAccents(
    stone = Color(0xFF6E6053),
    wood = Color(0xFF6E5439),
    vegetation = Color(0xFF46654B),
    warning = Color(0xFF9C6234),
    structure = Color(0xFF5C6C7A),
    vehiclePrimary = Color(0xFF405C7A),
    vehicleSecondary = Color(0xFF7A4040),
    vehicleTertiary = Color(0xFF7A6838)
)

private fun accentFor(accents: WorldAccents, category: AccentCategory, obstacleId: Long): Color =
    when (category) {
        AccentCategory.STONE -> accents.stone
        AccentCategory.WOOD -> accents.wood
        AccentCategory.VEGETATION -> accents.vegetation
        AccentCategory.WARNING -> accents.warning
        AccentCategory.STRUCTURE -> accents.structure
        AccentCategory.VEHICLE -> vehicleVariant(accents, obstacleId)
    }

/** obstacle.id % 3, never negative — deterministic and stable for the obstacle's whole lifetime, never randomized. */
private fun vehicleVariant(accents: WorldAccents, obstacleId: Long): Color {
    val options = listOf(accents.vehiclePrimary, accents.vehicleSecondary, accents.vehicleTertiary)
    val index = (obstacleId % options.size + options.size) % options.size
    return options[index.toInt()]
}

/**
 * The single entry point renderers use. Returns null when the type is
 * never accented (POTHOLE/RAMP/MOVING_DOG, or any type before its
 * category's distance threshold) — callers should fall back to the
 * ordinary monochrome [WorldPalette] color in that case, exactly as if
 * this function didn't exist.
 *
 * Composition order (matches the spec's documented sequence):
 * 1. [ColorProgressionModel] resolves category + accentStrength from distance (pure, no Color).
 * 2. This function resolves the category's Day/Night-blended accent Color using [nightAmount].
 * 3. The result is blended from [palette]'s monochrome foreground toward
 *    that accent using accentStrength — so at strength 0 this is
 *    indistinguishable from monochrome, and at strength 1 it's the full
 *    (Day/Night-appropriate) accent.
 */
fun accentColorForObstacle(
    type: ObstacleType,
    obstacleId: Long,
    distanceMeters: Int,
    palette: WorldPalette,
    nightAmount: Float
): Color? {
    val category = ColorProgressionModel.categoryFor(type) ?: return null
    val strength = ColorProgressionModel.accentStrengthFor(category, distanceMeters)
    if (strength <= 0f) return null

    val dayColor = accentFor(DAY_ACCENTS, category, obstacleId)
    val nightColor = accentFor(NIGHT_ACCENTS, category, obstacleId)
    val blendedAccent = lerp(dayColor, nightColor, nightAmount.coerceIn(0f, 1f))

    return lerp(palette.foreground, blendedAccent, strength)
}
