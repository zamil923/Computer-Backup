package com.cyclingrunner.game.game

/**
 * Pure obstacle movement: screenSpeed = worldSpeed - obstacle.relativeVelocityDpPerSec
 * (0 for every stationary type, so this is identical to the Session 4
 * behavior — obstacle.x -= worldSpeed*dt — for anything that isn't a
 * Session 5 moving hazard). Also recycles anything fully off the left
 * edge so the active list can't grow without bound over a long run.
 *
 * Split out from [GameEngine.advance] purely so it's independently unit
 * testable without needing a whole [GameUiState].
 */
object ObstacleMotion {

    fun advance(obstacles: List<Obstacle>, worldSpeed: Float, dt: Float): List<Obstacle> =
        obstacles.mapNotNull { obstacle ->
            val screenSpeed = worldSpeed - obstacle.relativeVelocityDpPerSec
            val moved = obstacle.copy(x = obstacle.x - screenSpeed * dt)
            if (moved.x + moved.width < 0f) null else moved
        }
}
