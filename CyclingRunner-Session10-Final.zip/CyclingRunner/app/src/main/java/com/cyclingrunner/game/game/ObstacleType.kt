package com.cyclingrunner.game.game

/**
 * The full obstacle pool. Session 4's five stay unchanged; Session 5 adds
 * CRATE/BUSH/PARKED_VEHICLE (stationary hazards), SLOW_VEHICLE/MOVING_DOG
 * (moving hazards, [isMoving] = true), and RAMP/BRIDGE (traversable
 * terrain, [isTerrain] = true — never a hazard; see [CollisionSystem]).
 *
 * [isMoving] and [isTerrain] exist so other code (spawner, collision,
 * motion) can query a type's category instead of scattering
 * type-by-type `when` checks across multiple files.
 *
 * Deliberately not a cactus or Chrome Dino artwork anywhere in this pool —
 * cycling/road-appropriate hazards and terrain only.
 */
enum class ObstacleType(val isMoving: Boolean = false, val isTerrain: Boolean = false) {
    SMALL_ROCK,
    LARGE_ROCK,
    POTHOLE,
    ROAD_BARRIER,
    FALLEN_BRANCH,
    CRATE,
    BUSH,
    PARKED_VEHICLE,
    SLOW_VEHICLE(isMoving = true),
    MOVING_DOG(isMoving = true),
    RAMP(isTerrain = true),
    BRIDGE(isTerrain = true)
}
