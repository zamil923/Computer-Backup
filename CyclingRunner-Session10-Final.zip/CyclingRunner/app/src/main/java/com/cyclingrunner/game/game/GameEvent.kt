package com.cyclingrunner.game.game

/**
 * One-shot gameplay moments, as opposed to continuous state. Session 9's
 * audio/haptics system is the intended consumer — it can collect
 * [GameViewModel.events] for JumpStarted/Landed/ObstacleHit/NewBest
 * instead of diffing [CyclistState.isAirborne], [Obstacle.hasBeenHit], or
 * [GameUiState.isNewBest] itself.
 *
 * Nothing subscribes to this yet; it exists purely as the hook the spec
 * asks for. [ObstacleHit] is already the reliable one-shot crash trigger
 * (Session 6's collision-to-GAME_OVER transition is driven by it, not a
 * separate CrashHit event) — Session 9 will map it to a crash sound.
 * [NewBest] is a separate concern (a record was actually beaten), not a
 * hazard event, so it gets its own entry rather than being folded in.
 */
sealed interface GameEvent {
    data object JumpStarted : GameEvent
    data object Landed : GameEvent
    data class ObstacleHit(val obstacleType: ObstacleType) : GameEvent
    data object NewBest : GameEvent
}
