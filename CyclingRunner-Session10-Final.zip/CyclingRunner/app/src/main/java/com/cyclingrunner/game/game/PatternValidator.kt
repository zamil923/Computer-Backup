package com.cyclingrunner.game.game

/**
 * The spec asks for generated obstacle sequences to be validated for
 * fairness and rejected/regenerated if unsafe. This spawner only ever has
 * one obstacle in flight per timer cycle (see [ObstacleSpawner]), which
 * structurally rules out the specific "overlapping impossible geometry"
 * scenarios the spec warns about (two solid obstacles overlapping, a dog
 * spawning inside another obstacle) — those require spawning multiple
 * obstacles concurrently or very close together, which this design avoids
 * by construction. What a single-obstacle-at-a-time spawner still needs
 * validating is the TIME GAP between consecutive obstacles, which is what
 * this object does: an honest, minimal implementation of the fairness
 * requirement rather than a combinatorial pattern-sequence generator.
 *
 * [ObstacleSpawner] enforces this by clamping the next interval up to the
 * required minimum rather than rejecting-and-resampling — functionally
 * equivalent, but with no chance of a long or unbounded retry loop.
 */
object PatternValidator {

    fun isGapSafe(previousType: ObstacleType?, nextType: ObstacleType, gapSeconds: Float): Boolean =
        gapSeconds >= requiredRecoverySeconds(previousType, nextType)

    /**
     * Absolute floor for any gap, plus a recovery bonus when either side of
     * the gap involves a moving hazard or terrain feature — those need
     * more attention than a simple static obstacle, per the spec's
     * "recovery window" requirement.
     */
    fun requiredRecoverySeconds(previousType: ObstacleType?, nextType: ObstacleType): Float {
        if (previousType == null) return GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS
        val needsBonus = previousType.isMoving || previousType.isTerrain || nextType.isMoving
        return GameConfig.MIN_SAFE_SPAWN_INTERVAL_SECONDS + if (needsBonus) GameConfig.RECOVERY_BONUS_SECONDS else 0f
    }
}
