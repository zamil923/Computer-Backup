package com.cyclingrunner.game.game

/**
 * Internal difficulty stage, derived purely from distance (see
 * [DifficultyModel]). This gates which [ObstacleType]s are allowed to
 * spawn — it is never shown to the player as a "Level 2" indicator or
 * similar; the game is one continuous endless ride with no stage
 * transitions, loading screens, or interruptions.
 */
enum class DifficultyTier {
    BEGINNER,
    EASY,
    MEDIUM,
    HARD,
    ENDLESS
}
