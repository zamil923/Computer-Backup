package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.cyclingrunner.game.game.CyclistGeometry
import com.cyclingrunner.game.game.GameConfig
import com.cyclingrunner.game.game.Obstacle
import com.cyclingrunner.game.game.ObstacleType
import com.cyclingrunner.game.ui.theme.WorldPalette
import com.cyclingrunner.game.ui.theme.accentColorForObstacle

/**
 * Dedicated obstacle rendering layer. Draws pure [Obstacle] state only —
 * movement, spawning, collision and terrain-elevation all live in
 * GameEngine/ObstacleSpawner/ObstacleMotion/CollisionSystem/TerrainSurface,
 * not here.
 *
 * Render order (set by GameScreen): Background -> Road -> Obstacles ->
 * Cyclist -> HUD, so obstacles sit on the road but behind the rider.
 *
 * Original, road/trail-appropriate silhouettes only — no cactus, no
 * Chrome Dino artwork. Everything here is procedural vector drawing.
 *
 * Session 5 adds CRATE/BUSH/PARKED_VEHICLE/SLOW_VEHICLE/MOVING_DOG
 * (hazards, filled) and RAMP/BRIDGE (traversable terrain, drawn as an
 * outline rather than filled, to visually read as "safe to ride over"
 * rather than "solid wall").
 *
 * Session 7: every shape draws from [palette] instead of a hard-coded
 * color, so obstacles invert correctly between Day and Night. The
 * pothole specifically is drawn as negative space (filled with
 * [WorldPalette.background], outlined in [WorldPalette.foreground]) —
 * this reads correctly as "an opening" in both phases without any
 * phase-specific branching, and fixes what would otherwise be a
 * black-shape-on-black-background problem at Night.
 *
 * Session 8: [distanceMeters]/[nightAmount] resolve an optional accent
 * color per obstacle via [accentColorForObstacle] — null before a
 * category's distance threshold (or for POTHOLE/RAMP/MOVING_DOG, which
 * are never accented), a Day/Night-blended muted color once unlocked.
 * The accent is deliberately confined to a small restrained region of
 * each shape (an inner facet, a stripe, a railing, a vehicle body) while
 * the outer silhouette stays in [palette.foreground] — obstacle identity
 * always comes from shape/silhouette, never from color alone, so nothing
 * here changes if every accent were stripped away.
 */
@Composable
fun ObstacleLayer(
    obstacles: List<Obstacle>,
    palette: WorldPalette,
    distanceMeters: Int,
    nightAmount: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val groundY = CyclistGeometry.groundY(size.height)
        obstacles.forEach { obstacle ->
            val accent = accentColorForObstacle(obstacle.type, obstacle.id, distanceMeters, palette, nightAmount)
            when (obstacle.type) {
                ObstacleType.SMALL_ROCK, ObstacleType.LARGE_ROCK -> drawRock(obstacle, groundY, palette, accent)
                ObstacleType.ROAD_BARRIER -> drawBarrier(obstacle, groundY, palette, accent)
                ObstacleType.FALLEN_BRANCH -> drawBranch(obstacle, groundY, palette, accent)
                ObstacleType.POTHOLE -> drawPothole(obstacle, groundY, palette)
                ObstacleType.CRATE -> drawCrate(obstacle, groundY, palette, accent)
                ObstacleType.BUSH -> drawBush(obstacle, groundY, palette, accent)
                ObstacleType.PARKED_VEHICLE, ObstacleType.SLOW_VEHICLE -> drawVehicle(obstacle, groundY, palette, accent)
                ObstacleType.MOVING_DOG -> drawDog(obstacle, groundY, palette)
                ObstacleType.RAMP -> drawRamp(obstacle, groundY, palette)
                ObstacleType.BRIDGE -> drawBridge(obstacle, groundY, palette, accent)
            }
            // Dev-only hitbox visualization; GameConfig.DEBUG_SHOW_COLLISION_BOUNDS
            // is false in production, so this never draws in normal gameplay.
            if (GameConfig.DEBUG_SHOW_COLLISION_BOUNDS && !obstacle.type.isTerrain) {
                drawObstacleDebugBounds(obstacle, groundY)
            }
        }
    }
}

private fun DrawScope.drawRock(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    val left = obstacle.x
    val top = groundY - obstacle.height
    val w = obstacle.width
    val h = obstacle.height
    // A slightly irregular silhouette so it doesn't read as a plain box.
    // The outer silhouette always stays palette.foreground — identity and
    // readability never depend on the accent.
    val path = Path().apply {
        moveTo(left + w * 0.05f, groundY)
        lineTo(left, top + h * 0.55f)
        lineTo(left + w * 0.30f, top + h * 0.10f)
        lineTo(left + w * 0.62f, top)
        lineTo(left + w * 0.92f, top + h * 0.35f)
        lineTo(left + w, groundY)
        close()
    }
    drawPath(path = path, color = palette.foreground)

    // A small inner facet picks up the stone accent once unlocked — a
    // partial fill, not a full recolor, per the spec's explicit guidance.
    if (accent != null) {
        val facet = Path().apply {
            moveTo(left + w * 0.30f, top + h * 0.10f)
            lineTo(left + w * 0.62f, top)
            lineTo(left + w * 0.55f, top + h * 0.45f)
            close()
        }
        drawPath(path = facet, color = accent)
    }
}

private fun DrawScope.drawBarrier(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    val left = obstacle.x
    val w = obstacle.width
    val h = obstacle.height
    val postWidth = w * 0.12f
    val barHeight = h * 0.28f
    val barTop = groundY - h

    // Two support posts and the horizontal bar always stay monochrome.
    drawRect(color = palette.foreground, topLeft = Offset(left, barTop + barHeight), size = Size(postWidth, h - barHeight))
    drawRect(
        color = palette.foreground,
        topLeft = Offset(left + w - postWidth, barTop + barHeight),
        size = Size(postWidth, h - barHeight)
    )
    drawRect(color = palette.foreground, topLeft = Offset(left, barTop), size = Size(w, barHeight))
    // Diagonal stripe hints for a barricade look — these pick up the
    // restrained warning accent once unlocked, staying secondaryForeground
    // (not bright/flashing) before that.
    val stripeColor = accent ?: palette.secondaryForeground
    val stripeCount = 3
    for (i in 0 until stripeCount) {
        val sx = left + w * (0.18f + i * 0.28f)
        drawLine(
            color = stripeColor,
            start = Offset(sx, barTop),
            end = Offset(sx + barHeight, barTop + barHeight),
            strokeWidth = 2f
        )
    }
}

private fun DrawScope.drawBranch(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    val left = obstacle.x
    val w = obstacle.width
    val h = obstacle.height
    val top = groundY - h
    // A low, wide capsule reads clearly as a log/branch lying across the
    // road — the body always stays monochrome.
    drawRoundRect(
        color = palette.foreground,
        topLeft = Offset(left, top),
        size = Size(w, h),
        cornerRadius = CornerRadius(h / 2f, h / 2f)
    )
    // A couple of small twig lines for character, kept minimal.
    drawLine(color = palette.foreground, start = Offset(left + w * 0.25f, top), end = Offset(left + w * 0.20f, top - h * 0.6f), strokeWidth = 2f)
    drawLine(color = palette.foreground, start = Offset(left + w * 0.65f, top), end = Offset(left + w * 0.72f, top - h * 0.5f), strokeWidth = 2f)
    // A thin wood-grain accent line along the top once unlocked.
    if (accent != null) {
        drawLine(
            color = accent,
            start = Offset(left + w * 0.12f, top + h * 0.35f),
            end = Offset(left + w * 0.88f, top + h * 0.35f),
            strokeWidth = h * 0.18f
        )
    }
}

/**
 * Negative-space treatment rather than a solid fill: the opening reads as
 * "background showing through," with a foreground edge and a
 * secondary-colored inner contour for definition. Works identically well
 * in Day (light background peeking through a dark road) and Night (dark
 * background peeking through a light road) with no phase-specific
 * branching — see the class doc for why a simple filled shape doesn't.
 * Deliberately never accented (see ColorProgressionModel.categoryFor):
 * a color fill here would undo this fix and re-break Night visibility.
 */
private fun DrawScope.drawPothole(obstacle: Obstacle, groundY: Float, palette: WorldPalette) {
    val topLeft = Offset(obstacle.x, groundY - obstacle.height / 2f)
    val size = Size(obstacle.width, obstacle.height)

    drawOval(color = palette.background, topLeft = topLeft, size = size)
    drawOval(color = palette.foreground, topLeft = topLeft, size = size, style = Stroke(width = 2.5f))

    val insetTopLeft = Offset(topLeft.x + size.width * 0.18f, topLeft.y + size.height * 0.28f)
    val insetSize = Size(size.width * 0.64f, size.height * 0.5f)
    drawOval(color = palette.secondaryForeground, topLeft = insetTopLeft, size = insetSize, style = Stroke(width = 2f))
}

private fun DrawScope.drawCrate(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    val left = obstacle.x
    val top = groundY - obstacle.height
    drawRect(color = palette.foreground, topLeft = Offset(left, top), size = Size(obstacle.width, obstacle.height))
    // The X-brace reads as a wooden crate, and picks up the wood accent
    // once unlocked; the solid body itself always stays monochrome.
    val braceColor = accent ?: palette.secondaryForeground
    drawLine(color = braceColor, start = Offset(left, top), end = Offset(left + obstacle.width, groundY), strokeWidth = 2f)
    drawLine(color = braceColor, start = Offset(left + obstacle.width, top), end = Offset(left, groundY), strokeWidth = 2f)
}

private fun DrawScope.drawBush(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    // A cluster of overlapping circles for a rounded, irregular silhouette —
    // deliberately not a cactus shape (no spines, no vertical arms). The
    // largest, leading circle always stays monochrome for a stable
    // silhouette anchor; the two smaller ones pick up the vegetation
    // accent once unlocked — a partial fill, not the whole bush.
    val cx = obstacle.x + obstacle.width / 2f
    val r = obstacle.height * 0.65f
    val innerColor = accent ?: palette.foreground
    drawCircle(color = palette.foreground, radius = r, center = Offset(cx - obstacle.width * 0.22f, groundY - r * 0.8f))
    drawCircle(color = innerColor, radius = r * 0.85f, center = Offset(cx, groundY - r * 0.9f))
    drawCircle(color = innerColor, radius = r * 0.7f, center = Offset(cx + obstacle.width * 0.25f, groundY - r * 0.7f))
}

private fun DrawScope.drawVehicle(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    val left = obstacle.x
    val width = obstacle.width
    val bodyHeight = obstacle.height
    val bodyTop = groundY - bodyHeight

    // Body matches the actual (forgiving) gameplay collision height exactly.
    // Picks up the vehicle accent once unlocked; a thin monochrome outline
    // is added on top whenever it does, keeping contrast against either
    // background regardless of the accent's own tone.
    val bodyColor = accent ?: palette.foreground
    drawRoundRect(
        color = bodyColor,
        topLeft = Offset(left, bodyTop),
        size = Size(width, bodyHeight),
        cornerRadius = CornerRadius(bodyHeight * 0.25f, bodyHeight * 0.25f)
    )
    if (accent != null) {
        drawRoundRect(
            color = palette.foreground,
            topLeft = Offset(left, bodyTop),
            size = Size(width, bodyHeight),
            cornerRadius = CornerRadius(bodyHeight * 0.25f, bodyHeight * 0.25f),
            style = Stroke(width = 1.5f)
        )
    }
    // Cabin/roof drawn visibly taller than the actual hitbox — a deliberate
    // forgiving vertical hitbox (see ObstacleGeometry), the vertical
    // equivalent of the horizontal forgiving inset used everywhere else.
    // Always monochrome: an anchor of the game's core identity even once
    // the body itself is accented.
    val cabinWidth = width * 0.5f
    val cabinHeight = bodyHeight * 0.55f
    drawRoundRect(
        color = palette.foreground,
        topLeft = Offset(left + width * 0.22f, bodyTop - cabinHeight),
        size = Size(cabinWidth, cabinHeight),
        cornerRadius = CornerRadius(cabinHeight * 0.3f, cabinHeight * 0.3f)
    )
    // Wheels, in the secondary tone so the body silhouette stays the clearest read.
    val wheelRadius = bodyHeight * 0.22f
    drawCircle(color = palette.secondaryForeground, radius = wheelRadius, center = Offset(left + width * 0.22f, groundY))
    drawCircle(color = palette.secondaryForeground, radius = wheelRadius, center = Offset(left + width * 0.78f, groundY))
}

private fun DrawScope.drawDog(obstacle: Obstacle, groundY: Float, palette: WorldPalette) {
    val left = obstacle.x
    val width = obstacle.width
    val height = obstacle.height
    val bodyTop = groundY - height

    // Original minimal silhouette — body, head, two simple legs, a tail.
    // No realistic detail, no motion beyond the predictable horizontal
    // drift TerrainSurface/ObstacleMotion already handle.
    drawRoundRect(
        color = palette.foreground,
        topLeft = Offset(left, bodyTop),
        size = Size(width * 0.75f, height * 0.6f),
        cornerRadius = CornerRadius(height * 0.3f, height * 0.3f)
    )
    drawCircle(color = palette.foreground, radius = height * 0.35f, center = Offset(left + width * 0.85f, bodyTop + height * 0.15f))
    drawLine(
        color = palette.foreground,
        start = Offset(left + width * 0.12f, bodyTop + height * 0.6f),
        end = Offset(left + width * 0.12f, groundY),
        strokeWidth = 3f
    )
    drawLine(
        color = palette.foreground,
        start = Offset(left + width * 0.55f, bodyTop + height * 0.6f),
        end = Offset(left + width * 0.55f, groundY),
        strokeWidth = 3f
    )
    drawLine(
        color = palette.foreground,
        start = Offset(left, bodyTop + height * 0.2f),
        end = Offset(left - width * 0.15f, bodyTop),
        strokeWidth = 2f
    )
}

/**
 * Low on the left edge, rising to full height on the right edge — matches
 * TerrainSurface's elevation formula exactly (progress 0 at the left edge,
 * where the cyclist first makes contact, to 1 at the right edge, the
 * launch point). Drawn as an outline, not filled, to read as "ride onto
 * this" rather than "solid wall" — it's never a hazard (see CollisionSystem).
 * The outline treatment (rather than a fill) is itself what keeps this
 * reading as "traversable" in both Day and Night, not just the color.
 */
private fun DrawScope.drawRamp(obstacle: Obstacle, groundY: Float, palette: WorldPalette) {
    val left = obstacle.x
    val right = obstacle.x + obstacle.width
    val peakY = groundY - obstacle.height
    val path = Path().apply {
        moveTo(left, groundY)
        lineTo(right, peakY)
        lineTo(right, groundY)
    }
    drawPath(path = path, color = palette.foreground, style = Stroke(width = 4f))
}

/**
 * Approach ramp -> flat deck -> descend ramp, matching TerrainSurface's
 * elevation profile exactly. An outline (plus light support/railing hints)
 * rather than a filled shape, for the same "traversable, not solid" read
 * as the ramp above. The deck and supports always stay monochrome — only
 * the railing hint picks up the structure accent once unlocked, keeping
 * the bridge reading clearly as terrain rather than a colored obstacle.
 */
private fun DrawScope.drawBridge(obstacle: Obstacle, groundY: Float, palette: WorldPalette, accent: Color?) {
    val left = obstacle.x
    val width = obstacle.width
    val height = obstacle.height
    val approachX = left + width * 0.25f
    val descendX = left + width * 0.75f
    val right = left + width
    val deckY = groundY - height

    val deckPath = Path().apply {
        moveTo(left, groundY)
        lineTo(approachX, deckY)
        lineTo(descendX, deckY)
        lineTo(right, groundY)
    }
    drawPath(path = deckPath, color = palette.foreground, style = Stroke(width = 4f))

    // Simple supports under the deck.
    drawLine(color = palette.foreground, start = Offset(approachX, deckY), end = Offset(approachX, groundY), strokeWidth = 2f)
    drawLine(color = palette.foreground, start = Offset(descendX, deckY), end = Offset(descendX, groundY), strokeWidth = 2f)
    // Minimal railing hint along the flat deck — the one accented detail.
    drawLine(
        color = accent ?: palette.secondaryForeground,
        start = Offset(approachX, deckY - height * 0.15f),
        end = Offset(descendX, deckY - height * 0.15f),
        strokeWidth = 2f
    )
}

/** Mirrors CollisionSystem's actual hitbox so the debug outline is trustworthy, not just decorative. */
private fun DrawScope.drawObstacleDebugBounds(obstacle: Obstacle, groundY: Float) {
    val insetHalf = obstacle.width * (1f - GameConfig.OBSTACLE_COLLISION_WIDTH_FACTOR) / 2f
    val left = obstacle.x + insetHalf
    val right = obstacle.x + obstacle.width - insetHalf
    val isPothole = obstacle.type == ObstacleType.POTHOLE
    val top = if (isPothole) groundY - 2f else groundY - obstacle.height
    val height = if (isPothole) 4f else obstacle.height
    drawRect(
        color = Color(0xFFCC3333),
        topLeft = Offset(left, top),
        size = Size(right - left, height),
        style = Stroke(width = 2f)
    )
}
