package com.cyclingrunner.game.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import java.io.File

/**
 * Loads the four synthesized feedback tones (see [ToneWavWriter]) into a
 * small [SoundPool] and plays them on demand. Tone files are generated
 * once into the app's cache directory on first construction — not
 * regenerated per play or per recomposition — and reused on subsequent
 * launches if still present.
 *
 * [SoundPool.load] is asynchronous: a sound isn't actually playable the
 * instant [SoundPool.load] returns, only once its completion callback
 * fires. [play] checks [loadedSoundIds] and simply skips silently if a
 * sound hasn't finished loading yet — given these files are a few
 * kilobytes each, this window is brief, and a missed very-first sound is
 * far preferable to gameplay ever depending on audio timing.
 *
 * Every operation here is defensive: a failure to generate, load, or
 * play a sound is logged and silently ignored. Gameplay must never
 * depend on audio succeeding (see the class's callers in
 * [GameFeedbackController], which is a pure observer of gameplay events,
 * never an authority over them).
 */
class GameAudioManager(context: Context) {

    private val appContext = context.applicationContext
    private val tag = "GameAudioManager"

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val loadedSoundIds = mutableSetOf<Int>()

    init {
        // Registered before any load() call below so a very-fast load
        // completion can never be missed.
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSoundIds.add(sampleId)
            } else {
                Log.w(tag, "Sound $sampleId failed to load (status=$status)")
            }
        }
    }

    // Short, soft retro "pop" (~140ms) — plays only on an accepted jump,
    // never for an ignored airborne tap (GameFeedbackController gates that).
    private val jumpSoundId = loadGeneratedTone("jump.wav") { file ->
        ToneWavWriter.writeToneWav(file, frequencyHz = 620.0, durationSeconds = 0.14, amplitude = 0.45)
    }

    // Very brief, quiet "tick" (~70ms) — deliberately shorter/quieter than jump or crash.
    private val landSoundId = loadGeneratedTone("land.wav") { file ->
        ToneWavWriter.writeToneWav(file, frequencyHz = 300.0, durationSeconds = 0.07, amplitude = 0.22)
    }

    // Short low-pitched "thump" (~180ms) — clearly distinct from jump/land, not explosive.
    private val crashSoundId = loadGeneratedTone("crash.wav") { file ->
        ToneWavWriter.writeToneWav(file, frequencyHz = 150.0, durationSeconds = 0.18, amplitude = 0.55)
    }

    // Two short ascending notes — a brief, restrained positive chime.
    private val newBestSoundId = loadGeneratedTone("new_best.wav") { file ->
        ToneWavWriter.writeChimeWav(file, firstHz = 700.0, secondHz = 1050.0, noteDurationSeconds = 0.09, amplitude = 0.4)
    }

    private fun loadGeneratedTone(fileName: String, generate: (File) -> Unit): Int? = try {
        val file = File(appContext.cacheDir, fileName)
        if (!file.exists() || file.length() == 0L) {
            generate(file)
        }
        soundPool.load(file.absolutePath, 1)
    } catch (e: Exception) {
        Log.w(tag, "Failed to prepare $fileName; continuing without it", e)
        null
    }

    fun playJump() = play(jumpSoundId)
    fun playLand() = play(landSoundId)
    fun playCrash() = play(crashSoundId)
    fun playNewBest() = play(newBestSoundId)

    private fun play(soundId: Int?) {
        val id = soundId ?: return
        if (id !in loadedSoundIds) return
        try {
            soundPool.play(id, 1f, 1f, /* priority = */ 0, /* loop = */ 0, /* rate = */ 1f)
        } catch (e: Exception) {
            Log.w(tag, "Failed to play sound $id", e)
        }
    }

    /** Releases the SoundPool. Call when the owning controller is discarded (see GameFeedbackController.release). */
    fun release() {
        try {
            soundPool.release()
        } catch (e: Exception) {
            Log.w(tag, "Failed to release SoundPool", e)
        }
    }
}
