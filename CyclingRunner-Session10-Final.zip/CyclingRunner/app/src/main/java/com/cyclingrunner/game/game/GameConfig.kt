package com.cyclingrunner.game.game

/**
 * Central tuning values, all in the same viewport-pixel-per-second unit
 * Compose's Canvas draws in (loosely called "dp" below for readability;
 * true density-independent scaling is out of scope for this session).
 *
 * Session 2's key change: road scroll, parallax layers, wheel rotation
 * and pedal rotation are now all derived from the single shared
 * [GameUiState.worldSpeedDpPerSec] value in [GameEngine], instead of
 * ticking on their own independent constants. That's what keeps them
 * from drifting out of sync with each other, and it's what will let
 * Session 5 raise difficulty by changing just that one number.
 */
object GameConfig {

    // World speed / distance
    const val BASE_SCROLL_SPEED_DP_PER_SEC = 220f
    const val METERS_PER_SCROLLED_DP = 0.045f

    // Parallax layers — all scroll offsets are worldSpeed * factor * dt
    const val NEAR_LAYER_PARALLAX_FACTOR = 0.6f
    const val FAR_LAYER_PARALLAX_FACTOR = 0.25f
    const val CLOUD_LAYER_PARALLAX_FACTOR = 0.12f

    // Cyclist layout fractions, shared by the renderer and (from Session 4)
    // collision-bounds prep, so ground level / cyclist position can't
    // silently disagree between drawing code and gameplay code.
    const val GROUND_Y_FRACTION = 0.82f
    const val CYCLIST_X_FRACTION = 0.22f
    const val WHEEL_RADIUS_HEIGHT_FRACTION = 0.045f
    const val WHEEL_SPACING_FACTOR = 3.1f

    // Wheel / pedal rotation, derived from world speed:
    // wheelAngularVelocity = worldSpeed / wheelRadius. A fixed reference
    // radius is used rather than each device's actual rendered radius —
    // a deliberate simplification (screen-size-perfect physical rotation
    // isn't required; visual correspondence to speed is).
    const val WHEEL_RADIUS_REFERENCE_DP = 24f
    const val PEDAL_GEAR_RATIO = 2.6f // wheel revolutions per crank revolution
    const val BODY_BOB_TO_PEDAL_RATIO = 2f // bob cycles per pedal revolution

    // Jump foundation, now driven by real tap input (Session 3). Impulse and
    // gravity were tuned in Session 1/2's foundation and are reused as-is:
    // apex height ≈ impulse²/(2*gravity), total airtime ≈ 2*impulse/gravity
    // — roughly 0.7s and comfortably above wheel height at these values,
    // i.e. a short, clearly-visible bunny-hop rather than a superhero leap.
    const val GRAVITY_DP_PER_SEC2 = 2200f
    const val JUMP_IMPULSE_DP_PER_SEC = 760f

    // Purely cosmetic landing feedback (see CyclistState.landingSquashSeconds).
    // Never feeds back into verticalOffset/verticalVelocity, so it cannot
    // cause a second bounce.
    const val LANDING_SQUASH_DURATION_SECONDS = 0.09f
    const val LANDING_SQUASH_MAX_FACTOR = 0.12f

    // Obstacle spawning (Session 4). Intervals are in seconds so spacing
    // stays correct if Session 5 later changes worldSpeed — a time gap
    // is a fixed reaction-time budget regardless of how fast the world
    // is scrolling, whereas a fixed pixel gap would not be.
    const val OBSTACLE_INITIAL_GRACE_SECONDS = 2.2f
    const val OBSTACLE_MIN_SPAWN_INTERVAL_SECONDS = 1.6f
    const val OBSTACLE_MAX_SPAWN_INTERVAL_SECONDS = 3.0f
    const val OBSTACLE_SPAWN_MARGIN_PX = 40f // spawns just past the right edge, not visibly popping in

    // Obstacle collision (Session 4)
    const val OBSTACLE_COLLISION_WIDTH_FACTOR = 0.8f // forgiving: central 80% of visual width counts
    const val POTHOLE_CLEARANCE_FACTOR = 0.8f // fraction of a wheel radius needed above ground to clear a pothole

    // Difficulty milestones (Session 5), centralized here rather than
    // scattered across the model that reads them. Tiers only gate which
    // obstacle types are allowed to spawn — speed and spawn frequency ramp
    // continuously (see DIFFICULTY_RAMP_DISTANCE_METERS below), so crossing
    // a tier boundary never itself causes a sudden physics change.
    const val DIFFICULTY_EASY_START_METERS = 500
    const val DIFFICULTY_MEDIUM_START_METERS = 1500
    const val DIFFICULTY_HARD_START_METERS = 3000
    const val DIFFICULTY_ENDLESS_START_METERS = 5000

    // Distance over which speed and spawn frequency linearly ramp from
    // their base (0m) values to their endless-mode values. Set equal to
    // the ENDLESS threshold so max difficulty and max obstacle variety
    // arrive together. A straight linear ramp (see DifficultyModel) means
    // there is no discrete jump at any distance — only a continuously
    // changing number, however finely you sample it.
    const val DIFFICULTY_RAMP_DISTANCE_METERS = 5000f
    const val MAX_SCROLL_SPEED_DP_PER_SEC = 340f // plateaus here; never increases further

    const val MIN_SPAWN_INTERVAL_AT_MAX_DIFFICULTY_SECONDS = 1.1f
    const val MAX_SPAWN_INTERVAL_AT_MAX_DIFFICULTY_SECONDS = 2.0f
    const val MOVING_OBSTACLE_CHANCE_AT_ENDLESS = 0.3f

    // Absolute safety floor, independent of difficulty tier: comfortably
    // above the fixed jump airtime (2*impulse/gravity ≈ 0.69s — jump
    // physics never speeds up, per spec) plus a human reaction-time
    // buffer. No profile is ever allowed to schedule a gap below this,
    // and a bonus is added after a moving or terrain hazard, which needs
    // more attention than a simple static obstacle. See PatternValidator.
    const val MIN_SAFE_SPAWN_INTERVAL_SECONDS = 1.0f
    const val RECOVERY_BONUS_SECONDS = 0.6f

    // Moving-hazard relative velocity: screenSpeed = worldSpeed - relativeVelocity,
    // i.e. these obstacles close the gap slower than a static obstacle would,
    // per the spec's explicit formula. Never a second global speed system —
    // just a per-obstacle offset from the one shared worldSpeed.
    const val SLOW_VEHICLE_RELATIVE_VELOCITY_DP_PER_SEC = 45f
    const val MOVING_DOG_RELATIVE_VELOCITY_DP_PER_SEC = 70f

    // Ramp launch: smaller than a full manual jump impulse (760), for the
    // "small natural launch" the spec asks for, applied through the exact
    // same verticalVelocity/isAirborne fields a manual jump uses — see
    // GameEngine's terrain integration and TerrainSurface.
    const val RAMP_LAUNCH_VELOCITY_DP_PER_SEC = 620f

    // Crash presentation (Session 6). Purely cosmetic — GameEngine never
    // reads these; they're used by the UI layer's own Compose animation
    // driving CyclistLayer's crashTiltDegrees and the Game Over overlay's
    // celebration, decoupled from the deterministic simulation clock.
    const val CRASH_TILT_DEGREES = 28f
    const val CRASH_ANIMATION_DURATION_MS = 450
    const val NEW_BEST_CELEBRATION_DURATION_MS = 1200

    // Dev-only hitbox visualization. Must stay false in production builds;
    // nothing in normal gameplay reads this.
    const val DEBUG_SHOW_COLLISION_BOUNDS = false

    // Day/Night visual cycle (Session 7). Purely a rendering concern — no
    // GameEngine code reads these, and DayNightModel takes distanceMeters
    // as input, never writes gameplay state. A "half-cycle" is one solid
    // Day or Night stretch; the cycle alternates Day/Night every
    // DAY_NIGHT_CYCLE_METERS, starting in Day at distance 0.
    const val DAY_NIGHT_CYCLE_METERS = 1000
    // Total distance window, centered on each Day<->Night boundary, over
    // which the palette blends smoothly rather than cutting instantly.
    // At base speed (~9.9 m/s) this is roughly a 1.6s blend, within the
    // spec's 0.5-1.5s guidance across the game's speed range.
    const val DAY_NIGHT_TRANSITION_METERS = 16f

    // Selective obstacle color progression (Session 8). Purely a rendering
    // concern, exactly like Day/Night above — GameEngine never reads these.
    // Thresholds are cumulative unlock distances per AccentCategory (see
    // ColorProgressionModel.categoryFor for which ObstacleTypes map to
    // which category); WOOD is bundled with the vegetation threshold, a
    // deliberate curated choice (natural materials unlocking together)
    // rather than its own stage.
    const val COLOR_STONE_UNLOCK_METERS = 1000
    const val COLOR_WARNING_UNLOCK_METERS = 2000
    const val COLOR_VEGETATION_UNLOCK_METERS = 3000
    const val COLOR_STRUCTURE_UNLOCK_METERS = 4000
    const val COLOR_VEHICLE_UNLOCK_METERS = 5000
    // Distance after crossing a category's threshold over which its accent
    // smoothly fades in from 0 to full strength, avoiding a hard visual
    // switch at the exact threshold meter.
    const val COLOR_ACCENT_TRANSITION_METERS = 40f

    // Loop safety: clamp a single frame's delta so resuming from a long
    // backgrounded pause can't be read as one enormous simulation step.
    const val MAX_FRAME_DELTA_SECONDS = 0.05f

    // Loop cadence
    const val TARGET_FRAME_DELAY_MS = 16L
}
