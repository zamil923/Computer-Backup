package com.cyclingrunner.game.game

/**
 * High-level state machine for a single run.
 *
 * Session 1 only drives the app through READY, RUNNING and PAUSED.
 * GAME_OVER is modeled now — with no code path reaching it yet — so
 * Session 4/6 (collisions, crash, restart-after-death) can plug into an
 * existing state machine instead of one that needs to be reshaped later.
 */
enum class GameState {
    READY,
    RUNNING,
    PAUSED,
    GAME_OVER
}
