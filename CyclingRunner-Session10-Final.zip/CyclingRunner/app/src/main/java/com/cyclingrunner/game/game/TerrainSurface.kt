package com.cyclingrunner.game.game

/**
 * Computes how much a RAMP or BRIDGE obstacle currently under the cyclist
 * should raise them above the base ground, and whether a ramp has just
 * been ridden off the end (triggering a launch).
 *
 * Coordinate note: obstacles move right-to-left while the cyclist's
 * screen X is fixed, so — for a fixed reference point — contact with an
 * obstacle begins when the obstacle's LEFT edge reaches that point and
 * ends when its RIGHT edge does; the cyclist's position within the
 * obstacle's span moves from 0 (left edge, first contact) to 1 (right
 * edge, last contact) over the time they overlap. [progressWithin] is
 * that 0..1 value. A RAMP is therefore drawn (see ObstacleLayer) low on
 * its left edge and high on its right edge: the cyclist meets the low
 * end first and launches off the high end last.
 *
 * This never introduces a second ground-Y or a second jump-physics
 * system: elevation is applied by GameEngine as an override of the
 * existing [CyclistState.verticalOffset] while grounded, and a ramp
 * launch sets [CyclistState.isAirborne] / [CyclistState.verticalVelocity]
 * through the exact same fields a manual jump uses.
 */
object TerrainSurface {

    data class Result(val elevation: Float, val rampLaunchVelocity: Float?)

    /**
     * [obstaclesBeforeMove]/[obstaclesAfterMove] are the same frame's
     * obstacle list before and after [ObstacleMotion.advance] — comparing
     * them lets a ramp's launch be detected as an edge transition (was
     * overlapping, now isn't) without needing any extra per-obstacle flag
     * or stored "previous" state.
     *
     * Returns no elevation and no launch while [cyclistIsAirborne] — once
     * a real jump (or a previous ramp launch) has the cyclist under normal
     * gravity physics, terrain has no further effect until they land.
     */
    fun evaluate(
        obstaclesBeforeMove: List<Obstacle>,
        obstaclesAfterMove: List<Obstacle>,
        cyclistLeadingX: Float,
        cyclistIsAirborne: Boolean
    ): Result {
        if (cyclistIsAirborne) return Result(elevation = 0f, rampLaunchVelocity = null)

        val elevation = obstaclesAfterMove.maxOfOrNull { elevationFor(it, cyclistLeadingX) } ?: 0f

        val afterById = obstaclesAfterMove.associateBy { it.id }
        var launchVelocity: Float? = null
        for (before in obstaclesBeforeMove) {
            if (before.type != ObstacleType.RAMP) continue
            val wasOn = isOverlapping(before, cyclistLeadingX)
            if (!wasOn) continue
            val after = afterById[before.id]
            val stillOn = after != null && isOverlapping(after, cyclistLeadingX)
            if (!stillOn) {
                launchVelocity = GameConfig.RAMP_LAUNCH_VELOCITY_DP_PER_SEC
            }
        }

        return Result(elevation, launchVelocity)
    }

    private fun isOverlapping(obstacle: Obstacle, x: Float): Boolean =
        x >= obstacle.x && x <= obstacle.x + obstacle.width

    private fun progressWithin(obstacle: Obstacle, x: Float): Float =
        if (!isOverlapping(obstacle, x)) -1f else ((x - obstacle.x) / obstacle.width).coerceIn(0f, 1f)

    private fun elevationFor(obstacle: Obstacle, x: Float): Float = when (obstacle.type) {
        ObstacleType.RAMP -> rampElevation(obstacle, x)
        ObstacleType.BRIDGE -> bridgeElevation(obstacle, x)
        else -> 0f
    }

    private fun rampElevation(obstacle: Obstacle, x: Float): Float {
        val progress = progressWithin(obstacle, x)
        return if (progress < 0f) 0f else progress * obstacle.height
    }

    /**
     * Approach (rising) for the first quarter, a flat raised deck for the
     * middle half, then descend for the last quarter — elevation is
     * exactly 0 again at progress=1, so overlap ending always coincides
     * with already being back at base ground level: no snap, no jitter.
     */
    private fun bridgeElevation(obstacle: Obstacle, x: Float): Float {
        val progress = progressWithin(obstacle, x)
        if (progress < 0f) return 0f
        val approachEnd = 0.25f
        val descendStart = 0.75f
        return when {
            progress < approachEnd -> (progress / approachEnd) * obstacle.height
            progress < descendStart -> obstacle.height
            else -> ((1f - progress) / (1f - descendStart)) * obstacle.height
        }
    }
}
