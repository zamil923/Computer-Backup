package com.cyclingrunner.game.game

/**
 * Pure collision math — no Android/Compose types — so bounds intersection,
 * jump clearance and pothole clearance can be unit tested directly without
 * booting the rendering pipeline.
 *
 * No tunneling protection needed beyond this per-frame overlap check: the
 * existing [GameConfig.MAX_FRAME_DELTA_SECONDS] clamp already caps a single
 * frame's obstacle movement to worldSpeed * 0.05s (about 11px at the
 * Session 4 base speed), far smaller than any obstacle's or the cyclist's
 * footprint, so a valid frame step cannot skip an obstacle clean through
 * the cyclist between checks.
 */
object CollisionSystem {

    /**
     * True if [cyclistBounds] (already jump-correct — see
     * [CyclistGeometry.approximateBounds] / [CyclistGeometry.wheelBottomY])
     * overlaps [obstacle] enough to count as a hit.
     *
     * Applies a forgiving horizontal inset to the obstacle (visual art can
     * be wider than the actual hitbox — see [GameConfig.OBSTACLE_COLLISION_WIDTH_FACTOR])
     * and treats potholes specially: horizontal overlap plus insufficient
     * vertical clearance, rather than a solid rectangle — a hole in the
     * road isn't a wall to bump into, and empty space above it is never
     * treated as solid.
     */
    fun checkCollision(
        cyclistBounds: CyclistGeometry.Bounds,
        cyclistVerticalOffset: Float,
        groundY: Float,
        potholeClearance: Float,
        obstacle: Obstacle
    ): Boolean {
        if (obstacle.hasBeenHit) return false
        // Ramps and bridges are traversable terrain, not hazards — see
        // TerrainSurface, which is what actually governs riding on them.
        if (obstacle.type.isTerrain) return false

        val insetHalf = obstacle.width * (1f - GameConfig.OBSTACLE_COLLISION_WIDTH_FACTOR) / 2f
        val obstacleLeft = obstacle.x + insetHalf
        val obstacleRight = obstacle.x + obstacle.width - insetHalf
        val horizontallyOverlaps = cyclistBounds.right > obstacleLeft && cyclistBounds.left < obstacleRight
        if (!horizontallyOverlaps) return false

        return if (obstacle.type == ObstacleType.POTHOLE) {
            cyclistVerticalOffset < potholeClearance
        } else {
            val obstacleTop = groundY - obstacle.height
            // cyclistBounds.bottom is the wheel-contact line. Once it rises
            // above the obstacle's top edge, the obstacle has been cleared.
            cyclistBounds.bottom > obstacleTop
        }
    }
}
