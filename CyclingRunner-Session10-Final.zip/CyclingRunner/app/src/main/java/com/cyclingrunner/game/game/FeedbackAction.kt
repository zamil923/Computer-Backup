package com.cyclingrunner.game.game

/**
 * The four kinds of feedback the game ever produces, decoupled from
 * exactly which [GameEvent] triggered them (see [FeedbackMapper]) so the
 * Android audio/haptic layer (Session 9's `audio` package) has one small,
 * closed set of actions to execute rather than pattern-matching on
 * GameEvent itself.
 */
enum class FeedbackAction {
    JUMP,
    LAND,
    CRASH,
    NEW_BEST
}
