package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import com.cyclingrunner.game.game.CyclistGeometry
import com.cyclingrunner.game.ui.theme.WorldPalette

/**
 * The ground line plus small scrolling detail marks (dots/cracks/stones).
 * Details repeat on a fixed segment length so the modulo-based scroll
 * offset loops with no visible seam. Ground level comes from
 * [CyclistGeometry] so it always agrees exactly with where the cyclist
 * is drawn.
 *
 * Session 7: drawn from [palette] (foreground for the ground line,
 * secondaryForeground for the small details) rather than a hard-coded
 * color, so Night correctly renders a light road instead of a dark one.
 */
@Composable
fun RoadLayer(scrollPx: Float, palette: WorldPalette, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val groundY = CyclistGeometry.groundY(height)

        drawLine(
            color = palette.foreground,
            start = Offset(0f, groundY),
            end = Offset(width, groundY),
            strokeWidth = 4f
        )

        val segment = 120f
        val offset = scrollPx % segment
        var x = -offset
        var index = 0
        while (x < width) {
            when (index % 3) {
                0 -> drawCircle(color = palette.secondaryForeground, radius = 3f, center = Offset(x, groundY + 14f))
                1 -> drawLine(
                    color = palette.secondaryForeground,
                    start = Offset(x, groundY + 10f),
                    end = Offset(x + 14f, groundY + 10f),
                    strokeWidth = 3f
                )
                else -> drawCircle(color = palette.secondaryForeground, radius = 2f, center = Offset(x, groundY + 20f))
            }
            x += segment
            index++
        }
    }
}
