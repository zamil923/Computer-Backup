package com.cyclingrunner.game.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cyclingrunner.game.ui.theme.WorldPalette

/**
 * 44dp minimum touch target, well above the usual ~40dp accessibility floor.
 *
 * Session 7: the button's own fill/icon colors come from [palette] (fill
 * = foreground, icon = background — an inverted, high-contrast button
 * against either world) rather than fixed black/white. Left as a solid
 * button rather than blending into the scene either way — it needs to
 * stay visible and tappable in both Day and Night, not just correctly
 * "inverted" in the abstract.
 *
 * Session 9: [clearAndSetSemantics] replaces the raw ▶/‖ glyph with a
 * clear "Pause"/"Resume" announcement for TalkBack.
 */
@Composable
fun PauseButton(
    isPaused: Boolean,
    onClick: () -> Unit,
    palette: WorldPalette,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(20.dp)
            .size(44.dp)
            .clip(CircleShape)
            .background(palette.foreground)
            .clickable { onClick() }
            .clearAndSetSemantics { contentDescription = if (isPaused) "Resume" else "Pause" },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (isPaused) "\u25B6" else "\u2016",
            color = palette.background,
            fontSize = 18.sp
        )
    }
}
