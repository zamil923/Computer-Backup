package com.cyclingrunner.game.game

/**
 * A restrained set of material/purpose categories that obstacles can
 * gradually gain a color accent for, as distance increases (see
 * [ColorProgressionModel]). Not every [ObstacleType] maps to one —
 * POTHOLE, RAMP and MOVING_DOG are deliberately excluded (see
 * [ColorProgressionModel.categoryFor]) and stay monochrome for the whole
 * run, per the spec's emphasis on restraint and gameplay readability.
 */
enum class AccentCategory {
    STONE,
    WOOD,
    VEGETATION,
    WARNING,
    STRUCTURE,
    VEHICLE
}
