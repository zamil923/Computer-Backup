# Announce+Gui

Announce+Gui is a Paper/Leaf 1.21.11 plugin that provides a native Minecraft Dialog-based editor for server-wide title announcements.

## Features

- Native Minecraft Dialog UI — no chest/inventory GUI.
- Title and subtitle text inputs.
- MiniMessage formatting, including gradients.
- Preset colour selection and custom HEX validation.
- Configurable fade-in, stay, and fade-out timings.
- Configurable sound, volume, and pitch.
- Preview without broadcasting.
- Server-wide send.
- UUID-isolated staff drafts.
- Draft cleanup on send, cancel, and disconnect.
- Optional PlaceholderAPI support without a hard dependency.
- No external HTTP requests, telemetry, or arbitrary command execution.

## Compatibility

- Minecraft: 1.21.11
- Server: Leaf 1.21.11
- API: Paper API
- Java: 21

The project compiles against the official Paper API `1.21.11-R0.1-SNAPSHOT`.

## Installation

1. Build the project with Gradle.
2. Put `AnnouncePlusGui-1.0.0.jar` in the server's `plugins` directory.
3. Start or restart the server.
4. Edit `plugins/Announce+Gui/config.yml` as required.

## Commands

- `/announce` — opens the native announcement editor.
- `/announce reload` — reloads `config.yml`.
- `/announce help` — shows command help.

## Permissions

- `announcegui.use` — access the editor; default `op`.
- `announcegui.reload` — reload configuration; default `op`.

## Dialog controls

The editor provides:

- Title
- Subtitle
- Colour
- Custom HEX
- Fade In
- Stay
- Fade Out
- Sound
- Volume
- Pitch
- Preview
- Send
- Cancel

Preview only affects the staff member who clicked Preview. Send affects all online players.

## MiniMessage

Title and subtitle support Adventure MiniMessage, for example:

`<red>SERVER RESTART</red>`

`<gradient:#A303F9:#4B0082>SERVER EVENT</gradient>`

Malformed MiniMessage is handled safely and is displayed as literal text instead of crashing the plugin.

## PlaceholderAPI

PlaceholderAPI is optional. If it is installed, placeholders in title/subtitle text are resolved separately for each recipient at send time. The plugin still works normally when PlaceholderAPI is absent.

## Configuration

See `src/main/resources/config.yml` for messages, dialog sizing, defaults, colours, timing options, and sound options.

## Building

Do not commit or ship build output from this source package. To build locally:

```text
gradle build
```

or, if you have generated a Gradle wrapper locally:

```text
./gradlew build
```

The expected plugin artifact is `build/libs/AnnouncePlusGui-1.0.0.jar`.

## Example announcement

Title:

`<gradient:#A303F9:#4B0082><bold>SERVER EVENT</bold></gradient>`

Subtitle:

`<yellow>Event starting in 5 minutes!</yellow>`

Select the desired timing and sound, use Preview to verify it, then click Send.
