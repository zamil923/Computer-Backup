package me.qfie.announcegui.listener;

import me.qfie.announcegui.manager.AnnouncementManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {
    private final AnnouncementManager manager;

    public PlayerListener(AnnouncementManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        manager.clear(event.getPlayer());
    }
}
