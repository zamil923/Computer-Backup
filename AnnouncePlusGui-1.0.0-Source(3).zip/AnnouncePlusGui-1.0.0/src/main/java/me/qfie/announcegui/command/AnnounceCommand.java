package me.qfie.announcegui.command;

import me.qfie.announcegui.dialog.DialogManager;
import me.qfie.announcegui.util.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class AnnounceCommand implements CommandExecutor, TabCompleter {
    private final JavaPlugin plugin;
    private final DialogManager dialogs;

    public AnnounceCommand(JavaPlugin plugin, DialogManager dialogs) {
        this.plugin = plugin;
        this.dialogs = dialogs;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("announcegui.reload")) {
                sender.sendMessage(MessageUtil.parse(plugin.getConfig().getString("messages.no-permission", "<red>No permission.</red>")));
                return true;
            }
            plugin.reloadConfig();
            sender.sendMessage(MessageUtil.parse(plugin.getConfig().getString("messages.reloaded", "<green>Reloaded.</green>")));
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(MessageUtil.parse("<yellow>/announce</yellow> <gray>- Open the native announcement editor.</gray>"));
            sender.sendMessage(MessageUtil.parse("<yellow>/announce reload</yellow> <gray>- Reload config.yml.</gray>"));
            sender.sendMessage(MessageUtil.parse("<yellow>/announce help</yellow> <gray>- Show this help.</gray>"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(MessageUtil.parse(plugin.getConfig().getString("messages.player-only", "<red>Players only.</red>")));
            return true;
        }

        if (!player.hasPermission("announcegui.use")) {
            player.sendMessage(MessageUtil.parse(plugin.getConfig().getString("messages.no-permission", "<red>No permission.</red>")));
            return true;
        }

        dialogs.open(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("reload", "help");
        return List.of();
    }
}
