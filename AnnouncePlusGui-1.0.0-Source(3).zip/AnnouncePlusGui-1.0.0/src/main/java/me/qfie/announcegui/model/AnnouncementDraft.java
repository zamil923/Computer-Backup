package me.qfie.announcegui.model;

public final class AnnouncementDraft {
    private String title;
    private String subtitle;
    private String colour;
    private int fadeIn;
    private int stay;
    private int fadeOut;
    private String sound;
    private float volume;
    private float pitch;

    public AnnouncementDraft(String title, String subtitle, String colour,
                              int fadeIn, int stay, int fadeOut,
                              String sound, float volume, float pitch) {
        this.title = title;
        this.subtitle = subtitle;
        this.colour = colour;
        this.fadeIn = fadeIn;
        this.stay = stay;
        this.fadeOut = fadeOut;
        this.sound = sound;
        this.volume = volume;
        this.pitch = pitch;
    }

    public AnnouncementDraft copy() {
        return new AnnouncementDraft(title, subtitle, colour, fadeIn, stay, fadeOut, sound, volume, pitch);
    }

    public String title() { return title; }
    public String subtitle() { return subtitle; }
    public String colour() { return colour; }
    public int fadeIn() { return fadeIn; }
    public int stay() { return stay; }
    public int fadeOut() { return fadeOut; }
    public String sound() { return sound; }
    public float volume() { return volume; }
    public float pitch() { return pitch; }

    public void title(String value) { title = value; }
    public void subtitle(String value) { subtitle = value; }
    public void colour(String value) { colour = value; }
    public void fadeIn(int value) { fadeIn = value; }
    public void stay(int value) { stay = value; }
    public void fadeOut(int value) { fadeOut = value; }
    public void sound(String value) { sound = value; }
    public void volume(float value) { volume = value; }
    public void pitch(float value) { pitch = value; }
}
