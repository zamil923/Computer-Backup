package me.qfie.announcegui.manager;

import me.qfie.announcegui.model.AnnouncementDraft;
import me.qfie.announcegui.util.MessageUtil;
import me.qfie.announcegui.util.PlaceholderUtil;
import org.bukkit.Registry;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AnnouncementManager {
    private final JavaPlugin plugin;
    private final Map<UUID, AnnouncementDraft> drafts = new ConcurrentHashMap<>();

    public AnnouncementManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public AnnouncementDraft getOrCreate(Player player) {
        return drafts.computeIfAbsent(player.getUniqueId(), id -> newDefaultDraft());
    }

    public void put(Player player, AnnouncementDraft draft) {
        drafts.put(player.getUniqueId(), draft);
    }

    public void clear(Player player) {
        drafts.remove(player.getUniqueId());
    }

    public void clear(UUID uuid) {
        drafts.remove(uuid);
    }

    public AnnouncementDraft newDefaultDraft() {
        return new AnnouncementDraft(
                plugin.getConfig().getString("announcement.default-title", "<red>Announcement</red>"),
                plugin.getConfig().getString("announcement.default-subtitle", "<gray>Message</gray>"),
                plugin.getConfig().getString("announcement.default-color", "#FFFFFF"),
                plugin.getConfig().getInt("announcement.fade-in", 1),
                plugin.getConfig().getInt("announcement.stay", 5),
                plugin.getConfig().getInt("announcement.fade-out", 2),
                plugin.getConfig().getString("sound.default", "BLOCK_NOTE_BLOCK_PLING"),
                (float) plugin.getConfig().getDouble("sound.volume", 1.0),
                (float) plugin.getConfig().getDouble("sound.pitch", 1.0)
        );
    }

    public void preview(Player player, AnnouncementDraft draft) {
        sendTitle(player, draft);
        playSound(player, draft);
    }

    public void broadcast(Player sender, AnnouncementDraft draft) {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            AnnouncementDraft perPlayer = draft.copy();
            perPlayer.title(PlaceholderUtil.apply(plugin, player, perPlayer.title()));
            perPlayer.subtitle(PlaceholderUtil.apply(plugin, player, perPlayer.subtitle()));
            sendTitle(player, perPlayer);
            playSound(player, perPlayer);
        }
    }

    private void sendTitle(Player player, AnnouncementDraft draft) {
        var title = MessageUtil.parse(draft.title());
        var subtitle = MessageUtil.parse(draft.subtitle());
        var times = net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ofSeconds(Math.max(0, draft.fadeIn())),
                java.time.Duration.ofSeconds(Math.max(0, draft.stay())),
                java.time.Duration.ofSeconds(Math.max(0, draft.fadeOut()))
        );
        player.showTitle(net.kyori.adventure.title.Title.title(title, subtitle, times));
    }

    private void playSound(Player player, AnnouncementDraft draft) {
        if (!plugin.getConfig().getBoolean("sound.enabled", true)) return;
        String raw = draft.sound();
        if (raw == null || raw.equalsIgnoreCase("NONE") || raw.isBlank()) return;

        try {
            NamespacedKey key = NamespacedKey.minecraft(raw.toLowerCase(java.util.Locale.ROOT));
            Sound sound = Registry.SOUNDS.get(key);
            if (sound == null) throw new IllegalArgumentException("Unknown sound: " + raw);
            player.playSound(player.getLocation(), sound, draft.volume(), draft.pitch());
        } catch (IllegalArgumentException ignored) {
            plugin.getLogger().warning("Invalid sound '" + raw + "'; skipping it.");
        }
    }
}
