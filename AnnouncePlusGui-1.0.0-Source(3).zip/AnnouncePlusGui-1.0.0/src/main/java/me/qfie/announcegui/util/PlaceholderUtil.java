package me.qfie.announcegui.util;

import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class PlaceholderUtil {
    private PlaceholderUtil() {}

    public static String apply(Plugin plugin, Player player, String text) {
        if (text == null || text.isEmpty()) return "";
        if (plugin.getServer().getPluginManager().getPlugin("PlaceholderAPI") == null) {
            return text;
        }
        try {
            Class<?> papi = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
            return (String) papi.getMethod("setPlaceholders", Player.class, String.class)
                    .invoke(null, player, text);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return text;
        }
    }
}
