package me.qfie.announcegui.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

public final class MessageUtil {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private MessageUtil() {}

    public static Component parse(String input) {
        if (input == null || input.isBlank()) {
            return Component.empty();
        }
        try {
            return MM.deserialize(input);
        } catch (RuntimeException ignored) {
            // Fall back to literal text so malformed MiniMessage cannot break the plugin.
            return Component.text(input);
        }
    }
}
