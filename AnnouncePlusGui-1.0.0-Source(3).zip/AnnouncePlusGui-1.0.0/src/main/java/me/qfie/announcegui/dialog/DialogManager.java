package me.qfie.announcegui.dialog;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.input.SingleOptionDialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import me.qfie.announcegui.manager.AnnouncementManager;
import me.qfie.announcegui.model.AnnouncementDraft;
import me.qfie.announcegui.util.ColorUtil;
import me.qfie.announcegui.util.MessageUtil;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Creates and handles the native Minecraft Dialog editor.
 *
 * This intentionally uses Paper's supported Dialog API only; there is no
 * inventory GUI and no NMS code.
 */
public final class DialogManager {
    private static final String KEY_TITLE = "title";
    private static final String KEY_SUBTITLE = "subtitle";
    private static final String KEY_COLOR = "color";
    private static final String KEY_HEX = "hex";
    private static final String KEY_FADE_IN = "fade_in";
    private static final String KEY_STAY = "stay";
    private static final String KEY_FADE_OUT = "fade_out";
    private static final String KEY_SOUND = "sound";
    private static final String KEY_VOLUME = "volume";
    private static final String KEY_PITCH = "pitch";

    private final JavaPlugin plugin;
    private final AnnouncementManager announcements;

    public DialogManager(JavaPlugin plugin, AnnouncementManager announcements) {
        this.plugin = plugin;
        this.announcements = announcements;
    }

    public void open(Player player) {
        showEditor(player, announcements.getOrCreate(player));
    }

    private void showEditor(Player player, AnnouncementDraft draft) {
        player.showDialog(createEditorDialog(draft));
    }

    private Dialog createEditorDialog(AnnouncementDraft draft) {
        int width = Math.max(1, Math.min(1024, plugin.getConfig().getInt("dialog.input-width", 320)));
        List<DialogInput> inputs = new ArrayList<>();

        inputs.add(DialogInput.text(
                KEY_TITLE, width, Component.text("Title"), true,
                draft.title(), positiveMax("dialog.max-title-length", 256), null));

        inputs.add(DialogInput.text(
                KEY_SUBTITLE, width, Component.text("Subtitle"), true,
                draft.subtitle(), positiveMax("dialog.max-subtitle-length", 512), null));

        inputs.add(createColourInput(width, draft));

        // Always visible so the staff member can enter a custom value without
        // requiring another dialog round-trip. It is only used when CUSTOM_HEX is selected.
        inputs.add(DialogInput.text(
                KEY_HEX, width, Component.text("Custom HEX (e.g. #A303F9)"), true,
                ColorUtil.isValidHex(draft.colour()) ? ColorUtil.normalize(draft.colour()) : "#FFFFFF",
                positiveMax("dialog.max-hex-length", 7), null));

        inputs.add(createTimingInput(KEY_FADE_IN, "Fade In", draft.fadeIn(), width));
        inputs.add(createTimingInput(KEY_STAY, "Stay", draft.stay(), width));
        inputs.add(createTimingInput(KEY_FADE_OUT, "Fade Out", draft.fadeOut(), width));
        inputs.add(createSoundInput(draft.sound(), width));

        inputs.add(DialogInput.text(KEY_VOLUME, width, Component.text("Sound Volume"), true,
                Float.toString(draft.volume()), 8, null));
        inputs.add(DialogInput.text(KEY_PITCH, width, Component.text("Sound Pitch"), true,
                Float.toString(draft.pitch()), 8, null));

        List<ActionButton> actions = List.of(
                actionButton("Preview", this::handlePreview),
                actionButton("Send", this::handleSend),
                actionButton("Cancel", this::handleCancel)
        );

        DialogBase base = DialogBase.builder(
                        MessageUtil.parse(plugin.getConfig().getString("dialog.title", "Announce+Gui")))
                .externalTitle(MessageUtil.parse(plugin.getConfig().getString("dialog.title", "Announce+Gui")))
                .canCloseWithEscape(true)
                .pause(false)
                .afterAction(DialogBase.DialogAfterAction.WAIT_FOR_RESPONSE)
                .body(List.of(DialogBody.plainMessage(
                        MessageUtil.parse(plugin.getConfig().getString(
                                "dialog.description", "Create a server announcement")))))
                .inputs(inputs)
                .build();

        return Dialog.create(builder -> builder.empty()
                .base(base)
                .type(DialogType.multiAction(actions, null, 3)));
    }

    private DialogInput createColourInput(int width, AnnouncementDraft draft) {
        List<SingleOptionDialogInput.OptionEntry> entries = new ArrayList<>();
        var section = plugin.getConfig().getConfigurationSection("colours");
        String selectedPreset = presetForValue(section, draft.colour());

        if (section != null) {
            for (Map.Entry<String, Object> entry : section.getValues(false).entrySet()) {
                String id = entry.getKey();
                entries.add(SingleOptionDialogInput.OptionEntry.create(
                        id,
                        Component.text(id.toUpperCase(Locale.ROOT)),
                        id.equalsIgnoreCase(selectedPreset)));
            }
        }

        entries.add(SingleOptionDialogInput.OptionEntry.create(
                "CUSTOM_HEX", Component.text("CUSTOM HEX"), selectedPreset == null));

        if (entries.stream().noneMatch(SingleOptionDialogInput.OptionEntry::initial)) {
            // A valid dialog input must have one selected option.
            entries.set(0, SingleOptionDialogInput.OptionEntry.create(
                    entries.get(0).id(), entries.get(0).display(), true));
        }

        return DialogInput.singleOption(KEY_COLOR, width, entries, Component.text("Colour"), true);
    }

    private DialogInput createTimingInput(String key, String label, int selected, int width) {
        List<SingleOptionDialogInput.OptionEntry> entries = new ArrayList<>();
        List<Integer> values = plugin.getConfig().getIntegerList("timing-options");
        if (values.isEmpty()) values = List.of(1, 2, 3, 5, 10, 15, 30);

        boolean selectedFound = false;
        for (int value : values) {
            boolean initial = value == selected && !selectedFound;
            if (initial) selectedFound = true;
            entries.add(SingleOptionDialogInput.OptionEntry.create(
                    Integer.toString(value),
                    Component.text(value + " second" + (value == 1 ? "" : "s")),
                    initial));
        }
        if (!selectedFound) {
            entries.set(0, SingleOptionDialogInput.OptionEntry.create(
                    entries.get(0).id(), entries.get(0).display(), true));
        }
        return DialogInput.singleOption(key, width, entries, Component.text(label), true);
    }

    private DialogInput createSoundInput(String selected, int width) {
        List<SingleOptionDialogInput.OptionEntry> entries = new ArrayList<>();
        List<String> values = plugin.getConfig().getStringList("sound-options");
        if (values.isEmpty()) values = List.of(
                "NONE", "BLOCK_NOTE_BLOCK_PLING", "ENTITY_EXPERIENCE_ORB_PICKUP",
                "ENTITY_PLAYER_LEVELUP", "UI_BUTTON_CLICK");

        boolean selectedFound = false;
        for (String value : values) {
            boolean initial = value.equalsIgnoreCase(selected) && !selectedFound;
            if (initial) selectedFound = true;
            entries.add(SingleOptionDialogInput.OptionEntry.create(
                    value, Component.text(value), initial));
        }
        if (!selectedFound) {
            entries.set(0, SingleOptionDialogInput.OptionEntry.create(
                    entries.get(0).id(), entries.get(0).display(), true));
        }
        return DialogInput.singleOption(KEY_SOUND, width, entries, Component.text("Sound"), true);
    }

    private ActionButton actionButton(String label, java.util.function.BiConsumer<Player, DialogResponseView> handler) {
        ClickCallback.Options options = ClickCallback.Options.builder()
                .uses(1)
                .lifetime(Duration.ofMinutes(5))
                .build();

        return ActionButton.builder(Component.text(label))
                .width(120)
                .action(io.papermc.paper.registry.data.dialog.action.DialogAction.customClick(
                        (response, audience) -> {
                            if (audience instanceof Player player) {
                                handler.accept(player, response);
                            }
                        }, options))
                .build();
    }

    private void handlePreview(Player player, DialogResponseView response) {
        AnnouncementDraft draft = readDraft(player, response);
        if (draft == null) {
            showEditor(player, announcements.getOrCreate(player));
            return;
        }
        announcements.put(player, draft);
        announcements.preview(player, draft);
        showEditor(player, draft);
    }

    private void handleSend(Player player, DialogResponseView response) {
        AnnouncementDraft draft = readDraft(player, response);
        if (draft == null) {
            showEditor(player, announcements.getOrCreate(player));
            return;
        }
        announcements.broadcast(player, draft);
        announcements.clear(player);
        player.closeDialog();
        player.sendMessage(MessageUtil.parse(plugin.getConfig().getString(
                "messages.sent", "<green>Announcement sent successfully.</green>")));
    }

    private void handleCancel(Player player, DialogResponseView response) {
        announcements.clear(player);
        player.closeDialog();
        player.sendMessage(MessageUtil.parse(plugin.getConfig().getString(
                "messages.cancelled", "<gray>Announcement cancelled.</gray>")));
    }

    private AnnouncementDraft readDraft(Player player, DialogResponseView response) {
        try {
            String title = required(response.getText(KEY_TITLE));
            String subtitle = required(response.getText(KEY_SUBTITLE));
            String selectedColour = required(response.getText(KEY_COLOR));
            String hex = response.getText(KEY_HEX);

            String colour;
            if (selectedColour.equalsIgnoreCase("CUSTOM_HEX")) {
                if (!ColorUtil.isValidHex(hex)) {
                    player.sendMessage(MessageUtil.parse(plugin.getConfig().getString(
                            "messages.invalid-color", "<red>Invalid HEX colour.</red>")));
                    return null;
                }
                colour = ColorUtil.normalize(hex);
            } else {
                String configured = plugin.getConfig().getString("colours." + selectedColour);
                colour = ColorUtil.isValidHex(configured) ? ColorUtil.normalize(configured)
                        : plugin.getConfig().getString("announcement.default-color", "#FFFFFF");
                if (!ColorUtil.isValidHex(colour)) colour = "#FFFFFF";
            }

            int fadeIn = Integer.parseInt(required(response.getText(KEY_FADE_IN)));
            int stay = Integer.parseInt(required(response.getText(KEY_STAY)));
            int fadeOut = Integer.parseInt(required(response.getText(KEY_FADE_OUT)));
            float volume = Float.parseFloat(required(response.getText(KEY_VOLUME)));
            float pitch = Float.parseFloat(required(response.getText(KEY_PITCH)));

            if (fadeIn < 0 || stay < 0 || fadeOut < 0 || volume < 0 || pitch < 0) {
                throw new NumberFormatException("negative values");
            }
            if (volume > 10.0f || pitch > 10.0f) {
                throw new NumberFormatException("sound value out of range");
            }

            return new AnnouncementDraft(title, subtitle, colour,
                    fadeIn, stay, fadeOut,
                    required(response.getText(KEY_SOUND)), volume, pitch);
        } catch (RuntimeException ex) {
            player.sendMessage(MessageUtil.parse(plugin.getConfig().getString(
                    "messages.invalid-input", "<red>Invalid announcement input.</red>")));
            return null;
        }
    }

    private String required(String value) {
        if (value == null) throw new IllegalArgumentException("missing dialog input");
        return value;
    }

    private String presetForValue(org.bukkit.configuration.ConfigurationSection section, String value) {
        if (section == null || value == null) return null;
        for (String key : section.getKeys(false)) {
            String configured = section.getString(key);
            if (configured != null && configured.equalsIgnoreCase(value)) return key;
        }
        return null;
    }

    private int positiveMax(String path, int fallback) {
        return Math.max(1, plugin.getConfig().getInt(path, fallback));
    }
}
