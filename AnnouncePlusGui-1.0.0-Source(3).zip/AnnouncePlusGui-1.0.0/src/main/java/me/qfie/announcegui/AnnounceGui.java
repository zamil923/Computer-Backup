package me.qfie.announcegui;

import me.qfie.announcegui.command.AnnounceCommand;
import me.qfie.announcegui.dialog.DialogManager;
import me.qfie.announcegui.listener.PlayerListener;
import me.qfie.announcegui.manager.AnnouncementManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class AnnounceGui extends JavaPlugin {
    private AnnouncementManager announcementManager;
    private DialogManager dialogManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        announcementManager = new AnnouncementManager(this);
        dialogManager = new DialogManager(this, announcementManager);

        var command = getCommand("announce");
        if (command == null) {
            getLogger().severe("Command 'announce' is missing from plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        AnnounceCommand executor = new AnnounceCommand(this, dialogManager);
        command.setExecutor(executor);
        command.setTabCompleter(executor);

        getServer().getPluginManager().registerEvents(
                new PlayerListener(announcementManager), this);

        getLogger().info("Announce+Gui 1.0.0 enabled.");
    }
}
