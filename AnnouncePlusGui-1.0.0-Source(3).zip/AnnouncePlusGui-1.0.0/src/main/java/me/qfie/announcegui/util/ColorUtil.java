package me.qfie.announcegui.util;

import java.util.regex.Pattern;

public final class ColorUtil {
    private static final Pattern HEX = Pattern.compile("^#[0-9A-Fa-f]{6}$");

    private ColorUtil() {}

    public static boolean isValidHex(String value) {
        return value != null && HEX.matcher(value.trim()).matches();
    }

    public static String normalize(String value) {
        return value == null ? "#FFFFFF" : value.trim().toUpperCase(java.util.Locale.ROOT);
    }
}
